using FastEndpoints;
using FastEndpoints.Swagger;
using Microsoft.AspNetCore.Diagnostics;
using NSwag;
using Serilog;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure;
using SHT.MerchantPortal.Modules.EntityManagement.Infrastructure;
using SHT.MerchantPortal.Modules.Fortuna.Api;
using SHT.MerchantPortal.Modules.Reconciliation.Infrastructure;
using SHT.MerchantPortal.Modules.TransactionManagement.Infrastructure;
using SHT.MerchantPortal.Modules.Core.Infrastructure;

using SHT.MerchantPortal.Shared.Kernel.Common;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Reflection;
using System.Text.Json;
using SHT.MerchantPortal.Modules.Fortuna.Infrastructure.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Cấu hình Serilog
builder.Host.UseSerilog((context, configuration) =>
    configuration.ReadFrom.Configuration(context.Configuration));

// Đăng ký FastEndpoints và chỉ định các Assembly chứa Endpoint
builder.Services.AddFastEndpoints(options =>
{
    options.Assemblies =
    [
        Assembly.Load("SHT.MerchantPortal.Modules.Core.Api"),
        Assembly.Load("SHT.MerchantPortal.Modules.Authentication.Api"),
        Assembly.Load("SHT.MerchantPortal.Modules.Reconciliation.Api"),
        Assembly.Load("SHT.MerchantPortal.Modules.TransactionManagement.Api"),
        Assembly.Load("SHT.MerchantPortal.Modules.Fortuna.Api"),
        Assembly.Load("SHT.MerchantPortal.Modules.EntityManagement.Api")
    ];
    // Thêm logging để debug
    options.IncludeAbstractValidators = true;
    
    
});

builder.Services.SwaggerDocument(options =>
{
    options.ShortSchemaNames = true;
    options.MaxEndpointVersion = 1;
    options.MinEndpointVersion = 0;
    options.DocumentSettings = s =>
    {
        s.Title = "MerchantPortal API";
        s.Version = "v1";
        s.AddAuth("Bearer", new()
        {
            Type = OpenApiSecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT"
        });
        s.PostProcess = document =>
        {
            foreach (var path in document.Paths)
            {
                foreach (var operation in path.Value.Values)
                {
                    if (string.IsNullOrEmpty(operation.OperationId)) continue;
                    var shortName = operation.OperationId.Split('.').Last()
                        .Replace("Endpoint", "");
                    operation.OperationId = shortName;
                }
            }
        };
    };
});


// Register Infrastructure
builder.Services.AddCoreServices(builder.Configuration);
builder.Services.AddCoreModule(builder.Configuration);
builder.Services.AddAuthenticationModule(builder.Configuration);
builder.Services.AddReconciliationModule(builder.Configuration);
builder.Services.AddEntityManagementModule(builder.Configuration);
builder.Services.AddTransactionModule(builder.Configuration);
builder.Services.AddFortunaModule(builder.Configuration);

var app = builder.Build();
app.UseExceptionHandler(appError =>
{
    appError.Run(async context =>
    {
        var logger = context.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger("GlobalExceptionHandler");

        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

        var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
        if (contextFeature != null)
        {
            object response;

            switch (contextFeature.Error)
            {
                case FluentValidation.ValidationException validationEx:
                    context.Response.StatusCode = StatusCodes.Status400BadRequest;
                    response = new
                    {
                        statusCode = context.Response.StatusCode,
                        isSuccess = false,
                        message = "VALIDATION_FAILED",
                        errors = validationEx.Errors.Select(e => new
                        {
                            field = e.PropertyName,
                            error = e.ErrorMessage
                        })
                    };
                    break;

                case ConflictException conflictEx:
                    context.Response.StatusCode = StatusCodes.Status409Conflict;
                    response = new
                    {
                        statusCode = context.Response.StatusCode,
                        isSuccess = false,
                        message = "CONFLICT",
                        errors = new[] { conflictEx.Message }
                    };
                    break;

                case NotFoundException notFoundEx:
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                    response = new
                    {
                        statusCode = context.Response.StatusCode,
                        isSuccess = false,
                        message = "NOT_FOUND",
                        errors = new[] { notFoundEx.Message }
                    };
                    break;

                default:
                    logger.LogError(contextFeature.Error, "Unhandled exception occurred.");
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    response = new
                    {
                        statusCode = context.Response.StatusCode,
                        isSuccess = false,
                        message = "SYSTEM_ERROR",
                        errors = new[] { contextFeature.Error.Message }
                    };
                    break;
            }

            if (contextFeature.Error is not ValidationException)
            {
                logger.LogError(contextFeature.Error, "An unhandled exception has occurred.");
            }

            await context.Response.WriteAsJsonAsync(response);
        }
    });
});
app.UseCors(SystemConstants.MerchantCorsPolicy);

// Middleware ghi log thông tin user (tùy chọn)
app.Use(async (context, next) =>
{
    var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();
    if (context.User.Identity?.IsAuthenticated == true)
    {
        logger.LogInformation("User authenticated as: {Name}", context.User.Identity.Name);
        foreach (var claim in context.User.Claims)
        {
            logger.LogInformation("Claim: {Type} = {Value}", claim.Type, claim.Value);
        }
    }
    await next();
});

// Sắp xếp lại thứ tự: Authentication và Authorization phải nằm TRƯỚC UseFastEndpoints
app.UseAuthentication();
app.UseAuthorization();

app.UseFastEndpoints(c =>
{
    c.Endpoints.RoutePrefix = "api";
    c.Versioning.Prefix = "v";
    c.Versioning.DefaultVersion = 1;
    c.Endpoints.ShortNames = true;
    c.Versioning.PrependToRoute = true;
    c.Serializer.Options.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
})
.UseSwaggerGen(); // Chained call để tạo document cho Swagger

// Cấu hình UI của Swagger
if (app.Environment.IsDevelopment())
{
    app.UseOpenApi();
    app.UseSwaggerUi();
}

app.Run();


