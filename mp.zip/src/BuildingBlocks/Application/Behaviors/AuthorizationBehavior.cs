using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;

public class AuthorizationBehavior<TRequest, TResponse>(IServiceProvider serviceProvider)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IAuthorizableRequest // Chỉ áp dụng cho các request được đánh dấu
{
    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        var handlerType = typeof(IAuthorizationHandler<>).MakeGenericType(request.GetType());
        
        // 2. Dùng DI container để tìm handler tương ứng
        var handler = serviceProvider.GetService(handlerType);

        if (handler is null) return await next(cancellationToken);
        // 3. Gọi phương thức AuthorizeAsync một cách linh hoạt
        var authorizeMethod = handlerType.GetMethod(nameof(IAuthorizationHandler<TRequest>.AuthorizeAsync));
        var hasAccessTask = (Task<bool>?)authorizeMethod?.Invoke(handler, [request]);

        if (hasAccessTask is not null && !await hasAccessTask)
        {
            throw new Exception("Bạn không có quyền thực hiện hành động này.");
        }

        return await next(cancellationToken);
    }
}