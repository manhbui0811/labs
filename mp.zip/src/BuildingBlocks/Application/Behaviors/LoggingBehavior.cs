using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using System.Diagnostics;
using System.Text.Json;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;

/// <summary>
/// Behavior for logging MediatR requests and responses
/// </summary>
/// <typeparam name="TRequest">The request type</typeparam>
/// <typeparam name="TResponse">The response type</typeparam>
public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _logger;

    public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger)
    {
        _logger = logger;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        var requestName = typeof(TRequest).Name;
        var requestId = Guid.NewGuid().ToString();

        using (LogContext.PushProperty("RequestId", requestId))
        using (LogContext.PushProperty("RequestName", requestName))
        {
            _logger.LogInformation(
                "Handling {RequestName} with ID {RequestId}. Request: {@Request}",
                requestName,
                requestId,
                SanitizeRequest(request));

            var stopwatch = Stopwatch.StartNew();

            try
            {
                var response = await next();

                stopwatch.Stop();

                _logger.LogInformation(
                    "Completed {RequestName} with ID {RequestId} in {ElapsedMs}ms. Response: {@Response}",
                    requestName,
                    requestId,
                    stopwatch.ElapsedMilliseconds,
                    SanitizeResponse(response));

                return response;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();

                _logger.LogError(ex,
                    "Failed {RequestName} with ID {RequestId} in {ElapsedMs}ms",
                    requestName,
                    requestId,
                    stopwatch.ElapsedMilliseconds);

                throw;
            }
        }
    }

    private static object SanitizeRequest(TRequest request)
    {
        // For sensitive data, we should remove or mask certain properties
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };

        var json = JsonSerializer.Serialize(request, options);
        var sanitized = json.Replace("\"password\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase)
                           .Replace("\"token\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase);

        return JsonSerializer.Deserialize<object>(sanitized);
    }

    private static object? SanitizeResponse(TResponse response)
    {
        if (response == null) return null;

        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };

        var json = JsonSerializer.Serialize(response, options);
        var sanitized = json.Replace("\"password\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase)
                           .Replace("\"token\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase);

        return JsonSerializer.Deserialize<object>(sanitized);
    }
}


