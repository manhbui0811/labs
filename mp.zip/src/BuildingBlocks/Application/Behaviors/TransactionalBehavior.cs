﻿using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands; // Chứa ITransactionalCommand
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence; // Chứa IUnitOfWork

namespace SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;

public class TransactionalBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<TransactionalBehavior<TRequest, TResponse>> _logger;

    public TransactionalBehavior(
        IUnitOfWork unitOfWork,
        ILogger<TransactionalBehavior<TRequest, TResponse>> logger)
    {
        // Inject IUnitOfWork, không còn phụ thuộc vào TransactionScope
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        // Sử dụng marker interface ITransactionalCommand để kích hoạt
        // Đây là cách làm rõ ràng và an toàn nhất
        var isTransactional = request is ITransactionalCommand ||
                      request.GetType().GetInterfaces()
                             .Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(ITransactionalCommand<>));

        if (!isTransactional)
        {
            return await next();
        }

        var requestName = typeof(TRequest).Name;
        TResponse response;

        try
        {
            // Bắt đầu transaction bằng IUnitOfWork
            await _unitOfWork.BeginTransactionAsync(cancellationToken);
            _logger.LogInformation("--- Begin transaction for {RequestName}", requestName);

            response = await next();

            // Commit transaction bằng IUnitOfWork
            await _unitOfWork.CommitTransactionAsync(cancellationToken);
            _logger.LogInformation("--- Commit transaction for {RequestName}", requestName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "--- Rollback transaction for {RequestName}", requestName);

            // Rollback transaction bằng IUnitOfWork
            await _unitOfWork.RollbackTransactionAsync(cancellationToken);

            throw; // Ném lại lỗi để các behavior khác hoặc global exception handler xử lý
        }

        return response;
    }
}