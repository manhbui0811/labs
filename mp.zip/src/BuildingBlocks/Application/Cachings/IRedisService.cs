﻿namespace SHT.MerchantPortal.BuildingBlocks.Application.Cachings
{
    public interface IRedisService
    {
        Task<string?> GetAsync(string key);

        Task<T?> GetAsync<T>(string key);

        Task SetAsync(string key, string value, TimeSpan? expiry = null);
        
        Task SetAsync<T>(string key, T value, TimeSpan? expiry = null);

        Task RemoveAsync(string key);
    }
}
