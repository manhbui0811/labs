using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;

namespace SHT.MerchantPortal.BuildingBlocks.Application.CircuitBreaker;

public interface ICircuitBreakerService
{
    Task<Result<T>> ExecuteAsync<T>(
        string serviceName,
        Func<Task<T>> operation,
        Func<Task<T>>? fallback = null,
        CancellationToken cancellationToken = default);

    Task<Result> ExecuteAsync(
        string serviceName,
        Func<Task> operation,
        Func<Task>? fallback = null,
        CancellationToken cancellationToken = default);

    Task<Result<CircuitBreakerState>> GetStateAsync(string serviceName, CancellationToken cancellationToken = default);

    Task<Result> ResetAsync(string serviceName, CancellationToken cancellationToken = default);
}


