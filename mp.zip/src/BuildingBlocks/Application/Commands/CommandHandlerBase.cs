using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands;

/// <summary>
/// Base class for command handlers that don't return a value
/// </summary>
/// <typeparam name="TCommand">The command type</typeparam>
public abstract class CommandHandlerBase<TCommand> : IRequestHandler<TCommand>
    where TCommand : class, ICommand
{
    protected readonly ILogger<CommandHandlerBase<TCommand>> Logger;
    protected readonly ICurrentUser CurrentUser;

    protected CommandHandlerBase(
        ILogger<CommandHandlerBase<TCommand>> logger,
        ICurrentUser currentUser)
    {
        Logger = logger;
        CurrentUser = currentUser;
    }

    public abstract Task Handle(TCommand request, CancellationToken cancellationToken);
}

/// <summary>
/// Base class for command handlers that return a value
/// </summary>
/// <typeparam name="TCommand">The command type</typeparam>
/// <typeparam name="TResponse">The response type</typeparam>
public abstract class CommandHandlerBase<TCommand, TResponse> : IRequestHandler<TCommand, TResponse>
    where TCommand : class, ICommand<TResponse>
{
    protected readonly ILogger<CommandHandlerBase<TCommand, TResponse>> Logger;
    protected readonly ICurrentUser CurrentUser;

    protected CommandHandlerBase(
        ILogger<CommandHandlerBase<TCommand, TResponse>> logger,
        ICurrentUser currentUser)
    {
        Logger = logger;
        CurrentUser = currentUser;
    }

    public abstract Task<TResponse> Handle(TCommand request, CancellationToken cancellationToken);
}


