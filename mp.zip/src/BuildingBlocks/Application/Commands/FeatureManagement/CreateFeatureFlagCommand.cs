using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands.FeatureManagement;

public class CreateFeatureFlagCommand : ITransactionalCommand<FeatureFlagDto>
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsEnabled { get; set; } = false;
    public DateTimeOffset? ExpiresAt { get; set; }
    public Dictionary<string, string>? Settings { get; set; }
}


