using SHT.MerchantPortal.BuildingBlocks.Application.Commands;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands.FeatureManagement;

public class UpdateFeatureFlagCommand : ITransactionalCommand
{
    public Guid Id { get; set; }
    public string? Description { get; set; }
    public bool? IsEnabled { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public Dictionary<string, string>? Settings { get; set; }
}


