using MediatR;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands;

/// <summary>
/// Marker interface for commands that don't return a value
/// </summary>
public interface ICommand : IRequest
{
}

/// <summary>
/// Marker interface for commands that return a value of type TResponse
/// </summary>
/// <typeparam name="TResponse">The return type</typeparam>
public interface ICommand<out TResponse> : IRequest<TResponse>
{
}

/// <summary>
/// Marker interface for transactional commands
/// Commands implementing this interface will be wrapped in a database transaction
/// </summary>
public interface ITransactional
{
}


public interface ITransactionalCommand : ICommand, ITransactional
{
}

/// <summary>
/// Marker interface for transactional commands that return a value
/// </summary>
/// <typeparam name="TResponse">The return type</typeparam>
public interface ITransactionalCommand<out TResponse> : ICommand<TResponse>, ITransactional
{
}


