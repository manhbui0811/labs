using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Responses;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands.Security;

public class CreateApiKeyCommand : ITransactionalCommand<CreateApiKeyResponse>
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? EntityId { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public string? Scopes { get; set; }
}


