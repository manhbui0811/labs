using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Security;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Commands.Security;

public class CreateEncryptionKeyCommand : ITransactionalCommand<EncryptionKeyDto>
{
    public string KeyIdentifier { get; set; } = string.Empty;
    public EncryptionType KeyType { get; set; }
    public KeyCategory KeyCategory { get; set; }
    public OwnerType OwnerType { get; set; }
    public Guid? OwnerId { get; set; }
    public string Algorithm { get; set; } = string.Empty;
    public DateTimeOffset? ExpiresAt { get; set; }
}


