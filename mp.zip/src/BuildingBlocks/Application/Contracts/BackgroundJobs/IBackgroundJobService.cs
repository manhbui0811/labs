using Quartz;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.BackgroundJobs;

public interface IBackgroundJobService
{
    Task ScheduleJobAsync<T>(string jobName, string cronExpression, object? parameters = null, CancellationToken cancellationToken = default) where T : IJob;
    Task TriggerJobAsync(string jobName, object? parameters = null, CancellationToken cancellationToken = default);
    Task<bool> DeleteJobAsync(string jobName, CancellationToken cancellationToken = default);
    Task<JobExecutionStatus> GetJobStatusAsync(string jobName, CancellationToken cancellationToken = default);
}

public class JobExecutionStatus
{
    public string JobName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime? LastExecution { get; set; }
    public DateTime? NextExecution { get; set; }
}


