using SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;
using SHT.MerchantPortal.Shared.Kernel.Events;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.EventBus;

public interface IEventBusService
{
    Task PublishAsync<T>(T @event, CancellationToken cancellationToken = default) where T : class, IIntegrationEvent;
    Task SendAsync<T>(T command, CancellationToken cancellationToken = default) where T : class, IIntegrationCommand;
}


