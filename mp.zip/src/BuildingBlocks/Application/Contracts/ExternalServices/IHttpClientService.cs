namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.ExternalServices;

public interface IHttpClientService
{
    Task<T?> GetAsync<T>(string endpoint, CancellationToken cancellationToken = default) where T : class;
    Task<TResponse?> PostAsync<TRequest, TResponse>(string endpoint, TRequest request, CancellationToken cancellationToken = default) where TRequest : class where TResponse : class;
    Task<TResponse?> PutAsync<TRequest, TResponse>(string endpoint, TRequest request, CancellationToken cancellationToken = default) where TRequest : class where TResponse : class;
    Task<bool> DeleteAsync(string endpoint, CancellationToken cancellationToken = default);
}


