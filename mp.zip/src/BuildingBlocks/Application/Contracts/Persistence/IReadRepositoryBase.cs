﻿using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using System.Linq.Expressions;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;

/// <summary>
/// Interface cơ sở cho các thao tác chỉ đọc (Query).
/// </summary>
public interface IReadRepositoryBase<TEntity, TId> where TEntity : EntityBase<TId> where TId : notnull // <-- Sửa Entity thành EntityBase
{
    Task<TEntity?> GetByIdAsync(TId id, CancellationToken cancellationToken = default);

    Task<TEntity?> FindAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<TEntity>> FindAllAsync(Expression<Func<TEntity, bool>>? predicate = null, CancellationToken cancellationToken = default);

    Task<PagedResult<TEntity>> GetPagedAsync(
        int page,
        int pageSize,
        Expression<Func<TEntity, bool>>? predicate = null,
        Expression<Func<TEntity, object>>? orderBy = null,
        bool ascending = true,
        CancellationToken cancellationToken = default);

    Task<bool> ExistsAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken cancellationToken = default);

    Task<int> CountAsync(Expression<Func<TEntity, bool>>? predicate = null, CancellationToken cancellationToken = default);
}

/// <summary>
/// Interface cơ sở cho thao tác chỉ đọc với khóa chính kiểu int.
/// </summary>
public interface IReadRepositoryBase<TEntity> : IReadRepositoryBase<TEntity, Guid> where TEntity : EntityBase<Guid>
{
}