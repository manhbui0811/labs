﻿using SHT.MerchantPortal.Shared.Kernel.Common; 

namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;

/// <summary>
/// Interface cơ sở cho các thao tác đầy đủ (Read/Write), kế thừa từ IReadRepositoryBase.
/// </summary>
public interface IRepositoryBase<TEntity, TId> : IReadRepositoryBase<TEntity, TId> where TEntity : EntityBase<TId> where TId : notnull // <-- Sửa Entity thành EntityBase
{
    Task<TEntity> AddAsync(TEntity entity, CancellationToken cancellationToken = default);

    Task AddRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default);

    Task UpdateAsync(TEntity entity, CancellationToken cancellationToken = default);

    Task UpdateRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default);

    Task DeleteAsync(TEntity entity, CancellationToken cancellationToken = default);

    Task DeleteRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default);

    Task HardDeleteAsync(TEntity entity, CancellationToken cancellationToken = default);

    Task HardDeleteRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default);

    IQueryable<TEntity> GetQueryable();
}

/// <summary>
/// Interface cơ sở đầy đủ với khóa chính kiểu int.
/// </summary>
public interface IRepositoryBase<TEntity> : IRepositoryBase<TEntity, Guid> where TEntity : EntityBase<Guid> 
{
}