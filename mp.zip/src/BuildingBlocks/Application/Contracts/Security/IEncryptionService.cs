﻿namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security
{
    public interface IEncryptionService
    {
        Task<byte[]> EncryptAsync(byte[] plaintext, string keyIdentifier, CancellationToken cancellationToken = default);
        Task<byte[]> DecryptAsync(byte[] ciphertext, string keyIdentifier, CancellationToken cancellationToken = default);
        Task<string> EncryptAsync(string plaintext, string keyIdentifier, CancellationToken cancellationToken = default);
        Task<string> DecryptAsync(string ciphertext, string keyIdentifier, CancellationToken cancellationToken = default);

        // --- Optimized Methods ---
        Task<byte[]> GetEncryptionKeyMaterialAsync(string keyIdentifier, CancellationToken cancellationToken = default);
        Task<byte[]> EncryptAsync(byte[] plaintext, byte[] keyMaterial, CancellationToken cancellationToken = default); // keyIdentifier is implicit or stored with keyMaterial if needed for context
        Task<byte[]> DecryptAsync(byte[] ciphertext, byte[] keyMaterial, CancellationToken cancellationToken = default);
        Task<string> EncryptAsync(string plaintext, byte[] keyMaterial, CancellationToken cancellationToken = default);
        Task<string> DecryptAsync(string ciphertext, byte[] keyMaterial, CancellationToken cancellationToken = default);
        // --- End Optimized Methods ---

        Task<string> HashAsync(string data, CancellationToken cancellationToken = default);
        Task<bool> VerifyHashAsync(string data, string hash, CancellationToken cancellationToken = default);

        Task<(string encryptedData, string iv, string authTag)> EncryptTrack2DataAsync(
            string track2Data,
            string keyIdentifier, // Or pre-fetched keyMaterial
            CancellationToken cancellationToken = default);

        Task<string> DecryptTrack2DataAsync(
            string encryptedData,
            string iv,
            string authTag,
            string keyIdentifier, // Or pre-fetched keyMaterial
            CancellationToken cancellationToken = default);
    }



}
