﻿namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security
{
    public interface IKeyProtector
    {
        Task<byte[]> GetKeyMaterialAsync(string alias, CancellationToken cancellationToken = default);
    }
}
