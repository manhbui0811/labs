namespace SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;

public interface ICurrentUserService
{
    Guid? UserId { get; }
    string? Email { get; }
    string? FullName { get; }
    string? KeycloakSubject { get; }
    Guid? EntityId { get; }
    string? IpAddress { get; }
    string? UserAgent { get; }
    bool IsAuthenticated { get; }
    bool HasPermission(string permission);
    IEnumerable<string> GetPermissions();
    IEnumerable<string> GetRoles();
}


