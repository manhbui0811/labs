using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using System.Linq.Expressions;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Extensions;

/// <summary>
/// Extension methods for IQueryable to support paging and sorting
/// </summary>
public static class QueryExtensions
{
    /// <summary>
    /// Apply paging to a queryable
    /// </summary>
    public static IQueryable<T> ApplyPaging<T>(this IQueryable<T> query, PagingRequest request)
    {
        return query.Skip(request.Skip).Take(request.Take);
    }

    /// <summary>
    /// Apply sorting to a queryable
    /// </summary>
    public static IQueryable<T> ApplySorting<T>(this IQueryable<T> query, string? sortBy, SortDirection direction)
    {
        if (string.IsNullOrWhiteSpace(sortBy))
        {
            return query;
        }

        var parameter = Expression.Parameter(typeof(T), "x");
        var property = GetProperty(typeof(T), sortBy);
        
        if (property == null)
        {
            return query;
        }

        var propertyAccess = Expression.MakeMemberAccess(parameter, property);
        var orderByExpression = Expression.Lambda(propertyAccess, parameter);

        var methodName = direction == SortDirection.Ascending ? "OrderBy" : "OrderByDescending";
        var method = typeof(Queryable).GetMethods()
            .Where(m => m.Name == methodName && m.GetParameters().Length == 2)
            .Single()
            .MakeGenericMethod(typeof(T), property.PropertyType);

        return (IQueryable<T>)method.Invoke(null, new object[] { query, orderByExpression })!;
    }

    /// <summary>
    /// Apply paging and sorting to a queryable
    /// </summary>
    public static IQueryable<T> ApplyPagingAndSorting<T>(this IQueryable<T> query, PagedAndSortedRequest request)
    {
        return query
            .ApplySorting(request.SortBy, request.SortDirection)
            .ApplyPaging(request);
    }

    /// <summary>
    /// Create a paged result from a queryable
    /// </summary>
    public static async Task<PagedResult<T>> ToPagedResultAsync<T>(
        this IQueryable<T> query, 
        PagingRequest request,
        CancellationToken cancellationToken = default)
    {
        var totalCount = query.Count();
        var items = query.ApplyPaging(request).ToList();

        return PagedResult<T>.Create(items, totalCount, request.PageNumber, request.PageSize);
    }

    private static System.Reflection.PropertyInfo? GetProperty(Type type, string propertyName)
    {
        var properties = propertyName.Split('.');
        var currentType = type;
        System.Reflection.PropertyInfo? property = null;

        foreach (var prop in properties)
        {
            property = currentType.GetProperty(prop, 
                System.Reflection.BindingFlags.IgnoreCase | 
                System.Reflection.BindingFlags.Public | 
                System.Reflection.BindingFlags.Instance);
            
            if (property == null)
            {
                return null;
            }

            currentType = property.PropertyType;
        }

        return property;
    }
}

// ========================================================================
// INFRASTRUCTURE PROJECT
// ========================================================================


