using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;
using System.Reflection;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Extensions;

/// <summary>
/// Extension methods for configuring application services
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Add MediatR with all behaviors configured
    /// </summary>
    public static IServiceCollection AddApplicationBehaviors(
        this IServiceCollection services,
        params Assembly[] assemblies)
    {
        // Add MediatR
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssemblies(assemblies);
        });

        // Add behaviors in order (important!)
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(PerformanceBehavior<,>));
        //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuditLoggingBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(TransactionalBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuthorizationBehavior<,>));

        return services;
    }

    /// <summary>
    /// Add FluentValidation validators from assemblies
    /// </summary>
    public static IServiceCollection AddValidators(
        this IServiceCollection services,
        params Assembly[] assemblies)
    {
        services.AddValidatorsFromAssemblies(assemblies);
        return services;
    }

    /// <summary>
    /// Add application services
    /// </summary>
    public static IServiceCollection AddApplicationServices(
        this IServiceCollection services,
        params Assembly[] assemblies)
    {
        return services
            .AddApplicationBehaviors(assemblies)
            .AddValidators(assemblies);
    }
}


