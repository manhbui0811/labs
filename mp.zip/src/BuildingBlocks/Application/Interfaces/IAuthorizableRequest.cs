namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

public interface IAuthorizableRequest
{
    
}

public interface IAuthorizationHandler<TRequest>
{
    /// <summary>
    /// Thực hiện kiểm tra quyền cho một request cụ thể.
    /// </summary>
    Task<bool> AuthorizeAsync(TRequest request);
}