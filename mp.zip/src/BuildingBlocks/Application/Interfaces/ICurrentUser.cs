namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

/// <summary>
/// Service for accessing current user information (legacy interface)
/// Note: This interface is maintained for backward compatibility.
/// New code should use ICurrentUserService instead.
/// </summary>
public interface ICurrentUser
{
    /// <summary>
    /// Gets the current user's ID
    /// </summary>
    Guid? UserId { get; }

    /// <summary>
    /// Gets the current user's email
    /// </summary>
    string? Email { get; }

    /// <summary>
    /// Gets the current user's full name
    /// </summary>
    string? FullName { get; }

    /// <summary>
    /// Gets the current user's Keycloak subject ID
    /// </summary>
    string? KeycloakSubject { get; }

    /// <summary>
    /// Gets the current user's entity ID (if applicable)
    /// </summary>
    Guid? EntityId { get; }

    /// <summary>
    /// Checks if the user is authenticated
    /// </summary>
    bool IsAuthenticated { get; }

    /// <summary>
    /// Checks if the user has the specified permission
    /// </summary>
    /// <param name="permission">The permission to check</param>
    /// <returns>True if the user has the permission</returns>
    bool HasPermission(string permission);

    /// <summary>
    /// Gets all permissions for the current user
    /// </summary>
    /// <returns>Collection of permission codes</returns>
    IEnumerable<string> GetPermissions();

    /// <summary>
    /// Gets the current user's roles
    /// </summary>
    /// <returns>Collection of role codes</returns>
    IEnumerable<string> GetRoles();
}


