﻿using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces
{
    public interface IDeviceKeyProvider
    {
        Task<byte[]?> GetPublicKeyBySerialNumberAsync(string serial);
        Task<DeviceApiKeySecret?> GetSecretByApiKeyAsync(string apiKey);

        Task UpdateLastUsedAsync(string apiKey);

        Task<DeviceProvisionedKey> ProvisionKey(Guid deviceId, CancellationToken ct = default);

        Task<DeviceProvisionedKey> RotateKey(string KeyId, CancellationToken ct = default);

        Task<DeviceRSAKey> CreateRSAKey(Guid deviceId, CancellationToken ct = default);
    }

    public class DeviceRSAKey
    {
        public string Id { get; set; } = null!;
        public string KeyIdentifier { get; set; } = null!;
        public string KeyVersion { get; set; } = null!;
        public string Algorithm { get; set; } = string.Empty;
        public EncryptionType KeyType { get; set; }
        public KeyCategory KeyCategory { get; set; }
        public OwnerType OwnerType { get; set; }
        public Guid OwnerId { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public string? PublicKeyPem { get; set; }
        public string? PrivateKeyPem { get; set; }
    }

    public class DeviceApiKeySecret
    {
        public bool IsValid { get; set; }

        public string ApiKey { get; set; } = string.Empty;

        public string? DeviceId { get; set; }

        public string? TerminalId { get; set; }

        public string? MerchantId { get; set; }

        public string? EntityId { get; set; }

        public byte[] HmacSecret { get; set; } = Array.Empty<byte>();
    }



    public class DeviceProvisionedKey
    {
        public string KeyId { get; set; } = default!;
        public string ApiKey { get; set; } = default!;
        public string HmacSecret { get; set; } = default!;
        public string? NtfyToken { get; set; } = default!;
        public DateTime? ExpiresAt { get; set; }
    }
}
