﻿using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces
{
    public interface IDeviceServiceShared
    {
        Task<DeviceAuthenticationInfo?> GetAuthenticationInfoAsync(Guid deviceId, CancellationToken cancellationToken = default);
        Task<Guid?> GetDeviceIdBySerialNumber(string serial, CancellationToken cancellationToken = default);
    }

    public class DeviceAuthenticationInfo
    {
        public string DeviceId { get; set; } = string.Empty;
        public string SerialNumber { get; set; } = string.Empty;
        public string DeviceName { get; set; } = string.Empty;
        public string? TerminalId { get; set; } = string.Empty;
        public string? MerchantId { get; set; } = string.Empty;
        public string EntityId { get; set; } = string.Empty;
        public PosStatus Status { get; set; }
    }
}
