using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces
{
    public interface IEventSnapshotService
    {
        Task<Result> SaveSnapshotAsync<T>(
            string aggregateType,
            Guid aggregateId,
            T aggregateData,
            long version = 1,
            CancellationToken cancellationToken = default);

        Task<Result<T?>> GetSnapshotAsync<T>(
            string aggregateType,
            Guid aggregateId,
            CancellationToken cancellationToken = default);

        Task<Result<IReadOnlyList<EventSnapshot>>> GetSnapshotsAsync(
            string aggregateType,
            CancellationToken cancellationToken = default);
    }
}

