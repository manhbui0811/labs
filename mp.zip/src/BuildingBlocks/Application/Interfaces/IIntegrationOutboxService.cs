using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;
using SHT.MerchantPortal.Shared.Kernel.Events;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces
{
    public interface IIntegrationOutboxService
    {
        Task<Result> EnqueueEventAsync<T>(T integrationEvent, CancellationToken cancellationToken = default)
            where T : class, IIntegrationEvent;

        Task<Result> EnqueueRichEventAsync<T>(T richEvent, CancellationToken cancellationToken = default)
            where T : RichIntegrationEventBase;

        Task<Result<IReadOnlyList<IntegrationOutboxItem>>> GetPendingEventsAsync(
            int batchSize = 100,
            CancellationToken cancellationToken = default);

        Task<Result> MarkEventAsProcessingAsync(Guid outboxId, CancellationToken cancellationToken = default);

        Task<Result> MarkEventAsProcessedAsync(Guid outboxId, CancellationToken cancellationToken = default);

        Task<Result> MarkEventAsFailedAsync(Guid outboxId, string errorMessage,
            CancellationToken cancellationToken = default);
    }
}


