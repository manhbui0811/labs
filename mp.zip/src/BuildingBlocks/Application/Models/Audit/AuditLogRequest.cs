namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Audit;

public class AuditLogRequest
{
    public string ActionType { get; set; } = string.Empty;
    public string? TableName { get; set; }
    public string? RecordId { get; set; }
    public object? Details { get; set; }
    public int? EntityId { get; set; }
}


