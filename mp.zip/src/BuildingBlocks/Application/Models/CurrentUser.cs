﻿using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using System.Security.Claims;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models
{
    public class CurrentUser(IHttpContextAccessor httpContextAccessor) : ICurrentUser
    {
        public Guid? UserId
        {
            get
            {
                var userIdClaim = httpContextAccessor.HttpContext.User?.FindFirstValue("system_uid");
                if (Guid.TryParse(userIdClaim, out var userId))
                {
                    return userId;
                }
                return null;
            }
        }
        public string? Email => httpContextAccessor.HttpContext.User?.FindFirstValue(ClaimTypes.Email);

        public string? FullName => httpContextAccessor.HttpContext.User?.FindFirstValue(ClaimTypes.Name);

        public string? KeycloakSubject => httpContextAccessor.HttpContext.User?.FindFirstValue("preferred_username");

        public Guid? EntityId => throw new NotImplementedException();

        public bool IsAuthenticated => httpContextAccessor.HttpContext.User?.Identity?.IsAuthenticated == true;


        public bool HasPermission(string permission) =>
            httpContextAccessor.HttpContext.User?.Claims.Any(c => c.Type == "permissions" && c.Value == permission) == true;

        public IEnumerable<string> GetPermissions() =>
            httpContextAccessor.HttpContext.User?.Claims.Where(c => c.Type == "permissions").Select(c => c.Value) ?? Enumerable.Empty<string>();

        public IEnumerable<string> GetRoles() =>
            httpContextAccessor.HttpContext.User?.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value) ?? Enumerable.Empty<string>();
    }
}