namespace SHT.MerchantPortal.BuildingBlocks.Application.Models;

public class Error
{
    public string Code { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;

    public Error(string code, string message)
    {
        Code = code;
        Message = message;
    }

    public static Error Create(string code, string message) => new(code, message);
    public static Error Create(string message) => new("SYSTEM_ERROR", message);

    public static Error None => new(string.Empty, string.Empty);

    public static Error NullValue => new("Error.NullValue", "The specified result value is null.");

    public static Error ConditionNotMet => new("Error.ConditionNotMet", "The specified condition was not met.");
}


