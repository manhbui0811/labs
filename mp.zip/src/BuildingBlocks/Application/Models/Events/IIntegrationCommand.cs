namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;

public interface IIntegrationCommand
{
    Guid Id { get; }
    DateTime CreatedAt { get; }
}


