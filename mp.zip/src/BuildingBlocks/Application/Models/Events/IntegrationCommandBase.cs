namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;

public abstract class IntegrationCommandBase : IIntegrationCommand
{
    public Guid Id { get; protected set; }
    public DateTime CreatedAt { get; protected set; }

    protected IntegrationCommandBase()
    {
        Id = Guid.NewGuid();
        CreatedAt = DateTime.UtcNow;
    }

    protected IntegrationCommandBase(Guid id, DateTime createdAt)
    {
        Id = id;
        CreatedAt = createdAt;
    }
}


