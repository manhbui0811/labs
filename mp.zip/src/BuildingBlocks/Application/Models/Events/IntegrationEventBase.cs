using SHT.MerchantPortal.Shared.Kernel.Events;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;

public abstract class IntegrationEventBase : IIntegrationEvent
{
    public Guid EventId { get; protected set; }
    public DateTime OccurredOn { get; protected set; }
    public int Version { get; protected set; }
    public string EventType { get; protected set; } = string.Empty;
    public Guid AggregateId { get; protected set; }
    public string RequestId { get; protected set; } = string.Empty;

    protected IntegrationEventBase()
    {
        EventId = Guid.NewGuid();
        OccurredOn = DateTime.UtcNow;
        Version = 1;
        EventType = GetType().Name;
        RequestId = Guid.NewGuid().ToString();
    }

    protected IntegrationEventBase(Guid aggregateId, string? requestId = null, int version = 1)
    {
        EventId = Guid.NewGuid();
        OccurredOn = DateTime.UtcNow;
        AggregateId = aggregateId;
        RequestId = requestId ?? Guid.NewGuid().ToString();
        Version = version;
        EventType = GetType().Name;
    }
}