﻿namespace SHT.MerchantPortal.BuildingBlocks.Application.Models
{
    public class ExportFileDto
    {
        public ExportFileDto(byte[] fileContent, string contentType, string fileName)
        {
            FileContent = fileContent;
            ContentType = contentType;
            FileName = fileName;
        }

        public byte[] FileContent { get; }
        public string ContentType { get; }
        public string FileName { get; }
    }
}
