namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;

public class FeatureFlagSettingDto
{
    public long Id { get; set; }
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}


