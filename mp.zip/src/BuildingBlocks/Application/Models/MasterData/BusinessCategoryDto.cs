namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;

public class BusinessCategoryDto
{
    public Guid Id { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string? MccCode { get; set; }
    public bool IsActive { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}


