using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;

public class ClientAppDto
{
    public Guid Id { get; set; }
    public string AppCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public ClientAppStatus Status { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}


