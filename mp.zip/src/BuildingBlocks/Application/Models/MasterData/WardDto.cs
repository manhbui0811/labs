namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;

public class WardDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string ProvinceCode { get; set; } = string.Empty;
    public string? ProvinceName { get; set; }
}


