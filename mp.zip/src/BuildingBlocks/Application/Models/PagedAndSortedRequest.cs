namespace SHT.MerchantPortal.BuildingBlocks.Application.Models;

/// <summary>
/// Base class for paginated and sorted requests
/// </summary>
public class PagedAndSortedRequest : PagingRequest
{
    /// <summary>
    /// Field to sort by
    /// </summary>
    public string? SortBy { get; set; }

    /// <summary>
    /// Sort direction
    /// </summary>
    public SortDirection SortDirection { get; set; } = SortDirection.Ascending;
}


