using System.ComponentModel.DataAnnotations;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models;

/// <summary>
/// Base class for paginated requests
/// </summary>
public class PagingRequest
{
    private int _pageNumber = 1;
    private int _pageSize = 20;

    /// <summary>
    /// Page number (1-based)
    /// </summary>
    [Range(1, int.MaxValue, ErrorMessage = "Page number must be greater than 0")]
    public int PageNumber
    {
        get => _pageNumber;
        set => _pageNumber = value < 1 ? 1 : value;
    }

    /// <summary>
    /// Number of items per page
    /// </summary>
    [Range(1, 100, ErrorMessage = "Page size must be between 1 and 100")]
    public int PageSize
    {
        get => _pageSize;
        set => _pageSize = value switch
        {
            < 1 => 1,
            > 100 => 100,
            _ => value
        };
    }

    /// <summary>
    /// Calculate skip count for database queries
    /// </summary>
    public int Skip => (PageNumber - 1) * PageSize;

    /// <summary>
    /// Get take count for database queries
    /// </summary>
    public int Take => PageSize;
}


