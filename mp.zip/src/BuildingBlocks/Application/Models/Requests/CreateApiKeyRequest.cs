using System.ComponentModel.DataAnnotations;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;

public class CreateApiKeyRequest
{
    [Required]
    [StringLength(255, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    public int? EntityId { get; set; }

    public DateTime? ExpiresAt { get; set; }

    [StringLength(1000)]
    public string? Scopes { get; set; }
}


