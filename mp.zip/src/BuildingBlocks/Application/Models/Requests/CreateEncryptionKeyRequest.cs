using System.ComponentModel.DataAnnotations;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;

public class CreateEncryptionKeyRequest
{
    [Required]
    [StringLength(255, MinimumLength = 1)]
    public string KeyIdentifier { get; set; } = string.Empty;

    [Required]
    public EncryptionType KeyType { get; set; }

    [Required]
    public KeyCategory KeyCategory { get; set; }

    [Required]
    public OwnerType OwnerType { get; set; }

    public Guid? OwnerId { get; set; }

    [Required]
    [StringLength(100, MinimumLength = 1)]
    public string Algorithm { get; set; } = string.Empty;

    public DateTimeOffset? ExpiresAt { get; set; }
}


