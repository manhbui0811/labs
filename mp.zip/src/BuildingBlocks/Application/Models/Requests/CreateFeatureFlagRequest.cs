using System.ComponentModel.DataAnnotations;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;

public class CreateFeatureFlagRequest
{
    [Required]
    [StringLength(255, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    public bool IsEnabled { get; set; } = false;

    public DateTimeOffset? ExpiresAt { get; set; }

    public Dictionary<string, string>? Settings { get; set; }
}


