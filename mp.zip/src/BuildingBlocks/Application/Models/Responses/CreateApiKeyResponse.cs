namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Responses;

public class CreateApiKeyResponse
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public DateTimeOffset? ExpiresAt { get; set; }
    public string? Scopes { get; set; }
    public DateTimeOffset CreatedAt { get; set; }

    public string SecurityWarning => "Please store this API key securely. It will not be shown again.";
}


