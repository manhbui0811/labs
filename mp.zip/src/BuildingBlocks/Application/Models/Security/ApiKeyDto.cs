namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Security;

public class ApiKeyDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int? EntityId { get; set; }
    public bool IsActive { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public DateTimeOffset? LastUsedAt { get; set; }
    public string? Scopes { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public bool IsExpired { get; set; }
    public bool IsValid { get; set; }
}


