using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models.Security;

public class EncryptionKeyDto
{
    public Guid Id { get; set; }
    public string KeyIdentifier { get; set; } = string.Empty;
    public string KeyVersion { get; set; } = string.Empty;
    public EncryptionType KeyType { get; set; }
    public KeyCategory KeyCategory { get; set; }
    public OwnerType OwnerType { get; set; }
    public Guid? OwnerId { get; set; }
    public EncryptionKeyStatus KeyStatus { get; set; }
    public string Algorithm { get; set; } = string.Empty;
    public DateTimeOffset? ActivatedAt { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public Guid? RotatedToKeyId { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
    public bool IsActive { get; set; }
}


