using System.ComponentModel.DataAnnotations;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Models;

/// <summary>
/// Base class for sorted requests
/// </summary>
public class SortingRequest
{
    /// <summary>
    /// Field to sort by
    /// </summary>
    public string? SortBy { get; set; }

    /// <summary>
    /// Sort direction
    /// </summary>
    public SortDirection SortDirection { get; set; } = SortDirection.Ascending;
}

/// <summary>
/// Sort direction enumeration
/// </summary>
public enum SortDirection
{
    Ascending = 0,
    Descending = 1
}


