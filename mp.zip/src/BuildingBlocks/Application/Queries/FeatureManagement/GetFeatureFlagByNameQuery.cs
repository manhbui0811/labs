using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries.FeatureManagement;

public class GetFeatureFlagByNameQuery : IQuery<FeatureFlagDto?>
{
    public string Name { get; set; } = string.Empty;
}


