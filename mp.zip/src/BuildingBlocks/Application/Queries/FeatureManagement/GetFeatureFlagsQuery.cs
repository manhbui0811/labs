using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries.FeatureManagement;

public class GetFeatureFlagsQuery : IQuery<IReadOnlyList<FeatureFlagDto>>
{
    public bool? IsEnabled { get; set; }
    public string? Search { get; set; }
}


