using MediatR;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries;

/// <summary>
/// Marker interface for queries that return a value of type TResponse
/// </summary>
/// <typeparam name="TResponse">The return type</typeparam>
public interface IQuery<out TResponse> : IRequest<TResponse>
{
}


