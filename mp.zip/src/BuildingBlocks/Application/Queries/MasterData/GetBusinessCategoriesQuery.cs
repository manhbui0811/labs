using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries.MasterData;

public class GetBusinessCategoriesQuery : IQuery<IReadOnlyList<BusinessCategoryDto>>
{
    public bool? IsActive { get; set; }
}


