using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries;

/// <summary>
/// Base class for query handlers
/// </summary>
/// <typeparam name="TQuery">The query type</typeparam>
/// <typeparam name="TResponse">The response type</typeparam>
public abstract class QueryHandlerBase<TQuery, TResponse> : IRequestHandler<TQuery, TResponse>
    where TQuery : class, IQuery<TResponse>
{
    protected readonly ILogger<QueryHandlerBase<TQuery, TResponse>> Logger;
    protected readonly ICurrentUser CurrentUser;

    protected QueryHandlerBase(
        ILogger<QueryHandlerBase<TQuery, TResponse>> logger,
        ICurrentUser currentUser)
    {
        Logger = logger;
        CurrentUser = currentUser;
    }

    public abstract Task<TResponse> Handle(TQuery request, CancellationToken cancellationToken);
}


