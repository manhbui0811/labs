using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Security;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Queries.Security;

public class GetApiKeysQuery : IQuery<IReadOnlyList<ApiKeyDto>>
{
    public int? EntityId { get; set; }
    public bool? IsActive { get; set; }
}


