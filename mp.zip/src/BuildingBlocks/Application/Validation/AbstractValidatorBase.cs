using FluentValidation;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Validation;

/// <summary>
/// Base class for FluentValidation validators
/// </summary>
/// <typeparam name="T">The type being validated</typeparam>
public abstract class AbstractValidatorBase<T> : AbstractValidator<T>
{
    protected AbstractValidatorBase()
    {
        ConfigureRules();
    }

    /// <summary>
    /// Configure validation rules
    /// </summary>
    protected abstract void ConfigureRules();

    /// <summary>
    /// Common validation rule for required string fields
    /// </summary>
    protected void RequiredString(string propertyName, int maxLength = 255)
    {
        RuleFor(x => GetPropertyValue(x, propertyName))
            .NotEmpty()
            .WithMessage($"{propertyName} is required")
            .MaximumLength(maxLength)
            .WithMessage($"{propertyName} cannot exceed {maxLength} characters");
    }

    /// <summary>
    /// Common validation rule for optional string fields
    /// </summary>
    protected void OptionalString(string propertyName, int maxLength = 255)
    {
        RuleFor(x => GetPropertyValue(x, propertyName))
            .MaximumLength(maxLength)
            .WithMessage($"{propertyName} cannot exceed {maxLength} characters")
            .When(x => !string.IsNullOrWhiteSpace(GetPropertyValue(x, propertyName)));
    }

    /// <summary>
    /// Common validation rule for email fields
    /// </summary>
    protected void EmailField(string propertyName)
    {
        RuleFor(x => GetPropertyValue(x, propertyName))
            .NotEmpty()
            .WithMessage($"{propertyName} is required")
            .EmailAddress()
            .WithMessage($"{propertyName} must be a valid email address");
    }

    /// <summary>
    /// Get property value using reflection
    /// </summary>
    private string? GetPropertyValue(T instance, string propertyName)
    {
        var property = typeof(T).GetProperty(propertyName);
        return property?.GetValue(instance)?.ToString();
    }
}


