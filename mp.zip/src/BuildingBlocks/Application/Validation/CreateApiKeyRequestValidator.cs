using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Validation;

public class CreateApiKeyRequestValidator : AbstractValidator<CreateApiKeyRequest>
{
    public CreateApiKeyRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .WithMessage("API key name is required")
            .MaximumLength(255)
            .WithMessage("API key name cannot exceed 255 characters");

        RuleFor(x => x.Description)
            .MaximumLength(1000)
            .WithMessage("Description cannot exceed 1000 characters");

        RuleFor(x => x.EntityId)
            .GreaterThan(0)
            .When(x => x.EntityId.HasValue)
            .WithMessage("Entity ID must be greater than 0");

        RuleFor(x => x.ExpiresAt)
            .GreaterThan(DateTime.UtcNow)
            .When(x => x.ExpiresAt.HasValue)
            .WithMessage("Expiration date must be in the future");

        RuleFor(x => x.Scopes)
            .MaximumLength(1000)
            .WithMessage("Scopes cannot exceed 1000 characters");
    }
}


