using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Validation;

public class CreateEncryptionKeyRequestValidator : AbstractValidator<CreateEncryptionKeyRequest>
{
    public CreateEncryptionKeyRequestValidator()
    {
        RuleFor(x => x.KeyIdentifier)
            .NotEmpty()
            .WithMessage("Key identifier is required")
            .MaximumLength(255)
            .WithMessage("Key identifier cannot exceed 255 characters")
            .Matches("^[a-zA-Z0-9_-]+$")
            .WithMessage("Key identifier can only contain letters, numbers, hyphens, and underscores");

        RuleFor(x => x.KeyType)
            .IsInEnum()
            .WithMessage("Invalid key type");

        RuleFor(x => x.KeyCategory)
            .IsInEnum()
            .WithMessage("Invalid key category");

        RuleFor(x => x.OwnerType)
            .IsInEnum()
            .WithMessage("Invalid owner type");

        RuleFor(x => x.OwnerId)
            .NotEmpty()
            .When(x => x.OwnerType != OwnerType.SYSTEM)
            .WithMessage("Owner ID is required for non-system keys");

        RuleFor(x => x.Algorithm)
            .NotEmpty()
            .WithMessage("Algorithm is required")
            .MaximumLength(100)
            .WithMessage("Algorithm cannot exceed 100 characters");

        RuleFor(x => x.ExpiresAt)
            .GreaterThan(DateTimeOffset.UtcNow)
            .When(x => x.ExpiresAt.HasValue)
            .WithMessage("Expiration date must be in the future");
    }
}


