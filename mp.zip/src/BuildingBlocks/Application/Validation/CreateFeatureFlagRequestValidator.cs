using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Requests;

namespace SHT.MerchantPortal.BuildingBlocks.Application.Validation;

public class CreateFeatureFlagRequestValidator : AbstractValidator<CreateFeatureFlagRequest>
{
    public CreateFeatureFlagRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .WithMessage("Feature flag name is required")
            .MaximumLength(255)
            .WithMessage("Feature flag name cannot exceed 255 characters")
            .Matches("^[a-zA-Z0-9_-]+$")
            .WithMessage("Feature flag name can only contain letters, numbers, hyphens, and underscores");

        RuleFor(x => x.Description)
            .MaximumLength(1000)
            .WithMessage("Description cannot exceed 1000 characters");

        RuleFor(x => x.ExpiresAt)
            .GreaterThan(DateTimeOffset.UtcNow)
            .When(x => x.ExpiresAt.HasValue)
            .WithMessage("Expiration date must be in the future");

        RuleForEach(x => x.Settings.Keys)
            .NotEmpty()
            .WithMessage("Setting key cannot be empty")
            .MaximumLength(255)
            .WithMessage("Setting key cannot exceed 255 characters")
            .When(x => x.Settings != null);
    }
}


