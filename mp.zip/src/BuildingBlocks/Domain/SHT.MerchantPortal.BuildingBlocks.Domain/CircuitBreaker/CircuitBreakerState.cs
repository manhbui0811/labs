using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;

public class CircuitBreakerState : EntityBase<Guid>
{
    public string ServiceName { get; private set; }
    public BreakerState State { get; private set; }
    public int FailureCount { get; private set; }
    public DateTime? LastFailureTime { get; private set; }
    public DateTime? OpenUntil { get; private set; }
    public int SuccessCount { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime UpdatedAt { get; private set; }
    
    private CircuitBreakerState() { }
    
    public CircuitBreakerState(string serviceName)
    {
        Id = Guid.NewGuid();
        ServiceName = serviceName;
        State = BreakerState.Closed;
        FailureCount = 0;
        SuccessCount = 0;
        CreatedAt = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
    }
    
    public void RecordFailure()
    {
        FailureCount++;
        LastFailureTime = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
        
        if (FailureCount >= 5) // Threshold
        {
            Open();
        }
    }
    
    public void RecordSuccess()
    {
        SuccessCount++;
        UpdatedAt = DateTime.UtcNow;
        
        if (State == BreakerState.HalfOpen && SuccessCount >= 3)
        {
            Close();
        }
    }
    
    public void Open()
    {
        State = BreakerState.Open;
        OpenUntil = DateTime.UtcNow.AddMinutes(1); // Open for 1 minute
        UpdatedAt = DateTime.UtcNow;
    }
    
    public void Close()
    {
        State = BreakerState.Closed;
        FailureCount = 0;
        SuccessCount = 0;
        OpenUntil = null;
        UpdatedAt = DateTime.UtcNow;
    }
    
    public void HalfOpen()
    {
        State = BreakerState.HalfOpen;
        SuccessCount = 0;
        UpdatedAt = DateTime.UtcNow;
    }
    
    public bool ShouldAttemptReset()
    {
        return State == BreakerState.Open && 
               OpenUntil.HasValue && 
               OpenUntil.Value <= DateTime.UtcNow;
    }
}

public enum BreakerState
{
    Closed = 0,
    Open = 1,
    HalfOpen = 2
}


