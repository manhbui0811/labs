// File: src/Contracts/SHT.MerchantPortal.Contracts/Integration/DeviceActivatedIntegrationEvent.cs

using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Contracts;

public sealed class DeviceActivatedIntegrationEvent : RichIntegrationEventBase
{
    public string SerialNumber { get; init; } = default!;
    public Guid PaymentChannelId { get; init; }
    public string MerchantCode { get; init; } = default!;
    public string TerminalCode { get; init; } = default!;
    public Guid? MerchantProfileId { get; init; }

    private DeviceActivatedIntegrationEvent() { } // Serialization

    public DeviceActivatedIntegrationEvent(
        Guid deviceId,
        string serialNumber,
        Guid paymentChannelId,
        string merchantCode,
        string terminalCode,
        Guid? merchantProfileId = null,
        string? correlationId = null,
        string? requestId = null)
        : base(deviceId, correlationId, requestId)
    {
        SerialNumber = serialNumber;
        PaymentChannelId = paymentChannelId;
        MerchantCode = merchantCode;
        TerminalCode = terminalCode;
        MerchantProfileId = merchantProfileId;

        AddMetadata("sourceService", "EntityManagement");
        AddMetadata("entityPath", $"devices/{deviceId}");
        AddMetadata("emVersion", "1.0");
        AddMetadata("routingTopic", $"devices/{serialNumber}/config");
    }
}