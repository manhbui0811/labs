using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Contracts;

public sealed class DeviceConfigurationRequestedIntegrationEvent : RichIntegrationEventBase
{
    public string SerialNumber { get; init; } = default!;
    public string ConfigurationType { get; init; } = default!;
    public Dictionary<string, object> ConfigurationData { get; init; } = new();

    private DeviceConfigurationRequestedIntegrationEvent() { } // For deserialization

    public DeviceConfigurationRequestedIntegrationEvent(
        Guid deviceId,
        string serialNumber,
        string configurationType,
        Dictionary<string, object> configurationData,
        string? correlationId = null,
        string? requestId = null)
        : base(deviceId, correlationId, requestId)
    {
        SerialNumber = serialNumber;
        ConfigurationType = configurationType;
        ConfigurationData = configurationData;

        AddMetadata("sourceService", "EntityManagement");
        AddMetadata("configurationType", configurationType);
    }
}