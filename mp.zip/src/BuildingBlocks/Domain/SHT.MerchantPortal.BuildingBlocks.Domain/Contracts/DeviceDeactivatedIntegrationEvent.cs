using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Contracts;

public sealed class DeviceDeactivatedIntegrationEvent : RichIntegrationEventBase
{
    public string SerialNumber { get; init; } = default!;
    public Guid MerchantProfileId { get; init; }
    public string MerchantCode { get; init; } = default!;
    public string TerminalCode { get; init; } = default!;
    public string Reason { get; init; } = default!;

    private DeviceDeactivatedIntegrationEvent() { } // For deserialization

    public DeviceDeactivatedIntegrationEvent(
        Guid deviceId,
        string serialNumber,
        Guid merchantProfileId,
        string merchantCode,
        string terminalCode,
        string reason,
        string? correlationId = null,
        string? requestId = null)
        : base(deviceId, correlationId, requestId)
    {
        SerialNumber = serialNumber;
        MerchantProfileId = merchantProfileId;
        MerchantCode = merchantCode;
        TerminalCode = terminalCode;
        Reason = reason;

        AddMetadata("sourceService", "EntityManagement");
        AddMetadata("entityPath", $"merchant/{merchantCode}/terminal/{terminalCode}");
    }
}