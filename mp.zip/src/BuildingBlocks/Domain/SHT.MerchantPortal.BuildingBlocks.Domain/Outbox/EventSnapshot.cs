
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

public class EventSnapshot : FullAuditedAggregateRoot<Guid>
{

    public string AggregateType { get; private set; } = string.Empty;
    public Guid AggregateId { get; private set; }
    public string SnapshotData { get; private set; } = string.Empty;
    public long Version { get; private set; }

    private EventSnapshot() { }

    private EventSnapshot(
        string aggregateType,
        Guid aggregateId,
        string snapshotData,
        long version)
    {
        Id = Guid.CreateVersion7();
        AggregateType = aggregateType;
        AggregateId = aggregateId;
        SnapshotData = snapshotData;
        Version = version;
        CreatedAt = DateTimeOffset.UtcNow;
    }

    public static EventSnapshot Create(
        string aggregateType,
        Guid aggregateId,
        string snapshotData,
        long version = 1)
    {
        if (string.IsNullOrWhiteSpace(aggregateType))
            throw new ArgumentException("Aggregate type cannot be empty", nameof(aggregateType));
            
        if (string.IsNullOrWhiteSpace(snapshotData))
            throw new ArgumentException("Snapshot data cannot be empty", nameof(snapshotData));

        return new EventSnapshot(aggregateType, aggregateId, snapshotData, version);
    }

    public void UpdateSnapshot(string snapshotData, long version)
    {
        SnapshotData = snapshotData;
        Version = version;
        UpdatedAt = DateTimeOffset.UtcNow;
    }
}

