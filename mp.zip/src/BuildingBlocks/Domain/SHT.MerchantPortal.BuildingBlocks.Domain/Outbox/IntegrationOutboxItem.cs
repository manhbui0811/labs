using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

public class IntegrationOutboxItem : FullAuditedAggregateRoot<Guid>
{
    public string EventType { get; private set; } = string.Empty;
    public Guid AggregateId { get; private set; }
    public string EventData { get; private set; } = string.Empty;
    public string RequestId { get; private set; } = string.Empty;
    public OutboxStatus Status { get; private set; }
    public int ProcessingAttempts { get; private set; }
    public int MaxRetries { get; private set; }
    public DateTimeOffset? ProcessedAt { get; private set; }
    public int RetryCount { get; private set; }
    public DateTimeOffset? NextRetryAt { get; private set; }
    public string? ErrorMessage { get; private set; }
    public bool CdcNotified { get; private set; }

    private IntegrationOutboxItem() { }

    private IntegrationOutboxItem(
        string eventType,
        Guid aggregateId,
        string eventData,
        string requestId,
        int maxRetries = 3)
    {
        Id = Guid.CreateVersion7();
        EventType = eventType;
        AggregateId = aggregateId;
        EventData = eventData;
        RequestId = requestId;
        Status = OutboxStatus.Pending;
        ProcessingAttempts = 0;
        MaxRetries = maxRetries;
        RetryCount = 0;
        CdcNotified = false;
        CreatedAt = DateTimeOffset.UtcNow;
    }

    public static IntegrationOutboxItem Create(
        string eventType,
        Guid aggregateId,
        string eventData,
        string requestId,
        int maxRetries = 3)
    {
        if (string.IsNullOrWhiteSpace(eventType))
            throw new ArgumentException("Event type cannot be empty", nameof(eventType));
            
        if (string.IsNullOrWhiteSpace(eventData))
            throw new ArgumentException("Event data cannot be empty", nameof(eventData));
            
        if (string.IsNullOrWhiteSpace(requestId))
            throw new ArgumentException("Request ID cannot be empty", nameof(requestId));

        return new IntegrationOutboxItem(eventType, aggregateId, eventData, requestId, maxRetries);
    }

    public void MarkAsProcessing()
    {
        Status = OutboxStatus.Processing;
        ProcessingAttempts++;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsProcessed()
    {
        Status = OutboxStatus.Processed;
        ProcessedAt = DateTimeOffset.UtcNow;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsFailed(string errorMessage)
    {
        Status = OutboxStatus.Failed;
        ErrorMessage = errorMessage;
        RetryCount++;
        CalculateNextRetry();
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsCdcNotified()
    {
        CdcNotified = true;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public bool ShouldRetry()
    {
        return Status == OutboxStatus.Failed && 
               RetryCount < MaxRetries &&
               (NextRetryAt == null || NextRetryAt <= DateTimeOffset.UtcNow);
    }

    private void CalculateNextRetry()
    {
        if (RetryCount >= MaxRetries)
        {
            NextRetryAt = null;
            return;
        }

        // Exponential backoff with jitter
        var baseDelay = TimeSpan.FromSeconds(Math.Pow(2, RetryCount));
        var jitter = TimeSpan.FromMilliseconds(Random.Shared.Next(0, 1000));
        NextRetryAt = DateTimeOffset.UtcNow.Add(baseDelay).Add(jitter);
    }
}


