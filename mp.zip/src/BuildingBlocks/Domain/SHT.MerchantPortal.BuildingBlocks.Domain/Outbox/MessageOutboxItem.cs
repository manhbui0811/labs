using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

public class MessageOutboxItem : FullAuditedAggregateRoot<Guid>
{
    public string Channel { get; private set; } = string.Empty; // MQTT/NTFY/HTTP
    public string Topic { get; private set; } = string.Empty;
    public string Payload { get; private set; } = string.Empty;
    public string? Headers { get; private set; }
    public OutboxStatus Status { get; private set; }
    public int ProcessingAttempts { get; private set; }
    public int MaxRetries { get; private set; }
    public DateTimeOffset? ProcessedAt { get; private set; }
    public int RetryCount { get; private set; }
    public DateTimeOffset? NextRetryAt { get; private set; }
    public string? ErrorMessage { get; private set; }
    public bool CdcNotified { get; private set; }

    private MessageOutboxItem() { }

    private MessageOutboxItem(
        string channel,
        string topic,
        string payload,
        string? headers = null,
        int maxRetries = 3)
    {
        Id = Guid.CreateVersion7();
        Channel = channel;
        Topic = topic;
        Payload = payload;
        Headers = headers;
        Status = OutboxStatus.Pending;
        ProcessingAttempts = 0;
        MaxRetries = maxRetries;
        RetryCount = 0;
        CdcNotified = false;
        CreatedAt = DateTimeOffset.UtcNow;
    }

    public static MessageOutboxItem Create(
        string channel,
        string topic,
        string payload,
        string? headers = null,
        int maxRetries = 3)
    {
        if (string.IsNullOrWhiteSpace(channel))
            throw new ArgumentException("Channel cannot be empty", nameof(channel));
            
        if (string.IsNullOrWhiteSpace(topic))
            throw new ArgumentException("Topic cannot be empty", nameof(topic));
            
        if (string.IsNullOrWhiteSpace(payload))
            throw new ArgumentException("Payload cannot be empty", nameof(payload));

        return new MessageOutboxItem(channel, topic, payload, headers, maxRetries);
    }

    public void MarkAsProcessing()
    {
        Status = OutboxStatus.Processing;
        ProcessingAttempts++;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsProcessed()
    {
        Status = OutboxStatus.Processed;
        ProcessedAt = DateTimeOffset.UtcNow;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsFailed(string errorMessage)
    {
        Status = OutboxStatus.Failed;
        ErrorMessage = errorMessage;
        RetryCount++;
        CalculateNextRetry();
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void MarkAsCdcNotified()
    {
        CdcNotified = true;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public bool ShouldRetry()
    {
        return Status == OutboxStatus.Failed && 
               RetryCount < MaxRetries &&
               (NextRetryAt == null || NextRetryAt <= DateTimeOffset.UtcNow);
    }

    private void CalculateNextRetry()
    {
        if (RetryCount >= MaxRetries)
        {
            NextRetryAt = null;
            return;
        }

        var baseDelay = TimeSpan.FromSeconds(Math.Pow(2, RetryCount));
        var jitter = TimeSpan.FromMilliseconds(Random.Shared.Next(0, 1000));
        NextRetryAt = DateTimeOffset.UtcNow.Add(baseDelay).Add(jitter);
    }
}


