using SHT.MerchantPortal.Shared.Kernel.Events;
using System.Text.Json;

namespace SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

public abstract class RichIntegrationEventBase : IIntegrationEvent
{
    public Guid EventId { get; protected set; }
    public int Version { get; protected set; }
    public DateTime OccurredOn { get; protected set; }
    public string EventType { get; protected set; } = string.Empty;
    public Guid AggregateId { get; protected set; }
    public string RequestId { get; protected set; } = string.Empty;
    public string? CorrelationId { get; protected set; }
    public Dictionary<string, object> Metadata { get; protected set; }
    
    protected RichIntegrationEventBase()
    {
        EventId = Guid.NewGuid();
        OccurredOn = DateTime.UtcNow;
        Version = 1;
        EventType = GetType().Name;
        RequestId = Guid.NewGuid().ToString();
        Metadata = new Dictionary<string, object>();
    }
    
    protected RichIntegrationEventBase(Guid aggregateId, string? correlationId = null, string? requestId = null) : this()
    {
        AggregateId = aggregateId;
        CorrelationId = correlationId;
        RequestId = requestId ?? Guid.NewGuid().ToString();
    }
    
    public void AddMetadata(string key, object value)
    {
        Metadata[key] = value;
    }

    /// <summary>
    /// Serialize the event data into rich format including metadata
    /// </summary>
    public virtual string SerializeEventData()
    {
        var eventData = new
        {
            EventId,
            EventType,
            AggregateId,
            RequestId,
            OccurredOn,
            Version,
            CorrelationId,
            Metadata,
            Payload = this
        };

        return JsonSerializer.Serialize(eventData, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        });
    }
}

