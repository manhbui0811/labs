﻿namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Authentication
{
    public static class PosAuthenticationDefaults
    {
        public const string AuthenticationScheme = "pos-signature";
        public const string DisplayName = "POS HTTP Message Signature Authentication";
    }
}
