using Microsoft.Extensions.Logging;
using Quartz;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.BackgroundJobs;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundJobs;

public class BackgroundJobService : IBackgroundJobService
{
    private readonly IScheduler _scheduler;
    private readonly ILogger<BackgroundJobService> _logger;

    public BackgroundJobService(IScheduler scheduler, ILogger<BackgroundJobService> logger)
    {
        _scheduler = scheduler;
        _logger = logger;
    }

    public async Task ScheduleJobAsync<T>(
        string jobName, 
        string cronExpression,
        object? parameters = null,
        CancellationToken cancellationToken = default) where T : IJob
    {
        var jobKey = new JobKey(jobName);
        var triggerKey = new TriggerKey($"{jobName}-trigger");

        var jobDetail = JobBuilder.Create<T>()
            .WithIdentity(jobKey)
            .Build();

        if (parameters != null)
        {
            foreach (var prop in parameters.GetType().GetProperties())
            {
                jobDetail.JobDataMap[prop.Name] = prop.GetValue(parameters);
            }
        }

        var trigger = TriggerBuilder.Create()
            .WithIdentity(triggerKey)
            .WithCronSchedule(cronExpression)
            .Build();

        await _scheduler.ScheduleJob(jobDetail, trigger, cancellationToken);
        
        _logger.LogInformation("Scheduled job {JobName} with cron expression {CronExpression}", 
            jobName, cronExpression);
    }

    public async Task TriggerJobAsync(
        string jobName, 
        object? parameters = null,
        CancellationToken cancellationToken = default)
    {
        var jobKey = new JobKey(jobName);
        
        var jobDataMap = new JobDataMap();
        if (parameters != null)
        {
            foreach (var prop in parameters.GetType().GetProperties())
            {
                jobDataMap[prop.Name] = prop.GetValue(parameters);
            }
        }

        await _scheduler.TriggerJob(jobKey, jobDataMap, cancellationToken);
        
        _logger.LogInformation("Triggered job {JobName}", jobName);
    }

    public async Task<bool> DeleteJobAsync(string jobName, CancellationToken cancellationToken = default)
    {
        var jobKey = new JobKey(jobName);
        var result = await _scheduler.DeleteJob(jobKey, cancellationToken);
        
        _logger.LogInformation("Deleted job {JobName}: {Result}", jobName, result);
        
        return result;
    }

    public async Task<JobExecutionStatus> GetJobStatusAsync(string jobName, CancellationToken cancellationToken = default)
    {
        var jobKey = new JobKey(jobName);
        var jobDetail = await _scheduler.GetJobDetail(jobKey, cancellationToken);
        
        if (jobDetail == null)
        {
            return new JobExecutionStatus
            {
                JobName = jobName,
                Status = "NotFound",
                LastExecution = null,
                NextExecution = null
            };
        }

        var triggers = await _scheduler.GetTriggersOfJob(jobKey, cancellationToken);
        var trigger = triggers.FirstOrDefault();
        
        return new JobExecutionStatus
        {
            JobName = jobName,
            Status = "Scheduled",
            LastExecution = trigger?.GetPreviousFireTimeUtc()?.DateTime,
            NextExecution = trigger?.GetNextFireTimeUtc()?.DateTime
        };
    }
}


