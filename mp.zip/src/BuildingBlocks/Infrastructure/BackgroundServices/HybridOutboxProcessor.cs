using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Npgsql;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundServices;

public class HybridOutboxProcessor : OutboxProcessorBase
{
    private readonly string _connectionString;
    private NpgsqlConnection? _connection;

    public HybridOutboxProcessor(
        IServiceProvider serviceProvider,
        ILogger<HybridOutboxProcessor> logger,
        string connectionString) : base(serviceProvider, logger)
    {
        _connectionString = connectionString;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        Logger.LogInformation("HybridOutboxProcessor starting...");

        // Start both real-time listener and polling fallback
        var realtimeTask = StartRealTimeListenerAsync(stoppingToken);
        var pollingTask = StartPollingAsync(stoppingToken);

        await Task.WhenAny(realtimeTask, pollingTask);
    }

    private async Task StartRealTimeListenerAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                _connection = new NpgsqlConnection(_connectionString);
                await _connection.OpenAsync(cancellationToken);

                _connection.Notification += OnNotificationReceived;

                await using var listenCmd = new NpgsqlCommand("LISTEN integration_outbox_new", _connection);
                await listenCmd.ExecuteNonQueryAsync(cancellationToken);

                Logger.LogInformation("Real-time listener started for integration outbox");

                while (!cancellationToken.IsCancellationRequested && _connection.State == System.Data.ConnectionState.Open)
                {
                    await _connection.WaitAsync(cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error in real-time listener, retrying in 5 seconds...");
                await Task.Delay(TimeSpan.FromSeconds(5), cancellationToken);
            }
            finally
            {
                if (_connection != null)
                {
                    _connection.Notification -= OnNotificationReceived;
                    await _connection.DisposeAsync();
                    _connection = null;
                }
            }
        }
    }

    private async Task StartPollingAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await ProcessOutboxEventsAsync(cancellationToken);
                await Task.Delay(TimeSpan.FromSeconds(30), cancellationToken); // Fallback polling every 30 seconds
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error in polling fallback");
                await Task.Delay(TimeSpan.FromSeconds(10), cancellationToken);
            }
        }
    }

    private void OnNotificationReceived(object sender, NpgsqlNotificationEventArgs e)
    {
        try
        {
            Logger.LogDebug("Received notification: {Payload}", e.Payload);

            var notification = JsonSerializer.Deserialize<OutboxNotification>(e.Payload);
            if (notification == null) return;

            // Process the notification immediately
            _ = Task.Run(async () =>
            {
                try
                {
                    using var scope = ServiceProvider.CreateScope();
                    var outboxService = scope.ServiceProvider.GetRequiredService<IIntegrationOutboxService>();

                    var eventsResult = await outboxService.GetPendingEventsAsync(1, CancellationToken.None);
                    if (!eventsResult.IsSuccess || eventsResult.Payload == null) return;

                    var targetEvent = eventsResult.Payload.FirstOrDefault(e => e.Id == notification.Id);
                    if (targetEvent != null)
                    {
                        await ProcessSingleEventAsync(targetEvent, outboxService, CancellationToken.None);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, "Error processing real-time notification for {EventId}", notification.Id);
                }
            });
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error handling notification: {Payload}", e.Payload);
        }
    }

    public override void Dispose()
    {
        if (_connection != null)
        {
            _connection.Notification -= OnNotificationReceived;
            _connection.Dispose();
        }
        base.Dispose();
    }

    private record OutboxNotification(Guid Id, string EventType, Guid AggregateId);
}


