using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Domain.Contracts;
using DeviceConfigurationRequestedIntegrationEvent = SHT.MerchantPortal.BuildingBlocks.Domain.Contracts.DeviceConfigurationRequestedIntegrationEvent;
using DeviceDeactivatedIntegrationEvent = SHT.MerchantPortal.BuildingBlocks.Domain.Contracts.DeviceDeactivatedIntegrationEvent;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundServices;

public class IntegrationEventRouter
{
    public static async Task RouteEventAsync(
        IntegrationOutboxItem outboxEvent,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var logger = serviceProvider.GetRequiredService<ILogger<IntegrationEventRouter>>();
        
        try
        {
            switch (outboxEvent.EventType)
            {
                case nameof(DeviceActivatedIntegrationEvent):
                    await HandleEventAsync<DeviceActivatedIntegrationEvent>(outboxEvent, serviceProvider, cancellationToken);
                    break;

                case nameof(DeviceDeactivatedIntegrationEvent):
                    await HandleEventAsync<DeviceDeactivatedIntegrationEvent>(outboxEvent, serviceProvider, cancellationToken);
                    break;

                case nameof(DeviceConfigurationRequestedIntegrationEvent):
                    await HandleEventAsync<DeviceConfigurationRequestedIntegrationEvent>(outboxEvent, serviceProvider, cancellationToken);
                    break;

                default:
                    logger.LogWarning("Unknown integration event type: {EventType}", outboxEvent.EventType);
                    break;
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to route integration event {EventType} with ID {EventId}",
                outboxEvent.EventType, outboxEvent.Id);
            throw;
        }
    }

    private static async Task HandleEventAsync<T>(
        IntegrationOutboxItem outboxEvent,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken) where T : class
    {
        var logger = serviceProvider.GetRequiredService<ILogger<IntegrationEventRouter>>();

        try
        {
            var mediator = serviceProvider.GetRequiredService<IMediator>();
            
            // Try to deserialize as rich event first, then fallback to simple event
            var eventData = DeserializeRichEvent<T>(outboxEvent.EventData) ?? 
                           DeserializeSimpleEvent<T>(outboxEvent.EventData);
            
            if (eventData != null)
            {
                await mediator.Publish(eventData, cancellationToken);
                logger.LogDebug("Successfully routed {EventType} event with ID {EventId}",
                    typeof(T).Name, outboxEvent.Id);
            }
            else
            {
                logger.LogWarning("Failed to deserialize {EventType} event with ID {EventId}",
                    typeof(T).Name, outboxEvent.Id);
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error handling {EventType} event with ID {EventId}",
                typeof(T).Name, outboxEvent.Id);
            throw;
        }
    }

    /// <summary>
    /// Deserialize rich event format that includes metadata wrapper
    /// </summary>
    private static T? DeserializeRichEvent<T>(string eventData) where T : class
    {
        try
        {
            var richEventWrapper = JsonSerializer.Deserialize<RichEventWrapper>(eventData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            if (richEventWrapper?.Payload != null)
            {
                var payloadJson = JsonSerializer.Serialize(richEventWrapper.Payload);
                return JsonSerializer.Deserialize<T>(payloadJson, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });
            }
        }
        catch (JsonException)
        {
            // Not a rich event format, will try simple format
        }

        return null;
    }

    /// <summary>
    /// Deserialize simple event format (direct serialization)
    /// </summary>
    private static T? DeserializeSimpleEvent<T>(string eventData) where T : class
    {
        try
        {
            return JsonSerializer.Deserialize<T>(eventData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }
        catch (JsonException)
        {
            // Could not deserialize as simple event either
            return null;
        }
    }

    /// <summary>
    /// Wrapper class for rich event format
    /// </summary>
    private class RichEventWrapper
    {
        public Guid EventId { get; set; }
        public string EventType { get; set; } = string.Empty;
        public Guid AggregateId { get; set; }
        public string RequestId { get; set; } = string.Empty;
        public DateTime OccurredOn { get; set; }
        public int Version { get; set; }
        public string? CorrelationId { get; set; }
        public Dictionary<string, object>? Metadata { get; set; }
        public object? Payload { get; set; }
    }
}

