﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundServices
{
    public abstract class OutboxProcessorBase : BackgroundService
    {
        protected readonly IServiceProvider ServiceProvider;
        protected readonly ILogger Logger;

        protected OutboxProcessorBase(IServiceProvider serviceProvider, ILogger logger)
        {
            ServiceProvider = serviceProvider;
            Logger = logger;
        }

        protected async Task ProcessOutboxEventsAsync(CancellationToken cancellationToken)
        {
            using var scope = ServiceProvider.CreateScope();
            var outboxService = scope.ServiceProvider.GetRequiredService<IIntegrationOutboxService>();

            try
            {
                var pendingResult = await outboxService.GetPendingEventsAsync(100, cancellationToken);
                if (!pendingResult.IsSuccess)
                {
                    Logger.LogError("Failed to get pending events: {Errors}",
                        string.Join(", ", pendingResult.Errors.Select(e => e.Message)));
                    return;
                }

                var pendingEvents = pendingResult.Payload;
                if (pendingEvents == null || !pendingEvents.Any())
                    return;

                Logger.LogInformation("Processing {Count} pending integration events", pendingEvents.Count);

                foreach (var outboxEvent in pendingEvents)
                {
                    await ProcessSingleEventAsync(outboxEvent, outboxService, cancellationToken);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error processing outbox events");
            }
        }

        protected virtual async Task ProcessSingleEventAsync(
            IntegrationOutboxItem outboxEvent,
            IIntegrationOutboxService outboxService,
            CancellationToken cancellationToken)
        {
            try
            {
                await outboxService.MarkEventAsProcessingAsync(outboxEvent.Id, cancellationToken);

                // Route the event to appropriate handlers
                await IntegrationEventRouter.RouteEventAsync(outboxEvent, ServiceProvider, cancellationToken);

                await outboxService.MarkEventAsProcessedAsync(outboxEvent.Id, cancellationToken);

                Logger.LogDebug("Successfully processed event {EventId} of type {EventType}",
                    outboxEvent.Id, outboxEvent.EventType);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Failed to process event {EventId} of type {EventType}",
                    outboxEvent.Id, outboxEvent.EventType);

                await outboxService.MarkEventAsFailedAsync(outboxEvent.Id, ex.Message, cancellationToken);
            }
        }
    }
}