using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;


namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundServices;

public class PollingOutboxProcessor : OutboxProcessorBase
{
    private readonly ILogger<PollingOutboxProcessor> _logger;
    public PollingOutboxProcessor(
        IServiceProvider serviceProvider,
        ILogger<PollingOutboxProcessor> logger) : base(serviceProvider, logger)
    {
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("PollingOutboxProcessor starting...");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ProcessOutboxEventsAsync(stoppingToken);
                await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken); // Poll every 10 seconds
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("PollingOutboxProcessor stopped");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in polling outbox processor");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }
}


