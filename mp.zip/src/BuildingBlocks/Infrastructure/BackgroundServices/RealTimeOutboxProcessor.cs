using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Npgsql;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundServices
{
    public class RealTimeOutboxProcessor : OutboxProcessorBase
    {
        private readonly string _connectionString;
        private NpgsqlConnection? _connection;

        public RealTimeOutboxProcessor(
            IServiceProvider serviceProvider,
            ILogger<RealTimeOutboxProcessor> logger,
            string connectionString) : base(serviceProvider, logger)
        {
            _connectionString = connectionString;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Logger.LogInformation("RealTimeOutboxProcessor starting...");

            try
            {
                await StartListeningAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "RealTimeOutboxProcessor encountered an error");
            }
        }

        private async Task StartListeningAsync(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    _connection = new NpgsqlConnection(_connectionString);
                    await _connection.OpenAsync(cancellationToken);

                    _connection.Notification += OnNotificationReceived;

                    // Listen to both integration and message outbox channels
                    await using var listenCmd1 = new NpgsqlCommand("LISTEN integration_outbox_new", _connection);
                    await listenCmd1.ExecuteNonQueryAsync(cancellationToken);

                    await using var listenCmd2 = new NpgsqlCommand("LISTEN message_outbox_new", _connection);
                    await listenCmd2.ExecuteNonQueryAsync(cancellationToken);

                    Logger.LogInformation("Started listening for PostgreSQL notifications");

                    // Keep the connection alive and process notifications
                    while (!cancellationToken.IsCancellationRequested &&
                           _connection.State == System.Data.ConnectionState.Open)
                    {
                        await _connection.WaitAsync(cancellationToken);
                    }
                }
                catch (OperationCanceledException)
                {
                    Logger.LogInformation("RealTimeOutboxProcessor stopped");
                    break;
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, "Error in PostgreSQL listener, retrying in 5 seconds...");
                    await Task.Delay(TimeSpan.FromSeconds(5), cancellationToken);
                }
                finally
                {
                    if (_connection != null)
                    {
                        _connection.Notification -= OnNotificationReceived;
                        await _connection.DisposeAsync();
                        _connection = null;
                    }
                }
            }
        }

        private void OnNotificationReceived(object sender, NpgsqlNotificationEventArgs e)
        {
            try
            {
                Logger.LogDebug("Received notification on channel {Channel}: {Payload}", e.Channel, e.Payload);

                var notification = JsonSerializer.Deserialize<OutboxNotification>(e.Payload);
                if (notification == null) return;

                // Process the notification asynchronously
                _ = Task.Run(async () =>
                {
                    try
                    {
                        if (e.Channel == "integration_outbox_new")
                        {
                            await ProcessIntegrationOutboxEventAsync(notification.Id, CancellationToken.None);
                        }
                        else if (e.Channel == "message_outbox_new")
                        {
                            await ProcessMessageOutboxEventAsync(notification.Id, CancellationToken.None);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex, "Error processing notification for {EventId}", notification.Id);
                    }
                });
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error handling PostgreSQL notification: {Payload}", e.Payload);
            }
        }

        private async Task ProcessIntegrationOutboxEventAsync(Guid eventId, CancellationToken cancellationToken)
        {
            using var scope = ServiceProvider.CreateScope();
            var outboxService = scope.ServiceProvider.GetRequiredService<IIntegrationOutboxService>();

            var eventsResult = await outboxService.GetPendingEventsAsync(1, cancellationToken);
            if (!eventsResult.IsSuccess || eventsResult.Payload == null) return;

            var targetEvent = eventsResult.Payload.FirstOrDefault(e => e.Id == eventId);
            if (targetEvent != null)
            {
                await ProcessSingleEventAsync(targetEvent, outboxService, cancellationToken);
            }
        }

        private async Task ProcessMessageOutboxEventAsync(Guid messageId, CancellationToken cancellationToken)
        {
            // Process message outbox events (MQTT/NTFY/HTTP dispatch)
            Logger.LogDebug("Processing message outbox event {MessageId}", messageId);

            // This will be handled by MessageOutboxProcessor in Fortuna module
            // We just log here for now
        }

        public override void Dispose()
        {
            if (_connection != null)
            {
                _connection.Notification -= OnNotificationReceived;
                _connection.Dispose();
            }

            base.Dispose();
        }

        private record OutboxNotification(Guid Id, string EventType, Guid AggregateId);
    }
}




