﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Cachings;
using StackExchange.Redis;
using System.Text.Json;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Cachings
{
    public class RedisService : IRedisService
    {
        private readonly ILogger<RedisService> _logger;
        private readonly ConnectionMultiplexer? _redis;
        private readonly IDatabase? _database;
        private readonly string _keyPrefix = string.Empty;
        private readonly TimeSpan _defaultExpiry;
        private readonly bool _isUsed;

        public RedisService(IConfiguration configuration, ILogger<RedisService> logger)
        {
            _logger = logger;

            // Lấy cờ để bật/tắt dịch vụ từ cấu hình
            _isUsed = configuration.GetValue<bool>("Redis:IsUsed");

            // Chỉ kết nối nếu dịch vụ được bật
            if (_isUsed)
            {
                var connectionString = configuration["Redis:Connection"];

                if (string.IsNullOrEmpty(connectionString))
                {
                    _logger.LogError("Redis connection string is not configured. Redis service will be disabled.");
                    _isUsed = false;
                    return;
                }

                // Lấy key prefix từ cấu hình, nếu không có thì mặc định là chuỗi rỗng
                _keyPrefix = configuration.GetValue<string>("Redis:KeyPrefix") ?? string.Empty;

                // Lấy thời gian hết hạn mặc định từ cấu hình
                var defaultExpiryInMinutes = configuration.GetValue<int?>("Redis:DefaultExpiryInMinutes") ?? 30;
                _defaultExpiry = TimeSpan.FromMinutes(defaultExpiryInMinutes);

                try
                {
                    // Kết nối đến Redis
                    _redis = ConnectionMultiplexer.Connect(connectionString);
                    _database = _redis.GetDatabase();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to connect to Redis. Redis service will be disabled.");
                    _isUsed = false;
                }
            }
        }

        public async Task<string?> GetAsync(string key)
        {
            if (!_isUsed || _database == null)
            {
                return null;
            }
            try
            {
                var value = await _database.StringGetAsync($"{_keyPrefix}{key}");
                return value.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting value from Redis for key: {Key}", key);
                return null;
            }
        }

        public async Task<T?> GetAsync<T>(string key)
        {
            if (!_isUsed || _database == null)
            {
                return default;
            }
            try
            {
                var value = await _database.StringGetAsync($"{_keyPrefix}{key}");
                return value.HasValue ? JsonSerializer.Deserialize<T>(value!) : default;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting and deserializing value from Redis for key: {Key}", key);
                return default;
            }
        }

        public async Task SetAsync(string key, string value, TimeSpan? expiry = null)
        {
            if (!_isUsed || _database == null)
            {
                return;
            }
            try
            {
                // Sử dụng thời gian hết hạn mặc định nếu không được cung cấp
                var finalExpiry = expiry ?? _defaultExpiry;
                await _database.StringSetAsync($"{_keyPrefix}{key}", value, finalExpiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting value in Redis for key: {Key}", key);
            }
        }

        public async Task SetAsync<T>(string key, T value, TimeSpan? expiry = null)
        {
            if (!_isUsed || _database == null || value == null)
            {
                return;
            }
            try
            {
                var finalExpiry = expiry ?? _defaultExpiry;
                var serializedValue = JsonSerializer.Serialize(value);
                await _database.StringSetAsync($"{_keyPrefix}{key}", serializedValue, finalExpiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error serializing and setting value in Redis for key: {Key}", key);
            }
        }

        public async Task RemoveAsync(string key)
        {
            if (!_isUsed || _database == null)
            {
                return;
            }
            try
            {
                await _database.KeyDeleteAsync($"{_keyPrefix}{key}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing key from Redis: {Key}", key);
            }
        }
    }
}
