﻿using System.Text.Json;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Common;

/// <summary>
/// Default JSON serializer options for the infrastructure layer
/// </summary>
public static class JsonOptions
{
    /// <summary>
    /// Default web API JSON serializer options
    /// </summary>
    public static readonly JsonSerializerOptions Web = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = false
    };

    /// <summary>
    /// JSON serializer options for pretty printing
    /// </summary>
    public static readonly JsonSerializerOptions Pretty = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };
}