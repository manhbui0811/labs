namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;

public class EventBusConfiguration
{
    public const string SectionName = "EventBus";
    
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string Username { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string VirtualHost { get; set; } = "/";
    public bool UseSSL { get; set; } = false;
    public int RetryCount { get; set; } = 3;
    public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(5);
}


