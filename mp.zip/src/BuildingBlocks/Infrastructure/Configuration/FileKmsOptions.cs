namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;

public class FileKmsOptions
{
    public const string SectionName = "KMS:File";

    public string MasterKeyPath { get; set; }

    public string? InitialMasterKeyBase64 { get; set; }
}


