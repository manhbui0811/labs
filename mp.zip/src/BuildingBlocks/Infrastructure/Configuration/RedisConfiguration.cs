namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;

public class RedisConfiguration
{
    public const string SectionName = "Redis";
    
    public string ConnectionString { get; set; } = string.Empty;
    public string InstanceName { get; set; } = "MerchantPortal";
    public int Database { get; set; } = 0;
    public TimeSpan DefaultExpiration { get; set; } = TimeSpan.FromMinutes(30);
    public bool EnableCompression { get; set; } = true;
}


