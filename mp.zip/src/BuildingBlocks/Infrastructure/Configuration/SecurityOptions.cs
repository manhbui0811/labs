﻿namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration
{
    public class SecurityOptions
    {
        public bool UserLocalMasterKey { get; set; } = true;
        public string LocalMasterKeyBase64 { get; set; } = "IY6Gg82co98qkSp1h6oQds2udP+KxLaF5d3Hhv1nGxY=";
        public string ProtectorType { get; set; } = "ENV";
    }

}
