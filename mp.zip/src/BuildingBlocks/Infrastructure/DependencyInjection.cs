﻿using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;
using SHT.MerchantPortal.BuildingBlocks.Application.Cachings;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Cachings;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Security;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddCoreServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpContextAccessor();
        AddRedis(services, configuration);
        services.AddSingleton<IDateTimeProvider, DateTimeProvider>();
        services.AddSingleton<IKeyProtector, EnvKeyProtector>();
        services.AddSingleton<IEncryptionService, EncryptionService>();
        services.AddScoped<ICurrentUser, CurrentUser>();
        services.AddScoped<ICurrentUserService, CurrentUserService>();
        //services.AddScoped<IAuditService, AuditService>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuthorizationBehavior<,>));
        return services;
    }

    private static void AddRedis(IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton<IRedisService, RedisService>();
    }
}