using MassTransit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Quartz;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.BackgroundJobs;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.EventBus;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.ExternalServices;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.FileStorage;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.BackgroundJobs;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.ExternalServices;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.FileStorage;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Configuration
        services.Configure<DatabaseConfiguration>(
            configuration.GetSection(DatabaseConfiguration.SectionName));
        services.Configure<RedisConfiguration>(
            configuration.GetSection(RedisConfiguration.SectionName));
        services.Configure<EventBusConfiguration>(
            configuration.GetSection(EventBusConfiguration.SectionName));

        // Database
        services.AddDatabase(configuration);

        // Caching
        services.AddCaching(configuration);

        // Event Bus
        services.AddEventBus(configuration);

        // Background Jobs
        services.AddBackgroundJobs(configuration);

        // External Services
        services.AddExternalServices(configuration);

        // Application Services
        services.AddApplicationServices();

        return services;
    }

    private static IServiceCollection AddDatabase(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        services.AddDbContext<DbContext>(options =>
        {
            options.UseNpgsql(connectionString, npgsqlOptions =>
            {
                npgsqlOptions.EnableRetryOnFailure(
                    maxRetryCount: 3,
                    maxRetryDelay: TimeSpan.FromSeconds(30),
                    errorCodesToAdd: null);
            });

            if (configuration.GetValue<bool>("Database:EnableSensitiveDataLogging"))
            {
                options.EnableSensitiveDataLogging();
            }

            if (configuration.GetValue<bool>("Database:EnableDetailedErrors"))
            {
                options.EnableDetailedErrors();
            }
        });

        services.AddScoped<IUnitOfWork, UnitOfWork>();

        return services;
    }

    private static IServiceCollection AddCaching(this IServiceCollection services, IConfiguration configuration)
    {
        var redisConnectionString = configuration.GetConnectionString("Redis");

        if (!string.IsNullOrEmpty(redisConnectionString))
        {
            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = redisConnectionString;
                options.InstanceName = configuration.GetValue<string>("Redis:InstanceName") ?? "MerchantPortal";
            });
        }
        else
        {
            services.AddMemoryCache();
        }

        services.AddScoped<ICacheService, CacheService>();

        return services;
    }

    private static IServiceCollection AddEventBus(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddMassTransit(x =>
        {
            x.UsingRabbitMq((context, cfg) =>
            {
                var eventBusConfig = configuration.GetSection(EventBusConfiguration.SectionName).Get<EventBusConfiguration>();

                cfg.Host(eventBusConfig?.Host ?? "localhost", h =>
                {
                    h.Username(eventBusConfig?.Username ?? "guest");
                    h.Password(eventBusConfig?.Password ?? "guest");
                });

                cfg.ConfigureEndpoints(context);
            });
        });

        return services;
    }

    private static IServiceCollection AddBackgroundJobs(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddQuartz(q =>
        {
            // Updated for newer Quartz versions
            q.SchedulerName = "MerchantPortal-Scheduler";
            q.SchedulerId = "AUTO";

            // Use in-memory store for simplicity (can be changed to database store)
            q.UseInMemoryStore();

            // Configure thread pool
            q.UseDefaultThreadPool(tp =>
            {
                tp.MaxConcurrency = 10;
            });
        });

        services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);
        services.AddScoped<IBackgroundJobService, BackgroundJobService>();

        return services;
    }

    private static IServiceCollection AddExternalServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient<IHttpClientService, HttpClientService>(client =>
        {
            client.Timeout = TimeSpan.FromSeconds(30);
        })
        .AddStandardResilienceHandler();

        services.AddScoped<IFileStorageService, FileStorageService>();

        return services;
    }

    private static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        //services.AddScoped<IAuditService, AuditService>();
        services.AddSingleton<IDateTimeProvider, DateTimeProvider>();
        services.AddSingleton<ICurrentUserService>();
        return services;
    }
}

