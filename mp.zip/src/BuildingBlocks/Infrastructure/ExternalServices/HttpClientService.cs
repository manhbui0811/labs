using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.ExternalServices;
using System.Text;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Common;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Extensions;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.ExternalServices;

public class HttpClientService : IHttpClientService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<HttpClientService> _logger;

    public HttpClientService(HttpClient httpClient, ILogger<HttpClientService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<T?> GetAsync<T>(
        string endpoint,
        CancellationToken cancellationToken = default) where T : class
    {
        try
        {
            _logger.LogInformation("Making GET request to {Endpoint}", endpoint);

            var response = await _httpClient.GetAsync(endpoint, cancellationToken);
            response.EnsureSuccessStatusCode();

            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<T>(content, JsonOptions.Web);

            _logger.LogInformation("Successfully completed GET request to {Endpoint}", endpoint);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed GET request to {Endpoint}", endpoint);
            throw;
        }
    }

    public async Task<TResponse?> PostAsync<TRequest, TResponse>(
        string endpoint,
        TRequest request,
        CancellationToken cancellationToken = default)
        where TRequest : class
        where TResponse : class
    {
        try
        {
            _logger.LogInformation("Making POST request to {Endpoint}", endpoint);

            var json = JsonSerializer.Serialize(request, JsonOptions.Web);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(endpoint, content, cancellationToken);
            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<TResponse>(responseContent, JsonOptions.Web);

            _logger.LogInformation("Successfully completed POST request to {Endpoint}", endpoint);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed POST request to {Endpoint}", endpoint);
            throw;
        }
    }

    public async Task<TResponse?> PutAsync<TRequest, TResponse>(
        string endpoint,
        TRequest request,
        CancellationToken cancellationToken = default)
        where TRequest : class
        where TResponse : class
    {
        try
        {
            _logger.LogInformation("Making PUT request to {Endpoint}", endpoint);

            var json = JsonSerializer.Serialize(request, JsonOptions.Web);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PutAsync(endpoint, content, cancellationToken);
            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<TResponse>(responseContent, JsonOptions.Web);

            _logger.LogInformation("Successfully completed PUT request to {Endpoint}", endpoint);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed PUT request to {Endpoint}", endpoint);
            throw;
        }
    }

    public async Task<bool> DeleteAsync(string endpoint, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Making DELETE request to {Endpoint}", endpoint);

            var response = await _httpClient.DeleteAsync(endpoint, cancellationToken);
            response.EnsureSuccessStatusCode();

            _logger.LogInformation("Successfully completed DELETE request to {Endpoint}", endpoint);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed DELETE request to {Endpoint}", endpoint);
            return false;
        }
    }
}