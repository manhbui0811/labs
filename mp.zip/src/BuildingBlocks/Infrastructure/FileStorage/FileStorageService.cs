using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.FileStorage;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.FileStorage;

public class FileStorageService : IFileStorageService
{
    private readonly ILogger<FileStorageService> _logger;

    public FileStorageService(ILogger<FileStorageService> logger)
    {
        _logger = logger;
    }

    public async Task<string> UploadAsync(
        Stream fileStream, 
        string fileName, 
        string contentType,
        CancellationToken cancellationToken = default)
    {
        // This is a simplified implementation
        // In production, you'd integrate with Azure Blob Storage, AWS S3, etc.
        
        var fileId = Guid.NewGuid().ToString();
        var filePath = Path.Combine("uploads", fileId, fileName);
        
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        
        await using var outputStream = File.Create(filePath);
        await fileStream.CopyToAsync(outputStream, cancellationToken);
        
        _logger.LogInformation("Uploaded file {FileName} to {FilePath}", fileName, filePath);
        
        return filePath;
    }

    public async Task<Stream> DownloadAsync(string filePath, CancellationToken cancellationToken = default)
    {
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException($"File not found: {filePath}");
        }
        
        var stream = new MemoryStream();
        await using var fileStream = File.OpenRead(filePath);
        await fileStream.CopyToAsync(stream, cancellationToken);
        stream.Position = 0;
        
        return stream;
    }

    public Task<bool> DeleteAsync(string filePath, CancellationToken cancellationToken = default)
    {
        if (File.Exists(filePath))
        {
            File.Delete(filePath);
            _logger.LogInformation("Deleted file {FilePath}", filePath);
            return Task.FromResult(true);
        }
        
        return Task.FromResult(false);
    }

    public Task<bool> ExistsAsync(string filePath, CancellationToken cancellationToken = default)
    {
        return Task.FromResult(File.Exists(filePath));
    }
}


