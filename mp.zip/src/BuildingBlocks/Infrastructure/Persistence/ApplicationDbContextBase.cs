using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Events;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;
using System.Linq.Expressions;
using System.Reflection;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;

public abstract class ApplicationDbContextBase : DbContext
{
    private readonly ILogger<ApplicationDbContextBase>? _logger;
    private readonly ICurrentUser? _currentUserService;
    private readonly IDateTimeProvider? _dateTimeProvider;
    
    protected ApplicationDbContextBase(DbContextOptions options) : base(options)
    {
    }
    protected ApplicationDbContextBase(
        DbContextOptions options,
        ILogger<ApplicationDbContextBase> logger,
        ICurrentUser currentUserService,
        IDateTimeProvider dateTimeProvider) : base(options)
    {
        _logger = logger;
        _currentUserService = currentUserService;
        _dateTimeProvider = dateTimeProvider;
    }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Apply configurations from all assemblies
        ApplyConfigurationsFromAssembly(modelBuilder);

        // Configure audit fields
        ConfigureAuditFields(modelBuilder);

        // Configure global filters
        ConfigureGlobalFilters(modelBuilder);
    }

    protected virtual void ApplyConfigurationsFromAssembly(ModelBuilder modelBuilder)
    {
        var assembly = GetType().Assembly;
        modelBuilder.ApplyConfigurationsFromAssembly(assembly);
    }

    protected virtual void ConfigureAuditFields(ModelBuilder modelBuilder)
    {
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            if (typeof(IAuditedEntity).IsAssignableFrom(entityType.ClrType))
            {
                modelBuilder.Entity(entityType.ClrType)
                    .Property<DateTimeOffset>("CreatedAt")
                    .HasDefaultValueSql("NOW()");

                modelBuilder.Entity(entityType.ClrType)
                    .Property<DateTimeOffset?>("UpdatedAt")
                    .HasDefaultValueSql("NOW()");
            }
        }
    }

    protected virtual void ConfigureGlobalFilters(ModelBuilder modelBuilder)
    {
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            if (typeof(ISoftDelete).IsAssignableFrom(entityType.ClrType))
            {
                var method = typeof(ApplicationDbContextBase)
                    .GetMethod(nameof(GetSoftDeleteFilter), BindingFlags.NonPublic | BindingFlags.Static)
                    ?.MakeGenericMethod(entityType.ClrType);

                var filter = method?.Invoke(null, new object[] { });
                modelBuilder.Entity(entityType.ClrType).HasQueryFilter((dynamic)filter!);
            }
        }
    }

    private static LambdaExpression GetSoftDeleteFilter<TEntity>()
        where TEntity : class, ISoftDelete
    {
        Expression<Func<TEntity, bool>> filter = x => !x.IsDeleted;
        return filter;
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        UpdateAuditFields();

        //var domainEvents = GetDomainEvents();
        var result = await base.SaveChangesAsync(cancellationToken);

        // Domain events will be published by MediatR pipeline
        //await PublishDomainEventsAsync(domainEvents);

        return result;
    }

    private void UpdateAuditFields()
    {
        if (_dateTimeProvider == null || _currentUserService == null) return;

        var now = _dateTimeProvider.UtcNow;
        var currentUserId = _currentUserService.UserId;

        foreach (var entry in ChangeTracker.Entries<IAuditedEntity>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedBy = currentUserId.ToString();
                    entry.Entity.CreatedAt = now;
                    entry.Entity.UpdatedBy = currentUserId.ToString();
                    entry.Entity.UpdatedAt = now;
                    break;

                case EntityState.Modified:
                    entry.Entity.UpdatedBy = currentUserId.ToString();
                    entry.Entity.UpdatedAt = now;
                    break;
            }
        }

        foreach (var entry in ChangeTracker.Entries<IAuditableEntity>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedBy = currentUserId;
                    entry.Entity.CreatedAt = now;
                    entry.Entity.UpdatedBy = currentUserId;
                    entry.Entity.UpdatedAt = now;
                    break;

                case EntityState.Modified:
                    entry.Entity.UpdatedBy = currentUserId;
                    entry.Entity.UpdatedAt = now;
                    break;
            }
        }
    }

    private List<IDomainEvent> GetDomainEvents()
    {
        var domainEvents = new List<IDomainEvent>();

        foreach (var entry in ChangeTracker.Entries<AggregateRootBase<object>>())
        {
            if (entry.Entity.DomainEvents.Any())
            {
                domainEvents.AddRange(entry.Entity.DomainEvents);
                entry.Entity.ClearDomainEvents();
            }
        }

        return domainEvents;
    }

    private async Task PublishDomainEventsAsync(List<IDomainEvent> domainEvents)
    {
        if (_logger == null) return;
        // This will be handled by MediatR pipeline behavior
        // For now, we just log that events were captured
        if (domainEvents.Any())
        {
            _logger.LogInformation("Captured {Count} domain events", domainEvents.Count);
        }
    }
}