//using Microsoft.EntityFrameworkCore.Metadata.Builders;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations.Extensions;

///// <summary>
///// Extension methods for EntityTypeBuilder to simplify configuration
///// </summary>
//public static class EntityTypeBuilderExtensions
//{
//    /// <summary>
//    /// Configure a relationship where the entity has many of another type without exposing the foreign key
//    /// </summary>
//    public static ReferenceCollectionBuilder<TEntity, TRelatedEntity> HasManyObject<TEntity, TRelatedEntity>(
//        this EntityTypeBuilder<TEntity> builder)
//        where TEntity : class
//        where TRelatedEntity : class
//    {
//        return builder.HasMany<TRelatedEntity>();
//    }

//    /// <summary>
//    /// Configure a relationship where the entity has one of another type without exposing the navigation property
//    /// </summary>
//    public static ReferenceReferenceBuilder<TEntity, TRelatedEntity> HasOneObject<TEntity, TRelatedEntity>(
//        this ReferenceCollectionBuilder<TEntity, TRelatedEntity> builder)
//        where TEntity : class
//        where TRelatedEntity : class
//    {
//        return builder.WithOne();
//    }
//}


