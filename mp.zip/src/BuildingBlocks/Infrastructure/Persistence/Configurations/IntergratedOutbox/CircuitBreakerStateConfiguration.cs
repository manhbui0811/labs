﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations.IntergratedOutbox
{
    public class CircuitBreakerStateConfiguration : IEntityTypeConfiguration<CircuitBreakerState>
    {
        public void Configure(EntityTypeBuilder<CircuitBreakerState> builder)
        {
            builder.ToTable("circuit_breaker_states", "fortuna");

            builder.HasKey(x => x.Id);

            builder.Property(x => x.ServiceName)
                .IsRequired()
                .HasMaxLength(200);

            builder.Property(x => x.State)
                .IsRequired()
                .HasConversion<string>();

            // Indexes
            builder.HasIndex(x => x.ServiceName).IsUnique();
            builder.HasIndex(x => x.State);
        }
    }

}
