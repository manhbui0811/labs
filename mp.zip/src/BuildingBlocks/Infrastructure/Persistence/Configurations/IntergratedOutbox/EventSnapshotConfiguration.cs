using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations.IntergratedOutbox;

public class EventSnapshotConfiguration : IEntityTypeConfiguration<EventSnapshot>
{
    public void Configure(EntityTypeBuilder<EventSnapshot> builder)
    {
        builder.ToTable("event_snapshots", "core");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.AggregateType)
            .IsRequired()
            .HasMaxLength(200);

        builder.Property(x => x.AggregateId)
            .IsRequired();

        builder.Property(x => x.SnapshotData)
            .IsRequired()
            .HasColumnType("jsonb");

        builder.Property(x => x.Version)
            .IsRequired();

        // Indexes
        builder.HasIndex(x => new { x.AggregateType, x.AggregateId }).IsUnique();
        builder.HasIndex(x => x.Version);

        // Audit fields
        builder.Property(x => x.CreatedAt).IsRequired();
        builder.Property(x => x.UpdatedAt);
        builder.Property(x => x.CreatedBy).HasMaxLength(255);
        builder.Property(x => x.UpdatedBy).HasMaxLength(255);

        // Soft delete
        builder.Property(x => x.IsDeleted).HasDefaultValue(false);
        builder.Property(x => x.DeletedAt);
        builder.Property(x => x.DeletedBy).HasMaxLength(255);

        builder.HasQueryFilter(x => !x.IsDeleted);
    }
}
