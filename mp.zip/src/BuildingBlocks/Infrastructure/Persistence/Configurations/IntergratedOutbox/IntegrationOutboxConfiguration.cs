﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations.IntergratedOutbox;

public class IntegrationOutboxConfiguration : IEntityTypeConfiguration<IntegrationOutboxItem>
{
    public void Configure(EntityTypeBuilder<IntegrationOutboxItem> builder)
    {
        builder.ToTable("integration_outbox", "core");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.EventType)
            .IsRequired()
            .HasMaxLength(200);

        builder.Property(x => x.AggregateId)
            .IsRequired();

        builder.Property(x => x.EventData)
            .IsRequired()
            .HasColumnType("jsonb");

        builder.Property(x => x.RequestId)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(x => x.Status)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(50);

        builder.Property(x => x.ProcessingAttempts)
            .IsRequired();

        builder.Property(x => x.MaxRetries)
            .IsRequired();

        builder.Property(x => x.RetryCount)
            .IsRequired();

        builder.Property(x => x.CdcNotified)
            .IsRequired();

        builder.Property(x => x.ErrorMessage)
            .HasColumnType("text");

        builder.HasIndex(x => x.Status);
        builder.HasIndex(x => new { x.Status, x.NextRetryAt });
        builder.HasIndex(x => x.RequestId).IsUnique();
        builder.HasIndex(x => x.CreatedAt);
    }
}