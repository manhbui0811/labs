﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations.IntergratedOutbox;

public class MessageOutboxConfiguration : IEntityTypeConfiguration<MessageOutboxItem>
{
    public void Configure(EntityTypeBuilder<MessageOutboxItem> builder)
    {
        builder.ToTable("message_outbox", "core");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Channel)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(x => x.Topic)
            .IsRequired()
            .HasMaxLength(500);

        builder.Property(x => x.Payload)
            .IsRequired()
            .HasColumnType("text");

        builder.Property(x => x.Headers)
            .HasColumnType("jsonb");

        builder.Property(x => x.Status)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(50);

        builder.Property(x => x.ErrorMessage)
            .HasColumnType("text");

        builder.HasIndex(x => x.Status);
        builder.HasIndex(x => new { x.Channel, x.Status });
        builder.HasIndex(x => new { x.Status, x.NextRetryAt });
    }
}