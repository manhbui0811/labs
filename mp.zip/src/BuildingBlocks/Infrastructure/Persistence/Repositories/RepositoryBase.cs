﻿using Microsoft.EntityFrameworkCore;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;

public abstract class RepositoryBase<TEntity, TId> : ReadRepositoryBase<TEntity, TId>, IRepositoryBase<TEntity, TId>
    where TEntity : EntityBase<TId>
    where TId : notnull
{
    protected RepositoryBase(DbContext context) : base(context) { }
    public IQueryable<TEntity> GetQueryable()
    {
        return _dbSet;
    }
    public virtual async Task<TEntity> AddAsync(TEntity entity, CancellationToken cancellationToken = default)
    {
        var entry = await _dbSet.AddAsync(entity, cancellationToken);
        return entry.Entity;
    }

    public virtual Task AddRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default)
    {
        return _dbSet.AddRangeAsync(entities, cancellationToken);
    }

    public virtual Task UpdateAsync(TEntity entity, CancellationToken cancellationToken = default)
    {
        _dbSet.Update(entity);
        return Task.CompletedTask;
    }

    public virtual Task UpdateRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default)
    {
        _dbSet.UpdateRange(entities);
        return Task.CompletedTask;
    }

    public virtual Task DeleteAsync(TEntity entity, CancellationToken cancellationToken = default)
    {
        if (entity is ISoftDelete softDeleteEntity)
        {
            // Sử dụng phương thức Delete đã đóng gói trong entity
            softDeleteEntity.Delete(null); // Giả sử null cho deletedBy ở tầng này
            _dbSet.Update(entity);
        }
        else
        {
            _dbSet.Remove(entity);
        }
        return Task.CompletedTask;
    }

    public virtual Task DeleteRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default)
    {
        foreach (var entity in entities)
        {
            if (entity is ISoftDelete softDeleteEntity)
            {
                softDeleteEntity.Delete(null);
            }
        }

        if (entities.Any(e => e is ISoftDelete))
        {
            _dbSet.UpdateRange(entities);
        }
        else if (entities.Any())
        {
            _dbSet.RemoveRange(entities);
        }
        return Task.CompletedTask;
    }

    public virtual Task HardDeleteAsync(TEntity entity, CancellationToken cancellationToken = default)
    {
        _dbSet.Remove(entity);
        return Task.CompletedTask;
    }

    public virtual Task HardDeleteRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default)
    {
        _dbSet.RemoveRange(entities);
        return Task.CompletedTask;
    }
}