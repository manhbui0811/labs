﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence
{
    public class SharedOutboxDbContext : ApplicationDbContextBase
    {
        public SharedOutboxDbContext(DbContextOptions<SharedOutboxDbContext> options) : base(options) { }

        public SharedOutboxDbContext(
            DbContextOptions<SharedOutboxDbContext> options,
            ILogger<SharedOutboxDbContext> logger,
            ICurrentUser currentUserService,
            IDateTimeProvider dateTimeProvider) : base(options, logger, currentUserService, dateTimeProvider) { }

        public DbSet<IntegrationOutboxItem> IntegrationOutboxItems => Set<IntegrationOutboxItem>();
        public DbSet<EventSnapshot> EventSnapshots => Set<EventSnapshot>();
        public DbSet<CircuitBreakerState> CircuitBreakerStates => Set<CircuitBreakerState>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 🔥 Apply configurations từ BuildingBlocks
            modelBuilder.ApplyConfiguration(new Configurations.IntergratedOutbox.IntegrationOutboxConfiguration());
            modelBuilder.ApplyConfiguration(new Configurations.IntergratedOutbox.EventSnapshotConfiguration());
            modelBuilder.ApplyConfiguration(new Configurations.IntergratedOutbox.CircuitBreakerStateConfiguration());
        }
    }
}
