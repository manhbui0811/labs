﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security;
using System.Security.Cryptography;
using System.Text;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Security
{
    public class EncryptionService : IEncryptionService
    {
        private const int AesGcmNonceSize = 12; // 96 bits
        private const int AesGcmTagSize = 16; // 128 bits
        private const int MaxPlaintextLength = 1024 * 1024; // 1MB
        private const int MaxCiphertextLength = 1024 * 1024; // 1MB
        private const int MaxTrack2Length = 37;

        private readonly ILogger<EncryptionService> _logger;
        private readonly RandomNumberGenerator _rng;
        private readonly IKeyProtector _keyProtector;


        public EncryptionService(
            IKeyProtector keyProtector,
            ILogger<EncryptionService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _keyProtector = keyProtector ?? throw new ArgumentNullException(nameof(keyProtector));
            _rng = RandomNumberGenerator.Create();
        }

        // OPTIMIZED: Method to get key material, relying on IKeyManagementService to cache it
        public async Task<byte[]> GetEncryptionKeyMaterialAsync(string keyIdentifier, CancellationToken cancellationToken = default)
        {
            var keyMaterial = await _keyProtector.GetKeyMaterialAsync(keyIdentifier, cancellationToken);
            if (keyMaterial == null)
            {
                _logger.LogError("Encryption key material not found for identifier: {KeyIdentifier}", keyIdentifier);
                throw new CryptographicException($"Key with identifier '{keyIdentifier}' not found or couldn't be accessed by KeyManagementService.");
            }
            return keyMaterial;
        }

        // Original EncryptAsync using keyIdentifier (relies on KeyManagementService caching)
        public async Task<byte[]> EncryptAsync(byte[] plaintext, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            ValidateEncryptionInput(plaintext, keyIdentifier);
            var keyMaterial = await GetEncryptionKeyMaterialAsync(keyIdentifier, cancellationToken); // Relies on KMS caching
            return await EncryptAsync(plaintext, keyMaterial, cancellationToken);
        }

        // OPTIMIZED: EncryptAsync using pre-fetched keyMaterial
        public Task<byte[]> EncryptAsync(byte[] plaintext, byte[] keyMaterial, CancellationToken cancellationToken = default)
        {
            // Input validation for plaintext should happen before this call or be very basic here
            if (plaintext == null || plaintext.Length == 0 || plaintext.Length > MaxPlaintextLength)
                throw new ArgumentException("Invalid plaintext for encryption.", nameof(plaintext));
            if (keyMaterial == null || keyMaterial.Length == 0)
                throw new ArgumentNullException(nameof(keyMaterial), "Key material cannot be null or empty.");

            try
            {
                var iv = GenerateNonce();
                var tag = new byte[AesGcmTagSize];
                var ciphertext = new byte[plaintext.Length];

                using (var aesGcm = new AesGcm(keyMaterial, AesGcmTagSize))
                {
                    aesGcm.Encrypt(iv, plaintext, ciphertext, tag);
                }
                return Task.FromResult(CombineEncryptedData(iv, ciphertext, tag));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error encrypting data with pre-fetched key.");
                throw;
            }
        }

        // Original DecryptAsync using keyIdentifier
        public async Task<byte[]> DecryptAsync(byte[] ciphertext, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            ValidateDecryptionInput(ciphertext, keyIdentifier);
            var keyMaterial = await GetEncryptionKeyMaterialAsync(keyIdentifier, cancellationToken); // Relies on KMS caching
            return await DecryptAsync(ciphertext, keyMaterial, cancellationToken);
        }

        // OPTIMIZED: DecryptAsync using pre-fetched keyMaterial
        public Task<byte[]> DecryptAsync(byte[] ciphertext, byte[] keyMaterial, CancellationToken cancellationToken = default)
        {
            // Input validation for ciphertext should happen before this call or be very basic here
            if (ciphertext == null || ciphertext.Length < (AesGcmNonceSize + AesGcmTagSize) || ciphertext.Length > MaxCiphertextLength)
                throw new ArgumentException("Invalid ciphertext for decryption.", nameof(ciphertext));
            if (keyMaterial == null || keyMaterial.Length == 0)
                throw new ArgumentNullException(nameof(keyMaterial), "Key material cannot be null or empty.");

            try
            {
                var (iv, actualCiphertext, tag) = SplitEncryptedData(ciphertext);
                using (var aesGcm = new AesGcm(keyMaterial, AesGcmTagSize))
                {
                    var plaintext = new byte[actualCiphertext.Length];
                    aesGcm.Decrypt(iv, actualCiphertext, tag, plaintext);
                    return Task.FromResult(plaintext);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error decrypting data with pre-fetched key.");
                throw;
            }
        }

        public async Task<string> EncryptAsync(string plaintext, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(plaintext)) throw new ArgumentException("Plaintext cannot be empty", nameof(plaintext));
            var plaintextBytes = Encoding.UTF8.GetBytes(plaintext);
            var encryptedBytes = await EncryptAsync(plaintextBytes, keyIdentifier, cancellationToken);
            return Convert.ToBase64String(encryptedBytes);
        }

        // OPTIMIZED for string with pre-fetched key
        public async Task<string> EncryptAsync(string plaintext, byte[] keyMaterial, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(plaintext)) throw new ArgumentException("Plaintext cannot be empty", nameof(plaintext));
            var plaintextBytes = Encoding.UTF8.GetBytes(plaintext);
            var encryptedBytes = await EncryptAsync(plaintextBytes, keyMaterial, cancellationToken);
            return Convert.ToBase64String(encryptedBytes);
        }

        public async Task<string> DecryptAsync(string ciphertext, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(ciphertext)) throw new ArgumentException("Ciphertext cannot be empty", nameof(ciphertext));
            var ciphertextBytes = Convert.FromBase64String(ciphertext);
            var plaintextBytes = await DecryptAsync(ciphertextBytes, keyIdentifier, cancellationToken);
            return Encoding.UTF8.GetString(plaintextBytes);
        }

        // OPTIMIZED for string with pre-fetched key
        public async Task<string> DecryptAsync(string ciphertext, byte[] keyMaterial, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(ciphertext)) throw new ArgumentException("Ciphertext cannot be empty", nameof(ciphertext));
            var ciphertextBytes = Convert.FromBase64String(ciphertext);
            var plaintextBytes = await DecryptAsync(ciphertextBytes, keyMaterial, cancellationToken);
            return Encoding.UTF8.GetString(plaintextBytes);
        }

        public Task<string> HashAsync(string data, CancellationToken cancellationToken = default) // Sửa lại, không cần async Task.Run ở đây
        {
            if (string.IsNullOrEmpty(data))
                throw new ArgumentException("Data cannot be empty", nameof(data));

            using var sha256 = SHA256.Create();
            var dataBytes = Encoding.UTF8.GetBytes(data);
            var hashBytes = sha256.ComputeHash(dataBytes); // ComputeHash là đồng bộ

            // Chuyển đổi byte array thành chuỗi hexa
            var builder = new StringBuilder();
            for (var i = 0; i < hashBytes.Length; i++)
            {
                builder.Append(hashBytes[i].ToString("x2"));
            }
            return Task.FromResult(builder.ToString());
        }

        public async Task<bool> VerifyHashAsync(string data, string hash, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(data))
                throw new ArgumentException("Data cannot be empty", nameof(data));
            if (string.IsNullOrEmpty(hash))
                throw new ArgumentException("Hash cannot be empty", nameof(hash));

            var computedHash = await HashAsync(data, cancellationToken); // Sẽ trả về hex

            // So sánh không phân biệt chữ hoa/thường cho chuỗi hex
            return string.Equals(computedHash, hash, StringComparison.OrdinalIgnoreCase);
        }

        // Track2Data methods would also benefit from pre-fetched keyMaterial if keyIdentifier implies the same key always.
        public async Task<(string encryptedData, string iv, string authTag)> EncryptTrack2DataAsync(
            string track2Data, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            // Similar to EncryptAsync, fetch key material once or accept pre-fetched
            ValidateTrack2Data(track2Data, keyIdentifier);
            var keyMaterial = await GetEncryptionKeyMaterialAsync(keyIdentifier, cancellationToken);
            // ... rest of the logic using keyMaterial
            var iv = GenerateNonce();
            var plaintext = Encoding.UTF8.GetBytes(track2Data);
            var tag = new byte[AesGcmTagSize];
            var ciphertext = new byte[plaintext.Length];
            using (var aesGcm = new AesGcm(keyMaterial, AesGcmTagSize))
            {
                aesGcm.Encrypt(iv, plaintext, ciphertext, tag);
            }
            return (Convert.ToBase64String(ciphertext), Convert.ToBase64String(iv), Convert.ToBase64String(tag));
        }

        public async Task<string> DecryptTrack2DataAsync(
            string encryptedData, string iv, string authTag, string keyIdentifier, CancellationToken cancellationToken = default)
        {
            // Similar to DecryptAsync, fetch key material once or accept pre-fetched
            ValidateTrack2DecryptionInput(encryptedData, iv, authTag, keyIdentifier);
            var keyMaterial = await GetEncryptionKeyMaterialAsync(keyIdentifier, cancellationToken);
            // ... rest of the logic using keyMaterial
            var ciphertext = Convert.FromBase64String(encryptedData);
            var ivBytes = Convert.FromBase64String(iv);
            var tagBytes = Convert.FromBase64String(authTag);
            using (var aesGcm = new AesGcm(keyMaterial, AesGcmTagSize))
            {
                var plaintext = new byte[ciphertext.Length];
                aesGcm.Decrypt(ivBytes, ciphertext, tagBytes, plaintext);
                var decryptedData = Encoding.UTF8.GetString(plaintext);
                // ValidateTrack2Data(decryptedData, keyIdentifier); // Potentially redundant if data integrity is ensured by AES-GCM
                return decryptedData;
            }
        }

        private byte[] GenerateNonce()
        {
            var nonce = new byte[AesGcmNonceSize];
            _rng.GetBytes(nonce);
            return nonce;
        }

        private static byte[] CombineEncryptedData(byte[] iv, byte[] ciphertext, byte[] tag)
        {
            var result = new byte[iv.Length + ciphertext.Length + tag.Length];
            Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
            Buffer.BlockCopy(ciphertext, 0, result, iv.Length, ciphertext.Length);
            Buffer.BlockCopy(tag, 0, result, iv.Length + ciphertext.Length, tag.Length);
            return result;
        }

        private static (byte[] iv, byte[] ciphertext, byte[] tag) SplitEncryptedData(byte[] data)
        {
            if (data.Length < AesGcmNonceSize + AesGcmTagSize) throw new ArgumentException("Ciphertext is too short to contain IV, ciphertext, and tag.", nameof(data));
            var iv = new byte[AesGcmNonceSize];
            var tag = new byte[AesGcmTagSize];
            var ciphertext = new byte[data.Length - iv.Length - tag.Length];

            Buffer.BlockCopy(data, 0, iv, 0, iv.Length);
            Buffer.BlockCopy(data, iv.Length, ciphertext, 0, ciphertext.Length);
            Buffer.BlockCopy(data, data.Length - tag.Length, tag, 0, tag.Length);

            return (iv, ciphertext, tag);
        }
        private static void ValidateEncryptionInput(byte[] plaintext, string keyIdentifier)
        {
            if (plaintext == null) throw new ArgumentNullException(nameof(plaintext));
            if (plaintext.Length == 0) throw new ArgumentException("Plaintext cannot be empty", nameof(plaintext));
            if (plaintext.Length > MaxPlaintextLength) throw new ArgumentException($"Plaintext length cannot exceed {MaxPlaintextLength} bytes", nameof(plaintext));
            if (string.IsNullOrEmpty(keyIdentifier)) throw new ArgumentException("Key identifier cannot be empty", nameof(keyIdentifier));
        }
        private static void ValidateDecryptionInput(byte[] ciphertext, string keyIdentifier)
        {
            if (ciphertext == null) throw new ArgumentNullException(nameof(ciphertext));
            if (ciphertext.Length == 0) throw new ArgumentException("Ciphertext cannot be empty", nameof(ciphertext));
            if (ciphertext.Length > MaxCiphertextLength) throw new ArgumentException($"Ciphertext length cannot exceed {MaxCiphertextLength} bytes", nameof(ciphertext));
            if (string.IsNullOrEmpty(keyIdentifier)) throw new ArgumentException("Key identifier cannot be empty", nameof(keyIdentifier));
        }
        private static void ValidateTrack2Data(string track2Data, string keyIdentifier)
        {
            if (string.IsNullOrEmpty(track2Data)) throw new ArgumentException("Track2 data cannot be empty", nameof(track2Data));
            if (track2Data.Length > MaxTrack2Length) throw new ArgumentException($"Track2 data length cannot exceed {MaxTrack2Length} characters", nameof(track2Data));
            if (string.IsNullOrEmpty(keyIdentifier)) throw new ArgumentException("Key identifier cannot be empty", nameof(keyIdentifier));
        }
        private static void ValidateTrack2DecryptionInput(string encryptedData, string iv, string authTag, string keyIdentifier)
        {
            if (string.IsNullOrEmpty(encryptedData)) throw new ArgumentException("Encrypted data cannot be empty", nameof(encryptedData));
            if (string.IsNullOrEmpty(iv)) throw new ArgumentException("IV cannot be empty", nameof(iv));
            if (string.IsNullOrEmpty(authTag)) throw new ArgumentException("Auth tag cannot be empty", nameof(authTag));
            if (string.IsNullOrEmpty(keyIdentifier)) throw new ArgumentException("Key identifier cannot be empty", nameof(keyIdentifier));
        }
    }
}
