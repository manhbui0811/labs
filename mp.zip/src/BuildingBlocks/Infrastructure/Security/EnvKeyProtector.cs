﻿using Microsoft.Extensions.Options;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Security
{
    public class EnvKeyProtector : IKeyProtector
    {
        private readonly SecurityOptions _securityOptions;
        public EnvKeyProtector(IOptions<SecurityOptions> securityOptions)
        {
            _securityOptions = securityOptions?.Value ?? throw new ArgumentNullException(nameof(securityOptions));
        }

        public Task<byte[]> GetKeyMaterialAsync(string alias, CancellationToken cancellationToken = default)
        {

            var base64Key = Environment.GetEnvironmentVariable(alias.ToUpper());
            if (string.IsNullOrEmpty(base64Key))
            {
                if (_securityOptions.UserLocalMasterKey && alias == "DEFAULT")
                    base64Key = _securityOptions.LocalMasterKeyBase64;
                else
                    throw new InvalidOperationException($"Missing env var: {alias}");
            };

            var key = Convert.FromBase64String(base64Key);
            if (key.Length != 32)
                throw new InvalidOperationException("Master key must be 32 bytes (AES-256)");

            return Task.FromResult(key);
        }
    }
}
