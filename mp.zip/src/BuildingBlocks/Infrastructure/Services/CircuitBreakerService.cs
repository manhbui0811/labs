using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.CircuitBreaker;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.CircuitBreaker;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

public class CircuitBreakerService<TDbContext> : ICircuitBreakerService 
    where TDbContext : DbContext
{
    private readonly TDbContext _dbContext;
    private readonly ILogger<CircuitBreakerService<TDbContext>> _logger;

    public CircuitBreakerService(
        TDbContext dbContext,
        ILogger<CircuitBreakerService<TDbContext>> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<Result<T>> ExecuteAsync<T>(
        string serviceName,
        Func<Task<T>> operation,
        Func<Task<T>>? fallback = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var circuitState = await GetOrCreateCircuitStateAsync(serviceName, cancellationToken);

            if (circuitState.ShouldAttemptReset())
            {
                circuitState.HalfOpen();
                await _dbContext.SaveChangesAsync(cancellationToken);
            }

            switch (circuitState.State)
            {
                case BreakerState.Open:
                    _logger.LogWarning("Circuit breaker is OPEN for service {ServiceName}", serviceName);
                    
                    if (fallback != null)
                    {
                        var fallbackResult = await fallback();
                        return Result.Success(fallbackResult);
                    }
                    
                    return Result.Failure<T>(Error.Create(
                        "CircuitBreaker.Open", 
                        $"Circuit breaker is open for service {serviceName}"));

                case BreakerState.HalfOpen:
                    _logger.LogInformation("Circuit breaker is HALF-OPEN for service {ServiceName}, attempting operation", serviceName);
                    break;

                case BreakerState.Closed:
                    break;
            }

            var result = await operation();
            
            circuitState.RecordSuccess();
            await _dbContext.SaveChangesAsync(cancellationToken);
            
            _logger.LogDebug("Operation succeeded for service {ServiceName}", serviceName);
            return Result.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Operation failed for service {ServiceName}", serviceName);
            
            var circuitState = await GetOrCreateCircuitStateAsync(serviceName, cancellationToken);
            circuitState.RecordFailure();
            await _dbContext.SaveChangesAsync(cancellationToken);

            if (fallback != null)
            {
                try
                {
                    var fallbackResult = await fallback();
                    return Result.Success(fallbackResult);
                }
                catch (Exception fallbackEx)
                {
                    _logger.LogError(fallbackEx, "Fallback also failed for service {ServiceName}", serviceName);
                }
            }

            return Result.Failure<T>(Error.Create(
                "CircuitBreaker.OperationFailed", 
                ex.Message));
        }
    }

    public async Task<Result> ExecuteAsync(
        string serviceName,
        Func<Task> operation,
        Func<Task>? fallback = null,
        CancellationToken cancellationToken = default)
    {
        var wrappedOperation = async () =>
        {
            await operation();
            return true;
        };

        Func<Task<bool>>? wrappedFallback = null;
        if (fallback != null)
        {
            wrappedFallback = async () =>
            {
                await fallback();
                return true;
            };
        }

        var result = await ExecuteAsync(serviceName, wrappedOperation, wrappedFallback, cancellationToken);
        
        return result.IsSuccess 
            ? Result.Success() 
            : Result.Failure(result.Error);
    }

    public async Task<Result<CircuitBreakerState>> GetStateAsync(
        string serviceName, 
        CancellationToken cancellationToken = default)
    {
        try
        {
            var state = await GetOrCreateCircuitStateAsync(serviceName, cancellationToken);
            return Result.Success(state);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get circuit breaker state for service {ServiceName}", serviceName);
            return Result.Failure<CircuitBreakerState>(Error.Create(
                "CircuitBreaker.GetStateFailed", 
                "Failed to get circuit breaker state"));
        }
    }

    public async Task<Result> ResetAsync(string serviceName, CancellationToken cancellationToken = default)
    {
        try
        {
            var circuitState = await GetOrCreateCircuitStateAsync(serviceName, cancellationToken);
            circuitState.Close();
            await _dbContext.SaveChangesAsync(cancellationToken);
            
            _logger.LogInformation("Circuit breaker reset for service {ServiceName}", serviceName);
            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to reset circuit breaker for service {ServiceName}", serviceName);
            return Result.Failure(Error.Create(
                "CircuitBreaker.ResetFailed", 
                "Failed to reset circuit breaker"));
        }
    }

    private async Task<CircuitBreakerState> GetOrCreateCircuitStateAsync(
        string serviceName, 
        CancellationToken cancellationToken)
    {
        var existingState = await _dbContext.Set<CircuitBreakerState>()
            .FirstOrDefaultAsync(x => x.ServiceName == serviceName, cancellationToken);

        if (existingState != null)
        {
            return existingState;
        }

        var newState = new CircuitBreakerState(serviceName);
        _dbContext.Set<CircuitBreakerState>().Add(newState);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return newState;
    }
}


