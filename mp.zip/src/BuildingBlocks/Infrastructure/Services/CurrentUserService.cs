﻿using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using System.Security.Claims;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ClaimsPrincipal? _user;

    public CurrentUserService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
        _user = _httpContextAccessor.HttpContext?.User;
    }

    public Guid? UserId
    {
        get
        {
            var userIdClaim = _user?.FindFirstValue("system_uid");
            if (Guid.TryParse(userIdClaim, out var userId))
            {
                return userId;
            }
            return null;
        }
    }
    public string? Email => _user?.FindFirstValue(ClaimTypes.Email);

    public string? FullName => _user?.FindFirstValue(ClaimTypes.Name);

    public string? KeycloakSubject => _user?.FindFirstValue("preferred_username");

    public Guid? EntityId => throw new NotImplementedException();

    public string? IpAddress => throw new NotImplementedException();

    public string? UserAgent => throw new NotImplementedException();

    public bool IsAuthenticated => throw new NotImplementedException();

    public IEnumerable<string> GetPermissions()
    {
        throw new NotImplementedException();
    }

    public IEnumerable<string> GetRoles()
    {
        throw new NotImplementedException();
    }

    public bool HasPermission(string permission)
    {
        throw new NotImplementedException();
    }
}
