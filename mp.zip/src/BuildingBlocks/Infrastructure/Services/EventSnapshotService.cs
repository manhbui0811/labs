using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

public class EventSnapshotService<TDbContext> : IEventSnapshotService 
    where TDbContext : DbContext
{
    private readonly TDbContext _dbContext;
    private readonly ILogger<EventSnapshotService<TDbContext>> _logger;

    public EventSnapshotService(
        TDbContext dbContext,
        ILogger<EventSnapshotService<TDbContext>> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<Result> SaveSnapshotAsync<T>(
        string aggregateType,
        Guid aggregateId,
        T aggregateData,
        long version = 1,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var snapshotData = JsonSerializer.Serialize(aggregateData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = false
            });

            var existingSnapshot = await _dbContext.Set<EventSnapshot>()
                .FirstOrDefaultAsync(x => x.AggregateType == aggregateType && 
                                        x.AggregateId == aggregateId, 
                                   cancellationToken);

            if (existingSnapshot != null)
            {
                existingSnapshot.UpdateSnapshot(snapshotData, version);
                _logger.LogDebug("Updated snapshot for {AggregateType} {AggregateId} at version {Version}", 
                    aggregateType, aggregateId, version);
            }
            else
            {
                var newSnapshot = EventSnapshot.Create(aggregateType, aggregateId, snapshotData, version);
                _dbContext.Set<EventSnapshot>().Add(newSnapshot);
                _logger.LogDebug("Created new snapshot for {AggregateType} {AggregateId} at version {Version}", 
                    aggregateType, aggregateId, version);
            }

            await _dbContext.SaveChangesAsync(cancellationToken);
            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to save snapshot for {AggregateType} {AggregateId}", 
                aggregateType, aggregateId);
            return Result.Failure(Error.Create(
                "EventSnapshot.SaveFailed", 
                "Failed to save event snapshot"));
        }
    }

    public async Task<Result<T?>> GetSnapshotAsync<T>(
        string aggregateType,
        Guid aggregateId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var snapshot = await _dbContext.Set<EventSnapshot>()
                .FirstOrDefaultAsync(x => x.AggregateType == aggregateType && 
                                        x.AggregateId == aggregateId, 
                                   cancellationToken);

            if (snapshot == null)
            {
                return Result.Success<T?>(default(T));
            }

            var data = JsonSerializer.Deserialize<T>(snapshot.SnapshotData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            return Result.Success(data);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get snapshot for {AggregateType} {AggregateId}", 
                aggregateType, aggregateId);
            return Result.Failure<T?>(Error.Create(
                "EventSnapshot.GetFailed", 
                "Failed to get event snapshot"));
        }
    }

    public async Task<Result<IReadOnlyList<EventSnapshot>>> GetSnapshotsAsync(
        string aggregateType,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var snapshots = await _dbContext.Set<EventSnapshot>()
                .Where(x => x.AggregateType == aggregateType)
                .OrderByDescending(x => x.Version)
                .ToListAsync(cancellationToken);

            return Result.Success<IReadOnlyList<EventSnapshot>>(snapshots);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get snapshots for aggregate type {AggregateType}", aggregateType);
            return Result.Failure<IReadOnlyList<EventSnapshot>>(Error.Create(
                "EventSnapshot.GetSnapshotsFailed", 
                "Failed to get event snapshots"));
        }
    }
}
