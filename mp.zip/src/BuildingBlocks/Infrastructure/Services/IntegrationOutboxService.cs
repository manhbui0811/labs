using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.Outbox;
using System.Text.Json;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.Events;
using SHT.MerchantPortal.Shared.Kernel.Events;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

public class IntegrationOutboxService<TDbContext> : IIntegrationOutboxService 
    where TDbContext : DbContext
{
    private readonly TDbContext _dbContext;
    private readonly ILogger<IntegrationOutboxService<TDbContext>> _logger;

    public IntegrationOutboxService(
        TDbContext dbContext,
        ILogger<IntegrationOutboxService<TDbContext>> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<Result> EnqueueEventAsync<T>(T integrationEvent, CancellationToken cancellationToken = default) 
        where T : class, IIntegrationEvent
    {
        try
        {
            var eventData = JsonSerializer.Serialize(integrationEvent, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = false
            });

            var outboxItem = IntegrationOutboxItem.Create(
                integrationEvent.EventType,
                integrationEvent.AggregateId,
                eventData,
                integrationEvent.RequestId);

            _dbContext.Set<IntegrationOutboxItem>().Add(outboxItem);
            await _dbContext.SaveChangesAsync(cancellationToken);

            _logger.LogDebug("Integration event {EventType} enqueued with ID {OutboxId}", 
                integrationEvent.EventType, outboxItem.Id);

            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to enqueue integration event {EventType}", 
                typeof(T).Name);
            return Result.Failure(Error.Create(
                "IntegrationOutbox.EnqueueFailed", 
                "Failed to enqueue integration event"));
        }
    }

    public async Task<Result> EnqueueRichEventAsync<T>(T richEvent, CancellationToken cancellationToken = default) 
        where T : RichIntegrationEventBase
    {
        try
        {
            var eventData = richEvent.SerializeEventData();

            var outboxItem = IntegrationOutboxItem.Create(
                richEvent.EventType,
                richEvent.AggregateId,
                eventData,
                richEvent.RequestId);

            _dbContext.Set<IntegrationOutboxItem>().Add(outboxItem);
            await _dbContext.SaveChangesAsync(cancellationToken);

            _logger.LogDebug("Rich integration event {EventType} enqueued with ID {OutboxId}", 
                richEvent.EventType, outboxItem.Id);

            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to enqueue rich integration event {EventType}", 
                typeof(T).Name);
            return Result.Failure(Error.Create(
                "IntegrationOutbox.EnqueueRichFailed", 
                "Failed to enqueue rich integration event"));
        }
    }

    public async Task<Result<IReadOnlyList<IntegrationOutboxItem>>> GetPendingEventsAsync(
        int batchSize = 100, 
        CancellationToken cancellationToken = default)
    {
        try
        {
            var pendingEvents = await _dbContext.Set<IntegrationOutboxItem>()
                .Where(x => x.Status == OutboxStatus.Pending || 
                           (x.Status == OutboxStatus.Failed && x.ShouldRetry()))
                .OrderBy(x => x.CreatedAt)
                .Take(batchSize)
                .ToListAsync(cancellationToken);

            return Result.Success<IReadOnlyList<IntegrationOutboxItem>>(pendingEvents);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get pending integration events");
            return Result.Failure<IReadOnlyList<IntegrationOutboxItem>>(
                Error.Create("IntegrationOutbox.GetPendingFailed", "Failed to get pending events"));
        }
    }

    public async Task<Result> MarkEventAsProcessingAsync(Guid outboxId, CancellationToken cancellationToken = default)
    {
        try
        {
            var outboxItem = await _dbContext.Set<IntegrationOutboxItem>()
                .FirstOrDefaultAsync(x => x.Id == outboxId, cancellationToken);

            if (outboxItem == null)
            {
                return Result.Failure(Error.Create("IntegrationOutbox.NotFound", "Outbox item not found"));
            }

            outboxItem.MarkAsProcessing();
            await _dbContext.SaveChangesAsync(cancellationToken);

            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to mark event {OutboxId} as processing", outboxId);
            return Result.Failure(Error.Create("IntegrationOutbox.MarkProcessingFailed", "Failed to mark as processing"));
        }
    }

    public async Task<Result> MarkEventAsProcessedAsync(Guid outboxId, CancellationToken cancellationToken = default)
    {
        try
        {
            var outboxItem = await _dbContext.Set<IntegrationOutboxItem>()
                .FirstOrDefaultAsync(x => x.Id == outboxId, cancellationToken);

            if (outboxItem == null)
            {
                return Result.Failure(Error.Create("IntegrationOutbox.NotFound", "Outbox item not found"));
            }

            outboxItem.MarkAsProcessed();
            await _dbContext.SaveChangesAsync(cancellationToken);

            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to mark event {OutboxId} as processed", outboxId);
            return Result.Failure(Error.Create("IntegrationOutbox.MarkProcessedFailed", "Failed to mark as processed"));
        }
    }

    public async Task<Result> MarkEventAsFailedAsync(Guid outboxId, string errorMessage, CancellationToken cancellationToken = default)
    {
        try
        {
            var outboxItem = await _dbContext.Set<IntegrationOutboxItem>()
                .FirstOrDefaultAsync(x => x.Id == outboxId, cancellationToken);

            if (outboxItem == null)
            {
                return Result.Failure(Error.Create("IntegrationOutbox.NotFound", "Outbox item not found"));
            }

            outboxItem.MarkAsFailed(errorMessage);
            await _dbContext.SaveChangesAsync(cancellationToken);

            return Result.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to mark event {OutboxId} as failed", outboxId);
            return Result.Failure(Error.Create("IntegrationOutbox.MarkFailedFailed", "Failed to mark as failed"));
        }
    }
}


