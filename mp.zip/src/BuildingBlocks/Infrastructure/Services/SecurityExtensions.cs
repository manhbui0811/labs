using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.WebUtilities;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

/// <summary>
///     Provides extension methods for common security operations in the CardlessServer system.
/// </summary>
public static class SecurityExtensions
{
    /// <summary>
    ///     Calculates HMAC SHA256 signature for the given data and secret.
    /// </summary>
    /// <param name="data">The data to sign.</param>
    /// <param name="secret">The secret key for signing.</param>
    /// <returns>Base64 encoded HMAC signature.</returns>
    public static string ComputeHmacSha256(this string data, string secret)
    {
        if (string.IsNullOrEmpty(data)) throw new ArgumentNullException(nameof(data));
        if (string.IsNullOrEmpty(secret)) throw new ArgumentNullException(nameof(secret));

        var keyBytes = Encoding.UTF8.GetBytes(secret);
        var dataBytes = Encoding.UTF8.GetBytes(data);

        using var hmac = new HMACSHA256(keyBytes);
        var hashBytes = hmac.ComputeHash(dataBytes);
        return Convert.ToBase64String(hashBytes);
    }

    /// <summary>
    ///     Verifies HMAC SHA256 signature for the given data and expected signature.
    /// </summary>
    /// <param name="data">The data that was signed.</param>
    /// <param name="secret">The secret key used for signing.</param>
    /// <param name="signature">The expected signature (Base64 encoded).</param>
    /// <returns>True if the signature is valid, false otherwise.</returns>
    public static bool VerifyHmacSha256(this string data, string secret, string signature)
    {
        if (string.IsNullOrEmpty(data)) throw new ArgumentNullException(nameof(data));
        if (string.IsNullOrEmpty(secret)) throw new ArgumentNullException(nameof(secret));
        if (string.IsNullOrEmpty(signature)) throw new ArgumentNullException(nameof(signature));

        var computedSignature = ComputeHmacSha256(data, secret);
        return CryptographicOperations.FixedTimeEquals(
            Convert.FromBase64String(computedSignature),
            Convert.FromBase64String(signature));
    }

    /// <summary>
    ///     Generates a cryptographically secure random string of the specified length.
    /// </summary>
    /// <param name="length">The length of the string to generate.</param>
    /// <param name="includeSpecialChars">Whether to include special characters.</param>
    /// <returns>The generated random string.</returns>
    public static string GenerateSecureRandomString(int length, bool includeSpecialChars = false)
    {
        const string lowerChars = "abcdefghijklmnopqrstuvwxyz";
        const string upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string numberChars = "0123456789";
        const string specialChars = "!@#$%^&*()-_=+[]{}|;:,.<>?";

        var chars = lowerChars + upperChars + numberChars;
        if (includeSpecialChars) chars += specialChars;

        var randomBytes = new byte[length];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomBytes);

        var result = new char[length];
        for (var i = 0; i < length; i++) result[i] = chars[randomBytes[i] % chars.Length];

        return new string(result);
    }

    /// <summary>
    ///     Generates a URL-safe random token of the specified length.
    /// </summary>
    /// <param name="byteLength">The number of random bytes to generate.</param>
    /// <returns>Base64Url encoded random token.</returns>
    public static string GenerateUrlSafeToken(int byteLength = 32)
    {
        var randomBytes = new byte[byteLength];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomBytes);
        return WebEncoders.Base64UrlEncode(randomBytes);
    }

    /// <summary>
    ///     Masks a credit card number, showing only the first 6 and last 4 digits.
    /// </summary>
    /// <param name="cardNumber">The card number to mask.</param>
    /// <returns>The masked card number.</returns>
    public static string MaskCardNumber(this string cardNumber)
    {
        if (string.IsNullOrEmpty(cardNumber)) return cardNumber;
        if (cardNumber.Length < 10) return cardNumber; // Too short to mask effectively

        // Keep first 6 and last 4 digits, mask the rest
        var maskLength = cardNumber.Length - 10;
        return cardNumber[..6] + new string('*', maskLength) + cardNumber[(cardNumber.Length - 4)..];
    }

    /// <summary>
    ///     Checks if an IP address falls within a CIDR range.
    /// </summary>
    /// <param name="ipAddress">The IP address to check.</param>
    /// <param name="cidrRange">The CIDR range (e.g., "192.168.1.0/24").</param>
    /// <returns>True if the IP address is within the range, false otherwise.</returns>
    public static bool IsInCidrRange(this string ipAddress, string cidrRange)
    {
        if (string.IsNullOrEmpty(ipAddress) || string.IsNullOrEmpty(cidrRange))
            return false;

        try
        {
            string[] parts = cidrRange.Split('/');
            if (parts.Length != 2)
                return false;

            if (!IPAddress.TryParse(ipAddress, out var address))
                return false;

            if (!IPAddress.TryParse(parts[0], out var cidrAddress))
                return false;

            if (!int.TryParse(parts[1], out var prefixLength) || prefixLength < 0 || prefixLength > 32)
                return false;

            var addressBytes = address.GetAddressBytes();
            var cidrBytes = cidrAddress.GetAddressBytes();

            if (addressBytes.Length != cidrBytes.Length)
                return false;

            // For IPv4 addresses
            if (addressBytes.Length == 4)
            {
                var mask = prefixLength == 0 ? 0 : ~(uint.MaxValue >> prefixLength);
                var addressValue = BitConverter.ToUInt32(addressBytes, 0);
                var cidrValue = BitConverter.ToUInt32(cidrBytes, 0);

                return (addressValue & mask) == (cidrValue & mask);
            }

            // For IPv6 addresses (simplified)
            return false;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    ///     Validates an email address format.
    /// </summary>
    /// <param name="email">The email address to validate.</param>
    /// <returns>True if the email is valid, false otherwise.</returns>
    public static bool IsValidEmail(this string email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;

        try
        {
            // Simple but effective regex for email validation
            return Regex.IsMatch(email,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                RegexOptions.IgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    ///     Converts timestamp string to DateTimeOffset.
    /// </summary>
    /// <param name="timestamp">The timestamp in format 'yyyyMMddHHmmss'.</param>
    /// <returns>DateTimeOffset representation of the timestamp.</returns>
    public static DateTimeOffset? ParseQrTimestamp(this string timestamp)
    {
        if (string.IsNullOrWhiteSpace(timestamp) || timestamp.Length != 14)
            return null;

        try
        {
            var year = int.Parse(timestamp.Substring(0, 4));
            var month = int.Parse(timestamp.Substring(4, 2));
            var day = int.Parse(timestamp.Substring(6, 2));
            var hour = int.Parse(timestamp.Substring(8, 2));
            var minute = int.Parse(timestamp.Substring(10, 2));
            var second = int.Parse(timestamp.Substring(12, 2));

            return new DateTimeOffset(year, month, day, hour, minute, second, TimeSpan.Zero);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    ///     Generates a CRC16 checksum for the given data.
    /// </summary>
    /// <param name="data">The data to calculate checksum for.</param>
    /// <returns>CRC16 checksum as a hexadecimal string.</returns>
    public static string CalculateCrc16(this string data)
    {
        const ushort polynomial = 0x1021;
        ushort crc = 0xFFFF;

        var bytes = Encoding.UTF8.GetBytes(data);
        foreach (var b in bytes)
        {
            crc ^= (ushort)(b << 8);
            for (var i = 0; i < 8; i++)
                if ((crc & 0x8000) != 0)
                    crc = (ushort)((crc << 1) ^ polynomial);
                else
                    crc <<= 1;
        }

        return crc.ToString("X4");
    }

    /// <summary>
    ///     Generates a fingerprint for a device based on hardware details.
    /// </summary>
    /// <param name="machineGuid">The machine GUID (Windows) or similar unique ID.</param>
    /// <param name="processorId">CPU identifier.</param>
    /// <param name="macAddress">Network adapter MAC address.</param>
    /// <param name="diskId">Primary disk serial number.</param>
    /// <returns>A hash representing the device fingerprint.</returns>
    public static string GenerateDeviceFingerprint(
        string machineGuid,
        string processorId = null,
        string macAddress = null,
        string diskId = null)
    {
        if (string.IsNullOrEmpty(machineGuid))
            throw new ArgumentNullException(nameof(machineGuid));

        // Combine all available hardware identifiers
        var sb = new StringBuilder();
        sb.Append(machineGuid);

        if (!string.IsNullOrEmpty(processorId))
            sb.Append('|').Append(processorId);

        if (!string.IsNullOrEmpty(macAddress))
            sb.Append('|').Append(macAddress);

        if (!string.IsNullOrEmpty(diskId))
            sb.Append('|').Append(diskId);

        // Hash the combined string using SHA256
        using var sha256 = SHA256.Create();
        var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()));
        return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
    }

    /// <summary>
    ///     Converts a hexadecimal string to a byte array.
    /// </summary>
    /// <param name="hex">The hexadecimal string.</param>
    /// <returns>The byte array.</returns>
    public static byte[] HexToBytes(this string hex)
    {
        if (string.IsNullOrEmpty(hex))
            throw new ArgumentNullException(nameof(hex));

        // Remove any non-hex characters (like spaces)
        hex = Regex.Replace(hex, "[^0-9A-Fa-f]", "");

        if (hex.Length % 2 != 0)
            throw new ArgumentException("Hexadecimal string must have an even length.");

        var result = new byte[hex.Length / 2];
        for (var i = 0; i < result.Length; i++) result[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
        return result;
    }

    /// <summary>
    ///     Converts a byte array to a hexadecimal string.
    /// </summary>
    /// <param name="bytes">The byte array.</param>
    /// <returns>The hexadecimal string.</returns>
    public static string ToHexString(this byte[] bytes)
    {
        if (bytes == null || bytes.Length == 0)
            return string.Empty;

        return BitConverter.ToString(bytes).Replace("-", "");
    }

    /// <summary>
    ///     XOR encryption/decryption of a string with a key.
    /// </summary>
    /// <param name="text">The string to encrypt/decrypt.</param>
    /// <param name="key">The key to use for encryption/decryption.</param>
    /// <returns>The encrypted/decrypted string.</returns>
    public static string XorEncryptDecrypt(this string text, string key)
    {
        if (string.IsNullOrEmpty(text))
            return text;

        if (string.IsNullOrEmpty(key))
            throw new ArgumentNullException(nameof(key));

        var result = new StringBuilder();
        for (var i = 0; i < text.Length; i++) result.Append((char)(text[i] ^ key[i % key.Length]));
        return result.ToString();
    }
}


