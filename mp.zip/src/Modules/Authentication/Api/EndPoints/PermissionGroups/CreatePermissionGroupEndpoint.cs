﻿using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class CreatePermissionGroupEndpoint : Endpoint<CreatePermissionGroupCommand, PermissionGroupDto>
    {
        private readonly ISender _sender;

        public CreatePermissionGroupEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Permissions Group");
            Post("/permission-groups");
            Description(b => b.WithTags("PermissionsCustom"));
            Summary(s => s.Summary = "Tạo PermissionGroup mới");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CreatePermissionGroupCommand req, CancellationToken ct)
        {
            var rs = await _sender.Send(req, ct);
            await Send.OkAsync(rs, ct);
        }
    }
}
