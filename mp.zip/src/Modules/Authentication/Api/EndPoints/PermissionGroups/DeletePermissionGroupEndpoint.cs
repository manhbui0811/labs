﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class DeletePermissionGroupEndpoint : Endpoint<DeletePermissionGroupCommand, PermissionGroupDto>
    {
        private readonly ISender _sender;

        public DeletePermissionGroupEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Delete("/permission-groups/{id}"); // Endpoint DELETE
            Tags("Permission Group");
            Summary(s => s.Summary = "Xóa một Permission Group theo ID");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK, 400 Bad Request, 404 Not Found
            // Việc xử lý 400 và 404 sẽ thông qua FluentValidation và Global Exception Handler
        }

        public override async Task HandleAsync(DeletePermissionGroupCommand req, CancellationToken ct)
        {
            // Lấy ID từ route và gán vào command
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
