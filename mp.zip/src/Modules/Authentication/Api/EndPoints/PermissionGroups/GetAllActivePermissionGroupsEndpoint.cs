﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class GetAllActivePermissionGroupsEndpoint : EndpointWithoutRequest<List<PermissionGroupDto>>

    {
        private readonly ISender _sender;

        public GetAllActivePermissionGroupsEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Get("/permission-groups/all/active");
            Tags("Permission group");
            Summary(s => s.Summary = "Lấy tất cả các Permission Groups đang hoạt động");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var result = await _sender.Send(new GetAllActivePermissionGroupsQuery(), ct);
            await Send.OkAsync(result, ct);
        }
    }
}
