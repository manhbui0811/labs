﻿using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class GetPermissionGroupByIdEndpoint : Endpoint<GetPermissionGroupByIdRequest, PermissionGroupDto>
    {
        private readonly ISender _sender;

        public GetPermissionGroupByIdEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Permissions");
            Get("/permission-groups/{id}");
            Summary(s => s.Summary = "Lấy chi tiết PermissionGroup theo Id");
            AllowAnonymous();
        }

        public override async Task HandleAsync(GetPermissionGroupByIdRequest req, CancellationToken ct)
        {
            var result = await _sender.Send(new GetPermissionGroupByIdQuery(req.Id), ct);
            if (result is null)
                await Send.NotFoundAsync(ct);
            else
                await Send.OkAsync(result, ct);
        }
    }

    public class GetPermissionGroupByIdRequest
    {
        [FromRoute]
        public Guid Id { get; set; }
    }

}
