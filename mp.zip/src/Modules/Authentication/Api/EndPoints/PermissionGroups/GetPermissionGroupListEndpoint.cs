﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class GetPermissionGroupListEndpoint : Endpoint<GetPermissionGroupListQuery, PagedResult<PermissionGroupDto>>
    {
        private readonly ISender _sender;

        public GetPermissionGroupListEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Get("/permission-groups"); // Endpoint
            Summary(s => s.Summary = "Lấy danh sách Permission Groups với phân trang, tìm kiếm và lọc");
            Tags("Permission Group");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK, 400 Bad Request
            // Việc xử lý 400 Bad Request sẽ thông qua FluentValidation và Global Exception Handler
        }

        public override async Task HandleAsync(GetPermissionGroupListQuery req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
