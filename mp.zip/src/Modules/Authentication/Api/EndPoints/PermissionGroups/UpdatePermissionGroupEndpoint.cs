﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PermissionGroups
{
    public class UpdatePermissionGroupEndpoint : Endpoint<UpdatePermissionGroupCommand>
    {
        private readonly ISender _sender;

        public UpdatePermissionGroupEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Permissions Group");
            Put("/permission-groups/{id}");
            Summary(s => s.Summary = "Cập nhật PermissionGroup theo Id");
            AllowAnonymous();
        }

        public override async Task HandleAsync(UpdatePermissionGroupCommand req, CancellationToken ct)
        {
            await _sender.Send(req, ct);
            await Send.OkAsync();
        }
    }
}
