﻿using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Permissions
{
    public class CreatePermissionEndpoint : Endpoint<CreatePermissionCommand, PermissionDto>
    {
        private readonly ISender _sender;

        public CreatePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Permissions");
            Post("/permissions");
            Summary(s => s.Summary = "Tạo mới Permission");
            AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
            Permissions("permissions.create");
        }

        public override async Task HandleAsync(CreatePermissionCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
