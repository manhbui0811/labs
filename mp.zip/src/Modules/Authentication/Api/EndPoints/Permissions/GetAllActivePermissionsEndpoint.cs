﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Permissions
{
    public class GetAllActivePermissionsEndpoint : EndpointWithoutRequest<List<PermissionDto>>
    {
        private readonly ISender _sender;

        public GetAllActivePermissionsEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Get("/permissions/all/active"); // Endpoint mới
            Tags("Permissions");
            Summary(s => s.Summary = "Lấy tất cả Permissions đang hoạt động (không phân trang, không lọc)");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var result = await _sender.Send(new GetAllActivePermissionsQuery(), ct);
            await Send.OkAsync(result, ct);
        }
    }
}
