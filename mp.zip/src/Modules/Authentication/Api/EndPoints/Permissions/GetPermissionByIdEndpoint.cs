﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Permissions
{
    public class GetPermissionByIdEndpoint : Endpoint<GetPermissionByIdQuery, PermissionDto>
    {
        private readonly ISender _sender;

        public GetPermissionByIdEndpoint(ISender sender, ICurrentUserService currentUserService)
        {
            _sender = sender;
        }

        public override void Configure()
        {
            Tags("Permissions");
            Get("/permissions/{id}");
            Summary(s => s.Summary = "Lấy thông tin Permission theo ID");
            AllowAnonymous();
        }

        public override async Task HandleAsync(GetPermissionByIdQuery req, CancellationToken ct)
        {
            req.Id = Route<Guid>("id");
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }

}
