﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Permissions
{
    public class UpdatePermissionEndpoint : Endpoint<UpdatePermissionCommand, PermissionDto>
    {
        private readonly ISender _sender;

        public UpdatePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Permissions");
            Put("/permissions/{id}");
            Summary(s => s.Summary = "Cập nhật Permission");
            AllowAnonymous();
        }

        public override async Task HandleAsync(UpdatePermissionCommand req, CancellationToken ct)
        {
            req.Id = Route<Guid>("id");
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }

}
