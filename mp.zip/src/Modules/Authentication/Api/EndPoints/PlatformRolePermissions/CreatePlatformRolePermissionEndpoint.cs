﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRolePermissions
{
    public class CreatePlatformRolePermissionEndpoint : Endpoint<CreatePlatformRolePermissionCommand, PlatformRolePermissionDto>
    {
        private readonly ISender _sender;
        public CreatePlatformRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Post("/platform-role-permissions");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CreatePlatformRolePermissionCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
