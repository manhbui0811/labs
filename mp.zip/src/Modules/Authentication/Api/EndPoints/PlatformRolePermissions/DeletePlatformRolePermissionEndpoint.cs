﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRolePermissions
{
    public class DeletePlatformRolePermissionEndpoint : EndpointWithoutRequest
    {
        private readonly ISender _sender;
        public DeletePlatformRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Delete("/platform-role-permissions/{id}");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var id = Route<Guid>("id");
            await _sender.Send(new DeletePlatformRolePermissionCommand { Id = id }, ct);
            await Send.OkAsync(ct);
        }
    }
}
