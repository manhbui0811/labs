﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class AddPlatformRolePermissionEndpoint : Endpoint<AddPlatformRolePermissionCommand, PlatformRolePermissionDto>
    {
        private readonly ISender _sender;

        public AddPlatformRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Post("/platform-roles/{platformRoleId}/permissions/{permissionId}"); // Endpoint
            Tags("PlatformRoles");
            Summary(s => s.Summary = "Thêm một quyền vào một vai trò nền tảng");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 201 Created, 400 Bad Request, 404 Not Found, 409 Conflict
        }

        public override async Task HandleAsync(AddPlatformRolePermissionCommand req, CancellationToken ct)
        {
            // Lấy IDs từ route và gán vào command
            req.PlatformRoleId = Route<Guid>("platformRoleId");
            req.PermissionId = Route<Guid>("permissionId");

            var result = await _sender.Send(req, ct);
            await Send.CreatedAtAsync<AddPlatformRolePermissionEndpoint>(
                routeValues: $"/api/v1/platform-roles/{result.PlatformRoleId}/permissions/{result.PermissionId}",
                responseBody: result,
                cancellation: ct
            );
        }
    }
}
