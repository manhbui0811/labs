﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class CreatePlatformRoleEndpoint : Endpoint<CreatePlatformRoleCommand, PlatformRoleDto>
    {
        private readonly ISender _sender;

        public CreatePlatformRoleEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Post("/platform-roles");
            Summary(s => s.Summary = "Tạo PlatformRole mới");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CreatePlatformRoleCommand req, CancellationToken ct)
        {
            var rs = await _sender.Send(req, ct);

            await Send.OkAsync(rs, ct);
        }
    }
}
