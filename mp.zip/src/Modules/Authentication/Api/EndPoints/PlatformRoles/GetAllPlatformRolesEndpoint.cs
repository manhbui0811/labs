﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class GetAllPlatformRolesEndpoint : EndpointWithoutRequest<List<PlatformRoleDto>>
    {
        private readonly ISender _sender;

        public GetAllPlatformRolesEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Get("/platform-roles/all"); 
            Summary(s => s.Summary = "Lấy tất cả Platform Roles");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var result = await _sender.Send(new GetAllPlatformRolesQuery(), ct);
            await Send.OkAsync(result, ct);
        }
    }
}
