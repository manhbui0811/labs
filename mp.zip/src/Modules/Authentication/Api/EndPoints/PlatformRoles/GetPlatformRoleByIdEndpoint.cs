﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class GetPlatformRoleByIdEndpoint : Endpoint<GetPlatformRoleByIdQuery, PlatformRoleDto>


    {
        private readonly ISender _sender;

        public GetPlatformRoleByIdEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Get("/platform-roles/{id}");
            AllowAnonymous();
            Summary(s => s.Summary = "Lấy PlatformRole theo Code");
        }

        public override async Task HandleAsync(GetPlatformRoleByIdQuery rq, CancellationToken ct)
        {
            var result = await _sender.Send(rq, ct);
            await Send.OkAsync(result, ct);


        }
    }
}
