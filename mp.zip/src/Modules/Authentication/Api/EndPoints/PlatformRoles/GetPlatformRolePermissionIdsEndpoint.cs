﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class GetPlatformRolePermissionIdsEndpoint : Endpoint<GetPlatformRolePermissionIdsQuery, List<Guid>>
    {
        private readonly ISender _sender;

        public GetPlatformRolePermissionIdsEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Get("/platform-roles/{platformRoleId}/permission-ids"); // Endpoint mới
            Summary(s => s.Summary = "Lấy danh sách các ID quyền được gán cho một vai trò nền tảng");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK, 400 Bad Request, 404 Not Found
        }

        public override async Task HandleAsync(GetPlatformRolePermissionIdsQuery req, CancellationToken ct)
        {
            // Lấy PlatformRoleId từ route và gán vào query
            req.PlatformRoleId = Route<Guid>("platformRoleId");

            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
