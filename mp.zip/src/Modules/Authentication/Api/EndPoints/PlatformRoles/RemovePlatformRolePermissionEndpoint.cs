﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class RemovePlatformRolePermissionEndpoint : Endpoint<RemovePlatformRolePermissionCommand>
    {
        private readonly ISender _sender;

        public RemovePlatformRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Delete("/platform-roles/{platformRoleId}/permissions/{permissionId}");
            Summary(s => s.Summary = "Xóa một quyền khỏi một vai trò nền tảng");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 204 No Content, 400 Bad Request, 404 Not Found
        }

        public override async Task HandleAsync(RemovePlatformRolePermissionCommand req, CancellationToken ct)
        {
            req.PlatformRoleId = Route<Guid>("platformRoleId");
            req.PermissionId = Route<Guid>("permissionId");
            await _sender.Send(req, ct);
            await Send.NoContentAsync(ct);
        }
    }
}
