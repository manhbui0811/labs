﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.PlatformRoles
{
    public class UpdatePlatformRoleEndpoint : Endpoint<UpdatePlatformRoleCommand, PlatformRoleDto>
    {
        private readonly ISender _sender;

        public UpdatePlatformRoleEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("PlatformRoles");
            Put("/platform-roles/{id}");
            Summary(s => s.Summary = "Cập nhật PlatformRole theo Code");
            AllowAnonymous();
        }

        public override async Task HandleAsync(UpdatePlatformRoleCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
