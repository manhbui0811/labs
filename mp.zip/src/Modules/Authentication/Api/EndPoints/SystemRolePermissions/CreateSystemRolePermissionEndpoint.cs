﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRolePermissions
{
    public class CreateSystemRolePermissionEndpoint : Endpoint<CreateSystemRolePermissionCommand, SystemRolePermissionDto>
    {
        private readonly ISender _sender;

        public CreateSystemRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Post("/system-role-permissions");
            Summary(s => s.Summary = "Tạo mối liên kết giữa SystemRole và Permission");
            AllowAnonymous(); // Hoặc sử dụng Authorization tùy thuộc vào yêu cầu
        }

        public override async Task HandleAsync(CreateSystemRolePermissionCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
