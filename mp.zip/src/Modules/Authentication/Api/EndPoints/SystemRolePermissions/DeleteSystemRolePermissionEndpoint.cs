﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRolePermissions
{
    public class DeleteSystemRolePermissionEndpoint : Endpoint<DeleteSystemRolePermissionCommand, SystemRolePermissionDto>
    {
        private readonly ISender _sender;

        public DeleteSystemRolePermissionEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Delete("/system-role-permissions/{id}");
            Summary(s => s.Summary = "Xóa mối liên kết giữa SystemRole và Permission theo ID");
            AllowAnonymous(); // Hoặc sử dụng Authorization tùy thuộc vào yêu cầu
        }

        public override async Task HandleAsync(DeleteSystemRolePermissionCommand req, CancellationToken ct)
        {
            // Lấy ID từ route và gán vào command
            req.Id = Route<Guid>("id");
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }

}
