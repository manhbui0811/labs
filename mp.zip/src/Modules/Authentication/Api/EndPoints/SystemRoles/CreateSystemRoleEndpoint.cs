﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRoles
{
    public class CreateSystemRoleEndpoint : Endpoint<CreateSystemRoleCommand, SystemRoleDto>
    {
        private readonly ISender _sender;

        public CreateSystemRoleEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Post("/system-roles");
            Summary(s => s.Summary = "Tạo mới SystemRole");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CreateSystemRoleCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
