﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRoles
{
    public class GetSystemRoleByIdEndpoint : EndpointWithoutRequest<SystemRoleDto>
    {
        private readonly ISender _sender;

        public GetSystemRoleByIdEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Get("/system-roles/{id}");
            Summary(s => s.Summary = "Lấy chi tiết SystemRole theo Id");
            AllowAnonymous();
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var id = Route<Guid>("id");
            var result = await _sender.Send(new GetSystemRoleByIdQuery(id), ct);
            if (result is null)
                await Send.NotFoundAsync(ct);
            else
                await Send.OkAsync(result, ct);
        }
    }
}
