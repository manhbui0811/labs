﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRoles
{
    public class GetSystemRoleListEndpoint : Endpoint<GetSystemRoleListQuery, List<SystemRoleDto>>
    {
        private readonly ISender _sender;

        public GetSystemRoleListEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Get("/system-roles");
            Summary(s => s.Summary = "Danh sách SystemRole (lọc theo IsActive)");
            AllowAnonymous();
        }

        public override async Task HandleAsync(GetSystemRoleListQuery req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
