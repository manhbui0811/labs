﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.SystemRoles
{
    public class UpdateSystemRoleEndpoint : Endpoint<UpdateSystemRoleCommand, SystemRoleDto>
    {
        private readonly ISender _sender;

        public UpdateSystemRoleEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("SystemRole");
            Put("/system-roles/{id}");
            Summary(s => s.Summary = "Cập nhật SystemRole theo Id");
            AllowAnonymous();
        }

        public override async Task HandleAsync(UpdateSystemRoleCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
