﻿using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Users
{
    public class CreateUserEndpoint : Endpoint<CreateUserCommand, UserDto>
    {
        private readonly ISender _sender;

        public CreateUserEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("User");
            Post("/users");
            Summary(s => s.Summary = "Tạo mới User");
            Options(o => o.WithName("CreateUser"));
            AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        }

        public override async Task HandleAsync(CreateUserCommand req, CancellationToken ct)
        {
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
