﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Users
{
    public class GetUserByIdEndpoint : Endpoint<GetUserByIdQuery, UserDto>
    {
        private readonly ISender _sender;

        public GetUserByIdEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("User");
            Get("/users/{id}");
            Summary(s => s.Summary = "Lấy thông tin User theo ID");
            AllowAnonymous();
        }

        public override async Task HandleAsync(GetUserByIdQuery req, CancellationToken ct)
        {
            req.Id = Route<Guid>("id");
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
