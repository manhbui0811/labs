﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Queries;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Users
{
    public class GetUserListEndpoint : Endpoint<GetUserListQuery, PagedResult<UserDto>>
    {
        private readonly ISender _sender;

        public GetUserListEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Get("/users");
            Tags("Users");
            Summary(s => s.Summary = "Lấy danh sách người dùng với tìm kiếm và phân trang");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
            // Các status code có thể trả về: 200 OK, 400 Bad Request
            // Việc xử lý 400 Bad Request sẽ thông qua FluentValidation và Global Exception Handler
        }

        public override async Task HandleAsync(GetUserListQuery req, CancellationToken ct)
        {
            // FastEndpoints tự động bind các tham số từ query string vào req
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
