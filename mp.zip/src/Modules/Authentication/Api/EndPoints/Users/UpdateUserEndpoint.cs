﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;

namespace SHT.MerchantPortal.Modules.Authentication.Api.EndPoints.Users
{
    public class UpdateUserEndpoint : Endpoint<UpdateUserCommand, UserDto>
    {
        private readonly ISender _sender;

        public UpdateUserEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("User");
            Put("/users/{id}");
            Summary(s => s.Summary = "Cập nhật User");
            AllowAnonymous();
        }

        public override async Task HandleAsync(UpdateUserCommand req, CancellationToken ct)
        {
            req.Id = Route<Guid>("id");
            var result = await _sender.Send(req, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
