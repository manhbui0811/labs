﻿using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Behaviors
{
    public class AuthenticationTransactionalBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
        where TRequest : notnull
    {
        private readonly IAuthenticationUnitOfWork _unitOfWork;
        private readonly ILogger<AuthenticationTransactionalBehavior<TRequest, TResponse>> _logger;

        public AuthenticationTransactionalBehavior(
            IAuthenticationUnitOfWork unitOfWork,
            ILogger<AuthenticationTransactionalBehavior<TRequest, TResponse>> logger)
        {
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<TResponse> Handle(
            TRequest request,
            RequestHandlerDelegate<TResponse> next,
            CancellationToken cancellationToken)
        {
            if(GetType().Assembly != typeof(TRequest).Assembly) return await next();
            //var isTransactional = request is ITransactionalCommand ||
            //              request.GetType().GetInterfaces()
            //                     .Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(ITransactionalCommand<>));

            if (!(request is ITransactional))
            {
                return await next();
            }

            var requestName = typeof(TRequest).Name;
            TResponse response;

            try
            {
                await _unitOfWork.BeginTransactionAsync(cancellationToken);
                _logger.LogInformation("--- Begin transaction for {RequestName}", requestName);

                response = await next();

                // Commit transaction bằng IUnitOfWork
                await _unitOfWork.CommitTransactionAsync(cancellationToken);
                _logger.LogInformation("--- Commit transaction for {RequestName}", requestName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "--- Rollback transaction for {RequestName}", requestName);

                // Rollback transaction bằng IUnitOfWork
                await _unitOfWork.RollbackTransactionAsync(cancellationToken);

                throw; 
            }

            return response;
        }
    }
}
