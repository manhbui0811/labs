﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Contracts
{

    public class DevicePublicKey
    {
        public bool IsValid { get; set; }

        public byte[] PublicKeyBytes { get; set; } = Array.Empty<byte>();
    }
}
