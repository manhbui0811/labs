﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Contracts.PosSignature
{
    public class ParsedSignatureHeader
    {
        public string KeyId { get; set; } = null!;
        public string Algorithm { get; set; } = null!;
        public List<string> Components { get; set; } = new();
        public string Signature { get; set; } = null!;
        public string SignatureInput { get; set; } = null!;
        public string? ContentDigest { get; set; }
        public string? Host { get; set; }
        public DateTimeOffset? Date { get; set; }
        public DateTimeOffset? Created { get; set; }
    }
}
