﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands
{
    public class CreatePermissionGroupCommand : ITransactionalCommand<PermissionGroupDto>
    {
        public string GroupCode { get; set; } = default!;
        public string GroupName { get; set; } = default!;
        public string? Description { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class CreatePermissionGroupCommandHandler : CommandHandlerBase<CreatePermissionGroupCommand, PermissionGroupDto>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;

        public CreatePermissionGroupCommandHandler(
            IRepositoryBase<PermissionGroup> repo,
            ILogger<CreatePermissionGroupCommandHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PermissionGroupDto> Handle(CreatePermissionGroupCommand request, CancellationToken ct)
        {
            // kiểm tra code xem có thằng nào đặt code này chưa
            var exists = await _repo.ExistsAsync(p => p.GroupCode == request.GroupCode, ct);
            if (exists)
            {
                throw new ConflictException($"PermissionGroup with action code '{request.GroupCode}' already exists.");
            }

            var entity = new PermissionGroup
            {
                GroupCode = request.GroupCode,
                GroupName = request.GroupName,
                Description = request.Description,
                DisplayOrder = request.DisplayOrder,
                IsActive = request.IsActive,
            };

            entity = await _repo.AddAsync(entity, ct);

            return new PermissionGroupDto
            {
                Id = entity.Id,
                GroupCode = entity.GroupCode,
                Description = entity.Description,
                DisplayOrder = entity.DisplayOrder,
                GroupName = entity.GroupName,
                IsActive = entity.IsActive
            };

        }
    }
}
