﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands
{
    public class DeletePermissionGroupCommand : ITransactionalCommand<PermissionGroupDto>
    {
        public Guid Id { get; set; }
    }

    // Validator cho DeletePermissionGroupCommand
    public class DeletePermissionGroupCommandValidator : AbstractValidatorBase<DeletePermissionGroupCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Permission Group ID cannot be empty.");
        }
    }

    // Handler cho DeletePermissionGroupCommand
    public class DeletePermissionGroupCommandHandler : CommandHandlerBase<DeletePermissionGroupCommand, PermissionGroupDto>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;
        private readonly IRepositoryBase<Permission> _permissionRepo;

        public DeletePermissionGroupCommandHandler(
            ILogger<DeletePermissionGroupCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PermissionGroup> repo,
            IRepositoryBase<Permission> permissionRepo
       )
            : base(logger, currentUser)
        {
            _repo = repo;
            _permissionRepo = permissionRepo;
        }

        public override async Task<PermissionGroupDto> Handle(DeletePermissionGroupCommand request, CancellationToken cancellationToken)
        {
            var entity = await _repo.GetByIdAsync(request.Id, cancellationToken);
            if (entity == null)
            {
                throw new NotFoundException($"Permission Group with ID '{request.Id}' not found.");
            }
            var exists = await _permissionRepo.ExistsAsync(_ => _.PermissionGroupId == request.Id);

            if (exists)
            {
                throw new ConflictException($"Permission Group with ID '{request.Id}' đã được sử dụng");
            }

            await _repo.DeleteAsync(entity, cancellationToken);
            // Trả về DTO của nhóm quyền đã xóa
            return new PermissionGroupDto
            {
                Id = entity.Id,
                GroupCode = entity.GroupCode,
                GroupName = entity.GroupName,
                Description = entity.Description,
                DisplayOrder = entity.DisplayOrder,
                IsActive = entity.IsActive
            };
        }
    }
}
