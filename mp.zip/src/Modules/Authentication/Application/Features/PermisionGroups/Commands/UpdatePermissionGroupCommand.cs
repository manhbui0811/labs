﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands
{
    public class UpdatePermissionGroupCommand : ITransactionalCommand
    {
        public Guid Id { get; set; }
        public string GroupCode { get; set; } = default!;
        public string GroupName { get; set; } = default!;
        public string? Description { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; }
    }

    public class UpdatePermissionGroupCommandHandler : CommandHandlerBase<UpdatePermissionGroupCommand>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;

        public UpdatePermissionGroupCommandHandler(
            IRepositoryBase<PermissionGroup> repo,
            ILogger<UpdatePermissionGroupCommandHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task Handle(UpdatePermissionGroupCommand request, CancellationToken ct)
        {
            var entity = await _repo.GetByIdAsync(request.Id, ct);
            if (entity is null)
                throw new NotFoundException($"PermissionGroup with Id '{request.Id}' not found.");
            if (!(entity.GroupCode == request.GroupCode))
            {
                var check = await _repo.ExistsAsync(_ => _.GroupCode == request.GroupCode, ct);
                if (check)
                {
                    throw new ConflictException($"PermissionGroup with code '{request.GroupCode}' already exists.");
                }


            }
            entity.GroupCode = request.GroupCode;
            entity.GroupName = request.GroupName;
            entity.Description = request.Description;
            entity.DisplayOrder = request.DisplayOrder;
            entity.IsActive = request.IsActive;
            await _repo.UpdateAsync(entity, ct);
        }
    }
}
