﻿using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs
{
    public class PermissionGroupDto
    {
        public Guid Id { get; set; }
        public string GroupCode { get; set; } = default!;
        public string GroupName { get; set; } = default!;
        public string? Description { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; }
    }

    public class CreatePermissionGroupValidator : AbstractValidatorBase<CreatePermissionGroupCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.GroupCode)
                .NotEmpty().WithMessage("GroupCode cannot be empty.");

            RuleFor(x => x.GroupName)
                .NotEmpty().WithMessage("GroupName cannot be empty.");
        }
    }
    public class UpdatePermissionGroupValidator : AbstractValidatorBase<UpdatePermissionGroupCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.GroupCode)
                .NotEmpty().WithMessage("GroupCode cannot be empty.");

            RuleFor(x => x.GroupName)
                .NotEmpty().WithMessage("GroupName cannot be empty.");
        }
    }

}
