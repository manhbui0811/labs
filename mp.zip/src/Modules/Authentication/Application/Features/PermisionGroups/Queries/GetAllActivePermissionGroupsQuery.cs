﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries
{
    public class GetAllActivePermissionGroupsQuery : IQuery<List<PermissionGroupDto>>
    {
    }
    public sealed class GetAllActivePermissionGroupsQueryHandler : QueryHandlerBase<GetAllActivePermissionGroupsQuery, List<PermissionGroupDto>>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;

        public GetAllActivePermissionGroupsQueryHandler(
            IRepositoryBase<PermissionGroup> repo,
            ILogger<GetAllActivePermissionGroupsQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<List<PermissionGroupDto>> Handle(GetAllActivePermissionGroupsQuery request, CancellationToken ct)
        {
            var activePermissionGroups = await _repo.FindAllAsync(pg => pg.IsActive, ct);
            var groupDtos = activePermissionGroups
                .Select(pg => new PermissionGroupDto
                {
                    Id = pg.Id,
                    GroupCode = pg.GroupCode,
                    GroupName = pg.GroupName,
                    IsActive = true
                })
                .OrderBy(x => x.DisplayOrder)
                .ThenBy(x => x.GroupName)
                .ToList();

            return groupDtos;
        }
    }

}
