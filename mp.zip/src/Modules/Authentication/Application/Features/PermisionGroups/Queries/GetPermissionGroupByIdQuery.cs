﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries
{
    public class GetPermissionGroupByIdQuery : IQuery<PermissionGroupDto?>
    {
        public Guid Id { get; set; }

        public GetPermissionGroupByIdQuery(Guid id) => Id = id;
    }

    public class GetPermissionGroupByIdQueryHandler : QueryHandlerBase<GetPermissionGroupByIdQuery, PermissionGroupDto?>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;

        public GetPermissionGroupByIdQueryHandler(
            IRepositoryBase<PermissionGroup> repo,
            ILogger<GetPermissionGroupByIdQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PermissionGroupDto?> Handle(GetPermissionGroupByIdQuery request, CancellationToken ct)
        {
            var entity = await _repo.GetByIdAsync(request.Id, ct);
            return entity == null ? null : new PermissionGroupDto
            {
                Id = entity.Id,
                GroupCode = entity.GroupCode,
                GroupName = entity.GroupName,
                Description = entity.Description,
                DisplayOrder = entity.DisplayOrder,
                IsActive = entity.IsActive
            };
        }
    }
}
