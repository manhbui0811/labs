﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Helpers;
using System.Linq.Expressions;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PermisionGroups.Queries
{
    public class GetPermissionGroupListQuery : IQuery<PagedResult<PermissionGroupDto>>
    {
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? Keyword { get; set; } // Tìm kiếm theo GroupCode hoặc GroupName
        public bool? IsActive { get; set; } // Lọc theo trạng thái hoạt động
    }

    // Validator cho GetPermissionGroupListQuery
    public class GetPermissionGroupListQueryValidator : AbstractValidatorBase<GetPermissionGroupListQuery>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Page)
                .GreaterThanOrEqualTo(1).WithMessage("Page must be greater than or equal to 1.");

            RuleFor(x => x.PageSize)
                .GreaterThanOrEqualTo(1).WithMessage("PageSize must be greater than or equal to 1.");

            OptionalString(nameof(GetPermissionGroupListQuery.Keyword), 255);
        }
    }

    // Handler cho GetPermissionGroupListQuery
    public sealed class GetPermissionGroupListHandler : QueryHandlerBase<GetPermissionGroupListQuery, PagedResult<PermissionGroupDto>>
    {
        private readonly IRepositoryBase<PermissionGroup> _repo;

        public GetPermissionGroupListHandler(
            IRepositoryBase<PermissionGroup> repo,
            ILogger<GetPermissionGroupListHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PagedResult<PermissionGroupDto>> Handle(GetPermissionGroupListQuery request, CancellationToken ct)
        {
            Expression<Func<PermissionGroup, bool>>? predicate = null;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                // Tìm kiếm theo từ khóa trong GroupCode HOẶC GroupName (không phân biệt chữ hoa, chữ thường)
                string lowerKeyword = request.Keyword.ToLower();
                predicate = predicate.And(x =>
                    (x.GroupCode != null && x.GroupCode.ToLower().Contains(lowerKeyword)) ||
                    (x.GroupName != null && x.GroupName.ToLower().Contains(lowerKeyword))
                );
            }

            if (request.IsActive.HasValue)
            {
                // Lọc theo trạng thái IsActive
                predicate = predicate.And(x => x.IsActive == request.IsActive.Value);
            }

            // Lấy dữ liệu phân trang từ repository
            var pagedData = await _repo.GetPagedAsync(
                request.Page,
                request.PageSize,
                predicate,
                orderBy: x => x.DisplayOrder, // Sắp xếp mặc định theo DisplayOrder
                ascending: true,
                ct
            );

            // Chuyển đổi sang DTO mà không dùng mapper
            var groupDtos = pagedData.Items.Select(x => new PermissionGroupDto
            {
                Id = x.Id,
                GroupCode = x.GroupCode,
                GroupName = x.GroupName,
                Description = x.Description,
                DisplayOrder = x.DisplayOrder,
                IsActive = x.IsActive,
            }).ToList();

            return new PagedResult<PermissionGroupDto>(
                groupDtos,
                pagedData.TotalCount,
                pagedData.PageNumber,
                pagedData.PageSize
            );
        }
    }
}
