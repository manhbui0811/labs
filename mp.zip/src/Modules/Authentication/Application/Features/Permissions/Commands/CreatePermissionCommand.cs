﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Commands
{
    public class CreatePermissionCommand : ITransactionalCommand<PermissionDto>
    {
        public string ActionCode { get; set; } = null!;
        public string Module { get; set; } = null!;
        public string? Description { get; set; }
        public Guid PermissionGroupId { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class CreatePermissionCommandValidator : AbstractValidatorBase<CreatePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RequiredString(nameof(CreatePermissionCommand.ActionCode), 100);
            RequiredString(nameof(CreatePermissionCommand.Module), 100);
            OptionalString(nameof(CreatePermissionCommand.Description), 255);
            RuleFor(x => x.PermissionGroupId)
                .NotEmpty().WithMessage("PermissionGroupId cannot be empty.");
        }
    }

    public class CreatePermissionCommandHandler : CommandHandlerBase<CreatePermissionCommand, PermissionDto>
    {
        private readonly IRepositoryBase<Permission> _permissionRepo;
        private readonly IRepositoryBase<PermissionGroup> _permissionGroupRepo;

        public CreatePermissionCommandHandler(
            ILogger<CreatePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<Permission> permissionRepo,
            IRepositoryBase<PermissionGroup> permissionGroupRepo)
            : base(logger, currentUser)
        {
            _permissionRepo = permissionRepo;
            _permissionGroupRepo = permissionGroupRepo;
        }

        public override async Task<PermissionDto> Handle(CreatePermissionCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra sự tồn tại của PermissionGroup
            var permissionGroupExists = await _permissionGroupRepo.ExistsAsync(pg => pg.Id == request.PermissionGroupId, cancellationToken);
            if (!permissionGroupExists)
            {
                throw new NotFoundException($"PermissionGroup with id '{request.PermissionGroupId}' not found.");
            }

            // Kiểm tra tính duy nhất của ActionCode
            var actionCodeExists = await _permissionRepo.ExistsAsync(p => p.ActionCode == request.ActionCode, cancellationToken);
            if (actionCodeExists)
            {
                throw new ConflictException($"Permission with action code '{request.ActionCode}' already exists.");
            }

            var entity = new Permission
            {
                ActionCode = request.ActionCode,
                Module = request.Module,
                Description = request.Description,
                PermissionGroupId = request.PermissionGroupId,
                IsActive = request.IsActive,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
            };

            await _permissionRepo.AddAsync(entity, cancellationToken);

            return new PermissionDto
            {
                Id = entity.Id,
                ActionCode = entity.ActionCode,
                Module = entity.Module,
                Description = entity.Description,
                PermissionGroupId = entity.PermissionGroupId,
                IsActive = entity.IsActive
            };
        }
    }

}