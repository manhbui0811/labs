﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Commands
{
    public class DeletePermissionCommand : ITransactionalCommand<PermissionDto>
    {
        public Guid Id { get; set; }
    }
    // Handler cho DeletePermissionCommand
    public class DeletePermissionCommandHandler : CommandHandlerBase<DeletePermissionCommand, PermissionDto>
    {
        private readonly IRepositoryBase<Permission> _repo;

        public DeletePermissionCommandHandler(
            ILogger<DeletePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<Permission> repo)
            : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PermissionDto> Handle(DeletePermissionCommand request, CancellationToken cancellationToken)
        {
            var entity = await _repo.GetByIdAsync(request.Id, cancellationToken);
            if (entity == null)
            {
                throw new NotFoundException($"Permission with ID '{request.Id}' not found.");
            }
            await _repo.DeleteAsync(entity, cancellationToken);

            // Trả về DTO của quyền đã xóa
            return new PermissionDto
            {
                Id = entity.Id,
                ActionCode = entity.ActionCode,
                Module = entity.Module,
                Description = entity.Description,
                PermissionGroupId = entity.PermissionGroupId,
                IsActive = entity.IsActive
            };
        }
    }
}
