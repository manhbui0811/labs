﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Commands
{
    public class UpdatePermissionCommand : ITransactionalCommand<PermissionDto>
    {
        public Guid Id { get; set; }
        public string ActionCode { get; set; } = null!;
        public string Module { get; set; } = null!;
        public string? Description { get; set; }
        public Guid PermissionGroupId { get; set; }
        public bool IsActive { get; set; }
    }
    public class UpdatePermissionCommandValidator : AbstractValidatorBase<UpdatePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Id cannot be empty.");
            RequiredString(nameof(UpdatePermissionCommand.ActionCode), 100);
            RequiredString(nameof(UpdatePermissionCommand.Module), 100);
            OptionalString(nameof(UpdatePermissionCommand.Description), 255);

            RuleFor(x => x.PermissionGroupId)
                .NotEmpty().WithMessage("PermissionGroupId cannot be empty.");
        }
    }
    public class UpdatePermissionCommandHandler : CommandHandlerBase<UpdatePermissionCommand, PermissionDto>
    {
        private readonly IRepositoryBase<Permission> _permissionRepo;
        private readonly IRepositoryBase<PermissionGroup> _permissionGroupRepo;

        public UpdatePermissionCommandHandler(
            ILogger<UpdatePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<Permission> permissionRepo,
            IRepositoryBase<PermissionGroup> permissionGroupRepo)
            : base(logger, currentUser)
        {
            _permissionRepo = permissionRepo;
            _permissionGroupRepo = permissionGroupRepo;
        }

        public override async Task<PermissionDto> Handle(UpdatePermissionCommand request, CancellationToken cancellationToken)
        {
            // Tìm Permission để cập nhật
            var entity = await _permissionRepo.GetByIdAsync(request.Id, cancellationToken);
            if (entity is null)
            {
                throw new NotFoundException($"Permission with id '{request.Id}' not found.");
            }

            // Kiểm tra sự tồn tại của PermissionGroup
            var permissionGroupExists = await _permissionGroupRepo.ExistsAsync(pg => pg.Id == request.PermissionGroupId, cancellationToken);
            if (!permissionGroupExists)
            {
                throw new NotFoundException($"PermissionGroup with id '{request.PermissionGroupId}' not found.");
            }

            // Kiểm tra tính duy nhất của ActionCode (không bao gồm chính entity đang cập nhật)
            var actionCodeExists = await _permissionRepo.ExistsAsync(p => p.Id != request.Id && p.ActionCode == request.ActionCode, cancellationToken);
            if (actionCodeExists)
            {
                throw new ConflictException($"Permission with action code '{request.ActionCode}' already exists.");
            }

            entity.ActionCode = request.ActionCode;
            entity.Module = request.Module;
            entity.Description = request.Description;
            entity.PermissionGroupId = request.PermissionGroupId;
            entity.IsActive = request.IsActive;
            entity.UpdatedAt = DateTime.UtcNow;

            await _permissionRepo.UpdateAsync(entity, cancellationToken);

            return new PermissionDto
            {
                Id = entity.Id,
                ActionCode = entity.ActionCode,
                Module = entity.Module,
                Description = entity.Description,
                PermissionGroupId = entity.PermissionGroupId,
                IsActive = entity.IsActive
            };
        }
    }
}