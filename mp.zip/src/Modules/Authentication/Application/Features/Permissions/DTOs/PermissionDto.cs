﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs
{
    public class PermissionDto
    {
        public Guid Id { get; set; }
        public string ActionCode { get; set; } = null!;
        public string Module { get; set; } = null!;
        public string? Description { get; set; }
        public Guid PermissionGroupId { get; set; }
        public bool IsActive { get; set; }
    }
}
