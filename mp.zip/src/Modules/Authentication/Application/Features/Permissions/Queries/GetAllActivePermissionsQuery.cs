﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Queries
{
    public class GetAllActivePermissionsQuery : IQuery<List<PermissionDto>>
    {
    }
    public sealed class GetAllActivePermissionsQueryHandler : QueryHandlerBase<GetAllActivePermissionsQuery, List<PermissionDto>>
    {
        private readonly IRepositoryBase<Permission> _repo;

        public GetAllActivePermissionsQueryHandler(
            IRepositoryBase<Permission> repo,
            ILogger<GetAllActivePermissionsQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<List<PermissionDto>> Handle(GetAllActivePermissionsQuery request, CancellationToken ct)
        {
            // Lấy tất cả các Permission đang hoạt động
            var activePermissions = await _repo.FindAllAsync(p => p.IsActive, ct);

            // Chuyển đổi sang DTO và sắp xếp mặc định theo Module, sau đó ActionCode
            var permissionDtos = activePermissions
                .Select(p => new PermissionDto
                {
                    Id = p.Id,
                    ActionCode = p.ActionCode,
                    Module = p.Module,
                    Description = p.Description,
                    PermissionGroupId = p.PermissionGroupId,
                    IsActive = p.IsActive,
                })
                .OrderBy(x => x.Module)
                .ThenBy(x => x.ActionCode)
                .ToList();
            return permissionDtos;
        }
    }
}
