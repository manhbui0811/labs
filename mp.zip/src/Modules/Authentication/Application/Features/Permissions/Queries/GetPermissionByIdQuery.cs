﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Queries
{
    public class GetPermissionByIdQuery : IQuery<PermissionDto>
    {
        public Guid Id { get; set; }
    }

    public class GetPermissionByIdQueryHandler : QueryHandlerBase<GetPermissionByIdQuery, PermissionDto>
    {
        private readonly IRepositoryBase<Permission> _permissionReadRepo;
        public GetPermissionByIdQueryHandler(
            ILogger<GetPermissionByIdQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<Permission> permissionReadRepo)
            : base(logger, currentUser)
        {
            _permissionReadRepo = permissionReadRepo;
        }

        public override async Task<PermissionDto> Handle(GetPermissionByIdQuery request, CancellationToken cancellationToken)
        {

            var entity = await _permissionReadRepo.GetByIdAsync(request.Id, cancellationToken);
            if (entity is null)
            {
                throw new NotFoundException($"Permission with id '{request.Id}' not found.");
            }

            return new PermissionDto
            {
                Id = entity.Id,
                ActionCode = entity.ActionCode,
                Module = entity.Module,
                Description = entity.Description,
                PermissionGroupId = entity.PermissionGroupId,
                IsActive = entity.IsActive
            };
        }
    }
}
