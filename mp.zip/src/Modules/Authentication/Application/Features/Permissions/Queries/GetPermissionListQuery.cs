﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Helpers;
using System.Linq.Expressions;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.Queries
{
    public class GetPermissionListQuery : IQuery<PagedResult<PermissionDto>>
    {
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? Keyword { get; set; } // Tìm kiếm theo ActionCode hoặc Module
        public bool? IsActive { get; set; } // Lọc theo trạng thái hoạt động
    }

    // Validator cho GetPermissionListQuery
    public class GetPermissionListQueryValidator : AbstractValidatorBase<GetPermissionListQuery>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Page)
                .GreaterThanOrEqualTo(1).WithMessage("Page must be greater than or equal to 1.");

            RuleFor(x => x.PageSize)
                .GreaterThanOrEqualTo(1).WithMessage("PageSize must be greater than or equal to 1.");

            OptionalString(nameof(GetPermissionListQuery.Keyword), 255);
        }
    }

    // Handler cho GetPermissionListQuery
    public sealed class GetPermissionListHandler : QueryHandlerBase<GetPermissionListQuery, PagedResult<PermissionDto>>
    {
        private readonly IRepositoryBase<Permission> _repo;

        public GetPermissionListHandler(
            IRepositoryBase<Permission> repo,
            ILogger<GetPermissionListHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PagedResult<PermissionDto>> Handle(GetPermissionListQuery request, CancellationToken ct)
        {
            Expression<Func<Permission, bool>>? predicate = null;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                // Tìm kiếm theo từ khóa trong ActionCode HOẶC Module (không phân biệt chữ hoa, chữ thường)
                string lowerKeyword = request.Keyword.ToLower();
                predicate = predicate.And(x =>
                    (x.ActionCode != null && x.ActionCode.ToLower().Contains(lowerKeyword)) ||
                    (x.Module != null && x.Module.ToLower().Contains(lowerKeyword))
                );
            }

            if (request.IsActive.HasValue)
            {
                // Lọc theo trạng thái IsActive
                predicate = predicate.And(x => x.IsActive == request.IsActive.Value);
            }

            // Lấy dữ liệu phân trang từ repository
            var pagedData = await _repo.GetPagedAsync(
                request.Page,
                request.PageSize,
                predicate,
                orderBy: x => x.Module, // Sắp xếp mặc định theo Module, sau đó ActionCode
                ascending: true,
                ct
            );

            // Chuyển đổi sang DTO mà không dùng mapper
            var permissionDtos = pagedData.Items.Select(x => new PermissionDto
            {
                Id = x.Id,
                ActionCode = x.ActionCode,
                Module = x.Module,
                Description = x.Description,
                PermissionGroupId = x.PermissionGroupId,
                IsActive = x.IsActive,
            }).ToList();

            return new PagedResult<PermissionDto>(
                permissionDtos,
                pagedData.TotalCount,
                pagedData.PageNumber,
                pagedData.PageSize
            );
        }
    }

}
