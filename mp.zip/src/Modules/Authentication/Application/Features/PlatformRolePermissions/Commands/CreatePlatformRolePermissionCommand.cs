﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.Commands
{
    public class CreatePlatformRolePermissionCommand : ICommand<PlatformRolePermissionDto>
    {
        public Guid PlatformRoleId { get; set; }
        public Guid PermissionId { get; set; }
    }

    public class CreatePlatformRolePermissionCommandValidator : AbstractValidatorBase<CreatePlatformRolePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.PlatformRoleId)
                .NotEmpty().WithMessage("PlatformRoleId cannot be empty.");
            RuleFor(x => x.PermissionId)
                .NotEmpty().WithMessage("PermissionId cannot be empty.");
        }
    }

    public class CreatePlatformRolePermissionHandler : CommandHandlerBase<CreatePlatformRolePermissionCommand, PlatformRolePermissionDto>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _repository;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepository;
        private readonly IRepositoryBase<Permission> _permissionRepository;

        public CreatePlatformRolePermissionHandler(
            IRepositoryBase<PlatformRolePermission> repository,
            IRepositoryBase<PlatformRole> platformRoleRepository,
            IRepositoryBase<Permission> permissionRepository,
            ILogger<CreatePlatformRolePermissionHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repository = repository;
            _platformRoleRepository = platformRoleRepository;
            _permissionRepository = permissionRepository;
        }

        public override async Task<PlatformRolePermissionDto> Handle(CreatePlatformRolePermissionCommand request, CancellationToken ct)
        {
            var exits = await _platformRoleRepository.ExistsAsync(x => x.Id == request.PlatformRoleId, ct);
            if (!exits)
            {
                throw new NotFoundException("PlatformRole");
            }
            exits = await _permissionRepository.ExistsAsync(x => x.Id == request.PermissionId, ct);
            if (!exits)
            {
                throw new NotFoundException("Permission");
            }


            var entity = new PlatformRolePermission
            {
                PlatformRoleId = request.PlatformRoleId,
                PermissionId = request.PermissionId,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            await _repository.AddAsync(entity, ct);

            return new PlatformRolePermissionDto
            {
                PlatformRoleId = entity.PlatformRoleId,
                PermissionId = entity.PermissionId,
            };
        }
    }
}
