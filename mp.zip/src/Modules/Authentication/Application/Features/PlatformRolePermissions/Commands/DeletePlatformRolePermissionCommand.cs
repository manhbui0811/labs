﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.Commands
{
    public class DeletePlatformRolePermissionCommand : ICommand, ITransactionalCommand
    {
        public Guid Id { get; set; }
    }

    public class DeletePlatformRolePermissionHandler : CommandHandlerBase<DeletePlatformRolePermissionCommand>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _repository;

        public DeletePlatformRolePermissionHandler(
            IRepositoryBase<PlatformRolePermission> repository,
            ILogger<DeletePlatformRolePermissionHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repository = repository;
        }

        public override async Task Handle(DeletePlatformRolePermissionCommand request, CancellationToken cancellationToken)
        {
            var entity = await _repository.FindAsync(_ => _.Id == request.Id, cancellationToken);
            if (entity == null)
                throw new NotFoundException($"PlatformRolePermission {request.Id} not found");

            await _repository.DeleteAsync(entity, cancellationToken);
        }
    }
}
