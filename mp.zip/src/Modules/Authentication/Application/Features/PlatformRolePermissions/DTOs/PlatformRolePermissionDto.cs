﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.DTOs
{

    public class PlatformRolePermissionDto
    {
        public Guid PlatformRoleId { get; set; }
        public Guid PermissionId { get; set; }
    }
}
