﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRolePermissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands
{
    public class AddPlatformRolePermissionCommand : ITransactionalCommand<PlatformRolePermissionDto>
    {
        public Guid PlatformRoleId { get; set; }
        public Guid PermissionId { get; set; }
    }

    /// <summary>
    /// Validator cho AddPlatformRolePermissionCommand.
    /// </summary>
    public class AddPlatformRolePermissionCommandValidator : AbstractValidatorBase<AddPlatformRolePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.PlatformRoleId)
                .NotEmpty().WithMessage("PlatformRoleId cannot be empty.");

            RuleFor(x => x.PermissionId)
                .NotEmpty().WithMessage("PermissionId cannot be empty.");
        }
    }

    /// <summary>
    /// Handler cho AddPlatformRolePermissionCommand.
    /// </summary>
    public class AddPlatformRolePermissionCommandHandler : CommandHandlerBase<AddPlatformRolePermissionCommand, PlatformRolePermissionDto>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _platformRolePermissionRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;
        private readonly IRepositoryBase<Permission> _permissionRepo;

        public AddPlatformRolePermissionCommandHandler(
            ILogger<AddPlatformRolePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PlatformRolePermission> platformRolePermissionRepo,
            IRepositoryBase<PlatformRole> platformRoleRepo,
            IRepositoryBase<Permission> permissionRepo)
            : base(logger, currentUser)
        {
            _platformRolePermissionRepo = platformRolePermissionRepo;
            _platformRoleRepo = platformRoleRepo;
            _permissionRepo = permissionRepo;
        }

        public override async Task<PlatformRolePermissionDto> Handle(AddPlatformRolePermissionCommand request, CancellationToken cancellationToken)
        {
            // 1. Kiểm tra sự tồn tại của Platform Role
            var platformRoleExists = await _platformRoleRepo.ExistsAsync(r => r.Id == request.PlatformRoleId, cancellationToken);
            if (!platformRoleExists)
            {
                throw new NotFoundException($"Platform Role with ID '{request.PlatformRoleId}' not found.");
            }

            // 2. Kiểm tra sự tồn tại của Permission
            var permissionExists = await _permissionRepo.ExistsAsync(p => p.Id == request.PermissionId, cancellationToken);
            if (!permissionExists)
            {
                throw new NotFoundException($"Permission with ID '{request.PermissionId}' not found.");
            }

            // 3. Kiểm tra xem ánh xạ đã tồn tại chưa để tránh trùng lặp
            var existingMapping = await _platformRolePermissionRepo.FindAsync(
                prp => prp.PlatformRoleId == request.PlatformRoleId && prp.PermissionId == request.PermissionId,
                cancellationToken
            );
            if (existingMapping != null)
            {
                throw new ConflictException($"Permission '{request.PermissionId}' is already assigned to Platform Role '{request.PlatformRoleId}'.");
            }

            // 4. Tạo entity ánh xạ mới
            var newMapping = new PlatformRolePermission
            {
                Id = Guid.NewGuid(),
                PlatformRoleId = request.PlatformRoleId,
                PermissionId = request.PermissionId,
            };
            await _platformRolePermissionRepo.AddAsync(newMapping, cancellationToken);
            Logger.LogInformation("Permission '{PermissionId}' successfully assigned to Platform Role '{PlatformRoleId}'.", request.PermissionId, request.PlatformRoleId);

            return new PlatformRolePermissionDto
            {
                PlatformRoleId = newMapping.PlatformRoleId,
                PermissionId = newMapping.PermissionId
            };
        }
    }
}
