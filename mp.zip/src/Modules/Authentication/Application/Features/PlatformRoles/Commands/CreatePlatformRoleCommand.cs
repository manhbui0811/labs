﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands
{
    public class CreatePlatformRoleCommand : ITransactionalCommand<PlatformRoleDto>
    {
        public string RoleCode { get; set; } = default!;
        public string RoleName { get; set; } = default!;
        public string? Description { get; set; }
        public Guid? ParentRoleId { get; set; }
        public bool IsActive { get; set; }
    }
    public class CreatePlatformRoleCommandValidator : AbstractValidatorBase<CreatePlatformRoleCommand>
    {
        protected override void ConfigureRules()
        {
            RequiredString(nameof(CreatePlatformRoleCommand.RoleCode), 100);
            RequiredString(nameof(CreatePlatformRoleCommand.RoleName), 200);
        }
    }
    public class CreatePlatformRoleHandler : CommandHandlerBase<CreatePlatformRoleCommand, PlatformRoleDto>
    {
        private readonly IRepositoryBase<PlatformRole> _repo;

        public CreatePlatformRoleHandler(
            IRepositoryBase<PlatformRole> repo,
            ILogger<CreatePlatformRoleHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser) => _repo = repo;

        public override async Task<PlatformRoleDto> Handle(CreatePlatformRoleCommand cmd, CancellationToken ct)
        {
            var exists = await _repo.ExistsAsync(pg => pg.RoleCode == cmd.RoleCode, ct);
            if (exists)
            {
                throw new Exception($"PlatformRole with code '{cmd.RoleCode}' already exists.");
            }

            if (cmd.ParentRoleId != null)
            {
                var parentExists = await _repo.ExistsAsync(pg => pg.Id == cmd.ParentRoleId, ct);
                if (!parentExists)
                {
                    throw new Exception($"Parent PlatformRole with ID '{cmd.ParentRoleId}' does not exist.");
                }
            }

            var entity = new PlatformRole
            {
                RoleCode = cmd.RoleCode,
                RoleName = cmd.RoleName,
                Description = cmd.Description,
                ParentRoleId = cmd.ParentRoleId,
                IsActive = cmd.IsActive,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            await _repo.AddAsync(entity, ct);

            return new PlatformRoleDto
            {
                Id = entity.Id,
                RoleCode = entity.RoleCode,
                RoleName = entity.RoleName,
                Description = entity.Description,
                ParentRoleId = entity.ParentRoleId,
                IsActive = entity.IsActive
            };
        }
    }
}
