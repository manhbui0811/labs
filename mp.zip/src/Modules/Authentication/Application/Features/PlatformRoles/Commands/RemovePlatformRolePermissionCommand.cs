﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands
{
    public class RemovePlatformRolePermissionCommand : ITransactionalCommand
    {
        public Guid PlatformRoleId { get; set; }
        public Guid PermissionId { get; set; }
    }

    /// Handler cho RemovePlatformRolePermissionCommand.
    /// </summary>
    public class RemovePlatformRolePermissionCommandHandler : CommandHandlerBase<RemovePlatformRolePermissionCommand>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _platformRolePermissionRepo;

        public RemovePlatformRolePermissionCommandHandler(
            ILogger<RemovePlatformRolePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PlatformRolePermission> platformRolePermissionRepo)
            : base(logger, currentUser)
        {
            _platformRolePermissionRepo = platformRolePermissionRepo;
        }

        public override async Task Handle(RemovePlatformRolePermissionCommand request, CancellationToken cancellationToken)
        {
            // Tìm entity ánh xạ cần xóa
            var existingMapping = await _platformRolePermissionRepo.FindAsync(
                prp => prp.PlatformRoleId == request.PlatformRoleId && prp.PermissionId == request.PermissionId,
                cancellationToken
            );

            if (existingMapping == null)
            {
                throw new NotFoundException($"Permission '{request.PermissionId}' is not assigned to Platform Role '{request.PlatformRoleId}'.");
            }

            // Xóa entity
            await _platformRolePermissionRepo.DeleteAsync(existingMapping, cancellationToken);
            return;
        }
    }
}
