﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands
{
    public sealed class UpdatePlatformRoleCommand : ITransactionalCommand<PlatformRoleDto>
    {
        public Guid Id { get; set; } = default!;
        public string RoleName { get; set; } = default!;
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }
    public class UpdatePlatformRoleCommandValidator : AbstractValidatorBase<UpdatePlatformRoleCommand>
    {
        protected override void ConfigureRules()
        {
            RequiredString(nameof(UpdatePlatformRoleCommand.RoleName), 200);
        }
    }
    public class UpdatePlatformRoleHandler : CommandHandlerBase<UpdatePlatformRoleCommand, PlatformRoleDto>
    {
        private readonly IRepositoryBase<PlatformRole> _repo;

        public UpdatePlatformRoleHandler(
            IRepositoryBase<PlatformRole> repo,
            ILogger<UpdatePlatformRoleHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser) => _repo = repo;

        public override async Task<PlatformRoleDto> Handle(UpdatePlatformRoleCommand cmd, CancellationToken ct)
        {
            var entity = await _repo.FindAsync(x => x.Id == cmd.Id, ct)
                         ?? throw new NotFoundException("PlatformRole");


            entity.RoleName = cmd.RoleName;
            entity.Description = cmd.Description;
            entity.IsActive = cmd.IsActive;
            entity.UpdatedAt = DateTime.UtcNow;
            await _repo.UpdateAsync(entity, ct);
            return new PlatformRoleDto
            {
                RoleCode = entity.RoleCode,
                RoleName = entity.RoleName,
                Description = entity.Description,
                ParentRoleId = entity.ParentRoleId,
                IsActive = entity.IsActive,
            };
        }
    }
}
