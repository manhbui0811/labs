﻿using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs
{
    public class PlatformRoleDto
    {
        public Guid Id { get; set; }
        public string RoleCode { get; set; } = default!;
        public string RoleName { get; set; } = default!;
        public string? Description { get; set; }
        public Guid? ParentRoleId { get; set; }
        public bool IsActive { get; set; }
    }





}
