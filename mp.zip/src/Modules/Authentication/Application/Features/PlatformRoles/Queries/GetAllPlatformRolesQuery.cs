﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries
{
    public class GetAllPlatformRolesQuery : IQuery<List<PlatformRoleDto>>
    {
    }

    public sealed class GetAllPlatformRolesQueryHandler : QueryHandlerBase<GetAllPlatformRolesQuery, List<PlatformRoleDto>>
    {
        private readonly IRepositoryBase<PlatformRole> _repo;

        public GetAllPlatformRolesQueryHandler(
            IRepositoryBase<PlatformRole> repo,
            ILogger<GetAllPlatformRolesQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<List<PlatformRoleDto>> Handle(GetAllPlatformRolesQuery request, CancellationToken ct)
        {
            // Lấy tất cả dữ liệu từ repository mà không cần predicate
            var roles = await _repo.FindAllAsync(null, ct);

            // Chuyển đổi sang DTO và sắp xếp mặc định theo RoleName
            var roleDtos = roles.Select(x => new PlatformRoleDto
            {
                Id = x.Id,
                RoleCode = x.RoleCode,
                RoleName = x.RoleName,
                Description = x.Description,
                ParentRoleId = x.ParentRoleId,
                IsActive = x.IsActive,
            }).OrderBy(x => x.RoleName).ToList();

            return roleDtos;
        }
    }
}
