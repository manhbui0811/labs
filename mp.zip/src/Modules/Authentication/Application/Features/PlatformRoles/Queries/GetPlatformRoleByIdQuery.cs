﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries
{

    public class GetPlatformRoleByIdQuery : IQuery<PlatformRoleDto>
    {
        public Guid Id { get; set; }
    }

    public class GetPlatformRoleByIdQueryHandler : QueryHandlerBase<GetPlatformRoleByIdQuery, PlatformRoleDto>
    {
        private readonly IRepositoryBase<PlatformRole> _repository;

        public GetPlatformRoleByIdQueryHandler(
            ILogger<GetPlatformRoleByIdQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PlatformRole> repository)
            : base(logger, currentUser)
        {
            _repository = repository;
        }

        public override async Task<PlatformRoleDto> Handle(GetPlatformRoleByIdQuery request, CancellationToken cancellationToken)
        {
            var entity = await _repository.FindAsync(x => x.Id == request.Id, cancellationToken);
            if (entity == null) throw new NotFoundException($"PlatformRole with id '{request.Id}' not found.");

            return new PlatformRoleDto
            {
                Id = entity.Id,
                RoleCode = entity.RoleCode,
                RoleName = entity.RoleName,
                Description = entity.Description,
                ParentRoleId = entity.ParentRoleId,
                IsActive = entity.IsActive,
            };
        }
    }
}
