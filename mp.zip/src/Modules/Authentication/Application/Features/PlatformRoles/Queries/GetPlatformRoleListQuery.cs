﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Helpers;
using System.Linq.Expressions;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries
{
    // Query để lấy danh sách Platform Roles với phân trang, tìm kiếm và lọc
    public class GetPlatformRoleListQuery : IQuery<PagedResult<PlatformRoleDto>>
    {
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? Keyword { get; set; } // Tìm kiếm theo RoleCode hoặc RoleName
        public bool? IsActive { get; set; } // Lọc theo trạng thái hoạt động
    }

    // Validator cho GetPlatformRoleListQuery
    public class GetPlatformRoleListQueryValidator : AbstractValidatorBase<GetPlatformRoleListQuery>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Page)
                .GreaterThanOrEqualTo(1).WithMessage("Page must be greater than or equal to 1.");

            RuleFor(x => x.PageSize)
                .GreaterThanOrEqualTo(1).WithMessage("PageSize must be greater than or equal to 1.");

            OptionalString(nameof(GetPlatformRoleListQuery.Keyword), 255);
        }
    }

    // Handler cho GetPlatformRoleListQuery
    public sealed class GetPlatformRoleListHandler : QueryHandlerBase<GetPlatformRoleListQuery, PagedResult<PlatformRoleDto>>
    {
        private readonly IRepositoryBase<PlatformRole> _repo;

        public GetPlatformRoleListHandler(
            IRepositoryBase<PlatformRole> repo,
            ILogger<GetPlatformRoleListHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<PagedResult<PlatformRoleDto>> Handle(GetPlatformRoleListQuery request, CancellationToken ct)
        {
            Expression<Func<PlatformRole, bool>>? predicate = null;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                // Tìm kiếm theo từ khóa trong RoleCode HOẶC RoleName (không phân biệt chữ hoa, chữ thường)
                string lowerKeyword = request.Keyword.ToLower();
                predicate = predicate.And(x =>
                    (x.RoleCode != null && x.RoleCode.ToLower().Contains(lowerKeyword)) ||
                    (x.RoleName != null && x.RoleName.ToLower().Contains(lowerKeyword))
                );
            }

            if (request.IsActive.HasValue)
            {
                // Lọc theo trạng thái IsActive
                predicate = predicate.And(x => x.IsActive == request.IsActive.Value);
            }

            // Lấy dữ liệu phân trang từ repository
            var pagedData = await _repo.GetPagedAsync(
                request.Page,
                request.PageSize,
                predicate,
                orderBy: x => x.RoleName, // Sắp xếp mặc định theo RoleName
                ascending: true,
                ct
            );

            // Chuyển đổi sang DTO mà không dùng mapper
            var roleDtos = pagedData.Items.Select(x => new PlatformRoleDto
            {
                Id = x.Id, // Đảm bảo Id được map
                RoleCode = x.RoleCode,
                RoleName = x.RoleName,
                Description = x.Description,
                ParentRoleId = x.ParentRoleId,
                IsActive = x.IsActive,
            }).ToList();

            return new PagedResult<PlatformRoleDto>(
                roleDtos,
                pagedData.TotalCount,
                pagedData.PageNumber,
                pagedData.PageSize
            );
        }
    }

}
