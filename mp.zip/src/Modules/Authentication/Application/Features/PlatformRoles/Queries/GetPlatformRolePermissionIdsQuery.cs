﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries
{
    public class GetPlatformRolePermissionIdsQuery : IQuery<List<Guid>>
    {
        public Guid PlatformRoleId { get; set; }
    }

    public sealed class GetPlatformRolePermissionIdsQueryHandler : QueryHandlerBase<GetPlatformRolePermissionIdsQuery, List<Guid>>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _platformRolePermissionRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;

        public GetPlatformRolePermissionIdsQueryHandler(
            ILogger<GetPlatformRolePermissionIdsQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PlatformRolePermission> platformRolePermissionRepo,
            IRepositoryBase<PlatformRole> platformRoleRepo)
            : base(logger, currentUser)
        {
            _platformRolePermissionRepo = platformRolePermissionRepo;
            _platformRoleRepo = platformRoleRepo;
        }

        public override async Task<List<Guid>> Handle(GetPlatformRolePermissionIdsQuery request, CancellationToken cancellationToken)
        {
            // 1. Kiểm tra sự tồn tại của Platform Role
            var platformRoleExists = await _platformRoleRepo.ExistsAsync(r => r.Id == request.PlatformRoleId, cancellationToken);
            if (!platformRoleExists)
            {
                throw new NotFoundException($"Platform Role with ID '{request.PlatformRoleId}' not found.");
            }

            // 2. Lấy tất cả các ánh xạ PermissionId cho PlatformRoleId này
            var permissionIds = (await _platformRolePermissionRepo.FindAllAsync(
                prp => prp.PlatformRoleId == request.PlatformRoleId,
                cancellationToken
            )).Select(prp => prp.PermissionId).ToList();

            return permissionIds;
        }
    }
}
