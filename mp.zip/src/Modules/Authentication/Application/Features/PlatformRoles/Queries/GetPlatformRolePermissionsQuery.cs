﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Permissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.PlatformRoles.Queries
{
    public class GetPlatformRolePermissionsQuery : IQuery<List<PermissionDto>>
    {
        public Guid PlatformRoleId { get; set; }
    }

    /// <summary>
    /// Handler cho GetPlatformRolePermissionsQuery.
    /// </summary>
    public sealed class GetPlatformRolePermissionsQueryHandler : QueryHandlerBase<GetPlatformRolePermissionsQuery, List<PermissionDto>>
    {
        private readonly IRepositoryBase<PlatformRolePermission> _platformRolePermissionRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;
        private readonly IRepositoryBase<Permission> _permissionRepo;

        public GetPlatformRolePermissionsQueryHandler(
            ILogger<GetPlatformRolePermissionsQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<PlatformRolePermission> platformRolePermissionRepo,
            IRepositoryBase<PlatformRole> platformRoleRepo,
            IRepositoryBase<Permission> permissionRepo)
            : base(logger, currentUser)
        {
            _platformRolePermissionRepo = platformRolePermissionRepo;
            _platformRoleRepo = platformRoleRepo;
            _permissionRepo = permissionRepo;
        }

        public override async Task<List<PermissionDto>> Handle(GetPlatformRolePermissionsQuery request, CancellationToken cancellationToken)
        {
            // 1. Kiểm tra sự tồn tại của Platform Role
            var platformRoleExists = await _platformRoleRepo.ExistsAsync(r => r.Id == request.PlatformRoleId, cancellationToken);
            if (!platformRoleExists)
            {
                throw new NotFoundException($"Platform Role with ID '{request.PlatformRoleId}' not found.");
            }

            // 2. Lấy tất cả các ánh xạ PermissionId cho PlatformRoleId này
            var permissionIds = (await _platformRolePermissionRepo.FindAllAsync(
                prp => prp.PlatformRoleId == request.PlatformRoleId,
                cancellationToken
            )).Select(prp => prp.PermissionId).ToList();

            if (!permissionIds.Any())
            {
                // Không có quyền nào được gán cho vai trò này, trả về danh sách rỗng
                return new List<PermissionDto>();
            }

            // 3. Lấy chi tiết các Permissions dựa trên danh sách ID đã tìm được
            var permissions = await _permissionRepo.FindAllAsync(p => permissionIds.Contains(p.Id), cancellationToken);

            // 4. Chuyển đổi sang DTO và sắp xếp mặc định
            var permissionDtos = permissions
                .Select(p => new PermissionDto
                {
                    Id = p.Id,
                    ActionCode = p.ActionCode,
                    Module = p.Module,
                    Description = p.Description,
                    PermissionGroupId = p.PermissionGroupId,
                    IsActive = p.IsActive,
                })
                .OrderBy(x => x.Module)
                .ThenBy(x => x.ActionCode)
                .ToList();

            return permissionDtos;
        }
    }
}
