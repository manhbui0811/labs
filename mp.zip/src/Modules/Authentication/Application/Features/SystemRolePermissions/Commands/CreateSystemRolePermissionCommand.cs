﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands
{
    public class CreateSystemRolePermissionCommand : ITransactionalCommand<SystemRolePermissionDto>
    {
        public Guid? SystemRoleId { get; set; }
        public Guid? PermissionId { get; set; }
    }

    public class CreateSystemRolePermissionCommandHandler : CommandHandlerBase<CreateSystemRolePermissionCommand, SystemRolePermissionDto>
    {
        private readonly IRepositoryBase<SystemRole> _systemRoleRepo;
        private readonly IRepositoryBase<Permission> _permissionRepo;
        private readonly IRepositoryBase<SystemRolePermission> _systemRolePermissionRepo;

        public CreateSystemRolePermissionCommandHandler(
            ILogger<CreateSystemRolePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<SystemRole> systemRoleRepo,
            IRepositoryBase<Permission> permissionRepo,
            IRepositoryBase<SystemRolePermission> systemRolePermissionRepo)
            : base(logger, currentUser)
        {
            _systemRoleRepo = systemRoleRepo;
            _permissionRepo = permissionRepo;
            _systemRolePermissionRepo = systemRolePermissionRepo;
        }

        public override async Task<SystemRolePermissionDto> Handle(CreateSystemRolePermissionCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra sự tồn tại của SystemRole
            var systemRoleExists = await _systemRoleRepo.ExistsAsync(x => x.Id == request.SystemRoleId, cancellationToken);
            if (!systemRoleExists)
            {
                throw new NotFoundException($"SystemRole with id '{request.SystemRoleId}' not found.");
            }

            // Kiểm tra sự tồn tại của Permission
            var permissionExists = await _permissionRepo.ExistsAsync(x => x.Id == request.PermissionId, cancellationToken);
            if (!permissionExists)
            {
                throw new NotFoundException($"Permission with id '{request.PermissionId}' not found.");
            }

            // Tạo thực thể SystemRolePermission
            var entity = new SystemRolePermission
            {
                SystemRoleId = request.SystemRoleId.Value,
                PermissionId = request.PermissionId.Value,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                // CreatedBy/UpdatedBy có thể được gán từ ICurrentUser
            };

            await _systemRolePermissionRepo.AddAsync(entity, cancellationToken);

            return new SystemRolePermissionDto
            {
                Id = entity.Id,
                SystemRoleId = entity.SystemRoleId,
                PermissionId = entity.PermissionId
            };
        }
    }
}
