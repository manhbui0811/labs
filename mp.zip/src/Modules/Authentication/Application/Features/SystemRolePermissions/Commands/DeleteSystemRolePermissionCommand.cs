﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands
{
    public class DeleteSystemRolePermissionCommand : ITransactionalCommand<SystemRolePermissionDto>
    {
        public Guid Id { get; set; }
    }

    public class DeleteSystemRolePermissionCommandHandler : CommandHandlerBase<DeleteSystemRolePermissionCommand, SystemRolePermissionDto>
    {
        private readonly IRepositoryBase<SystemRolePermission> _systemRolePermissionRepo;

        public DeleteSystemRolePermissionCommandHandler(
            ILogger<DeleteSystemRolePermissionCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<SystemRolePermission> systemRolePermissionRepo)
            : base(logger, currentUser)
        {
            _systemRolePermissionRepo = systemRolePermissionRepo;
        }

        public override async Task<SystemRolePermissionDto> Handle(DeleteSystemRolePermissionCommand request, CancellationToken cancellationToken)
        {
            // Tìm SystemRolePermission để xóa bằng ID
            var entity = await _systemRolePermissionRepo.GetByIdAsync(request.Id, cancellationToken);

            if (entity is null)
            {
                throw new NotFoundException($"SystemRolePermission with id '{request.Id}' not found.");
            }

            await _systemRolePermissionRepo.DeleteAsync(entity, cancellationToken);

            return new SystemRolePermissionDto
            {
                Id = entity.Id,
                SystemRoleId = entity.SystemRoleId,
                PermissionId = entity.PermissionId
            };
        }
    }
}
