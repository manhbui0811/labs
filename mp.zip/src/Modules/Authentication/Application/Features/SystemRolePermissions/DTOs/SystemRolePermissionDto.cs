﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.DTOs
{
    public class SystemRolePermissionDto
    {
        public Guid Id { get; set; }
        public Guid SystemRoleId { get; set; }
        public Guid PermissionId { get; set; }
    }
}
