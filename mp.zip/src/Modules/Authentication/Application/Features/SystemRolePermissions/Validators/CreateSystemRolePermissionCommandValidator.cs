﻿using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Validators
{
    public class CreateSystemRolePermissionCommandValidator : AbstractValidatorBase<CreateSystemRolePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.SystemRoleId)
                .NotEmpty().WithMessage("SystemRoleId cannot be empty.");

            RuleFor(x => x.PermissionId)
                .NotEmpty().WithMessage("PermissionId cannot be empty.");
        }
    }
}
