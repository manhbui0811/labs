﻿using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Validators
{
    public class DeleteSystemRolePermissionCommandValidator : AbstractValidatorBase<DeleteSystemRolePermissionCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Id cannot be empty.");
        }
    }
}
