﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Commands
{
    public sealed class CreateSystemRoleCommand : ITransactionalCommand<SystemRoleDto>
    {
        public string RoleCode { get; set; } = default!;
        public string RoleName { get; set; } = default!;
        public string? Description { get; set; }
        public Guid? ParentRoleId { get; set; }
        public bool IsActive { get; set; }

        public sealed class Handler : CommandHandlerBase<CreateSystemRoleCommand, SystemRoleDto>
        {
            private readonly IRepositoryBase<SystemRole> _repository;

            public Handler(
                IRepositoryBase<SystemRole> repository,
                ILogger<Handler> logger,
                ICurrentUser currentUser) : base(logger, currentUser)
            {
                _repository = repository;
            }

            public override async Task<SystemRoleDto> Handle(CreateSystemRoleCommand request, CancellationToken ct)
            {
                if (request.ParentRoleId.HasValue && await _repository.FindAsync(_ => _.Id == request.ParentRoleId.Value, ct) is null)
                    throw new NotFoundException("Parent role not found");

                var entity = new SystemRole
                {
                    RoleCode = request.RoleCode,
                    RoleName = request.RoleName,
                    Description = request.Description,
                    ParentRoleId = request.ParentRoleId,
                    IsActive = request.IsActive,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                entity = await _repository.AddAsync(entity, ct);

                return new SystemRoleDto
                {
                    Id = entity.Id,
                    RoleCode = entity.RoleCode,
                    RoleName = entity.RoleName,
                    Description = entity.Description,
                    ParentRoleId = entity.ParentRoleId,
                    IsActive = entity.IsActive,
                };
            }
        }
    }
}
