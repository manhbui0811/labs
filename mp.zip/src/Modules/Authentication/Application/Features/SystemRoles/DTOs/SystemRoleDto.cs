﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs
{
    public class SystemRoleDto
    {
        public Guid Id { get; set; } // Trả về trong DTO
        public string RoleCode { get; set; } = default!;
        public string RoleName { get; set; } = default!;
        public string? Description { get; set; }
        public Guid? ParentRoleId { get; set; }
        public bool IsActive { get; set; }
    }
}
