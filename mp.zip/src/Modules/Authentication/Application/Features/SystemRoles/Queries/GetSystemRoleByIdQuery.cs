﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Queries
{
    public sealed class GetSystemRoleByIdQuery(Guid id) : IQuery<SystemRoleDto?>
    {
        public Guid Id { get; } = id;

        public sealed class Handler : QueryHandlerBase<GetSystemRoleByIdQuery, SystemRoleDto?>
        {
            private readonly IRepositoryBase<SystemRole> _repository;

            public Handler(
                IRepositoryBase<SystemRole> repository,
                ILogger<Handler> logger,
                ICurrentUser currentUser) : base(logger, currentUser)
            {
                _repository = repository;
            }

            public override async Task<SystemRoleDto?> Handle(GetSystemRoleByIdQuery request, CancellationToken ct)
            {
                var entity = await _repository.FindAsync(_ => _.Id == request.Id, ct);
                return entity is null ? null : new SystemRoleDto
                {
                    Id = entity.Id,
                    RoleCode = entity.RoleCode,
                    RoleName = entity.RoleName,
                    Description = entity.Description,
                    ParentRoleId = entity.ParentRoleId,
                    IsActive = entity.IsActive,
                };
            }
        }
    }
}
