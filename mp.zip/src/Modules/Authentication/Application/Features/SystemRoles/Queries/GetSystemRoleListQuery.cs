﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRoles.Queries
{
    public sealed class GetSystemRoleListQuery(bool? isActive) : IQuery<List<SystemRoleDto>>
    {
        public bool? IsActive { get; } = isActive;

        public sealed class Handler : QueryHandlerBase<GetSystemRoleListQuery, List<SystemRoleDto>>
        {
            private readonly IRepositoryBase<SystemRole> _repository;

            public Handler(
                IRepositoryBase<SystemRole> repository,
                ILogger<Handler> logger,
                ICurrentUser currentUser) : base(logger, currentUser)
            {
                _repository = repository;
            }

            public override async Task<List<SystemRoleDto>> Handle(GetSystemRoleListQuery request, CancellationToken ct)
            {
                var list = await _repository.FindAllAsync(
                            x => !request.IsActive.HasValue || x.IsActive == request.IsActive,
                            ct);

                return list.Select(x => new SystemRoleDto
                {
                    Id = x.Id,
                    RoleCode = x.RoleCode,
                    RoleName = x.RoleName,
                    Description = x.Description,
                    ParentRoleId = x.ParentRoleId,
                    IsActive = x.IsActive,
                }).ToList();
            }
        }
    }
}
