﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Commands
{
    public class CreateUserCommand : ICommand<UserDto>
    {
        public string UserName { get; set; } = null!; //KeycloakSub trong 
        public string Password { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string FullName { get; set; } = null!;// FirstName + LastName => fullName
        public string UserType { get; set; } = null!;
        public Guid? PlatformRoleId { get; set; }
        public string Status { get; set; } = "active";
    }

    public class CreateUserCommandValidator : AbstractValidatorBase<CreateUserCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.UserName)
                .NotEmpty().WithMessage("UserName cannot be empty.");

            RuleFor(x => x.Password)
                .NotEmpty().WithMessage("Password cannot be empty.");

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email cannot be empty.")
                .EmailAddress().WithMessage("Email must be a valid email address.");

            RuleFor(x => x.FullName)
                .NotEmpty().WithMessage("FullName cannot be empty.");
        }
    }

    public class CreateUserCommandHandler : CommandHandlerBase<CreateUserCommand, UserDto>
    {
        private readonly IAuthenticationUnitOfWork _unitOfWork;
        private readonly IRepositoryBase<User> _userRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;
        private readonly IKeycloakService _keycloakService;

        public CreateUserCommandHandler(
            ILogger<CreateUserCommandHandler> logger,
            ICurrentUser currentUser,
            IAuthenticationUnitOfWork unitOfWork,
            IRepositoryBase<User> userRepo,
            IRepositoryBase<PlatformRole> platformRoleRepo,
            IKeycloakService keycloakService) // Inject IKeycloakService
            : base(logger, currentUser)
        {
            _unitOfWork = unitOfWork;
            _userRepo = userRepo;
            _platformRoleRepo = platformRoleRepo;
            _keycloakService = keycloakService;
        }

        public override async Task<UserDto> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            // Bắt đầu một giao dịch
            using var transaction = await _unitOfWork.BeginTransactionAsync(cancellationToken);
            try
            {
                if (request.PlatformRoleId != null)
                {
                    //Kiểm tra sự tồn tại của PlatformRole
                    var platformRoleExists = await _platformRoleRepo.ExistsAsync(r => r.Id == request.PlatformRoleId, cancellationToken);
                    if (!platformRoleExists)
                    {
                        throw new NotFoundException($"PlatformRole with id '{request.PlatformRoleId}' not found.");
                    }
                }

                // Kiểm tra tính duy nhất của Email trong DB
                var emailExists = await _userRepo.ExistsAsync(u => u.Email == request.Email, cancellationToken);
                if (emailExists)
                {
                    throw new Exception($"User with email '{request.Email}' already exists in local DB.");
                }

                // Tạo người dùng trên Keycloak
                bool createUser = await _keycloakService.CreateUserAsync(
                    request.UserName,
                    request.Email,
                    request.Password,
                    "",
                    request.FullName,
                    cancellationToken
                );


                // Nếu tạo thành công, lưu thông tin vào DB
                var entity = new User
                {
                    KeycloakSub = request.UserName, // Sử dụng ID trả về từ Keycloak
                    Email = request.Email,
                    FullName = request.FullName,
                    UserType = request.UserType,
                    PlatformRoleId = request.PlatformRoleId ?? new Guid(),
                    Status = request.Status,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                };

                await _userRepo.AddAsync(entity, cancellationToken);
                await _unitOfWork.CommitTransactionAsync();

                return new UserDto
                {
                    Id = entity.Id,
                    UserName = entity.KeycloakSub,
                    Email = entity.Email,
                    FullName = entity.FullName,
                    UserType = entity.UserType,
                    PlatformRoleId = entity.PlatformRoleId,
                    Status = entity.Status,
                    LastLoginAt = entity.LastLoginAt
                };
            }
            catch (Exception ex)
            {
                // Nếu có lỗi, rollback giao dịch và ném lại lỗi
                await transaction.RollbackAsync(cancellationToken);
                Logger.LogError(ex, "Failed to create user. Rolling back transaction.");
                throw;
            }
        }
    }
}
