﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Commands
{
    public class UpdateUserCommand : ITransactionalCommand<UserDto>
    {
        public Guid Id { get; set; }
        public string Email { get; set; } = null!;
        public string FullName { get; set; } = null!;
        public string UserType { get; set; } = null!;
        public Guid? PlatformRoleId { get; set; }
        public string Status { get; set; } = null!;
    }

    public class UpdateUserCommandValidator : AbstractValidatorBase<UpdateUserCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Id cannot be empty.");
            RuleFor(x => x.FullName)
                .NotEmpty().WithMessage("FullName cannot be empty.");
            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email cannot be empty.")
                .EmailAddress().WithMessage("Email must be a valid email address.");
            RequiredString(nameof(UpdateUserCommand.UserType), 50);
        }
    }
    public class UpdateUserCommandHandler : CommandHandlerBase<UpdateUserCommand, UserDto>
    {
        private readonly IRepositoryBase<User> _userRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;

        public UpdateUserCommandHandler(
            ILogger<UpdateUserCommandHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<User> userRepo,
            IRepositoryBase<PlatformRole> platformRoleRepo)
            : base(logger, currentUser)
        {
            _userRepo = userRepo;
            _platformRoleRepo = platformRoleRepo;
        }

        public override async Task<UserDto> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            // Tìm User để cập nhật
            var entity = await _userRepo.GetByIdAsync(request.Id, cancellationToken);
            if (entity is null)
            {
                throw new NotFoundException($"User with id '{request.Id}' not found.");
            }

            if (request.PlatformRoleId != null)
            {
                //Kiểm tra sự tồn tại của PlatformRole
                var platformRoleExists = await _platformRoleRepo.ExistsAsync(r => r.Id == request.PlatformRoleId, cancellationToken);
                if (!platformRoleExists)
                {
                    throw new NotFoundException($"PlatformRole with id '{request.PlatformRoleId}' not found.");
                }
            }

    
            var emailExists = await _userRepo.ExistsAsync(u => u.Id != request.Id && u.Email == request.Email, cancellationToken);
            if (emailExists)
            {
                throw new ConflictException($"User with email '{request.Email}' already exists.");
            }

            entity.Email = request.Email;
            entity.FullName = request.FullName;
            entity.UserType = request.UserType;
            entity.PlatformRoleId = request.PlatformRoleId?? new Guid();
            entity.Status = request.Status;
            entity.UpdatedAt = DateTime.UtcNow;

            await _userRepo.UpdateAsync(entity, cancellationToken);

            return new UserDto
            {
                Id = entity.Id,
                UserName = entity.KeycloakSub,
                Email = entity.Email,
                FullName = entity.FullName,
                UserType = entity.UserType,
                PlatformRoleId = entity.PlatformRoleId,
                Status = entity.Status,
                LastLoginAt = entity.LastLoginAt
            };
        }
    }
}
