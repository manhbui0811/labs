﻿using FluentValidation;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Commands;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs
{
    public class UserDto
    {
        public Guid Id { get; set; }
        public string UserName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? FullName { get; set; }
        public string UserType { get; set; } = null!;
        public Guid PlatformRoleId { get; set; }
        public string Status { get; set; } = null!;
        public DateTimeOffset? LastLoginAt { get; set; }
    }


   

}
