﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Queries
{
    public class GetUserByIdQuery : IQuery<UserDto>
    {
        public Guid Id { get; set; }
    }

    public class GetUserByIdQueryHandler : QueryHandlerBase<GetUserByIdQuery, UserDto>
    {
        private readonly IRepositoryBase<User> _userReadRepo;

        public GetUserByIdQueryHandler(
            ILogger<GetUserByIdQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<User> userReadRepo)
            : base(logger, currentUser)
        {
            _userReadRepo = userReadRepo;
        }

        public override async Task<UserDto> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
        {
            var entity = await _userReadRepo.GetByIdAsync(request.Id, cancellationToken);
            if (entity is null)
            {
                throw new NotFoundException($"User with id '{request.Id}' not found.");
            }

            return new UserDto
            {
                Id = entity.Id,
                UserName = entity.KeycloakSub,
                Email = entity.Email,
                FullName = entity.FullName,
                UserType = entity.UserType,
                PlatformRoleId = entity.PlatformRoleId,
                Status = entity.Status,
                LastLoginAt = entity.LastLoginAt
            };
        }
    }
}
