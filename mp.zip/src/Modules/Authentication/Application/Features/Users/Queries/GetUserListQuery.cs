﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.DTOs;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Helpers;
using System.Linq.Expressions;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Features.Users.Queries
{
    public class GetUserListQuery : IQuery<PagedResult<UserDto>>
    {
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? Keyword { get; set; }
        public string? UserType { get; set; }
        public string? Status { get; set; } // 'active'/'inactive'
        public Guid? PlatformRoleId { get; set; }
    }

    public class GetUserListQueryValidator : AbstractValidatorBase<GetUserListQuery>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.Page)
                .GreaterThanOrEqualTo(1).WithMessage("Page must be greater than or equal to 1.");

            RuleFor(x => x.PageSize)
                .GreaterThanOrEqualTo(1).WithMessage("PageSize must be greater than or equal to 1.");
        }
    }

    // Handler cho GetUserListQuery
    public class GetUserListQueryHandler : QueryHandlerBase<GetUserListQuery, PagedResult<UserDto>>
    {
        private readonly IRepositoryBase<User> _userRepo;

        public GetUserListQueryHandler(
            ILogger<GetUserListQueryHandler> logger,
            ICurrentUser currentUser,
            IRepositoryBase<User> userRepo)
            : base(logger, currentUser)
        {
            _userRepo = userRepo;
        }

        public override async Task<PagedResult<UserDto>> Handle(GetUserListQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<User, bool>>? predicate = null;
            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                // Tìm kiếm theo từ khóa trong UserName (KeycloakSub) HOẶC Email
                string lowerKeyword = request.Keyword.ToLower();
                predicate = predicate.And(u =>
                    (u.KeycloakSub != null && u.KeycloakSub.ToLower().Contains(lowerKeyword)) ||
                    (u.Email != null && u.Email.ToLower().Contains(lowerKeyword))
                );
            }

            if (!string.IsNullOrWhiteSpace(request.UserType))
            {
                predicate = predicate.And(u => u.UserType == request.UserType);
            }
            if (!string.IsNullOrWhiteSpace(request.Status))
            {
                predicate = predicate.And(u => u.Status == request.Status);
            }
            if (request.PlatformRoleId.HasValue && request.PlatformRoleId != Guid.Empty)
            {
                predicate = predicate.And(u => u.PlatformRoleId == request.PlatformRoleId.Value);
            }

            // Lấy dữ liệu phân trang từ repository
            var pagedData = await _userRepo.GetPagedAsync(
                request.Page,
                request.PageSize,
                predicate,
                orderBy: u => u.CreatedAt, 
                ascending: false,
                cancellationToken
            );

            // Chuyển đổi sang DTO mà không dùng mapper
            var userDtos = pagedData.Items.Select(u => new UserDto
            {
                Id = u.Id,
                UserName = u.KeycloakSub!, // Map KeycloakSub to UserName in DTO
                Email = u.Email,
                FullName = u.FullName,
                UserType = u.UserType,
                PlatformRoleId = u.PlatformRoleId,
                Status = u.Status,
                LastLoginAt = u.LastLoginAt
            }).ToList();

            return new PagedResult<UserDto>(
                userDtos,
                pagedData.TotalCount,
                pagedData.PageNumber,
                pagedData.PageSize
            );
        }
    }

}
