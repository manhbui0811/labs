﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Interfaces
{
    public interface IAntiReplayService
    {
        Task<bool> IsReplayAttackAsync(string keyId, DateTimeOffset created, string nonce);

        Task RecordSignatureAsync(string keyId, DateTimeOffset created, string nonce);
    }
}
