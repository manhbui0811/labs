﻿using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Interfaces
{
    public interface IAuthenticationUnitOfWork : IUnitOfWork
    {
    }
}
