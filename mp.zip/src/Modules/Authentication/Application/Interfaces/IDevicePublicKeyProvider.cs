﻿using SHT.MerchantPortal.Modules.Authentication.Application.Contracts;

namespace SHT.MerchantPortal.Modules.Authentication.Application.Interfaces
{

    public interface IDevicePublicKeyProvider
    {
        Task<DevicePublicKey?> GetPublicKeyBySerialNumberAsync(string serialNumber);

        Task<bool> IsDeviceAuthorizedAsync(string serialNumber);
    }
}
