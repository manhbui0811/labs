﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Interfaces
{
    public interface IKeycloakService
    {
        Task<bool> CreateUserAsync(
            string username,
            string email,
            string password,
            string firstName,
            string lastName,
            CancellationToken cancellationToken);
    }
}
