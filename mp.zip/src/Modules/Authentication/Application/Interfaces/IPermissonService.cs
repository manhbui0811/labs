﻿namespace SHT.MerchantPortal.Modules.Authentication.Application.Interfaces
{
    public interface IPermissionService
    {
        Task<List<string>> GetPlatformPermission(Guid Id, CancellationToken cancellationToken = default);
    }
}
