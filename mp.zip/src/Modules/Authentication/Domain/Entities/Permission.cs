﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{

    public class Permission : EntityBase<Guid>, IAuditableEntity
    {
        public string ActionCode { get; set; } = null!; // NOT NULL, UNIQUE
        public string Module { get; set; } = null!; // NOT NULL
        public string? Description { get; set; } // Optional
        public Guid PermissionGroupId { get; set; } // FK → permission_groups(id)
        public bool IsActive { get; set; } = true; // DEFAULT TRUE

        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

    }
}
