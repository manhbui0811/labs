﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{
    public class PermissionGroup : EntityBase<Guid>, IAuditableEntity
    {
        public string GroupCode { get; set; } = null!; // NOT NULL, UNIQUE
        public string GroupName { get; set; } = null!; // NOT NULL
        public string? Description { get; set; } // Optional
        public int DisplayOrder { get; set; } = 0; // DEFAULT 0
        public bool IsActive { get; set; } = true; // NOT NULL, DEFAULT TRUE
        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

    }
}
