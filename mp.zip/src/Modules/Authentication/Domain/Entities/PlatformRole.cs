﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{
    public class PlatformRole : EntityBase<Guid>, IAuditableEntity
    {
        
        public string RoleCode { get; set; } = null!; // NOT NULL, UNIQUE
        public string RoleName { get; set; } = null!; // NOT NULL
        public string? Description { get; set; } // Optional

        public Guid? ParentRoleId { get; set; } // FK → platform_roles(id)
        public bool IsActive { get; set; } = true; // DEFAULT TRUE

        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }
    }
}
