﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{
    public class SystemRole : EntityBase<Guid>, IAuditableEntity
    {
        public string RoleCode { get; set; } = null!; 
        public string RoleName { get; set; } = null!; 
        public string? Description { get; set; }

        public Guid? ParentRoleId { get; set; } 
        public bool IsActive { get; set; } = true; 

        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }


    }
}
