﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{
    public class SystemRolePermission : EntityBase<Guid>, IAuditableEntity
    {
        public Guid SystemRoleId { get; set; } // PK, FK → system_roles(id)
        public Guid PermissionId { get; set; } // PK, FK → permissions(id)

        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }


    }
}
