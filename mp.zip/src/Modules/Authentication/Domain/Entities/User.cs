﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Domain.Entities
{
    public class User  : EntityBase<Guid>, IAuditableEntity
    {
        public string KeycloakSub { get; set; } = null!; // NOT NULL, UNIQUE
        public string Email { get; set; } = null!; // NOT NULL, UNIQUE
        public string? FullName { get; set; } // Optional

        public string UserType { get; set; } = null!; // Enum: user_type (string representation in domain)
        public Guid PlatformRoleId { get; set; } // FK to platform_roles

        public string Status { get; set; } = "active"; // Enum: user_status, default = active

        public string? PreferencesJson { get; set; } // JSONB stored as string in domain layer

        public DateTimeOffset? LastLoginAt { get; set; }

        public bool IsDeleted { get; set; } = false;
        public DateTimeOffset? DeletedAt { get; set; }

        public Guid? CreatedBy { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }



    }
}
