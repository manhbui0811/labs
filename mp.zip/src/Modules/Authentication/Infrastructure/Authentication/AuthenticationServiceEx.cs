﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Authentication;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Services;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication
{
    public static class AuthenticationServiceEx
    {
        public static IServiceCollection AddAuthenticationServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Add Keycloak authentication
            services.AddKeycloakAuthentication(configuration);
            // Add POS authentication
            services.AddPosAuthentication(configuration);
            return services;
        }
        private static IServiceCollection AddKeycloakAuthentication(this IServiceCollection services, IConfiguration configuration)
        {

            var keycloakConfig = configuration.GetSection("Authentication:Keycloak");
            var authority = keycloakConfig["Authority"];
            var audience = keycloakConfig["Audience"];
            var requireHttpsMetadata = !keycloakConfig.GetValue<bool>("DisableHttpsMetadata");
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.Authority = authority;
                options.Audience = audience;
                options.MetadataAddress = $"{authority}/.well-known/openid-configuration";
                options.RequireHttpsMetadata = requireHttpsMetadata;

                if (!requireHttpsMetadata)
                {
                    options.BackchannelHttpHandler = new HttpClientHandler
                    {
                        ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
                    };
                }

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true
                };
            });

            // Keycloak-related services
            services.AddScoped<IClaimsTransformation, AuthenticationTransformer>();
            services.AddHttpClient<IKeycloakService, KeycloakService>(client =>
            {
                var keycloakBaseUrl = configuration["Authentication:Keycloak:ServerUri"] ?? "http://localhost:8080";
                client.BaseAddress = new Uri(keycloakBaseUrl);
            });
            services.AddScoped<IPermissionService, PermissionService>();

            return services;
        }

        private static IServiceCollection AddPosAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<PosAuthenticationOptions>(configuration.GetSection("Authentication:Pos"));
            services.AddAuthentication()
                .AddScheme<PosAuthenticationOptions, PosAuthenticationHandler>(
                    PosAuthenticationDefaults.AuthenticationScheme,
                    opts =>
                    {
                        configuration.GetSection("Authentication:Pos").Bind(opts);
                    });

            //// POS-specific services

            //// TODO: Replace mocks with real implementations later
            //services.AddSingleton<IDevicePublicKeyProvider, DevicePublicKeyProvider>();
            //services.AddSingleton<IAntiReplayService, AntiReplayService>();

            return services;
        }

        
    }
}
