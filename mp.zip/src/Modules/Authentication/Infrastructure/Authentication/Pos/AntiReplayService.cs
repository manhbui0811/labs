﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using System.Collections.Concurrent;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public class AntiReplayService : IAntiReplayService, IDisposable
    {
        private readonly ConcurrentDictionary<string, DateTimeOffset> _usedNonces = new();
        private readonly Timer _cleanupTimer;
        private readonly TimeSpan _nonceLifetime;
        private readonly ILogger<AntiReplayService> _logger;
        private bool _disposed;

        public AntiReplayService(IOptions<PosAuthenticationOptions> options, ILogger<AntiReplayService> logger)
        {
            _logger = logger;
            _nonceLifetime = TimeSpan.FromSeconds(options.Value.MaxSignatureAge * 2); // Double the signature age for safety

            // Cleanup expired nonces every 5 minutes
            _cleanupTimer = new Timer(CleanupExpiredNonces, null, TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(5));
        }

        public Task<bool> IsReplayAttackAsync(string keyId, DateTimeOffset created, string nonce)
        {
            ArgumentNullException.ThrowIfNull(keyId);
            ArgumentNullException.ThrowIfNull(nonce);

            var nonceKey = CreateNonceKey(keyId, nonce);

            // Check if nonce exists and is still valid
            if (_usedNonces.TryGetValue(nonceKey, out var existingTimestamp))
            {
                // If nonce exists and hasn't expired, it's a replay attack
                var isExpired = DateTimeOffset.UtcNow - existingTimestamp > _nonceLifetime;
                if (!isExpired)
                {
                    _logger.LogWarning("Replay attack detected for keyId: {KeyId}, nonce: {Nonce}", keyId, nonce);
                    return Task.FromResult(true);
                }

                // Remove expired nonce
                _usedNonces.TryRemove(nonceKey, out _);
            }

            return Task.FromResult(false);
        }

        public Task RecordSignatureAsync(string keyId, DateTimeOffset created, string nonce)
        {
            ArgumentNullException.ThrowIfNull(keyId);
            ArgumentNullException.ThrowIfNull(nonce);

            var nonceKey = CreateNonceKey(keyId, nonce);
            _usedNonces.TryAdd(nonceKey, created);

            _logger.LogDebug("Recorded signature for keyId: {KeyId}, nonce: {Nonce}", keyId, nonce);
            return Task.CompletedTask;
        }

        private static string CreateNonceKey(string keyId, string nonce)
        {
            return $"{keyId}:{nonce}";
        }

        private void CleanupExpiredNonces(object? state)
        {
            if (_disposed) return;

            try
            {
                var cutoff = DateTimeOffset.UtcNow - _nonceLifetime;
                var expiredKeys = new List<string>();

                foreach (var kvp in _usedNonces)
                {
                    if (kvp.Value < cutoff)
                    {
                        expiredKeys.Add(kvp.Key);
                    }
                }

                foreach (var key in expiredKeys)
                {
                    _usedNonces.TryRemove(key, out _);
                }

                if (expiredKeys.Count > 0)
                {
                    _logger.LogDebug("Cleaned up {Count} expired nonces", expiredKeys.Count);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during nonce cleanup");
            }
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                _cleanupTimer?.Dispose();
                _usedNonces.Clear();
                _disposed = true;
            }
        }
    }
}