﻿using SHT.MerchantPortal.Modules.Authentication.Application.Contracts;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public class DevicePublicKeyProvider : IDevicePublicKeyProvider
    {
        public Task<DevicePublicKey?> GetPublicKeyBySerialNumberAsync(string serialNumber)
        {
            return Task.FromResult<DevicePublicKey?>(new DevicePublicKey
            {
                IsValid = true,
                PublicKeyBytes = new byte[] { 1, 2, 3, 4 } // giả lập
            });
        }

        public Task<bool> IsDeviceAuthorizedAsync(string serialNumber)
        {
            // Giả lập luôn đúng
            return Task.FromResult(true);
        }
    }
}