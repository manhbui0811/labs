﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.Authentication.Application.Contracts.PosSignature;
using System.Globalization;
using System.Text.RegularExpressions;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public partial class PosAuthenticationHandler
    {
        #region Parse Headers
        private ParsedSignatureHeader? ParseHeaders()
        {
            var headers = Request.Headers;

            if (!headers.TryGetValue("signature-input", out var sigInputHeader))
            {
                Logger.LogWarning("Missing Signature-Input header");
                return null;
            }
            if (!headers.TryGetValue("signature", out var sigHeader))
            {
                Logger.LogWarning("Missing Signature header");
                return null;
            }
            var sigValue = sigHeader.ToString();
            var sigInput = sigInputHeader.ToString();

            // Ví dụ: sig1=("date" "content-digest");keyid="VFL817166";alg="rsa-pss-sha512";created=1678886400
            var match = Regex.Match(sigInput, @"^(\w+)=\(([^)]*)\);(.+)$");
            if (!match.Success)
            {
                Logger.LogWarning("Invalid Signature-Input format: {SigInput}", sigInput);
                return null;
            }

            var label = match.Groups[1].Value; // "sig1"
            var componentsRaw = match.Groups[2].Value; // "date" "content-digest"
            var paramString = match.Groups[3].Value;   // keyid="..." ;alg="..." ;created=...

            // Parse components
            var components = componentsRaw
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(c => c.Trim('"'))
                .ToList();

            // Parse params
            var parsedParams = paramString
                .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(p => p.Split('=', 2))
                .Where(p => p.Length == 2)
                .ToDictionary(
                    kv => kv[0].Trim(),
                    kv => kv[1].Trim().Trim('"'),
                    StringComparer.OrdinalIgnoreCase);

            var keyId = parsedParams.GetValueOrDefault("keyid");
            var algorithm = parsedParams.GetValueOrDefault("alg");
            var createdRaw = parsedParams.GetValueOrDefault("created");

            // created (epoch seconds)
            DateTimeOffset? created = null;
            if (!string.IsNullOrEmpty(createdRaw) && long.TryParse(createdRaw, out var unixTs))
            {
                created = DateTimeOffset.FromUnixTimeSeconds(unixTs);
            }

            // Parse Signature: sig1=:<base64 signature>:
            string? signatureBase64 = null;
            var sigMatch = Regex.Match(sigValue, @"^(\w+)=:([^:]+):$");
            if (sigMatch.Success && sigMatch.Groups[1].Value == label)
            {
                signatureBase64 = sigMatch.Groups[2].Value;
            }
            else
            {
                Logger.LogWarning("Invalid Signature format: {Sig}", sigValue);
                return null;
            }
            // Content-Digest header
            var contentDigest = headers.TryGetValue("content-digest", out var digestHeader)
                ? digestHeader.ToString()
                : null;

            // Host header
            var host = headers.TryGetValue("host", out var hostHeader)
                ? hostHeader.ToString()
                : Request.Host.Value;

            // Date header (optional)
            string? dateRaw = null;
            DateTimeOffset? dateParsed = null;
            if (headers.TryGetValue("date", out var dateHeader))
            {
                dateRaw = dateHeader.ToString();
                if (DateTimeOffset.TryParse(dateRaw, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var dt))
                {
                    dateParsed = dt;
                }
                else
                {
                    Logger.LogWarning("Invalid Date header format: {Date}", dateHeader);
                }
            }

            if (string.IsNullOrEmpty(keyId) || string.IsNullOrEmpty(algorithm))
            {
                Logger.LogWarning("Invalid Signature-Input params: {Params}", paramString);
                return null;
            }

            return new ParsedSignatureHeader
            {
                KeyId = keyId,
                Algorithm = algorithm,
                Components = components,
                Signature = signatureBase64 ?? "",
                SignatureInput = sigInput,
                Created = created,            
                Date = dateParsed,         
                ContentDigest = contentDigest,
                Host = host
            };
        }

        #endregion
    }
}
