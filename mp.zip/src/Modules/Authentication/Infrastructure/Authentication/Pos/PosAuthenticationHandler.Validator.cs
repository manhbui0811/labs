﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.Authentication.Application.Contracts.PosSignature;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public partial class PosAuthenticationHandler
    {
        #region Parse and Validate Headers


        private async Task<bool> ValidateSignatureEnvelope(ParsedSignatureHeader parsed)
        {
            return await ValidateDigestAsync(parsed) && ValidateDateHeader(parsed);
        }

        private async Task<bool> ValidateDigestAsync(ParsedSignatureHeader parsed)
        {
            if (!Options.ValidateContentDigest) return true;

            var digest = parsed.ContentDigest;
            if (string.IsNullOrEmpty(digest))
            {
                Logger.LogWarning("Missing Content-Digest header");
                return false;
            }

            if (!digest.StartsWith("SHA-256=", StringComparison.OrdinalIgnoreCase))
            {
                Logger.LogWarning("Invalid Content-Digest format: {Digest}", digest);
                return false;
            }

            var parts = digest.Split('=', 2);
            var b64 = parts[1].Trim();
            byte[] providedHash;

            try
            {
                providedHash = Convert.FromBase64String(b64);
            }
            catch (FormatException)
            {
                Logger.LogWarning("Invalid Base64 in Content-Digest: {Digest}", digest);
                return false;
            }


            Request.EnableBuffering();
            using var ms = new MemoryStream();
            await Request.Body.CopyToAsync(ms);

            ms.Position = 0;
            using var doc = JsonDocument.Parse(ms);

            // Serialize lại theo chuẩn JsonSerializer (ko thừa whitespace, newline)
            var normalizedJson = JsonSerializer.Serialize(doc.RootElement);

            // Tính hash trên normalized JSON
            using var sha = SHA256.Create();
            var hashBytes = sha.ComputeHash(Encoding.UTF8.GetBytes(normalizedJson));
            var hashBase64 = Convert.ToBase64String(hashBytes);

            Logger.LogDebug(normalizedJson);
            Logger.LogDebug(hashBase64);

            Request.Body.Position = 0;

            var isValid = CryptographicOperations.FixedTimeEquals(hashBytes, providedHash);
            if (!isValid)
            {
                Logger.LogWarning("Content-Digest mismatch. Expected {Expected}, got {Actual}",
                    Convert.ToBase64String(providedHash),
                    Convert.ToBase64String(hashBytes));
            }

            return isValid;
        }

        private bool ValidateDateHeader(ParsedSignatureHeader parsed)
        {
            if (!Options.ValidateDateHeader) return true;

            if (!parsed.Date.HasValue)
            {
                Logger.LogWarning("Missing date header");
                return false;
            }

            var age = Math.Abs((Clock.UtcNow - parsed.Date.Value).TotalSeconds);
            if (age > Options.MaxSignatureAge)
            {
                Logger.LogWarning("Signature timestamp too old. Age={AgeSeconds}s, MaxAllowed={Max}s",
                    age, Options.MaxSignatureAge);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Xây dựng chuỗi cơ sở chữ ký theo RFC 9421.
        /// </summary>
        private string GetSignatureBaseString(ParsedSignatureHeader parsed)
        {
            var sb = new StringBuilder();
            foreach (var component in parsed.Components)
            {
                // RFC 9421 yêu cầu các thành phần được thêm vào chuỗi
                // theo thứ tự chúng xuất hiện trong header 'components'.
                switch (component.ToLowerInvariant())
                {
                    case "host":
                        sb.AppendLine($"host: {parsed.Host}");
                        break;
                    case "date":
                        sb.AppendLine($"date: {parsed.Date?.ToString("R", CultureInfo.InvariantCulture)}");
                        break;
                    case "content-digest":
                        // Thêm header Content-Digest
                        if (!string.IsNullOrEmpty(parsed.ContentDigest))
                        {
                            sb.AppendLine($"content-digest: {parsed.ContentDigest}");
                        }
                        break;
                    default:
                        // Xử lý các thành phần khác nếu cần
                        break;
                }
            }
            sb.Append($"\"@signature-params\": {parsed.SignatureInput}");
            Logger.LogDebug("Signature base string:\n{BaseString}", sb.ToString());
            return sb.ToString();
        }


        private bool ValidateHmacSignature(ParsedSignatureHeader parsed, byte[] secretBytes)
        {
            var signatureBaseString = GetSignatureBaseString(parsed);
            var signatureBytes = Encoding.UTF8.GetBytes(signatureBaseString);

            byte[] computedSignature;
            try
            {
                using var hmac = new HMACSHA256(secretBytes);
                computedSignature = hmac.ComputeHash(signatureBytes);
                Logger.LogDebug(Convert.ToBase64String(computedSignature));
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error computing HMACSHA256 signature");
                return false;
            }

            byte[] providedSignature;
            try
            {
                providedSignature = Convert.FromBase64String(parsed.Signature);
            }
            catch (FormatException ex)
            {
                Logger.LogWarning(ex, "Invalid Base64 in Signature header");
                return false;
            }

            // So sánh chữ ký đã tính toán với chữ ký từ header
            var isValid = CryptographicOperations.FixedTimeEquals(computedSignature, providedSignature);
            if (!isValid)
            {
                Logger.LogWarning("Signature mismatch. Expected {Expected}, got {Actual}",
                    Convert.ToBase64String(providedSignature),
                    Convert.ToBase64String(computedSignature));
            }

            return isValid;
        }


        private bool ValidateRsaPssSignature(ParsedSignatureHeader parsed, byte[] publicKeyBytes)
        {
            var signingString = GetSignatureBaseString(parsed);
            byte[] signatureBytes;
            try
            {
                signatureBytes = Convert.FromBase64String(parsed.Signature);
            }
            catch
            {
                Logger.LogWarning("Invalid Base64 signature for RSA keyId {KeyId}", parsed.KeyId);
                return false;
            }
            try
            {
                SignWithRsaPssSha512(signingString);
                using var rsa = RSA.Create();
                rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);

                var dataBytes = Encoding.UTF8.GetBytes(signingString);
                var isValid = rsa.VerifyData(
                    dataBytes,
                    signatureBytes,
                    HashAlgorithmName.SHA512,
                    RSASignaturePadding.Pss);

                if (!isValid)
                {
                    Logger.LogWarning("RSA signature verification failed for keyId {KeyId}", parsed.KeyId);
                }

                return isValid;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "RSA signature verification error for keyId {KeyId}", parsed.KeyId);
                return false;
            }
        }
        public byte[] SignWithRsaPssSha512(string dataToSign)
        {
            try
            {
                var privateKeyPem =
@"-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCmWdnhFFmpdAr8rO2nPQzMOeFs\r\n0d7VZCigb391kN4wj9r0b26K2r7DsU+d6gLQnBVG0qDwykw/i0p21gpuwFyxnAS6A3wHSDet+X/7\r\nxEv+YwmwB0nOvpt6sUPEUv+iE5ZXOcz2wBbE8Mu6qFipA6+aaTrM7TeffZgeQyC93311RB9BSrSQ\r\nrbNjwtB6YDS+dSEFMbAkqFMtOZQTL/XwwBoFwtMrvOi71fSM+QG2NKinWLOEJb1iYqz0sS1w3JA3\r\nDFVWln59+B98eEDf+Cz3jDSSd/NCJ9qUGmBxn0Fjl0PaYg5Wsjg9n/FNIjRvZwkVoHPcLT3egLWI\r\nH1FEZgtWul+BAgMBAAECggEBAKGhOcatHDU+UBKT/1F4Sv//2Rz/idCywZqo2yIjARAUJj1MLA70\r\nXVgM5vvbTKLelPm8W626EX3IXDC85WQYubfEjP8jtZXpwFfkzUqVvvTLy7TiT/92SeFbbSnLLyCO\r\ngYv82D6EA1uVT43sVkDaGPwh9IT6lAn+YRg+RwjVprORTNXHOo+8F2Q9+V83GsBjyGHgeYDhhFUG\r\nHVyQ8gnsjl6ND4i/moXLXeT76HAkhdIiMNteFcLvT+KeNYUaxoa7dT/FkSqcp+GkK0QuIJbpHao8\r\nbjpad9zFDzHqzHIRUZx8wuBmoCu9PT8lEL2QEJtvXOv0flHyG+FFh5xvSw9PCQUCgYEAyM2g/AeG\r\nFBhIJMFh7vobEZV7lnIW6kY1q7K3UrQOm6CL797bA2ntreao0DAIH/DM3ZsV4jpuBOjdSTu/ll2A\r\nh3RX1bWAqlBcgl3QH/0WJ5siFoyp00o5Cot0Wx4b9iiBBXQYZ+bkkaFB52yN8nHWdBEbaeuL5Kv7\r\nuWNKUPHlZEsCgYEA1BPX1xon7WI0VE8HT24GpvqCJg75avd26Rwc7rHGGsWr5vB/5m6VodMMPaYr\r\n7l8a2XItnR5wemJP0gGgz5D87FcvBUf7n2yiQmmow+W6zJ+/vRcaJcP05f6SHW4p9la3rCkZPyYJ\r\nWe/ZmG7qB31FUfVp50Cx5yF7vhzIKAZWs+MCgYBxtC5yR/heLJm9ZluELM9jF5gRyqy7H+KIRPyV\r\nsiuLaE+VFkZCGpthm3j/2hLfs0TuP0EXBysBULLtIw4LoQqEqRaLhulCh5q6n1CYrID9EFUvG5uW\r\nbzL5i5npdpUywCC+68xeGVpYNE3TM571KAzdUEqLobtnUxOJGHYee7r/HQKBgFjPBm+5MEcj/K3h\r\nejo05Ow/swik9KVqg40SjLsYDtFfPaEzzRt964Mckd+vGm5zvRaZzagh+xAE41AaBnFlUcTWrYYU\r\norYcE8aj4FxIc3UE4JIafoSaDo/RjvZsD35syfV6MGxVTU0wN3qx16bTOpgboQGKAfW7+8mc2+SG\r\n4v/pAoGAUcLLGgS9eDXBocAegULy0nxcPcLLwu4xXwZ/e5KocoJRmMkvGLbVrcvKzbfYodZxh1qc\r\nsxsrtP4nOfCp/4V/jR0qF0f4kwrgs2KRpNch0cXr2YL6H6YMJHS5+AbU+bcprmIgbyc6s+LmeUIY\r\ncFkPOPCWO2mkMm8CFgknnK1w7iQ=\n-----END PRIVATE KEY-----";
                var pemFixed = privateKeyPem.Replace("\\n", "\n").Replace("\\r", "");

                using var rsa = RSA.Create();

                // Import private key (PEM base64)
                rsa.ImportFromPem(pemFixed.AsSpan());

                // Convert data thành byte[]
                var dataBytes = Encoding.UTF8.GetBytes(dataToSign);

                // Ký bằng RSA-PSS + SHA512
                var signature = rsa.SignData(
                    dataBytes,
                    HashAlgorithmName.SHA512,
                    RSASignaturePadding.Pss);

                Logger.LogDebug($"[Debug] Signature (Base64): {Convert.ToBase64String(signature)}");
                return signature;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error signing data with RSA private key");
                throw;
            }
        }
        #endregion
    }
}
