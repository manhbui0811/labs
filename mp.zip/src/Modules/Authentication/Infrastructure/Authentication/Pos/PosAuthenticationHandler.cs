﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Application.Contracts.PosSignature;
using System.Security.Claims;
using System.Text.Encodings.Web;



namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public partial class PosAuthenticationHandler : AuthenticationHandler<PosAuthenticationOptions>
    {
        private readonly IDeviceKeyProvider _deviceKeyProvider;
        [Obsolete]
        public PosAuthenticationHandler(
            IDeviceKeyProvider deviceKeyProvider,
            IOptionsMonitor<PosAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock)
            : base(options, logger, encoder, clock)
        {
            _deviceKeyProvider = deviceKeyProvider;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            try
            {
                // 1. Phân tích các header signature
                var parsed = ParseHeaders();
                if (parsed is null)
                {
                    return AuthenticateResult.Fail("Invalid signature headers");
                }
                bool isOk = false;
                // 2. Validate signature envelope
                isOk = await ValidateSignatureEnvelope(parsed);
                if (!isOk)
                {
                    return AuthenticateResult.Fail("Invalid signature envelope");
                }
                // 3. Determine

                var authContext = await DetermineAuthenticationContextAsync(parsed);
                if (authContext == null)
                {
                    Logger.LogWarning("Failed to determine authentication context for keyId: {KeyId}", parsed.KeyId);
                    return AuthenticateResult.Fail("Invalid key or device not found");
                }


                if(authContext.Context == AuthenticationContext.DailyOperations)
                {
                    isOk = ValidateHmacSignature(parsed, authContext.SigningKey);
                }
                else
                {
                    isOk = ValidateRsaPssSignature(parsed, authContext.SigningKey);

                }
                if (isOk)
                {
                    var principal = CreatePrincipal(authContext, parsed);
                    return AuthenticateResult.Success(new AuthenticationTicket(principal, Scheme.Name));
                }

                return AuthenticateResult.Fail($"Unsupported algorithm: {parsed.Algorithm}");

                //switch (parsed.Algorithm)
                //{
                //    case "HMAC-SHA256":
                //        return await ProcessHmacSHA256(parsed);
                //    case "RSA-PSS-SHA512":
                //        return await ProcessRSA_PSS_SHA512(parsed);
                //    default:
                //}
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error during POS signature authentication");
                return AuthenticateResult.Fail("Authentication error");
            }
        }

        private async Task<AuthContextInfo?> DetermineAuthenticationContextAsync(ParsedSignatureHeader signature)
        {
            // Determine context based on algorithm and endpoint
            if (signature.Algorithm == "rsa-pss-sha512")
            {
                // Provisioning context: keyId = serialNumber, need device public key
                var publicKey = await _deviceKeyProvider.GetPublicKeyBySerialNumberAsync(signature.KeyId);
                if (publicKey == null)
                {
                    return null;
                }

                return new AuthContextInfo
                {
                    Context = AuthenticationContext.Provisioning,
                    SigningKey = publicKey,
                    SerialNumber = signature.KeyId
                };
            }
            if (signature.Algorithm == "hmac-sha256")
            {
                // Daily operations context: keyId = apiKey, need HMAC secret
                var apiKeySecret = await _deviceKeyProvider.GetSecretByApiKeyAsync(signature.KeyId);
                if (apiKeySecret == null)
                {
                    return null;
                }

                return new AuthContextInfo
                {
                    Context = AuthenticationContext.DailyOperations,
                    SigningKey = apiKeySecret.HmacSecret,
                    ApiKey = apiKeySecret.ApiKey,
                    DeviceId = apiKeySecret.DeviceId,
                    TerminalId = apiKeySecret.TerminalId,
                    MerchantId = apiKeySecret.MerchantId,
                    EntityId = apiKeySecret.EntityId
                };
            }

            return null;
        }

        private ClaimsPrincipal CreatePrincipal(AuthContextInfo authContext, ParsedSignatureHeader signature)
        {
            var claims = new List<Claim>
        {
            new(ClaimTypes.AuthenticationMethod, "pos-signature"),
            new("keyid", signature.KeyId),
            new("algorithm", signature.Algorithm),
            new("auth_context", authContext.Context.ToString())
        };

            if (authContext.Context == AuthenticationContext.Provisioning)
            {
                claims.Add(new("serial_number", authContext.SerialNumber!));
            }
            else if (authContext.Context == AuthenticationContext.DailyOperations)
            {
                claims.Add(new("api_key", authContext.ApiKey!));
                claims.Add(new("device_id", authContext.DeviceId!));
                claims.Add(new("terminal_id", authContext.TerminalId!));
                claims.Add(new("merchant_id", authContext.MerchantId!));
                claims.Add(new("entity_id", authContext.EntityId.ToString()));

                // Set NameIdentifier to deviceId for daily operations
                claims.Add(new(ClaimTypes.NameIdentifier, authContext.DeviceId!));
            }

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            return new ClaimsPrincipal(identity);
        }

        private string ComputeNonce(ParsedSignatureHeader signature)
        {
            // Create a nonce from signature components and timestamp
            var components = string.Join(",", signature.Components);
            var input = $"{signature.KeyId}_{signature.Date:yyyyMMddHHmmss}_{components}";

            using var sha256 = System.Security.Cryptography.SHA256.Create();
            var hash = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
            return Convert.ToHexString(hash)[..16]; // First 16 chars
        }

        private class AuthContextInfo
        {
            public AuthenticationContext Context { get; init; }
            public byte[] SigningKey { get; init; } = Array.Empty<byte>();

            // Provisioning context
            public string? SerialNumber { get; init; }

            // Daily operations context
            public string? ApiKey { get; init; }
            public string? DeviceId { get; init; }
            public string? TerminalId { get; init; }
            public string? MerchantId { get; init; }
            public string? EntityId { get; init; }
        }

        private enum AuthenticationContext
        {
            Provisioning,
            DailyOperations
        }
    }
}
