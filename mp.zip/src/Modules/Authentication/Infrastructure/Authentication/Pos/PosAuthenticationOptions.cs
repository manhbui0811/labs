﻿using Microsoft.AspNetCore.Authentication;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication.Pos
{
    public class PosAuthenticationOptions : AuthenticationSchemeOptions
    {
        /// <summary>
        /// Maximum allowed age of the signature timestamp in seconds
        /// </summary>
        public int MaxSignatureAge { get; set; } = 300; // 5 minutes

        /// <summary>
        /// Required signature components that must be included in the signature
        /// </summary>
        public string[] RequiredComponents { get; set; } = { "date", "content-digest" };

        /// <summary>
        /// Whether to validate the Date header is within acceptable range
        /// </summary>
        public bool ValidateDateHeader { get; set; } = true;

        /// <summary>
        /// Whether to validate the Content-Digest header matches the request body
        /// </summary>
        public bool ValidateContentDigest { get; set; } = true;

        /// <summary>
        /// Whether to enable anti-replay protection
        /// </summary>
        public bool EnableAntiReplay { get; set; } = true;
    }
}
