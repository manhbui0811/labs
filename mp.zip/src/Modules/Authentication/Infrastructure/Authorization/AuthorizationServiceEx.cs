﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Authentication;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authorization.Pos;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authorization
{
    public static class AuthorizationServiceEx
    {
        public static IServiceCollection AddAuthorizationServices(this IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {
                // POS Daily Operations
                options.AddPolicy("PosDailyOperationsOnly", policy =>
                {
                    policy.AddAuthenticationSchemes(PosAuthenticationDefaults.AuthenticationScheme);
                    policy.RequireAuthenticatedUser();
                    policy.Requirements.Add(new PosAuthorizationRequirement
                    {
                        RequireDailyOperationsContext = true,
                        AllowedAuthContexts = new[] { "DailyOperations" }
                    });
                });

                // POS Provisioning
                options.AddPolicy("PosProvisioningOnly", policy =>
                {
                    policy.AddAuthenticationSchemes(PosAuthenticationDefaults.AuthenticationScheme);
                    policy.RequireAuthenticatedUser();
                    policy.Requirements.Add(new PosAuthorizationRequirement
                    {
                        RequireDailyOperationsContext = false,
                        AllowedAuthContexts = new[] { "Provisioning" }
                    });
                });
            });

            // Authorization Handlers
            services.AddSingleton<IAuthorizationHandler, PosAuthorizationHandler>();

            return services;
        }
    }
}
