﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authorization.Pos
{
    public class PosAuthorizationHandler : AuthorizationHandler<PosAuthorizationRequirement>
    {
        private readonly ILogger<PosAuthorizationHandler> _logger;

        public PosAuthorizationHandler(ILogger<PosAuthorizationHandler> logger)
        {
            _logger = logger;
        }

        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context,
            PosAuthorizationRequirement requirement)
        {
            // Check if authenticated with pos-signature scheme
            if (context.User.Identity?.AuthenticationType != "pos-signature")
            {
                _logger.LogWarning("Request not authenticated with pos-signature scheme");
                context.Fail();
                return Task.CompletedTask;
            }

            var authContext = context.User.FindFirst("auth_context")?.Value;
            if (string.IsNullOrEmpty(authContext))
            {
                _logger.LogWarning("Missing auth_context claim");
                context.Fail();
                return Task.CompletedTask;
            }

            // Check if specific auth contexts are allowed
            if (requirement.AllowedAuthContexts != null && !requirement.AllowedAuthContexts.Contains(authContext))
            {
                _logger.LogWarning("Auth context {AuthContext} not allowed. Allowed: {AllowedContexts}",
                    authContext, string.Join(", ", requirement.AllowedAuthContexts));
                context.Fail();
                return Task.CompletedTask;
            }

            // Check daily operations context requirement
            if (requirement.RequireDailyOperationsContext && authContext != "DailyOperations")
            {
                _logger.LogWarning("Daily operations context required but got: {AuthContext}", authContext);
                context.Fail();
                return Task.CompletedTask;
            }

            // For daily operations, check device claims
            if (authContext == "DailyOperations")
            {
                var deviceId = context.User.FindFirst("device_id")?.Value;
                var terminalId = context.User.FindFirst("terminal_id")?.Value;

                if (string.IsNullOrEmpty(deviceId) || string.IsNullOrEmpty(terminalId))
                {
                    _logger.LogWarning("Missing device_id or terminal_id claims for daily operations");
                    context.Fail();
                    return Task.CompletedTask;
                }
            }

            _logger.LogInformation("POS device authorization successful for auth context: {AuthContext}", authContext);
            context.Succeed(requirement);
            return Task.CompletedTask;
        }
    }
}
