﻿using Microsoft.AspNetCore.Authorization;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authorization.Pos
{
    public class PosAuthorizationRequirement : IAuthorizationRequirement
    {
        public bool RequireActiveDevice { get; init; } = true;
        public bool RequireDailyOperationsContext { get; init; } = true;
        public string[]? AllowedAuthContexts { get; init; }
    }
}
