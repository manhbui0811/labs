﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SHT.MerchantPortal.BuildingBlocks.Application.Behaviors;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Application.Behaviors;
using SHT.MerchantPortal.Modules.Authentication.Application.Features.SystemRolePermissions.Validators;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authentication;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Authorization;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddAuthenticationModule(this IServiceCollection services, IConfiguration configuration)
        {
            AddDatabase(services, configuration);
            AddAuthenticationAndAuthorization(services, configuration);
            AddMediatRWithBehaviors(services);
            AddCORS(services, configuration);
            return services;
        }

        private static void AddDatabase(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AuthenticationDbContext>(options =>
                options.UseNpgsql(configuration.GetConnectionString("Authentication")));

            services.AddScoped<IRepositoryBase<Permission>, AuthenticationRepository<Permission>>();
            services.AddScoped<IRepositoryBase<PermissionGroup>, AuthenticationRepository<PermissionGroup>>();
            services.AddScoped<IRepositoryBase<PlatformRole>, AuthenticationRepository<PlatformRole>>();
            services.AddScoped<IRepositoryBase<PlatformRolePermission>, AuthenticationRepository<PlatformRolePermission>>();
            services.AddScoped<IRepositoryBase<SystemRole>, AuthenticationRepository<SystemRole>>();
            services.AddScoped<IRepositoryBase<SystemRolePermission>, AuthenticationRepository<SystemRolePermission>>();
            services.AddScoped<IRepositoryBase<User>, AuthenticationRepository<User>>();

            services.AddScoped<IAuthenticationUnitOfWork, AuthenticationUnitOfWork>();
        }

        private static void AddCORS(IServiceCollection services, IConfiguration configuration)
        {
            services.AddCors(o => o.AddPolicy(SystemConstants.MerchantCorsPolicy, builder =>
            {
                builder.AllowAnyMethod()
                    .AllowAnyHeader()
                    .WithOrigins(configuration["AllowedOrigins"].Split(';'))
                    .AllowCredentials();
            }));
        }

        private static void AddAuthenticationAndAuthorization(IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthenticationServices(configuration);
            services.AddAuthorizationServices();
        }


        private static void AddMediatRWithBehaviors(IServiceCollection services)
        {
            services.AddMediatR(cfg =>
            {
                cfg.RegisterServicesFromAssembly(typeof(CreateSystemRolePermissionCommandValidator).Assembly);
            });

            services.AddValidatorsFromAssemblyContaining<CreateSystemRolePermissionCommandValidator>();
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuthenticationTransactionalBehavior<,>));
        }
    }
}
