﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence
{

    public class AuthenticationDbContext : ApplicationDbContextBase
    {
        public AuthenticationDbContext(DbContextOptions<AuthenticationDbContext> options) : base(options) { }
        public AuthenticationDbContext(
           DbContextOptions<AuthenticationDbContext> options,
           ILogger<AuthenticationDbContext> logger,
           ICurrentUser currentUserService,
           IDateTimeProvider dateTimeProvider)
           : base(options, logger, currentUserService, dateTimeProvider)
        {
        }
        
        public DbSet<Permission> Permissions => Set<Permission>();
        public DbSet<PermissionGroup> PermissionGroups => Set<PermissionGroup>();
        public DbSet<PlatformRole> PlatformRoles => Set<PlatformRole>();
        public DbSet<PlatformRolePermission> PlatformRolePermissions => Set<PlatformRolePermission>();
        public DbSet<SystemRole> SystemRoles => Set<SystemRole>();
        public DbSet<SystemRolePermission> SystemRolePermissions => Set<SystemRolePermission>();
        public DbSet<User> Users => Set<User>();
    }
}
