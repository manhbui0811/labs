﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Configurations
{
    public class PlatformRolePermissionConfiguration : IEntityTypeConfiguration<PlatformRolePermission>
    {
        public void Configure(EntityTypeBuilder<PlatformRolePermission> e)
        {
            e.ToTable("auth_platform_role_permissions");

            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");

            e.Property(x => x.PlatformRoleId).HasColumnName("platform_role_id").IsRequired();
            e.Property(x => x.PermissionId).HasColumnName("permission_id").IsRequired();

            e.HasIndex(x => new { x.PlatformRoleId, x.PermissionId }).IsUnique();

            e.Property(x => x.CreatedBy).HasColumnName("created_by");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by");
            e.Property(x => x.CreatedAt).HasColumnName("created_at").IsRequired().HasDefaultValueSql("NOW()");
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at").IsRequired().HasDefaultValueSql("NOW()");
        }
    }
}
