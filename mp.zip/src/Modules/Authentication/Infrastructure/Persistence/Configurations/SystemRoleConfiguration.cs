﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Configurations
{

    public class SystemRoleConfiguration : IEntityTypeConfiguration<SystemRole>
    {
        public void Configure(EntityTypeBuilder<SystemRole> e)
        {
            e.ToTable("auth_system_roles");

            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");

            e.Property(x => x.RoleCode).HasColumnName("role_code").HasMaxLength(100).IsRequired();
            e.HasIndex(x => x.RoleCode).IsUnique(); 

            e.Property(x => x.RoleName).HasColumnName("role_name").HasMaxLength(100).IsRequired();
            e.Property(x => x.Description).HasColumnName("description");
            e.Property(x => x.ParentRoleId).HasColumnName("parent_role_id"); 

            e.Property(x => x.IsActive).HasColumnName("is_active").IsRequired().HasDefaultValue(true);

            e.Property(x => x.CreatedBy).HasColumnName("created_by");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by");
            e.Property(x => x.CreatedAt).HasColumnName("created_at").IsRequired().HasDefaultValueSql("NOW()");
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at").IsRequired().HasDefaultValueSql("NOW()");
        }
    }
}
