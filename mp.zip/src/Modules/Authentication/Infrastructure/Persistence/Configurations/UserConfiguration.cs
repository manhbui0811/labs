﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Configurations
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> e)
        {
            e.ToTable("auth_users");

            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");

            e.Property(x => x.KeycloakSub).HasColumnName("keycloak_sub").HasMaxLength(100).IsRequired();
            e.HasIndex(x => x.KeycloakSub).IsUnique();

            e.Property(x => x.Email).HasColumnName("email").HasMaxLength(200).IsRequired();
            e.HasIndex(x => x.Email).IsUnique();

            e.Property(x => x.FullName).HasColumnName("full_name");

            e.Property(x => x.UserType).HasColumnName("user_type").HasMaxLength(100).IsRequired();
            e.Property(x => x.Status).HasColumnName("status").HasMaxLength(100).IsRequired().HasDefaultValue("active");

            e.Property(x => x.PlatformRoleId).HasColumnName("platform_role_id").IsRequired();

            e.Property(x => x.PreferencesJson).HasColumnName("preferences_json");

            e.Property(x => x.LastLoginAt).HasColumnName("last_login_at");

            e.Property(x => x.IsDeleted).HasColumnName("is_deleted").IsRequired().HasDefaultValue(false);
            e.Property(x => x.DeletedAt).HasColumnName("deleted_at");

            e.Property(x => x.CreatedBy).HasColumnName("created_by");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by");
            e.Property(x => x.CreatedAt).HasColumnName("created_at").HasDefaultValueSql("NOW()").IsRequired();
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at").HasDefaultValueSql("NOW()").IsRequired();
        }
    }
}
