﻿using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Repositories
{
    public class AuthenticationRepository<TEntity> : RepositoryBase<TEntity, Guid>, IRepositoryBase<TEntity>
    where TEntity : EntityBase<Guid>
    {
        public AuthenticationRepository(AuthenticationDbContext context) : base(context)
        {
        }
    }
}
