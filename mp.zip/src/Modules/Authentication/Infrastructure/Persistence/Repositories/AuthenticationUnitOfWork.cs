﻿using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Persistence.Repositories
{
    public class AuthenticationUnitOfWork : UnitOfWork, IAuthenticationUnitOfWork
    {
        public AuthenticationUnitOfWork(AuthenticationDbContext context) : base(context)
        {
        }
    }
}
