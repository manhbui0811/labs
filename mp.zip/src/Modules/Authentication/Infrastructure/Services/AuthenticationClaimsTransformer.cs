﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Cachings;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;
using System.Security.Claims;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Services
{
    public class AuthenticationTransformer : IClaimsTransformation
    {
        private readonly IRepositoryBase<User> _userRepo;
        private readonly IPermissionService _permissonService;
        private readonly IRedisService _redisService;
        private readonly IAuthenticationUnitOfWork _unitOfWork;
        private readonly ILogger<AuthenticationTransformer> _logger;

        public AuthenticationTransformer(
            IPermissionService permissonService,
            IRepositoryBase<User> userRepo,
            IAuthenticationUnitOfWork unitOfWork,
            ILogger<AuthenticationTransformer> logger,
            IRedisService redisService)
        {
            _permissonService = permissonService;
            _userRepo = userRepo;
            _redisService = redisService;
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            if (principal.Identity is not ClaimsIdentity identity || !identity.IsAuthenticated)
            {
                return principal;
            }

            var username = principal.FindFirstValue("preferred_username");
            if (string.IsNullOrEmpty(username))
            {
                return principal;
            }
            if (!string.IsNullOrEmpty(username))
            {
                var user = await _userRepo.FindAsync(_ => _.KeycloakSub == username);
                if (user != null)
                {
                    identity.AddClaim(new Claim("system_uid", user.Id.ToString()));

                    var existingPermissions = identity.FindAll("permissions").ToList();
                    foreach (var claim in existingPermissions)
                    {
                        identity.RemoveClaim(claim);
                    }

                    List<string>? permissions;
                    var cacheKey = $"permissions:user:{user.PlatformRoleId}";

                    permissions = await _redisService.GetAsync<List<string>>(cacheKey);
                    if (permissions == null)
                    {
                        permissions = await _permissonService.GetPlatformPermission(user.PlatformRoleId);
                        if (permissions != null)
                        {
                            await _redisService.SetAsync(cacheKey, permissions);
                        }
                    }
                    identity.AddClaim(new Claim("permissions", "permissions.create"));
                    if (permissions != null)
                    {
                        foreach (var permission in permissions)
                        {
                            identity.AddClaim(new Claim("permissions", permission));
                        }
                    }
                }
                // Trường hợp không tìm thấy user, đồng bộ từ keycloak sang
                else
                {
                    await _unitOfWork.BeginTransactionAsync();
                    var name = principal.FindFirstValue("name") ?? username;
                    var email = principal.FindFirstValue("email") ?? username;
                    var entity = new User
                    {
                        KeycloakSub = username,
                        Email = email,
                        FullName = name,
                        UserType = "sync",
                        PlatformRoleId = Guid.Empty,
                    };

                    await _userRepo.AddAsync(entity);
                    await _unitOfWork.CommitTransactionAsync();
                    _logger.LogInformation("User {Username} not found, created new user with ID {UserId}", username, entity.Id);
                }
            }

            return principal;
        }
    }

}
