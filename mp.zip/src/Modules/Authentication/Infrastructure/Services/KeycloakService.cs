﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Services
{
    public class KeycloakService : IKeycloakService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<KeycloakService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor; 
        public KeycloakService(
            HttpClient httpClient,
            ILogger<KeycloakService> logger,
            IHttpContextAccessor httpContextAccessor) 
        {
            _httpClient = httpClient;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }

        // Loại bỏ GetAdminTokenAsync vì không còn dùng

        public async Task<bool> CreateUserAsync(
            string username,
            string email,
            string password,
            string firstName,
            string lastName,
            CancellationToken cancellationToken)
        {
            try
            {
                var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].FirstOrDefault();

                if (string.IsNullOrWhiteSpace(token) || !token.StartsWith("Bearer "))
                    return false;

                var accessToken = token["Bearer ".Length..];

                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                //var response = await _httpClient.GetAsync($"/admin/realms/master/users?username=manager");


                //// Lấy token từ yêu cầu HTTP hiện tại
                ////  var accessToken = await _httpContextAccessor.HttpContext?.GetTokenAsync("access_token");
                //var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].FirstOrDefault();

                //if (string.IsNullOrEmpty(token))
                //{
                //    _logger.LogError("Failed to obtain access token from current HTTP context.");
                //    return false;
                //}

                //var accessToken = token["Bearer ".Length..];
                //_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                var createUserDto = new
                {
                    username,
                    email,
                    firstName,
                    lastName,
                    enabled = true,
                    emailVerified = false,
                    credentials = new[]
                    {
                        new {
                            type = "password",
                            value = password,
                            temporary = false
                        }
                    }
                };

                var response = await _httpClient.PostAsJsonAsync("admin/realms/merchant-portal/users", createUserDto, cancellationToken);

                if (response.IsSuccessStatusCode)
                {
                    var location = response.Headers.Location?.Segments[^1];
                    return true;
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    _logger.LogError("Failed to create user in Keycloak. Status: {StatusCode}, Error: {Error}", response.StatusCode, error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating user in Keycloak.");
                throw;
            }
        }
    }
}
