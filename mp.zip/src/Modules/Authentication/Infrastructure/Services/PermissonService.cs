﻿using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Authentication.Application.Interfaces;
using SHT.MerchantPortal.Modules.Authentication.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Authentication.Infrastructure.Services
{
    public class PermissionService : IPermissionService
    {
        private readonly IRepositoryBase<Permission> _permissionReadRepo;
        private readonly IRepositoryBase<PlatformRole> _platformRoleRepo;
        private readonly IRepositoryBase<PlatformRolePermission> _platformRolePermissonRepo;
        public PermissionService(
                IRepositoryBase<Permission> permissionReadRepo,
                IRepositoryBase<PlatformRole> platformRoleRepo,
                IRepositoryBase<PlatformRolePermission> platformRolePermissonRepo
            )
        {
            _permissionReadRepo = permissionReadRepo;
            _platformRoleRepo = platformRoleRepo;
            _platformRolePermissonRepo = platformRolePermissonRepo;
        }

        public async Task<List<string>> GetPlatformPermission(Guid platformRoleId, CancellationToken ct = default)
        {
            var allRoleIds = new HashSet<Guid>();
            var currentRoleId = platformRoleId;

            // Đệ quy lấy tất cả các parent role
            while (currentRoleId != Guid.Empty)
            {
                var role = await _platformRoleRepo.FindAsync(
                    _ => _.Id == currentRoleId && _.IsActive,
                    ct
                );

                if (role == null)
                {
                    break;
                }

                allRoleIds.Add(role.Id);
                currentRoleId = role.ParentRoleId ?? Guid.Empty;
            }

            if (allRoleIds.Count == 0)
            {
                return new List<string>();
            }

            // Lấy tất cả các PlatformRolePermission cho các role đã tìm thấy
            var rolePermissions = await _platformRolePermissonRepo.FindAllAsync(
                _ => allRoleIds.Contains(_.PlatformRoleId),
                ct
            );

            // Lấy tất cả các Permission có IsActive và ID nằm trong danh sách đã tìm thấy ở trên
            var permissionIds = rolePermissions.Select(_ => _.PermissionId).ToHashSet();
            var permissions = await _permissionReadRepo.FindAllAsync(
                _ => _.IsActive && permissionIds.Contains(_.Id),
                ct
            );

            // Trả về danh sách ActionCode duy nhất
            return permissions.Select(_ => _.ActionCode).Distinct().ToList();
        }
    }
}
