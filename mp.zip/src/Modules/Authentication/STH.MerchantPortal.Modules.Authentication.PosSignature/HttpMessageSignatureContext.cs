﻿using Microsoft.AspNetCore.Http;

namespace STH.MerchantPortal.Modules.Authentication.PosSignature
{
    internal class HttpMessageSignatureContext
    {
        public HttpRequest Request { get; set; }
        public object Algorithm { get; set; }
        public object KeyId { get; set; }
        public object SigningKey { get; set; }
        public object Components { get; set; }
        public object Created { get; set; }
        public int MaxAgeSeconds { get; set; }
    }
}