﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries;

namespace SHT.MerchantPortal.Modules.Core.Api.Endpoints.MasterData
{


    public class GetProvinceByCodeEndpoint : Endpoint<GetProvinceByCodeQuery, ProvinceDto>
    {
        private readonly ISender _sender;
        public GetProvinceByCodeEndpoint(ISender sender) => _sender = sender;
        public override void Configure()
        {
            Get("/provinces/{Code}");
            Tags("Master Data");
            Summary(s => s.Summary = "Lấy Tỉnh thành theo Code");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
        }

        public override async Task HandleAsync(GetProvinceByCodeQuery rq,CancellationToken ct)
        {
            var result = await _sender.Send(rq, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
