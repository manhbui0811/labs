﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries;

namespace SHT.MerchantPortal.Modules.Core.Api.Endpoints.MasterData
{

    public class GetProvincesEndpoint : EndpointWithoutRequest<List<ProvinceDto>>

    {
        private readonly ISender _sender;
        public GetProvincesEndpoint(ISender sender) => _sender = sender;
        public override void Configure()
        {
            Get("/provinces");
            Tags("Master Data");
            Summary(s => s.Summary = "Danh mục tỉnh thành");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
        }

        public override async Task HandleAsync(CancellationToken ct)
        {
            var result = await _sender.Send(new GetProvincesQuery(), ct);
            await Send.OkAsync(result, ct);
        }
    }
}
