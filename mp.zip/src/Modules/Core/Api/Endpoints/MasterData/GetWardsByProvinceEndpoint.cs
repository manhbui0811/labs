﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries;

namespace SHT.MerchantPortal.Modules.Core.Api.Endpoints.MasterData
{


    public class GetWardsByProvinceEndpoint : Endpoint<GetWardsByProvinceQuery,List<WardDto>>

    {
        private readonly ISender _sender;
        public GetWardsByProvinceEndpoint(ISender sender) => _sender = sender;
        public override void Configure()
        {
            Get("/provinces/{ProvinceCode}/wards");
            Tags("Master Data");
            Summary(s => s.Summary = "Danh mục Xã, phường theo tỉnh thành");
            // AuthSchemes(JwtBearerDefaults.AuthenticationScheme); // Uncomment nếu cần xác thực
            AllowAnonymous(); // Giữ hoặc xóa tùy theo yêu cầu xác thực
        }

        public override async Task HandleAsync(GetWardsByProvinceQuery rq,CancellationToken ct)
        {
            var result = await _sender.Send(rq, ct);
            await Send.OkAsync(result, ct);
        }
    }
}
