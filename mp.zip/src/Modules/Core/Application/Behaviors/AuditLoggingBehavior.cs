using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Services;
using System.Text.Json;

namespace SHT.MerchantPortal.Modules.Core.Application.Behaviors;

/// <summary>
/// Behavior for audit logging of commands
/// </summary>
/// <typeparam name="TRequest">The request type</typeparam>
/// <typeparam name="TResponse">The response type</typeparam>
public class AuditLoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly ILogger<AuditLoggingBehavior<TRequest, TResponse>> _logger;
    private readonly IAuditService _auditService;
    private readonly ICurrentUser _currentUser;

    public AuditLoggingBehavior(
        ILogger<AuditLoggingBehavior<TRequest, TResponse>> logger,
        IAuditService auditService,
        ICurrentUser currentUser)
    {
        _logger = logger;
        _auditService = auditService;
        _currentUser = currentUser;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        // Only audit commands, not queries
        if (request is not ICommand)
        {
            return await next();
        }

        var requestName = typeof(TRequest).Name;

        try
        {
            var response = await next();

            // Log successful command execution
            await _auditService.TrackCommandAsync(
                requestName,
                SanitizeCommandData(request),
                cancellationToken);

            _logger.LogInformation(
                "Audit logged for successful command {CommandName} by user {UserId}",
                requestName,
                _currentUser.UserId);

            return response;
        }
        catch (Exception ex)
        {
            // Log failed command execution
            await _auditService.TrackAsync(
                $"COMMAND_FAILED:{requestName}",
                details: new
                {
                    Command = SanitizeCommandData(request),
                    Error = ex.Message,
                    ex.StackTrace
                },
                entityId: _currentUser.EntityId,
                cancellationToken: cancellationToken);

            _logger.LogWarning(ex,
                "Audit logged for failed command {CommandName} by user {UserId}",
                requestName,
                _currentUser.UserId);

            throw;
        }
    }

    private static object SanitizeCommandData(TRequest request)
    {
        // Serialize and sanitize sensitive data
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };

        var json = JsonSerializer.Serialize(request, options);
        
        // Remove or mask sensitive fields
        var sanitized = json
            .Replace("\"password\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase)
            .Replace("\"token\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase)
            .Replace("\"secret\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase)
            .Replace("\"key\"", "\"[MASKED]\"", StringComparison.OrdinalIgnoreCase);

        return JsonSerializer.Deserialize<object>(sanitized) ?? new { };
    }
}


