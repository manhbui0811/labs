//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
//using SHT.MerchantPortal.Shared.Kernel.Entities;

//namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

//public interface IApiKeyRepository : IRepositoryBase<ApiKey, Guid>
//{
//    Task<ApiKey?> GetByKeyHashAsync(string keyHash, CancellationToken cancellationToken = default);
//    Task<IReadOnlyList<ApiKey>> GetByEntityIdAsync(int entityId, CancellationToken cancellationToken = default);
//    Task<IReadOnlyList<ApiKey>> GetAllActiveAsync(CancellationToken cancellationToken = default);
//}


