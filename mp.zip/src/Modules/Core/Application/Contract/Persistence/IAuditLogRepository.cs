

using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

public interface IAuditLogRepository : IRepositoryBase<AuditLog, long>
{
    Task<IReadOnlyList<AuditLog>> GetByUserIdAsync(
        string userId,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<AuditLog>> GetByRecordIdAsync(
        string recordId,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<AuditLog>> GetByActionTypeAsync(
        string actionType,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<AuditLog>> GetByDateRangeAsync(
        DateTimeOffset fromDate, 
        DateTimeOffset toDate,   
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default);
}

