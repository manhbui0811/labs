using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

public interface IBusinessCategoryRepository : IRepositoryBase<BusinessCategory, Guid>
{
    Task<BusinessCategory?> GetByMccCodeAsync(string mccCode, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<BusinessCategory>> GetAllActiveAsync(CancellationToken cancellationToken = default);
}


