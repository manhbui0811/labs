using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

public interface IClientAppRepository : IRepositoryBase<ClientApp, Guid>
{
    Task<ClientApp?> GetByAppCodeAsync(string appCode, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ClientApp>> GetAllActiveAsync(CancellationToken cancellationToken = default);
}


