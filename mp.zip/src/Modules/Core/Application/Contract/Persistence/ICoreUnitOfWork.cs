﻿using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence
{
    public interface ICoreUnitOfWork : IUnitOfWork
    {
    }
}
