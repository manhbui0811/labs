using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

public interface IDocumentTypeRepository : IRepositoryBase<DocumentType, int>
{
    Task<DocumentType?> GetByTypeCodeAsync(string typeCode, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<DocumentType>> GetAllActiveAsync(CancellationToken cancellationToken = default);
}


