//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using SHT.MerchantPortal.Shared.Kernel.Enums;

//namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

//public interface IEncryptionKeyRepository : IRepositoryBase<EncryptionKey, Guid>
//{
//    Task<EncryptionKey?> GetActiveKeyAsync(
//        string keyIdentifier,
//        OwnerType ownerType,
//        Guid? ownerId = null,
//        CancellationToken cancellationToken = default);

//    Task<IReadOnlyList<EncryptionKey>> GetKeysByOwnerAsync(
//        OwnerType ownerType,
//        Guid? ownerId,
//        CancellationToken cancellationToken = default);

//    Task<EncryptionKey?> GetByKeyIdentifierAndVersionAsync(
//        string keyIdentifier,
//        string keyVersion,
//        CancellationToken cancellationToken = default);

//    Task<EncryptionKey?> GetByKeyIdentifierAsync(
//        string keyIdentifier,
//        CancellationToken cancellationToken = default);
//}


