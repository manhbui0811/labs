using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;

public interface IFeatureFlagRepository : IRepositoryBase<FeatureFlag, Guid>
{
    Task<FeatureFlag?> GetByNameAsync(string name, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<FeatureFlag>> GetAllEnabledAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<FeatureFlag>> GetAllAsync(CancellationToken cancellationToken = default);
}


