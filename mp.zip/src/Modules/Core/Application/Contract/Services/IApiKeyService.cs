﻿using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Services;

public interface IApiKeyService
{
    /// <summary>
    /// Tạo API Key mới cho owner cụ thể (Merchant, POS, User…)
    /// </summary>
    Task<(ApiKey ApiKey, string PlainTextKey)> CreateApiKeyAsync(
        string prefix,
        OwnerType ownerType,
        Guid ownerId,
        string? scope = null,
        DateTime? expiresAt = null,
        Guid? createdBy = null,
        CancellationToken cancellationToken = default);

    Task<(ApiKey ApiKey, string PlainTextKey)> RotateKey(Guid keyId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Xác thực và lấy ApiKey entity từ plaintext API Key
    /// </summary>
    Task<ApiKey?> GetAsync(
        ApiKeyQueryType type,
        string data,
        bool validate = false,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Vô hiệu hoá API Key
    /// </summary>
    Task DeactivateAsync(Guid apiKeyId, Guid updatedBy, CancellationToken cancellationToken = default);
}

public enum ApiKeyQueryType
{
    ByPlainText,
    ById
}