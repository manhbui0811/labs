using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Services;

/// <summary>
/// Service for audit logging
/// </summary>
public interface IAuditService
{
    /// <summary>
    /// Track an audit event
    /// </summary>
    /// <param name="actionType">The type of action performed</param>
    /// <param name="tableName">The table/entity affected</param>
    /// <param name="recordId">The ID of the record affected</param>
    /// <param name="details">Additional details</param>
    /// <param name="entityId">The entity context</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task TrackAsync(
        string actionType,
        string? tableName = null,
        string? recordId = null,
        object? details = null,
        Guid? entityId = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Track a command execution
    /// </summary>
    /// <param name="commandName">The name of the command</param>
    /// <param name="commandData">The command data</param>
    /// <param name="cancellationToken">Cancellation token</param>
    Task TrackCommandAsync(
        string commandName,
        object commandData,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Get audit logs with filtering
    /// </summary>
    Task<IReadOnlyList<AuditLog>> GetAuditLogsAsync(
        int? userId = null,
        int? entityId = null,
        string? actionType = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default);
}


