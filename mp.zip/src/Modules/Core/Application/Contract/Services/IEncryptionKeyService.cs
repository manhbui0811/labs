using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Services;

public interface IEncryptionKeyService
{
    Task<EncryptionKey> CreateKeyAsync(
        string keyIdentifier,
        EncryptionType keyType,
        KeyCategory keyCategory,
        OwnerType ownerType,
        Guid? ownerId,
        string algorithm,
        string createdBy,
        CancellationToken cancellationToken = default);

    Task<EncryptionKey?> GetActiveKeyAsync(
        string keyIdentifier,
        OwnerType ownerType,
        Guid? ownerId = null,
        CancellationToken cancellationToken = default);

    Task<EncryptionKey?> GetKeyByIdAsync(Guid keyId, CancellationToken cancellationToken = default);

    Task ActivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default);

    Task RotateKeyAsync(Guid oldKeyId, string updatedBy, CancellationToken cancellationToken = default);

    Task DeactivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<EncryptionKey>> GetKeysByOwnerAsync(
        OwnerType ownerType,
        Guid? ownerId,
        CancellationToken cancellationToken = default);

    Task<CreateKeyResult> CreateHmacKeyAsync(string identifier, KeyCategory keyCategory, OwnerType ownerType, Guid ownerId, string? kekAlias = null, string? createdBy = null, CancellationToken cancellationToken = default);
    Task<byte[]?> GetHmacSecretByKeyIdentifierAsync(string identifier, CancellationToken cancellationToken = default);

    Task<CreateKeyResult> RotateHmacKeyAsync(string oldIdentifier, string newIdentifier, string updatedBy, CancellationToken cancellationToken = default);
    Task<CreateKeyResult> CreateRsaKeyAsync(KeyCategory keyCategory, OwnerType ownerType, Guid ownerId, string? kekAlias = null, string? createdBy = null, CancellationToken cancellationToken = default);

    Task<byte[]?> GetRSAPublicKeyAsync(KeyCategory keyCategory, Guid ownerId, OwnerType ownerType, CancellationToken cancellationToken = default);


}

public class CreateKeyResult
{
    public string Id { get; set; } = null!;
    public string KeyIdentifier { get; set; } = null!;
    public string KeyVersion { get; set; } = null!;
    public string Algorithm { get; set; } = string.Empty;
    public EncryptionType KeyType { get; set; }
    public KeyCategory KeyCategory { get; set; }
    public OwnerType OwnerType { get; set; }
    public Guid OwnerId { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public string? HmacSecret { get; set; }
    public string? PublicKeyPem { get; set; }
    public string? PrivateKeyPem { get; set; }

}
