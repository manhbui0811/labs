namespace SHT.MerchantPortal.Modules.Core.Application.Contract.Services;

public interface IFeatureFlagService
{
    Task<bool> IsEnabledAsync(string featureName, string? tenantId = null, string? userId = null, CancellationToken cancellationToken = default);
    Task<T?> GetSettingValueAsync<T>(string featureName, string settingKey, T? defaultValue = default, CancellationToken cancellationToken = default);
    Task EnableFeatureAsync(string featureName, string? updatedBy = null, CancellationToken cancellationToken = default);
    Task DisableFeatureAsync(string featureName, string? updatedBy = null, CancellationToken cancellationToken = default);
    Task EnableForTenantAsync(string featureName, string tenantId, string? updatedBy = null, CancellationToken cancellationToken = default);
    Task DisableForTenantAsync(string featureName, string tenantId, string? updatedBy = null, CancellationToken cancellationToken = default);
    Task EnableForUserAsync(string featureName, string userId, string? updatedBy = null, CancellationToken cancellationToken = default);
    Task DisableForUserAsync(string featureName, string userId, string? updatedBy = null, CancellationToken cancellationToken = default);
}


