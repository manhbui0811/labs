//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using SHT.MerchantPortal.Shared.Kernel.Enums;

//namespace SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;

//public interface IKeyManagementService
//{
//    Task<EncryptionKey> CreateKeyAsync(
//        EncryptionType keyType,
//        KeyCategory keyCategory,
//        OwnerType ownerType,
//        Guid? ownerId,
//        string algorithm,
//        string createdBy,
//        CancellationToken cancellationToken = default);

//    Task<EncryptionKey> ActivateKeyAsync(
//        Guid keyId,
//        string updatedBy,
//        CancellationToken cancellationToken = default);

//    Task<EncryptionKey> RotateKeyAsync(
//        Guid keyId,
//        string updatedBy,
//        CancellationToken cancellationToken = default);

//    Task<EncryptionKey> DeactivateKeyAsync(
//        Guid keyId,
//        string updatedBy,
//        CancellationToken cancellationToken = default);

//    Task<byte[]> GetPublicKeyAsync(
//        string keyIdentifier,
//        CancellationToken cancellationToken = default);

//    Task<byte[]?> GetKeyMaterialAsync(string keyIdentifier, CancellationToken cancellationToken = default);

//    Task<byte[]?>
//        GetPublicKeyMaterialAsync(string keyIdentifier,
//            CancellationToken cancellationToken = default); // For RSA/EC public keys
//}


