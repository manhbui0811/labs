﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries
{
    public class GetWardByCodeQuery : IQuery<WardDto>
    {
        public string Code { get; set; } = string.Empty;
    }
    public sealed class GetWardByCodeQueryHandler : QueryHandlerBase<GetWardByCodeQuery, WardDto>
    {
        private readonly IRepositoryBase<Province> _provinceRepo;
        private readonly IRepositoryBase<Ward> _wardRepo;

        public GetWardByCodeQueryHandler(
            IRepositoryBase<Province> provinceRepo,
            IRepositoryBase<Ward> wardRepo,
            ILogger<GetWardByCodeQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _provinceRepo = provinceRepo;
            _wardRepo = wardRepo;
        }

        public override async Task<WardDto> Handle(GetWardByCodeQuery request, CancellationToken ct)
        {
            var ward = await _wardRepo.FindAsync(_ => _.Code == request.Code, ct);
            if (ward == null) throw new NotFoundException("Ward not found");
            var province = await _provinceRepo.FindAsync(_ => _.Code == ward.ProvinceCode, ct);
            //if (province == null) throw new NotFoundException("Province not found");

            return new WardDto
            {
                Name = ward.Name,
                Code = ward.Code,
                ProvinceCode = ward.ProvinceCode,
                ProvinceName = province?.Name
            };
        }
    }
}
