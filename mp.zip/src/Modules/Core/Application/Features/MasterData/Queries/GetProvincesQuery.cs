﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries
{
    public class GetProvincesQuery : IQuery<List<ProvinceDto>>
    {
    }
    public sealed class GetProvincesQueryHandler : QueryHandlerBase<GetProvincesQuery, List<ProvinceDto>>
    {
        private readonly IRepositoryBase<Province> _repo;

        public GetProvincesQueryHandler(
            IRepositoryBase<Province> repo,
            ILogger<GetProvincesQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _repo = repo;
        }

        public override async Task<List<ProvinceDto>> Handle(GetProvincesQuery request, CancellationToken ct)
        {
            var provinces = await _repo.FindAllAsync(null, ct);
            return provinces
                .Select(p => new ProvinceDto
                {
                    Name = p.Name,
                    Code = p.Code,
                })
                .OrderBy(x => x.Code)
                .ToList();
        }
    }
}
