﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries
{
    public class GetProvinceByCodeQuery : IQuery<ProvinceDto>
    {
        public string Code { get; set; } = string.Empty;
    }
    public sealed class GetProvinceByCodeQueryHandler : QueryHandlerBase<GetProvinceByCodeQuery, ProvinceDto>
    {
        private readonly IRepositoryBase<Province> _provinceRepo;

        public GetProvinceByCodeQueryHandler(
            IRepositoryBase<Province> provinceRepo,
            IRepositoryBase<Ward> wardRepo,
            ILogger<GetProvinceByCodeQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _provinceRepo = provinceRepo;
        }

        public override async Task<ProvinceDto> Handle(GetProvinceByCodeQuery request, CancellationToken ct)
        {
            var province = await _provinceRepo.FindAsync(_ => _.Code == request.Code, ct);
            if (province == null) throw new NotFoundException("Province not found");

            return new ProvinceDto
            {
                Name = province.Name,
                Code = province.Code,
            };
        }
    }
}
