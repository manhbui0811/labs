﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries
{
    public class GetWardsByProvinceQuery : IQuery<List<WardDto>>
    {
        public string ProvinceCode { get; set; } = string.Empty;
    }
    public sealed class GetWardsByProvinceQueryHandler : QueryHandlerBase<GetWardsByProvinceQuery, List<WardDto>>
    {
        private readonly IRepositoryBase<Province> _provinceRepo;
        private readonly IRepositoryBase<Ward> _wardRepo;

        public GetWardsByProvinceQueryHandler(
            IRepositoryBase<Province> provinceRepo,
            IRepositoryBase<Ward> wardRepo,
            ILogger<GetWardsByProvinceQueryHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _provinceRepo = provinceRepo;
            _wardRepo = wardRepo;
        }

        public override async Task<List<WardDto>> Handle(GetWardsByProvinceQuery request, CancellationToken ct)
        {
            var province = await _provinceRepo.FindAsync(_ => _.Code == request.ProvinceCode, ct);
            if (province == null) throw new NotFoundException("Province not found");

            var wards = await _wardRepo.FindAllAsync(w => w.ProvinceCode == request.ProvinceCode, ct);
            return wards
                .Select(p => new WardDto
                {
                    Name = p.Name,
                    Code = p.Code,
                    ProvinceCode = p.ProvinceCode,
                    ProvinceName = province.Name
                })
                .OrderBy(x => x.Code)
                .ToList();
        }
    }
}
