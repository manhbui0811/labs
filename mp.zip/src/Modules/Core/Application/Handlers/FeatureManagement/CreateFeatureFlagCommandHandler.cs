//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands.FeatureManagement;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.Modules.Core.Application.Utilities;
//using SHT.MerchantPortal.Modules.Core.Domain.Entities;

//namespace SHT.MerchantPortal.Modules.Core.Application.Handlers.FeatureManagement;

//public class CreateFeatureFlagCommandHandler : CommandHandlerBase<CreateFeatureFlagCommand, FeatureFlagDto>
//{
//    private readonly IFeatureFlagRepository _featureFlagRepository;

//    public CreateFeatureFlagCommandHandler(
//        ILogger<CreateFeatureFlagCommandHandler> logger,
//        ICurrentUser currentUser,
//        IFeatureFlagRepository featureFlagRepository) : base(logger, currentUser)
//    {
//        _featureFlagRepository = featureFlagRepository;
//    }

//    public override async Task<FeatureFlagDto> Handle(CreateFeatureFlagCommand request, CancellationToken cancellationToken)
//    {
//        Logger.LogInformation("Creating feature flag {Name}", request.Name);

//        var createdBy = CurrentUser.Email ?? "System";
//        var featureFlag = new FeatureFlag(
//            request.Name,
//            createdBy,
//            request.IsEnabled,
//            request.Description,
//            request.ExpiresAt);

//        // Add settings if provided
//        if (request.Settings?.Any() == true)
//        {
//            foreach (var setting in request.Settings)
//            {
//                featureFlag.AddOrUpdateSetting(setting.Key, setting.Value, createdBy);
//            }
//        }

//        await _featureFlagRepository.AddAsync(featureFlag, cancellationToken);

//        Logger.LogInformation("Successfully created feature flag {FeatureFlagId}", featureFlag.Id);

//        return EntityMappingHelper.MapToFeatureFlagDto(featureFlag);
//    }
//}


