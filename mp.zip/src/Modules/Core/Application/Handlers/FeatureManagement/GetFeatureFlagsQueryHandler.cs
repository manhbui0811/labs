//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;
//using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
//using SHT.MerchantPortal.BuildingBlocks.Application.Queries.FeatureManagement;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.Modules.Core.Application.Utilities;
//using SHT.MerchantPortal.Modules.Core.Domain.Entities;

//namespace SHT.MerchantPortal.Modules.Core.Application.Handlers.FeatureManagement;

//public class GetFeatureFlagsQueryHandler : QueryHandlerBase<GetFeatureFlagsQuery, IReadOnlyList<FeatureFlagDto>>
//{
//    private readonly IFeatureFlagRepository _featureFlagRepository;

//    public GetFeatureFlagsQueryHandler(
//        ILogger<GetFeatureFlagsQueryHandler> logger,
//        ICurrentUser currentUser,
//        IFeatureFlagRepository featureFlagRepository) : base(logger, currentUser)
//    {
//        _featureFlagRepository = featureFlagRepository;
//    }

//    public override async Task<IReadOnlyList<FeatureFlagDto>> Handle(GetFeatureFlagsQuery request, CancellationToken cancellationToken)
//    {
//        Logger.LogInformation("Getting feature flags with filters: IsEnabled={IsEnabled}, Search={Search}", 
//            request.IsEnabled, request.Search);

//        IReadOnlyList<FeatureFlag> featureFlags;

//        if (request.IsEnabled.HasValue && request.IsEnabled.Value)
//        {
//            featureFlags = await _featureFlagRepository.GetAllEnabledAsync(cancellationToken);
//        }
//        else
//        {
//            featureFlags = await _featureFlagRepository.GetAllAsync(cancellationToken);
//        }

//        // Apply search filter if provided
//        if (!string.IsNullOrWhiteSpace(request.Search))
//        {
//            featureFlags = featureFlags
//                .Where(ff => ff.Name.Contains(request.Search, StringComparison.OrdinalIgnoreCase) ||
//                            ff.Description?.Contains(request.Search, StringComparison.OrdinalIgnoreCase) == true)
//                .ToList();
//        }

//        return featureFlags.Select(EntityMappingHelper.MapToFeatureFlagDto).ToList();
//    }
//}


