//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands.Security;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Application.Models.Responses;

//namespace SHT.MerchantPortal.BuildingBlocks.Application.Handlers.Security;

//public class CreateApiKeyCommandHandler : CommandHandlerBase<CreateApiKeyCommand, CreateApiKeyResponse>
//{
//    private readonly IApiKeyService _apiKeyService;

//    public CreateApiKeyCommandHandler(
//        ILogger<CreateApiKeyCommandHandler> logger,
//        ICurrentUser currentUser,
//        IApiKeyService apiKeyService) : base(logger, currentUser)
//    {
//        _apiKeyService = apiKeyService;
//    }

//    public override async Task<CreateApiKeyResponse> Handle(CreateApiKeyCommand request, CancellationToken cancellationToken)
//    {
//        Logger.LogInformation("Creating API key {Name} for entity {EntityId}", request.Name, request.EntityId);

//        var (apiKey, plainTextKey) = await _apiKeyService.CreateApiKeyAsync(
//            request.Name,
//            request.Description,
//            request.EntityId,
//            request.ExpiresAt,
//            request.Scopes,
//            cancellationToken);

//        Logger.LogInformation("Successfully created API key {ApiKeyId}", apiKey.Id);

//        return new CreateApiKeyResponse
//        {
//            Id = apiKey.Id,
//            Name = apiKey.Name,
//            ApiKey = plainTextKey,
//            ExpiresAt = apiKey.ExpiresAt,
//            Scopes = apiKey.Scopes,
//            CreatedAt = apiKey.CreatedAt
//        };
//    }
//}


