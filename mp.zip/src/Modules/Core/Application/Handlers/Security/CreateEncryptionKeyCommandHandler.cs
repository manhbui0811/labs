//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
//using SHT.MerchantPortal.BuildingBlocks.Application.Commands.Security;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Application.Models.Security;
//using SHT.MerchantPortal.BuildingBlocks.Application.Utilities;

//namespace SHT.MerchantPortal.BuildingBlocks.Application.Handlers.Security;

//public class CreateEncryptionKeyCommandHandler : CommandHandlerBase<CreateEncryptionKeyCommand, EncryptionKeyDto>
//{
//    private readonly IEncryptionKeyService _encryptionKeyService;

//    public CreateEncryptionKeyCommandHandler(
//        ILogger<CreateEncryptionKeyCommandHandler> logger,
//        ICurrentUser currentUser,
//        IEncryptionKeyService encryptionKeyService) : base(logger, currentUser)
//    {
//        _encryptionKeyService = encryptionKeyService;
//    }

//    public override async Task<EncryptionKeyDto> Handle(CreateEncryptionKeyCommand request, CancellationToken cancellationToken)
//    {
//        Logger.LogInformation("Creating encryption key {KeyIdentifier} of type {KeyType}", 
//            request.KeyIdentifier, request.KeyType);

//        var createdBy = CurrentUser.Email ?? "System";

//        var encryptionKey = await _encryptionKeyService.CreateKeyAsync(
//            request.KeyIdentifier,
//            request.KeyType,
//            request.KeyCategory,
//            request.OwnerType,
//            request.OwnerId,
//            request.Algorithm,
//            createdBy,
//            cancellationToken);

//        // Set expiry if provided
//        if (request.ExpiresAt.HasValue)
//        {
//            encryptionKey.SetExpiry(request.ExpiresAt.Value, createdBy);
//        }

//        Logger.LogInformation("Successfully created encryption key {KeyId}", encryptionKey.Id);

//        return EntityMappingHelper.MapToEncryptionKeyDto(encryptionKey);
//    }
//}


