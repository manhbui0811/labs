﻿using SHT.MerchantPortal.BuildingBlocks.Application.Models.FeatureManagement;
using SHT.MerchantPortal.BuildingBlocks.Application.Models.MasterData;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Application.Utilities
{
    public static class EntityMappingHelper
    {
        public static BusinessCategoryDto MapToBusinessCategoryDto(BusinessCategory businessCategory)
        {
            return new BusinessCategoryDto
            {
                Id = businessCategory.Id,
                CategoryName = businessCategory.CategoryName,
                MccCode = businessCategory.MccCode,
                IsActive = businessCategory.IsActive,
                CreatedAt = businessCategory.CreatedAt
            };
        }

        public static CurrencyDto MapToCurrencyDto(CurrencyEntity currency)
        {
            return new CurrencyDto
            {
                Code = currency.Id,
                Name = currency.Name,
                Symbol = currency.Symbol,
                IsActive = currency.IsActive
            };
        }

        public static DocumentTypeDto MapToDocumentTypeDto(DocumentType documentType)
        {
            return new DocumentTypeDto
            {
                Id = documentType.Id,
                TypeCode = documentType.TypeCode,
                TypeName = documentType.TypeName,
                Description = documentType.Description,
                IsActive = documentType.IsActive,
                CreatedAt = documentType.CreatedAt
            };
        }

        public static ClientAppDto MapToClientAppDto(ClientApp clientApp)
        {
            return new ClientAppDto
            {
                Id = clientApp.Id,
                AppCode = clientApp.AppCode,
                Name = clientApp.Name,
                Description = clientApp.Description,
                Status = clientApp.Status,
                CreatedAt = clientApp.CreatedAt
            };
        }

        //public static ApiKeyDto MapToApiKeyDto(ApiKey apiKey)
        //{
        //    return new ApiKeyDto
        //    {
        //        Id = apiKey.Id,
        //        Name = apiKey.Name,
        //        Description = apiKey.Description,
        //        IsActive = apiKey.IsActive,
        //        ExpiresAt = apiKey.ExpiresAt,
        //        LastUsedAt = apiKey.LastUsedAt,
        //        Scopes = apiKey.Scopes,
        //        CreatedAt = apiKey.CreatedAt,
        //        IsExpired = apiKey.IsExpired,
        //        IsValid = apiKey.IsValid
        //    };
        //}

        //public static EncryptionKeyDto MapToEncryptionKeyDto(EncryptionKey encryptionKey)
        //{
        //    return new EncryptionKeyDto
        //    {
        //        Id = encryptionKey.Id,
        //        KeyIdentifier = encryptionKey.KeyIdentifier,
        //        KeyVersion = encryptionKey.KeyVersion,
        //        KeyType = encryptionKey.KeyType,
        //        KeyCategory = encryptionKey.KeyCategory,
        //        OwnerType = encryptionKey.OwnerType,
        //        OwnerId = encryptionKey.OwnerId,
        //        KeyStatus = encryptionKey.KeyStatus,
        //        Algorithm = encryptionKey.Algorithm,
        //        ActivatedAt = encryptionKey.ActivatedAt,
        //        ExpiresAt = encryptionKey.ExpiresAt,
        //        RotatedToKeyId = encryptionKey.RotatedToKeyId,
        //        CreatedBy = encryptionKey.CreatedBy,
        //        CreatedAt = encryptionKey.CreatedAt,
        //        IsActive = encryptionKey.IsCurrentlyActive()
        //    };
        //}

        public static FeatureFlagDto MapToFeatureFlagDto(FeatureFlag featureFlag)
        {
            return new FeatureFlagDto
            {
                Id = featureFlag.Id,
                Name = featureFlag.Name,
                Description = featureFlag.Description,
                IsEnabled = featureFlag.IsEnabled,
                ExpiresAt = featureFlag.ExpiresAt,
                CreatedAt = featureFlag.CreatedAt,
                CreatedBy = featureFlag.CreatedBy,
                UpdatedAt = featureFlag.UpdatedAt,
                UpdatedBy = featureFlag.UpdatedBy,
                Settings = featureFlag.Settings?.Select(MapToFeatureFlagSettingDto).ToList()
            };
        }

        public static FeatureFlagSettingDto MapToFeatureFlagSettingDto(FeatureFlagSetting setting)
        {
            return new FeatureFlagSettingDto
            {
                Id = setting.Id,
                Key = setting.Key,
                Value = setting.Value
            };
        }
    }

}
