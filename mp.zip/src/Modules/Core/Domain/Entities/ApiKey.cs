﻿
using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Enums;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class ApiKey : EntityBase<Guid>, IAuditableEntity
{
    public OwnerType OwnerType { get; set; }
    public Guid OwnerId { get; set; }
    // Các ID của chủ sở hữu

    public string Name { get; set; } = null!; // Phần tiền tố của API Key (ví dụ: `pk_`)
    public string KeyPrefix { get; set; } = null!; // Phần tiền tố của API Key (ví dụ: `pk_`)
    public string KeyHash { get; set; } = null!; // Hash của plaintext API Key (argon2/bcrypt)
    public string Scope { get; set; } = "{}"; // JSONB stored as string, ví dụ: {"read": true, "write": ["user"]}
    public KeyStatus Status { get; set; } = KeyStatus.Active; // Default 'Active'
    public DateTime? ExpiresAt { get; set; }
    public DateTime? LastUsedAt { get; set; }

    // IAuditableEntity properties
    public Guid? CreatedBy { get; set; } // FK to users(id)
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public Guid? UpdatedBy { get; set; } // Added for IAuditableEntity consistency
}

