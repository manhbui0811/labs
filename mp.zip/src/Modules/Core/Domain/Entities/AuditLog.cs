using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class AuditLog : LongKeyEntityBase
{
    public string? UserId { get; private set; }
    public string? EntityId { get; private set; }
    public string? TableName { get; private set; }
    public string? RecordId { get; private set; }
    public string ActionType { get; private set; } = string.Empty;
    public string? Details { get; private set; }
    public string? IpAddress { get; private set; }
    public string? UserAgent { get; private set; }
    public DateTimeOffset Timestamp { get; private set; }

    private AuditLog() { }

    public AuditLog(
        string actionType,
        string? entityId,
        string? userId = null,
        string? tableName = null,
        string? recordId = null,
        string? details = null,
        string? ipAddress = null,
        string? userAgent = null)
    {
        if (string.IsNullOrWhiteSpace(actionType))
            throw new ArgumentException("Action type cannot be empty", nameof(actionType));
        EntityId=entityId;
        UserId = userId;
        ActionType = actionType.Trim();
        TableName = tableName?.Trim();
        RecordId = recordId?.Trim();
        Details = details;
        IpAddress = ipAddress?.Trim();
        UserAgent = userAgent?.Trim();
        Timestamp = DateTimeOffset.UtcNow;
    }
}