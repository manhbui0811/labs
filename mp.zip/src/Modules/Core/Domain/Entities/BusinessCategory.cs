using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class BusinessCategory : AuditedAggregateRoot<Guid>
{
    public string CategoryName { get; private set; } = string.Empty;
    public string? MccCode { get; private set; }
    public bool IsActive { get; private set; } = true;

    private BusinessCategory() { }

    public BusinessCategory(string categoryName, string? createdBy, string? mccCode = null)
        : base(Guid.NewGuid(), createdBy)
    {
        if (string.IsNullOrWhiteSpace(categoryName))
            throw new ArgumentException("Category name cannot be empty", nameof(categoryName));

        CategoryName = categoryName.Trim();
        MccCode = mccCode?.Trim();
    }

    public void UpdateCategoryName(string categoryName)
    {
        if (string.IsNullOrWhiteSpace(categoryName))
            throw new ArgumentException("Category name cannot be empty", nameof(categoryName));
        CategoryName = categoryName.Trim();
    }

    public void UpdateMccCode(string? mccCode) => MccCode = mccCode?.Trim();
    public void Activate() => IsActive = true;
    public void Deactivate() => IsActive = false;
}