using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class ClientApp : FullAuditedAggregateRoot<Guid>
{
    public string AppCode { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string? Description { get; private set; }
    public ClientAppStatus Status { get; private set; } = ClientAppStatus.Inactive;

    private ClientApp() { }

    public ClientApp(string appCode, string name, string? createdBy, string? description = null)
        : base(Guid.NewGuid(), createdBy)
    {
        if (string.IsNullOrWhiteSpace(appCode))
            throw new ArgumentException("App code cannot be empty", nameof(appCode));
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("App name cannot be empty", nameof(name));

        AppCode = appCode.Trim().ToUpperInvariant();
        Name = name.Trim();
        Description = description?.Trim();
    }

    public void UpdateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("App name cannot be empty", nameof(name));
        Name = name.Trim();
    }

    public void UpdateDescription(string? description) => Description = description?.Trim();
    public void Activate() => Status = ClientAppStatus.Active;
    public void Suspend() => Status = ClientAppStatus.Suspended;
    public void Deactivate() => Status = ClientAppStatus.Inactive;
}