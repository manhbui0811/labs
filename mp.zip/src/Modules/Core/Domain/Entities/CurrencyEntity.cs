using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.ValueObjects;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class CurrencyEntity : EntityBase<string>
{
    public string Name { get; private set; } = string.Empty;
    public string Symbol { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;

    private CurrencyEntity() { }

    public CurrencyEntity(string code, string name, string symbol) : base(code)
    {
        var currencyCode = new CurrencyCode(code);

        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Currency name cannot be empty", nameof(name));
        if (string.IsNullOrWhiteSpace(symbol))
            throw new ArgumentException("Currency symbol cannot be empty", nameof(symbol));

        Name = name.Trim();
        Symbol = symbol.Trim();
    }

    public void UpdateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Currency name cannot be empty", nameof(name));
        Name = name.Trim();
    }

    public void UpdateSymbol(string symbol)
    {
        if (string.IsNullOrWhiteSpace(symbol))
            throw new ArgumentException("Currency symbol cannot be empty", nameof(symbol));
        Symbol = symbol.Trim();
    }

    public void Activate() => IsActive = true;
    public void Deactivate() => IsActive = false;
    public CurrencyCode GetCurrencyCode() => new(Id);
}