using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class DocumentType: FullAuditedAggregateRoot<int>
{
    public string TypeCode { get; private set; } = string.Empty;
    public string TypeName { get; private set; } = string.Empty;
    public string? Description { get; private set; }
    public bool IsActive { get; private set; } = true;

    // EF Core constructor
    private DocumentType() : base() { }

    public DocumentType(string typeCode, string typeName, string? description = null) : base()
    {
        if (string.IsNullOrWhiteSpace(typeCode))
            throw new ArgumentException("Type code cannot be empty", nameof(typeCode));

        if (string.IsNullOrWhiteSpace(typeName))
            throw new ArgumentException("Type name cannot be empty", nameof(typeName));

        TypeCode = typeCode.Trim().ToUpperInvariant();
        TypeName = typeName.Trim();
        Description = description?.Trim();
    }

    public void UpdateTypeName(string typeName)
    {
        if (string.IsNullOrWhiteSpace(typeName))
            throw new ArgumentException("Type name cannot be empty", nameof(typeName));

        TypeName = typeName.Trim();
    }

    public void UpdateDescription(string? description)
    {
        Description = description?.Trim();
    }

    public void Activate() => IsActive = true;
    public void Deactivate() => IsActive = false;
}


