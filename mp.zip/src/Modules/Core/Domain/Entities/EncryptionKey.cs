﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Enums;
using SHT.MerchantPortal.Shared.Kernel.Interfaces;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class EncryptionKey : EntityBase<Guid>, IAuditableEntity
{
    public string KeyIdentifier { get; set; } = null!;
    public string KeyVersion { get; set; } = null!;
    public EncryptionType KeyType { get; set; }
    public KeyCategory KeyCategory { get; set; }
    public OwnerType OwnerType { get; set; }
    public Guid OwnerId { get; set; }

    // Material khóa
    public string? PublicKeyPem { get; set; } // PEM format for public keys
    public byte[]? EncryptedPrivateKeyMaterial { get; set; } // Encrypted private key material
    public byte[]? EncryptedSymmetricKeyMaterial { get; set; } // Encrypted symmetric key material
    public byte[]? EncryptedHmacSecretMaterial { get; set; } // Encrypted HMAC secret material

    // Thông tin wrap khóa
    public string? KeyWrapAlgorithm { get; set; }
    public string? PrivateKekAlias { get; set; } // Key Encryption Key alias for private key
    public string? SymmetricKekAlias { get; set; } // Key Encryption Key alias for symmetric key
    public string? HmacKekAlias { get; set; } // Key Encryption Key alias for HMAC secret

    public string Algorithm { get; set; } = null!; // Ví dụ: RSA-OAEP, AES-256-GCM, HMAC-SHA256
    public KeyStatus KeyStatus { get; set; } = KeyStatus.Inactive; // Default 'Inactive'
    public DateTime? ActivatedAt { get; set; }
    public DateTime? ExpiresAt { get; set; }

    // Quan hệ xoay vòng khóa
    public Guid? RotatedToKeyId { get; set; } // FK to self
    public Guid? ParentKeyId { get; set; } // FK to self (for key derivation/hierarchy)

    public string? Ksn { get; set; } // Key Serial Number (cho DUKPT)
    public string? KeyUsage { get; set; } // Ví dụ: "SIGN", "ENCRYPT", "DECRYPT", "VERIFY"
    public string? KeyName { get; set; }

    // Vị trí lưu trữ khóa hoặc alias KMS
    public string? VaultPath { get; set; }
    public string? KmsKeyAlias { get; set; }

    public string Metadata { get; set; } = "{}"; // JSONB stored as string

    // IAuditableEntity properties
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public Guid? CreatedBy { get; set; } // Assuming created_by is a UUID, changed from VARCHAR(100)
    public Guid? UpdatedBy { get; set; }

    // Read-only property for owner_fingerprint (generated column in DB)
    // This property will be populated by the database, not set by the application directly.
    // It's a derived value for indexing and unique constraints.
    public string? OwnerFingerprint { get; set; }
}