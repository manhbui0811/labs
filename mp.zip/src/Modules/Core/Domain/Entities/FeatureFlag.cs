using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Events;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class FeatureFlag : FullAuditedAggregateRoot<Guid>
{
    private readonly List<FeatureFlagSetting> _settings = new();

    public string Name { get; private set; } = string.Empty;
    public string? Description { get; private set; }
    public bool IsEnabled { get; private set; }
    public string EnabledForTenants { get; private set; } = string.Empty;
    public string EnabledForUsers { get; private set; } = string.Empty;
    public DateTimeOffset? ExpiresAt { get; private set; }

    public IReadOnlyCollection<FeatureFlagSetting> Settings => _settings.AsReadOnly();

    private FeatureFlag() { }

    public FeatureFlag(
        string name,
        string? createdBy,
        bool isEnabled = false,
        string? description = null,
        DateTimeOffset? expiresAt = null) : base(Guid.NewGuid(), createdBy)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Feature name cannot be empty", nameof(name));

        Name = name.Trim();
        Description = description?.Trim();
        IsEnabled = isEnabled;
        ExpiresAt = expiresAt;
    }

    public void Enable(string? updatedBy = null)
    {
        if (IsEnabled) return;
        IsEnabled = true;
        base.UpdateAuditInfo(updatedBy);
        AddDomainEvent(new FeatureFlagChangedEvent(Id, Name, IsEnabled, updatedBy ?? "System"));
    }

    public void Disable(string? updatedBy = null)
    {
        if (!IsEnabled) return;
        IsEnabled = false;
        base.UpdateAuditInfo(updatedBy);
        AddDomainEvent(new FeatureFlagChangedEvent(Id, Name, IsEnabled, updatedBy ?? "System"));
    }

    public void SetExpiration(DateTimeOffset? expiresAt, string? updatedBy = null)
    {
        ExpiresAt = expiresAt;
        base.UpdateAuditInfo(updatedBy);
    }

    public void AddOrUpdateSetting(string key, string value, string? updatedBy = null)
    {
        if (string.IsNullOrWhiteSpace(key))
            throw new ArgumentException("Setting key cannot be empty", nameof(key));

        var existingSetting = _settings.FirstOrDefault(s => s.Key == key);
        if (existingSetting != null)
        {
            existingSetting.SetValue(value);
        }
        else
        {
            _settings.Add(new FeatureFlagSetting(key, value));
        }
        base.UpdateAuditInfo(updatedBy);
    }

    public void RemoveSetting(string key, string? updatedBy = null)
    {
        var settingToRemove = _settings.FirstOrDefault(s => s.Key == key);
        if (settingToRemove != null)
        {
            _settings.Remove(settingToRemove);
            base.UpdateAuditInfo(updatedBy);
        }
    }

    public string? GetSettingValue(string key, string? defaultValue = null)
    {
        return _settings.FirstOrDefault(s => s.Key == key)?.Value ?? defaultValue;
    }

    public void EnableForTenant(string tenantId, string updateBy = null)
    {
        if (string.IsNullOrWhiteSpace(tenantId))
            return;

        var tenants = string.IsNullOrEmpty(EnabledForTenants)
            ? new List<string>()
            : new List<string>(EnabledForTenants.Split(',', StringSplitOptions.RemoveEmptyEntries));

        if (!tenants.Contains(tenantId))
        {
            tenants.Add(tenantId);
            EnabledForTenants = string.Join(',', tenants);
            UpdatedAt = DateTimeOffset.UtcNow;
            UpdatedBy = updateBy;
        }
    }

    public void DisableForTenant(string tenantId, string updateBy=null)
    {
        if (string.IsNullOrWhiteSpace(tenantId) || string.IsNullOrEmpty(EnabledForTenants))
            return;

        var tenants = new List<string>(EnabledForTenants.Split(',', StringSplitOptions.RemoveEmptyEntries));

        if (tenants.Remove(tenantId))
        {
            EnabledForTenants = string.Join(',', tenants);
            UpdatedBy=updateBy;
            UpdatedAt = DateTimeOffset.UtcNow;
        }
    }

    public void EnableForUser(string userId, string updateBy=null)
    {
        if (string.IsNullOrWhiteSpace(userId))
            return;

        var users = string.IsNullOrEmpty(EnabledForUsers)
            ? new List<string>()
            : new List<string>(EnabledForUsers.Split(',', StringSplitOptions.RemoveEmptyEntries));

        if (!users.Contains(userId))
        {
            users.Add(userId);
            EnabledForUsers = string.Join(',', users);
            UpdatedAt = DateTimeOffset.UtcNow;
            UpdatedBy = updateBy;
        }
    }

    public void DisableForUser(string userId, string updateBy = null)
    {
        if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrEmpty(EnabledForUsers))
            return;

        var users = new List<string>(EnabledForUsers.Split(',', StringSplitOptions.RemoveEmptyEntries));

        if (users.Remove(userId))
        {
            EnabledForUsers = string.Join(',', users);
            UpdatedBy = updateBy;
            UpdatedAt = DateTimeOffset.UtcNow;
        }
    }

    public bool IsEnabledForTenant(string tenantId)
    {
        if (!IsEnabled || (ExpiresAt.HasValue && ExpiresAt.Value < DateTimeOffset.UtcNow))
            return false;

        if (string.IsNullOrWhiteSpace(EnabledForTenants))
            return IsEnabled;

        return EnabledForTenants.Split(',', StringSplitOptions.RemoveEmptyEntries)
            .Contains(tenantId);
    }

    public bool IsEnabledForUser(string userId)
    {
        if (!IsEnabled || (ExpiresAt.HasValue && ExpiresAt.Value < DateTimeOffset.UtcNow))
            return false;

        if (string.IsNullOrWhiteSpace(EnabledForUsers))
            return IsEnabled;

        return EnabledForUsers.Split(',', StringSplitOptions.RemoveEmptyEntries)
            .Contains(userId);
    }

}