using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Core.Domain.Entities;

public class FeatureFlagSetting : LongKeyEntityBase
{
    public Guid FeatureFlagId { get; private set; }
    public string Key { get; private set; } = string.Empty;
    public string Value { get; private set; } = string.Empty;

    public virtual FeatureFlag? FeatureFlag { get; private set; }

    private FeatureFlagSetting() { }

    public FeatureFlagSetting(string key, string value)
    {
        if (string.IsNullOrWhiteSpace(key))
            throw new ArgumentException("Setting key cannot be empty", nameof(key));

        Key = key.Trim();
        Value = value ?? string.Empty;
    }

    internal void SetValue(string value) => Value = value ?? string.Empty;
}