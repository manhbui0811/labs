﻿using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Shared.Kernel.Entities
{
    public class KeyRotationEvent : EntityBase<Guid>
    {
        public Guid? KeyId { get; set; } // FK to EncryptionKey
        public string? OldVersion { get; set; }
        public string? NewVersion { get; set; }
        public string? RotatedBy { get; set; } // Assuming this is a string identifier
        public DateTime RotatedAt { get; set; } = DateTime.UtcNow;
        public string? Note { get; set; }
    }
}
