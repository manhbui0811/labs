﻿using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Shared.Kernel.Entities
{
    public class KeyUsageLog : EntityBase<Guid>
    {
        public Guid? KeyId { get; set; } // FK to EncryptionKey
        public OwnerType OwnerType { get; set; }
        public string? OwnerFingerprint { get; set; }
        public DateTime UsedAt { get; set; } = DateTime.UtcNow;
        public string Context { get; set; } = "{}"; // JSONB stored as string
    }
}
