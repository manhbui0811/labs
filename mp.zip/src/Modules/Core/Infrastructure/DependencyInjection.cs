﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Services;
using SHT.MerchantPortal.Modules.Core.Application.Features.MasterData.Queries;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Modules.Core.Infrastructure.Services;
using SHT.MerchantPortal.Shared.Kernel.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddCoreModule(this IServiceCollection services, IConfiguration configuration)
        {
            AddDatabase(services, configuration);
            AddModuleService(services, configuration);
            AddMediatRWithBehaviors(services);
            return services;
        }

        private static void AddDatabase(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CoreDbContext>(options =>
                options.UseNpgsql(configuration.GetConnectionString("Core")));


            services.AddScoped<IRepositoryBase<ApiKey>, CoreRepository<ApiKey>>();
            services.AddScoped<IRepositoryBase<EncryptionKey>, CoreRepository<EncryptionKey>>();
            services.AddScoped<IRepositoryBase<KeyRotationEvent>, CoreRepository<KeyRotationEvent>>();
            services.AddScoped<IRepositoryBase<KeyUsageLog>, CoreRepository<KeyUsageLog>>();
            services.AddScoped<IRepositoryBase<Province>, CoreRepository<Province>>();
            services.AddScoped<IRepositoryBase<Ward>, CoreRepository<Ward>>();

            services.AddScoped<ICoreUnitOfWork, CoreUnitOfWork>();
        }

        private static void AddModuleService(IServiceCollection services, IConfiguration configuration)
        {

            services.AddScoped<IApiKeyService, ApiKeyService>();
            services.AddScoped<IEncryptionKeyService, EncryptionKeyService>();
            services.AddScoped<IDeviceKeyProvider, DeviceKeyProvider>();
        }





        private static void AddMediatRWithBehaviors(IServiceCollection services)
        {
            services.AddMediatR(cfg =>
            {
                cfg.RegisterServicesFromAssembly(typeof(GetProvincesQuery).Assembly);
            });

        }
    }
}
