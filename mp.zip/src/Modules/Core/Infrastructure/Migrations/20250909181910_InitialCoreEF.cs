﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class InitialCoreEF : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "core");

            migrationBuilder.EnsureSchema(
                name: "audit");

            migrationBuilder.CreateTable(
                name: "api_keys",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    owner_type = table.Column<string>(type: "text", nullable: false),
                    owner_id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: false),
                    key_prefix = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    key_hash = table.Column<string>(type: "text", nullable: false),
                    scope = table.Column<string>(type: "jsonb", nullable: false, defaultValueSql: "'{}'::jsonb"),
                    status = table.Column<string>(type: "text", nullable: false, defaultValue: "Active"),
                    expires_at = table.Column<DateTime>(type: "timestamptz", nullable: true),
                    last_used_at = table.Column<DateTime>(type: "timestamptz", nullable: true),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_api_keys", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "audit_logs",
                schema: "audit",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<string>(type: "text", nullable: true),
                    entity_id = table.Column<string>(type: "text", nullable: true),
                    table_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    record_id = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    action_type = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    details = table.Column<string>(type: "JSONB", nullable: true),
                    ip_address = table.Column<string>(type: "character varying(45)", maxLength: 45, nullable: true),
                    user_agent = table.Column<string>(type: "TEXT", nullable: true),
                    timestamp = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_audit_logs", x => x.id);
                },
                comment: "Partitioned by timestamp (monthly)");

            migrationBuilder.CreateTable(
                name: "business_categories",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    category_name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    mcc_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false, defaultValue: true),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true, defaultValueSql: "NOW()"),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_business_categories", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "client_apps",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    app_code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    description = table.Column<string>(type: "TEXT", nullable: true),
                    status = table.Column<int>(type: "integer", nullable: false, defaultValue: 0),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true, defaultValueSql: "NOW()"),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    DeletedBy = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_client_apps", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "currencies",
                schema: "core",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    symbol = table.Column<string>(type: "character varying(5)", maxLength: 5, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_currencies", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "document_types",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    type_code = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    type_name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    description = table.Column<string>(type: "TEXT", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false, defaultValue: true),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true, defaultValueSql: "NOW()"),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    DeletedBy = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_document_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "encryption_keys",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    key_identifier = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    key_version = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    key_type = table.Column<string>(type: "text", nullable: false),
                    key_category = table.Column<string>(type: "text", nullable: false),
                    owner_type = table.Column<string>(type: "text", nullable: false),
                    owner_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    public_key_pem = table.Column<string>(type: "text", nullable: true),
                    encrypted_private_key_material = table.Column<byte[]>(type: "bytea", nullable: true),
                    encrypted_symmetric_key_material = table.Column<byte[]>(type: "bytea", nullable: true),
                    encrypted_hmac_secret_material = table.Column<byte[]>(type: "bytea", nullable: true),
                    key_wrap_algorithm = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    private_kek_alias = table.Column<string>(type: "text", nullable: true),
                    symmetric_kek_alias = table.Column<string>(type: "text", nullable: true),
                    hmac_kek_alias = table.Column<string>(type: "text", nullable: true),
                    algorithm = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    key_status = table.Column<string>(type: "text", nullable: false, defaultValue: "Inactive"),
                    activated_at = table.Column<DateTime>(type: "timestamptz", nullable: true),
                    expires_at = table.Column<DateTime>(type: "timestamptz", nullable: true),
                    rotated_to_key_id = table.Column<Guid>(type: "uuid", nullable: true),
                    parent_key_id = table.Column<Guid>(type: "uuid", nullable: true),
                    ksn = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    key_usage = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    key_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    vault_path = table.Column<string>(type: "text", nullable: true),
                    kms_key_alias = table.Column<string>(type: "text", nullable: true),
                    metadata = table.Column<string>(type: "jsonb", nullable: false, defaultValueSql: "'{}'::jsonb"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    owner_fingerprint = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_encryption_keys", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "feature_flags",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    description = table.Column<string>(type: "TEXT", nullable: true),
                    is_enabled = table.Column<bool>(type: "boolean", nullable: false, defaultValue: false),
                    enabled_for_tenants = table.Column<string>(type: "TEXT", nullable: false, defaultValue: ""),
                    enabled_for_users = table.Column<string>(type: "TEXT", nullable: false, defaultValue: ""),
                    expires_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()"),
                    updated_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true, defaultValueSql: "NOW()"),
                    created_by = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    updated_by = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    DeletedBy = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_feature_flags", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "key_rotation_events",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    key_id = table.Column<Guid>(type: "uuid", nullable: true),
                    old_version = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true),
                    new_version = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true),
                    rotated_by = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    rotated_at = table.Column<DateTime>(type: "timestamptz", nullable: false, defaultValueSql: "NOW()"),
                    note = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_key_rotation_events", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "key_usage_log",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    key_id = table.Column<Guid>(type: "uuid", nullable: true),
                    owner_type = table.Column<string>(type: "text", nullable: false),
                    owner_fingerprint = table.Column<string>(type: "text", nullable: true),
                    used_at = table.Column<DateTime>(type: "timestamptz", nullable: false, defaultValueSql: "NOW()"),
                    context = table.Column<string>(type: "jsonb", nullable: false, defaultValueSql: "'{}'::jsonb")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_key_usage_log", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "provinces",
                schema: "core",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_provinces", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "feature_flag_settings",
                schema: "core",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    feature_flag_id = table.Column<Guid>(type: "uuid", nullable: false),
                    key = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    value = table.Column<string>(type: "TEXT", nullable: false, defaultValue: "")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_feature_flag_settings", x => x.id);
                    table.ForeignKey(
                        name: "FK_feature_flag_settings_feature_flags_feature_flag_id",
                        column: x => x.feature_flag_id,
                        principalSchema: "core",
                        principalTable: "feature_flags",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "wards",
                schema: "core",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    province_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_wards", x => x.code);
                    table.ForeignKey(
                        name: "FK_wards_provinces_province_code",
                        column: x => x.province_code,
                        principalSchema: "core",
                        principalTable: "provinces",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "uq_api_key_hash",
                schema: "core",
                table: "api_keys",
                column: "key_hash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_audit_logs_action_type",
                schema: "audit",
                table: "audit_logs",
                column: "action_type");

            migrationBuilder.CreateIndex(
                name: "ix_audit_logs_entity_id",
                schema: "audit",
                table: "audit_logs",
                column: "entity_id");

            migrationBuilder.CreateIndex(
                name: "ix_audit_logs_timestamp",
                schema: "audit",
                table: "audit_logs",
                column: "timestamp");

            migrationBuilder.CreateIndex(
                name: "ix_audit_logs_user_id",
                schema: "audit",
                table: "audit_logs",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_business_categories_is_active",
                schema: "core",
                table: "business_categories",
                column: "is_active");

            migrationBuilder.CreateIndex(
                name: "ix_business_categories_mcc_code",
                schema: "core",
                table: "business_categories",
                column: "mcc_code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_client_apps_app_code",
                schema: "core",
                table: "client_apps",
                column: "app_code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_client_apps_status",
                schema: "core",
                table: "client_apps",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "ix_currencies_is_active",
                schema: "core",
                table: "currencies",
                column: "is_active");

            migrationBuilder.CreateIndex(
                name: "ix_document_types_is_active",
                schema: "core",
                table: "document_types",
                column: "is_active");

            migrationBuilder.CreateIndex(
                name: "ix_document_types_type_code",
                schema: "core",
                table: "document_types",
                column: "type_code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_enck_kid",
                schema: "core",
                table: "encryption_keys",
                columns: new[] { "key_identifier", "key_version" });

            migrationBuilder.CreateIndex(
                name: "ix_enck_owner_status",
                schema: "core",
                table: "encryption_keys",
                columns: new[] { "owner_type", "owner_fingerprint", "key_status" });

            migrationBuilder.CreateIndex(
                name: "ix_enck_parent",
                schema: "core",
                table: "encryption_keys",
                column: "parent_key_id");

            migrationBuilder.CreateIndex(
                name: "ix_enck_rotated_to",
                schema: "core",
                table: "encryption_keys",
                column: "rotated_to_key_id");

            migrationBuilder.CreateIndex(
                name: "uq_enck_owner_id_ver",
                schema: "core",
                table: "encryption_keys",
                columns: new[] { "owner_fingerprint", "key_identifier", "key_version" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_feature_flag_settings_flag_key",
                schema: "core",
                table: "feature_flag_settings",
                columns: new[] { "feature_flag_id", "key" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_feature_flags_expires_at",
                schema: "core",
                table: "feature_flags",
                column: "expires_at");

            migrationBuilder.CreateIndex(
                name: "ix_feature_flags_is_enabled",
                schema: "core",
                table: "feature_flags",
                column: "is_enabled");

            migrationBuilder.CreateIndex(
                name: "ix_feature_flags_name",
                schema: "core",
                table: "feature_flags",
                column: "name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_provinces_name",
                schema: "core",
                table: "provinces",
                column: "name");

            migrationBuilder.CreateIndex(
                name: "ix_wards_name",
                schema: "core",
                table: "wards",
                column: "name");

            migrationBuilder.CreateIndex(
                name: "ix_wards_province_code",
                schema: "core",
                table: "wards",
                column: "province_code");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "api_keys",
                schema: "core");

            migrationBuilder.DropTable(
                name: "audit_logs",
                schema: "audit");

            migrationBuilder.DropTable(
                name: "business_categories",
                schema: "core");

            migrationBuilder.DropTable(
                name: "client_apps",
                schema: "core");

            migrationBuilder.DropTable(
                name: "currencies",
                schema: "core");

            migrationBuilder.DropTable(
                name: "document_types",
                schema: "core");

            migrationBuilder.DropTable(
                name: "encryption_keys",
                schema: "core");

            migrationBuilder.DropTable(
                name: "feature_flag_settings",
                schema: "core");

            migrationBuilder.DropTable(
                name: "key_rotation_events",
                schema: "core");

            migrationBuilder.DropTable(
                name: "key_usage_log",
                schema: "core");

            migrationBuilder.DropTable(
                name: "wards",
                schema: "core");

            migrationBuilder.DropTable(
                name: "feature_flags",
                schema: "core");

            migrationBuilder.DropTable(
                name: "provinces",
                schema: "core");
        }
    }
}
