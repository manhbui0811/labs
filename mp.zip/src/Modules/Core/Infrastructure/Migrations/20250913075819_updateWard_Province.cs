﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class updateWard_Province : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_wards_provinces_province_code",
                schema: "core",
                table: "wards");

            migrationBuilder.DropPrimaryKey(
                name: "PK_wards",
                schema: "core",
                table: "wards");

            migrationBuilder.DropPrimaryKey(
                name: "PK_provinces",
                schema: "core",
                table: "provinces");

            migrationBuilder.AlterColumn<string>(
                name: "province_code",
                schema: "core",
                table: "wards",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(10)",
                oldMaxLength: 10);

            migrationBuilder.AlterColumn<string>(
                name: "code",
                schema: "core",
                table: "wards",
                type: "character varying(150)",
                maxLength: 150,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(10)",
                oldMaxLength: 10);

            migrationBuilder.AddColumn<Guid>(
                name: "id",
                schema: "core",
                table: "wards",
                type: "uuid",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AlterColumn<string>(
                name: "code",
                schema: "core",
                table: "provinces",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(10)",
                oldMaxLength: 10);

            migrationBuilder.AddColumn<Guid>(
                name: "id",
                schema: "core",
                table: "provinces",
                type: "uuid",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AlterColumn<string>(
                name: "key_status",
                schema: "core",
                table: "encryption_keys",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text",
                oldDefaultValue: "Inactive");

            migrationBuilder.AddPrimaryKey(
                name: "PK_wards",
                schema: "core",
                table: "wards",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_provinces",
                schema: "core",
                table: "provinces",
                column: "id");

            migrationBuilder.CreateIndex(
                name: "IX_wards_code",
                schema: "core",
                table: "wards",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_provinces_code",
                schema: "core",
                table: "provinces",
                column: "code",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_wards",
                schema: "core",
                table: "wards");

            migrationBuilder.DropIndex(
                name: "IX_wards_code",
                schema: "core",
                table: "wards");

            migrationBuilder.DropPrimaryKey(
                name: "PK_provinces",
                schema: "core",
                table: "provinces");

            migrationBuilder.DropIndex(
                name: "IX_provinces_code",
                schema: "core",
                table: "provinces");

            migrationBuilder.DropColumn(
                name: "id",
                schema: "core",
                table: "wards");

            migrationBuilder.DropColumn(
                name: "id",
                schema: "core",
                table: "provinces");

            migrationBuilder.AlterColumn<string>(
                name: "province_code",
                schema: "core",
                table: "wards",
                type: "character varying(10)",
                maxLength: 10,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "code",
                schema: "core",
                table: "wards",
                type: "character varying(10)",
                maxLength: 10,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(150)",
                oldMaxLength: 150);

            migrationBuilder.AlterColumn<string>(
                name: "code",
                schema: "core",
                table: "provinces",
                type: "character varying(10)",
                maxLength: 10,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "key_status",
                schema: "core",
                table: "encryption_keys",
                type: "text",
                nullable: false,
                defaultValue: "Inactive",
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddPrimaryKey(
                name: "PK_wards",
                schema: "core",
                table: "wards",
                column: "code");

            migrationBuilder.AddPrimaryKey(
                name: "PK_provinces",
                schema: "core",
                table: "provinces",
                column: "code");

            migrationBuilder.AddForeignKey(
                name: "FK_wards_provinces_province_code",
                schema: "core",
                table: "wards",
                column: "province_code",
                principalSchema: "core",
                principalTable: "provinces",
                principalColumn: "code",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
