﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations
{
    public class ApiKeyConfiguration : IEntityTypeConfiguration<ApiKey>
    {
        public void Configure(EntityTypeBuilder<ApiKey> builder)
        {
            builder.ToTable("api_keys"); // Tên bảng

            builder.HasKey(x => x.Id); // Khóa chính
            builder.Property(x => x.Id).HasColumnName("id");

            // Cấu hình các trường OwnerType và các Owner ID
            builder.Property(e => e.OwnerType).HasColumnName("owner_type").HasConversion<string>().IsRequired();
            builder.Property(e => e.OwnerId).HasColumnName("owner_id");

            // Cấu hình các trường khác
            builder.Property(e => e.KeyPrefix).HasColumnName("key_prefix").HasMaxLength(16).IsRequired();
            builder.Property(e => e.KeyHash).HasColumnName("key_hash").HasColumnType("text").IsRequired();
            builder.Property(e => e.Scope).HasColumnName("scope").HasColumnType("jsonb").IsRequired().HasDefaultValueSql("'{}'::jsonb");
            builder.Property(e => e.Status).HasColumnName("status").HasConversion<string>().IsRequired().HasDefaultValue(KeyStatus.Active);
            builder.Property(e => e.ExpiresAt).HasColumnName("expires_at").HasColumnType("timestamptz");
            builder.Property(e => e.LastUsedAt).HasColumnName("last_used_at").HasColumnType("timestamptz");

            // Cấu hình các trường IAuditableEntity
            builder.Property(e => e.CreatedBy).HasColumnName("created_by");
            builder.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.UpdatedBy).HasColumnName("updated_by"); // Đã thêm UpdatedBy vào Entity

            // Cấu hình ràng buộc duy nhất (UNIQUE constraint)
            builder.HasIndex(e => e.KeyHash).IsUnique().HasDatabaseName("uq_api_key_hash");

            // Note: Ràng buộc CHECK (ck_apikey_owner_match) phức tạp trong SQL cần được xử lý ở tầng Application (ví dụ: trong Validator hoặc Service)
            // hoặc thông qua user-defined function/trigger nếu cần enforce ở DB level, do EF Core không hỗ trợ CHECK constraint phức tạp này trực tiếp.
            // Các foreign key REFERENCES users(id) đã được loại bỏ theo yêu cầu của bạn "tôi không dùng khóa phụ".
        }
    }
}
