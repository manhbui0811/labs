using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
{
    public void Configure(EntityTypeBuilder<AuditLog> builder)
    {
        builder.ToTable("audit_logs", "audit");

        builder.HasKey(al => al.Id);

        builder.Property(al => al.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(al => al.UserId)
            .HasColumnName("user_id");

        builder.Property(al => al.EntityId)
            .HasColumnName("entity_id");

        builder.Property(al => al.ActionType)
            .HasColumnName("action_type")
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(al => al.TableName)
            .HasColumnName("table_name")
            .HasMaxLength(100);

        builder.Property(al => al.RecordId)
            .HasColumnName("record_id")
            .HasMaxLength(100);

        builder.Property(al => al.Details)
            .HasColumnName("details")
            .HasColumnType("JSONB");

        builder.Property(al => al.IpAddress)
            .HasColumnName("ip_address")
            .HasMaxLength(45);

        builder.Property(al => al.UserAgent)
            .HasColumnName("user_agent")
            .HasColumnType("TEXT");

        builder.Property(al => al.Timestamp)
            .HasColumnName("timestamp")
            .HasDefaultValueSql("NOW()");

        builder.HasIndex(al => al.UserId)
            .HasDatabaseName("ix_audit_logs_user_id");

        builder.HasIndex(al => al.EntityId)
            .HasDatabaseName("ix_audit_logs_entity_id");

        builder.HasIndex(al => al.ActionType)
            .HasDatabaseName("ix_audit_logs_action_type");

        builder.HasIndex(al => al.Timestamp)
            .HasDatabaseName("ix_audit_logs_timestamp");

        // Partition by timestamp (monthly partitions)
        builder.ToTable(tb => tb.HasComment("Partitioned by timestamp (monthly)"));
    }
}


