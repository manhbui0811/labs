using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class BusinessCategoryConfiguration : IEntityTypeConfiguration<BusinessCategory>
{
    public void Configure(EntityTypeBuilder<BusinessCategory> builder)
    {
        builder.ToTable("business_categories", "core");

        builder.HasKey(bc => bc.Id);

        builder.Property(bc => bc.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(bc => bc.CategoryName)
            .HasColumnName("category_name")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(bc => bc.MccCode)
            .HasColumnName("mcc_code")
            .HasMaxLength(10);

        builder.Property(bc => bc.IsActive)
            .HasColumnName("is_active")
            .HasDefaultValue(true);

        builder.Property(bc => bc.CreatedBy)
            .HasColumnName("created_by");

        builder.Property(bc => bc.CreatedAt)
            .HasColumnName("created_at")
            .HasDefaultValueSql("NOW()");

        builder.Property(bc => bc.UpdatedBy)
            .HasColumnName("updated_by");

        builder.Property(bc => bc.UpdatedAt)
            .HasColumnName("updated_at")
            .HasDefaultValueSql("NOW()");

        builder.HasIndex(bc => bc.MccCode)
            .IsUnique()
            .HasDatabaseName("ix_business_categories_mcc_code");

        builder.HasIndex(bc => bc.IsActive)
            .HasDatabaseName("ix_business_categories_is_active");
    }
}


