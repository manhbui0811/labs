using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class ClientAppConfiguration : IEntityTypeConfiguration<ClientApp>
{
    public void Configure(EntityTypeBuilder<ClientApp> builder)
    {
        builder.ToTable("client_apps", "core");

        builder.HasKey(ca => ca.Id);

        builder.Property(ca => ca.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(ca => ca.AppCode)
            .HasColumnName("app_code")
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(ca => ca.Name)
            .HasColumnName("name")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(ca => ca.Description)
            .HasColumnName("description")
            .HasColumnType("TEXT");

        builder.Property(ca => ca.Status)
            .HasColumnName("status")
            .HasConversion<int>()
            .HasDefaultValue(ClientAppStatus.Inactive);

        builder.Property(ca => ca.CreatedBy)
            .HasColumnName("created_by");

        builder.Property(ca => ca.CreatedAt)
            .HasColumnName("created_at")
            .HasDefaultValueSql("NOW()");

        builder.Property(ca => ca.UpdatedBy)
            .HasColumnName("updated_by");

        builder.Property(ca => ca.UpdatedAt)
            .HasColumnName("updated_at")
            .HasDefaultValueSql("NOW()");

        builder.HasIndex(ca => ca.AppCode)
            .IsUnique()
            .HasDatabaseName("ix_client_apps_app_code");

        builder.HasIndex(ca => ca.Status)
            .HasDatabaseName("ix_client_apps_status");
    }
}


