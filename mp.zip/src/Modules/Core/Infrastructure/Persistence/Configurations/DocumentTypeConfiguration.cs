using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class DocumentTypeConfiguration : IEntityTypeConfiguration<DocumentType>
{
    public void Configure(EntityTypeBuilder<DocumentType> builder)
    {
        builder.ToTable("document_types", "core");

        builder.HasKey(dt => dt.Id);

        builder.Property(dt => dt.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(dt => dt.TypeCode)
            .HasColumnName("type_code")
            .HasMaxLength(100)
            .IsRequired();

        builder.Property(dt => dt.TypeName)
            .HasColumnName("type_name")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(dt => dt.Description)
            .HasColumnName("description")
            .HasColumnType("TEXT");

        builder.Property(dt => dt.IsActive)
            .HasColumnName("is_active")
            .HasDefaultValue(true);

        builder.Property(dt => dt.CreatedBy)
            .HasColumnName("created_by");

        builder.Property(dt => dt.CreatedAt)
            .HasColumnName("created_at")
            .HasDefaultValueSql("NOW()");

        builder.Property(dt => dt.UpdatedBy)
            .HasColumnName("updated_by");

        builder.Property(dt => dt.UpdatedAt)
            .HasColumnName("updated_at")
            .HasDefaultValueSql("NOW()");

        builder.HasIndex(dt => dt.TypeCode)
            .IsUnique()
            .HasDatabaseName("ix_document_types_type_code");

        builder.HasIndex(dt => dt.IsActive)
            .HasDatabaseName("ix_document_types_is_active");
    }
}


