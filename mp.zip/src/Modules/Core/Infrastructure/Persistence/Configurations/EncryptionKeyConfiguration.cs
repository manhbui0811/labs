﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations
{
    public class EncryptionKeyConfiguration : IEntityTypeConfiguration<EncryptionKey>
    {
        public void Configure(EntityTypeBuilder<EncryptionKey> builder)
        {
            builder.ToTable("encryption_keys"); // Tên bảng

            builder.HasKey(x => x.Id); // Khóa chính
            builder.Property(x => x.Id).HasColumnName("id");

            // Các thuộc tính cơ bản
            builder.Property(e => e.KeyIdentifier).HasColumnName("key_identifier").HasMaxLength(100).IsRequired();
            builder.Property(e => e.KeyVersion).HasColumnName("key_version").HasMaxLength(40).IsRequired();

            // Các enum
            builder.Property(e => e.KeyType).HasColumnName("key_type").HasConversion<string>().IsRequired();
            builder.Property(e => e.KeyCategory).HasColumnName("key_category").HasConversion<string>().IsRequired();
            builder.Property(e => e.OwnerType).HasColumnName("owner_type").HasConversion<string>().IsRequired();
            builder.Property(e => e.KeyStatus).HasColumnName("key_status").HasConversion<string>().IsRequired();

            // Các ID của chủ sở hữu
            builder.Property(e => e.OwnerId).HasColumnName("owner_user_id");

            // Key material và Key wrapping
            builder.Property(e => e.PublicKeyPem).HasColumnName("public_key_pem").HasColumnType("text");
            builder.Property(e => e.EncryptedPrivateKeyMaterial).HasColumnName("encrypted_private_key_material").HasColumnType("bytea");
            builder.Property(e => e.EncryptedSymmetricKeyMaterial).HasColumnName("encrypted_symmetric_key_material").HasColumnType("bytea");
            builder.Property(e => e.EncryptedHmacSecretMaterial).HasColumnName("encrypted_hmac_secret_material").HasColumnType("bytea");

            builder.Property(e => e.KeyWrapAlgorithm).HasColumnName("key_wrap_algorithm").HasMaxLength(50);
            builder.Property(e => e.PrivateKekAlias).HasColumnName("private_kek_alias").HasColumnType("text");
            builder.Property(e => e.SymmetricKekAlias).HasColumnName("symmetric_kek_alias").HasColumnType("text");
            builder.Property(e => e.HmacKekAlias).HasColumnName("hmac_kek_alias").HasColumnType("text");

            // Thuộc tính Algorithm, Status, Thời gian
            builder.Property(e => e.Algorithm).HasColumnName("algorithm").HasMaxLength(50).IsRequired();
            builder.Property(e => e.ActivatedAt).HasColumnName("activated_at").HasColumnType("timestamptz");
            builder.Property(e => e.ExpiresAt).HasColumnName("expires_at").HasColumnType("timestamptz");

            // Quan hệ xoay vòng khóa và parent key (không cấu hình FK)
            builder.Property(e => e.RotatedToKeyId).HasColumnName("rotated_to_key_id");
            builder.Property(e => e.ParentKeyId).HasColumnName("parent_key_id");

            // Các thuộc tính khác
            builder.Property(e => e.Ksn).HasColumnName("ksn").HasMaxLength(32);
            builder.Property(e => e.KeyUsage).HasColumnName("key_usage").HasMaxLength(50);
            builder.Property(e => e.KeyName).HasColumnName("key_name").HasMaxLength(100);
            builder.Property(e => e.VaultPath).HasColumnName("vault_path").HasColumnType("text");
            builder.Property(e => e.KmsKeyAlias).HasColumnName("kms_key_alias").HasColumnType("text");
            builder.Property(e => e.Metadata).HasColumnName("metadata").HasColumnType("jsonb").IsRequired().HasDefaultValueSql("'{}'::jsonb");

            // Các trường IAuditableEntity
            builder.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.CreatedBy).HasColumnName("created_by"); // uuid_v7 trong SQL
            builder.Property(e => e.UpdatedBy).HasColumnName("updated_by"); // uuid_v7 trong SQL

            // Cột generated always as (không cấu hình GenerateAlwaysAs ở đây, nó sẽ được database xử lý)
            builder.Property(e => e.OwnerFingerprint).HasColumnName("owner_fingerprint");
            // Vì nó là GENERATED ALWAYS AS, EF Core sẽ đọc nó nhưng không cố gắng ghi.

            // Ràng buộc duy nhất (UNIQUE constraint)
            builder.HasIndex(e => new { e.OwnerFingerprint, e.KeyIdentifier, e.KeyVersion })
                   .IsUnique()
                   .HasDatabaseName("uq_enck_owner_id_ver");

            // Các chỉ mục (Indexes)
            builder.HasIndex(e => new { e.OwnerType, e.OwnerFingerprint, e.KeyStatus }).HasDatabaseName("ix_enck_owner_status");
            builder.HasIndex(e => new { e.KeyIdentifier, e.KeyVersion }).HasDatabaseName("ix_enck_kid"); // LOWER(key_identifier)
            builder.HasIndex(e => e.ParentKeyId).HasDatabaseName("ix_enck_parent");
            builder.HasIndex(e => e.RotatedToKeyId).HasDatabaseName("ix_enck_rotated_to");

            // Lưu ý: Các CHECK constraint phức tạp và TRIGGER cần được quản lý ngoài EF Core, trực tiếp trên database.
        }
    }
}
