﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class FeatureFlagConfiguration : IEntityTypeConfiguration<FeatureFlag>
{
    public void Configure(EntityTypeBuilder<FeatureFlag> builder)
    {
        builder.ToTable("feature_flags", "core");

        builder.HasKey(ff => ff.Id);

        builder.Property(ff => ff.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(ff => ff.Name)
            .HasColumnName("name")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(ff => ff.Description)
            .HasColumnName("description")
            .HasColumnType("TEXT");

        builder.Property(ff => ff.IsEnabled)
            .HasColumnName("is_enabled")
            .HasDefaultValue(false);

        builder.Property(ff => ff.EnabledForTenants)
            .HasColumnName("enabled_for_tenants")
            .HasColumnType("TEXT")
            .HasDefaultValue(string.Empty);

        builder.Property(ff => ff.EnabledForUsers)
            .HasColumnName("enabled_for_users")
            .HasColumnType("TEXT")
            .HasDefaultValue(string.Empty);

        builder.Property(ff => ff.ExpiresAt)
            .HasColumnName("expires_at");

        builder.Property(ff => ff.CreatedAt)
            .HasColumnName("created_at")
            .HasDefaultValueSql("NOW()");

        builder.Property(ff => ff.CreatedBy)
            .HasColumnName("created_by")
            .HasMaxLength(255);

        builder.Property(ff => ff.UpdatedAt)
            .HasColumnName("updated_at");

        builder.Property(ff => ff.UpdatedBy)
            .HasColumnName("updated_by")
            .HasMaxLength(255);

        // Relationships
        builder.HasMany(ff => ff.Settings)
            .WithOne(s => s.FeatureFlag) // Giả sử FeatureFlagSetting có thuộc tính điều hướng tên là FeatureFlag
            .HasForeignKey(s => s.FeatureFlagId)
            .OnDelete(DeleteBehavior.Cascade);

        // Indexes
        builder.HasIndex(ff => ff.Name)
            .IsUnique()
            .HasDatabaseName("ix_feature_flags_name");

        builder.HasIndex(ff => ff.IsEnabled)
            .HasDatabaseName("ix_feature_flags_is_enabled");

        builder.HasIndex(ff => ff.ExpiresAt)
            .HasDatabaseName("ix_feature_flags_expires_at");
    }
}


