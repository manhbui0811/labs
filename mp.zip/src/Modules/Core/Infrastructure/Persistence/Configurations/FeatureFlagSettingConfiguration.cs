using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class FeatureFlagSettingConfiguration : IEntityTypeConfiguration<FeatureFlagSetting>
{
    public void Configure(EntityTypeBuilder<FeatureFlagSetting> builder)
    {
        builder.ToTable("feature_flag_settings", "core");

        builder.HasKey(ffs => ffs.Id);

        builder.Property(ffs => ffs.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(ffs => ffs.FeatureFlagId)
            .HasColumnName("feature_flag_id")
            .IsRequired();

        builder.Property(ffs => ffs.Key)
            .HasColumnName("key")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(ffs => ffs.Value)
            .HasColumnName("value")
            .HasColumnType("TEXT")
            .HasDefaultValue(string.Empty);

        // Relationships
        builder.HasOne(ffs => ffs.FeatureFlag)
            .WithMany(ff => ff.Settings)
            .HasForeignKey(ffs => ffs.FeatureFlagId)
            .OnDelete(DeleteBehavior.Cascade);

        // Indexes
        builder.HasIndex(ffs => new { ffs.FeatureFlagId, ffs.Key })
            .IsUnique()
            .HasDatabaseName("ix_feature_flag_settings_flag_key");
    }
}


