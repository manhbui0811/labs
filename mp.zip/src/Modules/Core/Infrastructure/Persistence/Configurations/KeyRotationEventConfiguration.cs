﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Shared.Kernel.Entities;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations
{
    public class KeyRotationEventConfiguration : IEntityTypeConfiguration<KeyRotationEvent>
    {
        public void Configure(EntityTypeBuilder<KeyRotationEvent> builder)
        {
            builder.ToTable("key_rotation_events"); // Tên bảng

            builder.HasKey(x => x.Id); // Khóa chính
            builder.Property(x => x.Id).HasColumnName("id");

            builder.Property(e => e.KeyId).HasColumnName("key_id"); // Không cấu hình FK
            builder.Property(e => e.OldVersion).HasColumnName("old_version").HasMaxLength(40);
            builder.Property(e => e.NewVersion).HasColumnName("new_version").HasMaxLength(40);
            builder.Property(e => e.RotatedBy).HasColumnName("rotated_by").HasMaxLength(100);
            builder.Property(e => e.RotatedAt).HasColumnName("rotated_at").HasColumnType("timestamptz").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.Note).HasColumnName("note").HasColumnType("text");
        }
    }
}
