﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Shared.Kernel.Entities;

namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Configurations
{
    public class KeyUsageLogConfiguration : IEntityTypeConfiguration<KeyUsageLog>
    {
        public void Configure(EntityTypeBuilder<KeyUsageLog> builder)
        {
            builder.ToTable("key_usage_log"); // Tên bảng

            builder.HasKey(x => x.Id); // Khóa chính
            builder.Property(x => x.Id).HasColumnName("id");

            builder.Property(e => e.KeyId).HasColumnName("key_id"); // Không cấu hình FK
            builder.Property(e => e.OwnerType).HasColumnName("owner_type").HasConversion<string>().IsRequired();
            builder.Property(e => e.OwnerFingerprint).HasColumnName("owner_fingerprint").HasColumnType("text");
            builder.Property(e => e.UsedAt).HasColumnName("used_at").HasColumnType("timestamptz").IsRequired().HasDefaultValueSql("NOW()");
            builder.Property(e => e.Context).HasColumnName("context").HasColumnType("jsonb").IsRequired().HasDefaultValueSql("'{}'::jsonb");

        }
    }
}
