using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Configurations;

public class WardConfiguration : IEntityTypeConfiguration<Ward>
{
    public void Configure(EntityTypeBuilder<Ward> builder)
    {
        builder.ToTable("wards", "core");

        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).HasColumnName("id");

        builder.Property(p => p.Code)
            .HasColumnName("code")
            .HasMaxLength(150)
            .IsRequired();
        builder.HasIndex(x => x.Code).IsUnique();

        builder.Property(w => w.Name)
            .HasColumnName("name")
            .HasMaxLength(255)
            .IsRequired();

        builder.Property(w => w.ProvinceCode)
            .HasColumnName("province_code")
            .HasMaxLength(100)
            .IsRequired();

        builder.HasIndex(w => w.ProvinceCode)
            .HasDatabaseName("ix_wards_province_code");

        builder.HasIndex(w => w.Name)
            .HasDatabaseName("ix_wards_name");
    }
}


