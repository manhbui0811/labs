﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence
{

    public class CoreDbContext : ApplicationDbContextBase
    {
        public CoreDbContext(DbContextOptions<CoreDbContext> options) : base(options) { }
        public CoreDbContext(
           DbContextOptions<CoreDbContext> options,
           ILogger<CoreDbContext> logger,
           ICurrentUser currentUserService,
           IDateTimeProvider dateTimeProvider)
           : base(options, logger, currentUserService, dateTimeProvider)
        {
        }

        public DbSet<ApiKey> ApiKeys => Set<ApiKey>();
        public DbSet<EncryptionKey> EncryptionKeys => Set<EncryptionKey>();
        public DbSet<KeyRotationEvent> KeyRotationEvents => Set<KeyRotationEvent>();
        public DbSet<KeyUsageLog> KeyUsageLogs => Set<KeyUsageLog>();
        public DbSet<Ward> Wards => Set<Ward>();
        public DbSet<Province> Provinces => Set<Province>();
       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("core");
            base.OnModelCreating(modelBuilder);
        }
    }
}
