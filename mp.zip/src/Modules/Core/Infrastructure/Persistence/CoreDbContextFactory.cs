﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence
{
    public class CoreDbContextFactory : IDesignTimeDbContextFactory<CoreDbContext>
    {
        public CoreDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CoreDbContext>();

            // Load cấu hình từ appsettings.json (nếu cần)
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .Build();

            var connectionString = configuration.GetConnectionString("Core")
                                   ?? "Server=103.167.89.139;Port=5432;Database=MerchantPortal;Username=merchant;Password=Ab123456@";

            optionsBuilder.UseNpgsql(connectionString);


            return new CoreDbContext(optionsBuilder.Options);
        }


    }
}