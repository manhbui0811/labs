﻿//// File: ApiKeyRepository.cs
//using Microsoft.EntityFrameworkCore;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.Shared.Kernel.Entities;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;

//public class ApiKeyRepository : RepositoryBase<ApiKey, Guid>, IApiKeyRepository
//{
//    public ApiKeyRepository(DbContext context) : base(context) { }

//    public Task<ApiKey?> GetByKeyHashAsync(string keyHash, CancellationToken cancellationToken = default)
//    {
//        return _dbSet.FirstOrDefaultAsync(ak => ak.KeyHash == keyHash, cancellationToken);
//    }

//    public Task<IReadOnlyList<ApiKey>> GetByEntityIdAsync(int entityId, CancellationToken cancellationToken = default)
//    {
//        throw new NotImplementedException();
//    }

//    public async Task<IReadOnlyList<ApiKey>> GetByOwnerIdAsync(string ownerId, CancellationToken cancellationToken = default)
//    {
//        // Giả sử OwnerId trong ApiKey là string, nếu là kiểu khác cần sửa lại
//        // return await _dbSet.Where(ak => ak.OwnerId == ownerId).OrderByDescending(ak => ak.CreatedAt).ToListAsync(cancellationToken);
//        throw new NotImplementedException(); // Cần sửa lại cho đúng kiểu OwnerId
//    }

//    public async Task<IReadOnlyList<ApiKey>> GetAllActiveAsync(CancellationToken cancellationToken = default)
//    {
//        return await _dbSet
//            .Where(ak => ak.IsValid)
//            .OrderByDescending(ak => ak.CreatedAt)
//            .ToListAsync(cancellationToken);
//    }
//}