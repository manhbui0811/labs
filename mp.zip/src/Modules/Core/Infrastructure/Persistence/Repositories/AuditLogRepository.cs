﻿using Microsoft.EntityFrameworkCore;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories;

public class AuditLogRepository : RepositoryBase<AuditLog, long>, IAuditLogRepository
{
    public AuditLogRepository(DbContext context) : base(context) { }

    public async Task<IReadOnlyList<AuditLog>> GetByUserIdAsync(
        string userId,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(al => al.UserId == userId)
            .OrderByDescending(al => al.Timestamp)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<AuditLog>> GetByRecordIdAsync(
        string recordId,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(al => al.RecordId == recordId)
            .OrderByDescending(al => al.Timestamp)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<AuditLog>> GetByActionTypeAsync(
        string actionType,
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(al => al.ActionType == actionType)
            .OrderByDescending(al => al.Timestamp)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<AuditLog>> GetByDateRangeAsync(
        DateTimeOffset fromDate, // <-- Sửa thành DateTimeOffset
        DateTimeOffset toDate,   // <-- Sửa thành DateTimeOffset
        int page = 1,
        int pageSize = 50,
        CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(al => al.Timestamp >= fromDate && al.Timestamp <= toDate)
            .OrderByDescending(al => al.Timestamp)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
    }
}