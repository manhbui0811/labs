﻿using Microsoft.EntityFrameworkCore;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories;

public class BusinessCategoryRepository : RepositoryBase<BusinessCategory, Guid>, IBusinessCategoryRepository
{
    public BusinessCategoryRepository(DbContext context) : base(context) { }

    public Task<BusinessCategory?> GetByMccCodeAsync(string mccCode, CancellationToken cancellationToken = default)
    {
        return _dbSet.FirstOrDefaultAsync(bc => bc.MccCode == mccCode, cancellationToken);
    }

    public async Task<IReadOnlyList<BusinessCategory>> GetAllActiveAsync(CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(bc => bc.IsActive)
            .OrderBy(bc => bc.CategoryName)
            .ToListAsync(cancellationToken);
    }
}