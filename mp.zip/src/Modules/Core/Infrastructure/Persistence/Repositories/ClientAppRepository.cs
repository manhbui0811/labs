﻿using Microsoft.EntityFrameworkCore;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories;

public class ClientAppRepository : RepositoryBase<ClientApp, Guid>, IClientAppRepository
{
    public ClientAppRepository(DbContext context) : base(context) { }

    public Task<ClientApp?> GetByAppCodeAsync(string appCode, CancellationToken cancellationToken = default)
    {
        return _dbSet.FirstOrDefaultAsync(ca => ca.AppCode == appCode.ToUpperInvariant(), cancellationToken);
    }

    public async Task<IReadOnlyList<ClientApp>> GetAllActiveAsync(CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Where(ca => ca.Status == ClientAppStatus.Active)
            .OrderBy(ca => ca.Name)
            .ToListAsync(cancellationToken);
    }
}