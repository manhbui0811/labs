﻿using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories
{
    public class CoreRepository<TEntity> : RepositoryBase<TEntity, Guid>, IRepositoryBase<TEntity>
    where TEntity : EntityBase<Guid>
    {
        public CoreRepository(CoreDbContext context) : base(context)
        {
        }
    }
}
