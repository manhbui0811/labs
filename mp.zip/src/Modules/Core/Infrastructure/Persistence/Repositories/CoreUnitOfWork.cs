﻿using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories
{
    public class CoreUnitOfWork : UnitOfWork, ICoreUnitOfWork
    {
        public CoreUnitOfWork(CoreDbContext context) : base(context)
        {
        }
    }
}
