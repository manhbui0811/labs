﻿//using Microsoft.EntityFrameworkCore;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using SHT.MerchantPortal.Shared.Kernel.Enums;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;

//public class EncryptionKeyRepository : RepositoryBase<EncryptionKey, Guid>, IEncryptionKeyRepository
//{
//    public EncryptionKeyRepository(DbContext context) : base(context) { }

//    public Task<EncryptionKey?> GetActiveKeyAsync(
//        string keyIdentifier,
//        OwnerType ownerType,
//        Guid? ownerId = null,
//        CancellationToken cancellationToken = default)
//    {
//        return _dbSet.FirstOrDefaultAsync(k =>
//            k.KeyIdentifier == keyIdentifier &&
//            k.OwnerType == ownerType &&
//            k.OwnerId == ownerId &&
//            k.KeyStatus == EncryptionKeyStatus.Active, cancellationToken);
//    }

//    public async Task<IReadOnlyList<EncryptionKey>> GetKeysByOwnerAsync(
//        OwnerType ownerType,
//        Guid? ownerId,
//        CancellationToken cancellationToken = default)
//    {
//        return await _dbSet
//            .Where(k => k.OwnerType == ownerType && k.OwnerId == ownerId)
//            .OrderByDescending(k => k.CreatedAt)
//            .ToListAsync(cancellationToken);
//    }

//    public Task<EncryptionKey?> GetByKeyIdentifierAndVersionAsync(
//        string keyIdentifier,
//        string keyVersion,
//        CancellationToken cancellationToken = default)
//    {
//        return _dbSet.FirstOrDefaultAsync(k =>
//            k.KeyIdentifier == keyIdentifier && k.KeyVersion == keyVersion, cancellationToken);
//    }

//    public Task<EncryptionKey?> GetByKeyIdentifierAsync(
//        string keyIdentifier,
//        CancellationToken cancellationToken = default)
//    {
//        return _dbSet.FirstOrDefaultAsync(k =>
//            k.KeyIdentifier == keyIdentifier , cancellationToken);
//    }
//}