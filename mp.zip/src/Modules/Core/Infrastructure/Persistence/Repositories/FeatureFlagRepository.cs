﻿using Microsoft.EntityFrameworkCore;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Persistence.Repositories;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Persistence.Repositories;

public class FeatureFlagRepository : RepositoryBase<FeatureFlag, Guid>, IFeatureFlagRepository
{
    public FeatureFlagRepository(DbContext context) : base(context) { }

    public Task<FeatureFlag?> GetByNameAsync(string name, CancellationToken cancellationToken = default)
    {
        return _dbSet
            .Include(ff => ff.Settings)
            .FirstOrDefaultAsync(ff => ff.Name == name, cancellationToken);
    }

    public async Task<IReadOnlyList<FeatureFlag>> GetAllEnabledAsync(CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Include(ff => ff.Settings)
            .Where(ff => ff.IsEnabled && !ff.IsDeleted)
            .OrderBy(ff => ff.Name)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<FeatureFlag>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _dbSet
            .Include(ff => ff.Settings)
            .Where(ff => !ff.IsDeleted)
            .OrderBy(ff => ff.Name)
            .ToListAsync(cancellationToken);
    }
}