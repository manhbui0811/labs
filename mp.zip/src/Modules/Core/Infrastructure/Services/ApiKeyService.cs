using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Services;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;
using System.Security.Cryptography;
using System.Text;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Services;

public class ApiKeyService : IApiKeyService
{
    private readonly IRepositoryBase<ApiKey> _repository;
    private readonly ILogger<ApiKeyService> _logger;

    public ApiKeyService(IRepositoryBase<ApiKey> repository, ICoreUnitOfWork unitOfWork, ILogger<ApiKeyService> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    public async Task<(ApiKey ApiKey, string PlainTextKey)> CreateApiKeyAsync(
        string prefix,
        OwnerType ownerType,
        Guid ownerId,
        string? scope,
        DateTime? expiresAt,
        Guid? createdBy,
        CancellationToken cancellationToken = default)
    {
        var plainTextKey = GenerateApiKey(prefix);
        var hash = HashApiKey(plainTextKey);

        var apiKey = new ApiKey
        {
            Name = "_",
            OwnerType = ownerType,
            OwnerId = ownerId,
            KeyPrefix = prefix,
            KeyHash = hash,
            Scope = scope ?? "{}",
            ExpiresAt = expiresAt,
            Status = KeyStatus.Active,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            CreatedBy = createdBy
        };

        await _repository.AddAsync(apiKey, cancellationToken);

        _logger.LogInformation("Created API key for {OwnerType} {OwnerId}", ownerType, ownerId);
        return (apiKey, plainTextKey);
    }

    public async Task<ApiKey?> GetAsync(ApiKeyQueryType type, string data, bool validate = false, CancellationToken cancellationToken = default)
    {
    
        ApiKey? apiKey = type switch
        {
            ApiKeyQueryType.ByPlainText => await _repository.FindAsync(x => x.KeyHash == HashApiKey(data), cancellationToken),
            ApiKeyQueryType.ById => await _repository.GetByIdAsync(Guid.Parse(data), cancellationToken),
            _ => null
        };
        if (apiKey == null)
        {
            _logger.LogInformation("API Key not found, Type:{0}, data:{1}", type.ToString(), data);
            return null;
        }

        if (validate)
        {

            if (apiKey.Status != KeyStatus.Active)
            {
                _logger.LogInformation("API Key is not active");
                return null;
            }
            if (apiKey.ExpiresAt.HasValue && apiKey.ExpiresAt.Value < DateTime.UtcNow)
            {
                _logger.LogWarning("Invalid or expired API key");
                return null;
            }

        }
        return apiKey;
    }


    public async Task<(ApiKey ApiKey, string PlainTextKey)> RotateKey(Guid keyId, CancellationToken cancellationToken = default)
    {
        var oldKey = await _repository.GetByIdAsync(keyId, cancellationToken);
        if (oldKey == null)
        {
            throw new NotFoundException($"API Key with ID {keyId} not found.");
        }
        oldKey.Status = KeyStatus.Revoked;
        oldKey.UpdatedAt = DateTime.UtcNow;
        await _repository.UpdateAsync(oldKey, cancellationToken);

        var (newKey, plainText) = await CreateApiKeyAsync(
            prefix: oldKey.KeyPrefix,
            ownerType: oldKey.OwnerType,
            ownerId: oldKey.OwnerId,
            scope: oldKey.Scope,
            expiresAt: oldKey.ExpiresAt,
            createdBy: oldKey.CreatedBy,
            cancellationToken: cancellationToken);
        _logger.LogInformation("Rotated ApiKey {OldIdentifier} to new key {NewIdentifier}", keyId, newKey.Id);
        return (newKey, plainText);
    }

    public async Task DeactivateAsync(
        Guid apiKeyId,
        Guid updatedBy,
        CancellationToken cancellationToken = default)
    {
        var apiKey = await _repository.GetByIdAsync(apiKeyId, cancellationToken);
        if (apiKey != null)
        {
            apiKey.Status = KeyStatus.Revoked;
            apiKey.UpdatedBy = updatedBy;
            apiKey.UpdatedAt = DateTime.UtcNow;

            await _repository.UpdateAsync(apiKey, cancellationToken);

            _logger.LogInformation("Deactivated API key {ApiKeyId}", apiKeyId);
        }
    }

    #region Helpers

    private static string GenerateApiKey(string prefix)
    {
        const int keyLength = 32;

        using var rng = RandomNumberGenerator.Create();
        var bytes = new byte[keyLength];
        rng.GetBytes(bytes);

        var key = Convert.ToBase64String(bytes)
            .Replace("+", "")
            .Replace("/", "")
            .Replace("=", "")
            .Substring(0, keyLength);

        return prefix + "-" + key;
    }

    private static string HashApiKey(string plainTextKey)
    {
        using var sha256 = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(plainTextKey);
        var hash = sha256.ComputeHash(bytes);
        //Console.WriteLine(Convert.ToBase64String(hash));
        return Convert.ToBase64String(hash);
    }





    #endregion
}

