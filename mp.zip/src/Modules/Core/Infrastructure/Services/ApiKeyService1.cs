//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using System.Security.Cryptography;
//using System.Text;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

//public class ApiKeyService : IApiKeyService
//{
//    private readonly IApiKeyRepository _apiKeyRepository;
//    private readonly ILogger<ApiKeyService> _logger;

//    public ApiKeyService(
//        IApiKeyRepository apiKeyRepository,
//        ILogger<ApiKeyService> logger)
//    {
//        _apiKeyRepository = apiKeyRepository;
//        _logger = logger;
//    }

//    public async Task<(ApiKey apiKey, string plainTextKey)> CreateApiKeyAsync(
//        string name,
//        string? description = null,
//        string? entityId = null,
//        DateTime? expiresAt = null,
//        string? scopes = null,
//        CancellationToken cancellationToken = default)
//    {
//        var plainTextKey = GenerateApiKey();
//        var keyHash = HashApiKey(plainTextKey);

//        var apiKey = new ApiKey(name, keyHash, description, entityId, expiresAt, scopes);
//        await _apiKeyRepository.AddAsync(apiKey, cancellationToken);

//        _logger.LogInformation("Created API key {ApiKeyId} for entity {EntityId}", apiKey.Id, entityId);

//        return (apiKey, plainTextKey);
//    }

//    public async Task<ApiKey?> ValidateApiKeyAsync(string plainTextKey, CancellationToken cancellationToken = default)
//    {
//        if (string.IsNullOrWhiteSpace(plainTextKey))
//            return null;

//        var keyHash = HashApiKey(plainTextKey);
//        var apiKey = await _apiKeyRepository.GetByKeyHashAsync(keyHash, cancellationToken);

//        if (apiKey?.IsValid == true)
//        {
//            // Update last used timestamp
//            await UpdateLastUsedAsync(apiKey.Id, cancellationToken);
//            return apiKey;
//        }

//        return null;
//    }

//    public async Task<ApiKey?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
//    {
//        return await _apiKeyRepository.GetByIdAsync(id, cancellationToken);
//    }

//    public async Task<IReadOnlyList<ApiKey>> GetByEntityIdAsync(int entityId, CancellationToken cancellationToken = default)
//    {
//        return await _apiKeyRepository.GetByEntityIdAsync(entityId, cancellationToken);
//    }

//    public async Task DeactivateApiKeyAsync(Guid id, CancellationToken cancellationToken = default)
//    {
//        var apiKey = await _apiKeyRepository.GetByIdAsync(id, cancellationToken);
//        if (apiKey != null)
//        {
//            apiKey.Deactivate();
//            await _apiKeyRepository.UpdateAsync(apiKey, cancellationToken);
            
//            _logger.LogInformation("Deactivated API key {ApiKeyId}", id);
//        }
//    }

//    public async Task UpdateLastUsedAsync(Guid id, CancellationToken cancellationToken = default)
//    {
//        var apiKey = await _apiKeyRepository.GetByIdAsync(id, cancellationToken);
//        if (apiKey != null)
//        {
//            apiKey.UpdateLastUsed();
//            await _apiKeyRepository.UpdateAsync(apiKey, cancellationToken);
//        }
//    }

//    public async Task<bool> HasScopeAsync(Guid apiKeyId, string scope, CancellationToken cancellationToken = default)
//    {
//        var apiKey = await _apiKeyRepository.GetByIdAsync(apiKeyId, cancellationToken);
//        if (apiKey?.Scopes == null)
//            return false;

//        var scopes = apiKey.Scopes.Split(',', StringSplitOptions.RemoveEmptyEntries)
//            .Select(s => s.Trim())
//            .ToList();

//        return scopes.Contains(scope) || scopes.Contains("*");
//    }

//    private static string GenerateApiKey()
//    {
//        const string prefix = "sht_";
//        const int keyLength = 32;
        
//        using var rng = RandomNumberGenerator.Create();
//        var bytes = new byte[keyLength];
//        rng.GetBytes(bytes);
        
//        var key = Convert.ToBase64String(bytes)
//            .Replace("+", "")
//            .Replace("/", "")
//            .Replace("=", "")
//            .Substring(0, keyLength);
            
//        return prefix + key;
//    }

//    private static string HashApiKey(string plainTextKey)
//    {
//        using var sha256 = SHA256.Create();
//        var bytes = Encoding.UTF8.GetBytes(plainTextKey);
//        var hash = sha256.ComputeHash(bytes);
//        return Convert.ToBase64String(hash);
//    }
//}


