//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using SHT.MerchantPortal.BuildingBlocks.Application.Models.Audit;
//using System.Text.Json;
//using SHT.MerchantPortal.Shared.Kernel.Entities;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

//public class AuditService : IAuditService
//{
//    private readonly DbContext _context;
//    private readonly ICurrentUserService _currentUserService;
//    private readonly ILogger<AuditService> _logger;

//    public AuditService(
//        DbContext context,
//        ICurrentUserService currentUserService,
//        ILogger<AuditService> logger)
//    {
//        _context = context;
//        _currentUserService = currentUserService;
//        _logger = logger;
//    }

//    public async Task TrackAsync(
//        string actionType,
//        string? tableName = null,
//        string? recordId = null,
//        object? details = null,
//        Guid? entityId = null,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            await _context.Database.ExecuteSqlRawAsync(
//                @"INSERT INTO audit.audit_logs 
//                  (user_id, entity_id, action_type, table_name, record_id, details, ip_address, user_agent, timestamp)
//                  VALUES ({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8})",
//                _currentUserService.UserId,
//                entityId ?? _currentUserService.EntityId,
//                actionType,
//                tableName,
//                recordId,
//                details != null ? JsonSerializer.Serialize(details) : null,
//                _currentUserService.IpAddress,
//                _currentUserService.UserAgent,
//                DateTime.UtcNow);
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Failed to create audit log for action {ActionType}", actionType);
//            // Don't throw - audit logging should not break the main flow
//        }
//    }

//    public async Task TrackCommandAsync(
//        string commandName,
//        object commandData,
//        CancellationToken cancellationToken = default)
//    {
//        await TrackAsync(
//            $"COMMAND_EXECUTED:{commandName}",
//            details: commandData,
//            cancellationToken: cancellationToken);
//    }

//    public async Task<IReadOnlyList<AuditLog>> GetAuditLogsAsync(
//        int? userId = null,
//        int? entityId = null,
//        string? actionType = null,
//        DateTime? fromDate = null,
//        DateTime? toDate = null,
//        int page = 1,
//        int pageSize = 50,
//        CancellationToken cancellationToken = default)
//    {
//        var parameters = new List<object>();
//        var whereConditions = new List<string>();
        
//        var sql = "SELECT * FROM audit.audit_logs WHERE 1=1";
        
//        if (userId.HasValue)
//        {
//            whereConditions.Add($" AND user_id = ${parameters.Count}");
//            parameters.Add(userId.Value);
//        }
        
//        if (entityId.HasValue)
//        {
//            whereConditions.Add($" AND entity_id = ${parameters.Count}");
//            parameters.Add(entityId.Value);
//        }
        
//        if (!string.IsNullOrEmpty(actionType))
//        {
//            whereConditions.Add($" AND action_type = ${parameters.Count}");
//            parameters.Add(actionType);
//        }
        
//        if (fromDate.HasValue)
//        {
//            whereConditions.Add($" AND timestamp >= ${parameters.Count}");
//            parameters.Add(fromDate.Value);
//        }
        
//        if (toDate.HasValue)
//        {
//            whereConditions.Add($" AND timestamp <= ${parameters.Count}");
//            parameters.Add(toDate.Value);
//        }
        
//        sql += string.Join("", whereConditions);
//        sql += " ORDER BY timestamp DESC";
//        sql += $" LIMIT {pageSize} OFFSET {(page - 1) * pageSize}";

//        // This is a simplified implementation
//        // In a real scenario, you'd use Dapper or a proper repository
//        var result = new List<AuditLog>();
        
//        _logger.LogInformation("Retrieved audit logs with parameters: {Parameters}", string.Join(", ", parameters));
        
//        return result;
//    }
//}


