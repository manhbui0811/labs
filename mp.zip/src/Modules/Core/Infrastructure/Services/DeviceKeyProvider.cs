﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Services;
using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Services
{
    public class DeviceKeyProvider : IDeviceKeyProvider
    {
        private readonly IApiKeyService _apiKeyService;
        private readonly IEncryptionKeyService _encryptionKeyService;
        private readonly IDeviceServiceShared _deviceService;
        private readonly ILogger<DeviceKeyProvider> _logger;
        private readonly ICoreUnitOfWork _unitOfWork;


        public DeviceKeyProvider(
            IApiKeyService apiKeyService,
            ICoreUnitOfWork unitOfWork,
            IEncryptionKeyService encryptionKeyService,
            IDeviceServiceShared deviceService,
            ILogger<DeviceKeyProvider> logger)
        {
            _apiKeyService = apiKeyService ?? throw new ArgumentNullException(nameof(apiKeyService));
            _encryptionKeyService = encryptionKeyService ?? throw new ArgumentNullException(nameof(encryptionKeyService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _deviceService = deviceService ?? throw new ArgumentNullException(nameof(deviceService));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        public async Task<DeviceRSAKey> CreateRSAKey(Guid deviceId, CancellationToken ct = default)
        {
            await _unitOfWork.BeginTransactionAsync(ct);
            try
            {
                var key = await _encryptionKeyService.CreateRsaKeyAsync(KeyCategory.Signing, OwnerType.POS_DEVICE, deviceId, cancellationToken: ct);
                await _unitOfWork.CommitTransactionAsync();
                return new DeviceRSAKey
                {
                    Id = key.Id,
                    KeyIdentifier = key.KeyIdentifier,
                    KeyVersion = key.KeyVersion,
                    Algorithm = key.Algorithm,
                    KeyType = key.KeyType,
                    KeyCategory = key.KeyCategory,
                    OwnerType = key.OwnerType,
                    OwnerId = key.OwnerId,
                    ExpiresAt = key.ExpiresAt,
                    PublicKeyPem = key.PublicKeyPem,
                    PrivateKeyPem = key.PrivateKeyPem
                };
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackTransactionAsync();
                _logger.LogError("CreateRSAKey error: {0}", ex.Message);
                throw;
            }
        }

        public async Task<byte[]?> GetPublicKeyBySerialNumberAsync(string serial)
        {
            var deviceId = await _deviceService.GetDeviceIdBySerialNumber(serial);
            if (deviceId == null) return null;
            return await _encryptionKeyService.GetRSAPublicKeyAsync(KeyCategory.Signing, deviceId.Value, OwnerType.POS_DEVICE);
        }

        public async Task<DeviceApiKeySecret?> GetSecretByApiKeyAsync(string keyId)
        {
            var apiKey = await _apiKeyService.GetAsync(ApiKeyQueryType.ByPlainText, keyId, true);
            if (apiKey is null)
            {
                _logger.LogWarning("API Key not found or invalid");
                return null;
            }
            var hmacSecret = await _encryptionKeyService.GetHmacSecretByKeyIdentifierAsync(apiKey.Id.ToString());

            if (hmacSecret == null || hmacSecret.Length == 0)
            {
                _logger.LogWarning("HMAC secret not found for device: {DeviceId}", apiKey.OwnerId);
                return null;
            }
            var deviceInfo = await _deviceService.GetAuthenticationInfoAsync(apiKey.OwnerId);
            if (deviceInfo == null)
            {
                _logger.LogWarning("Device not found: {DeviceId}", apiKey.OwnerId);
                return null;
            }
            var apiKeySecret = new DeviceApiKeySecret
            {
                ApiKey = keyId,
                DeviceId = deviceInfo.DeviceId,
                TerminalId = deviceInfo.TerminalId,
                MerchantId = deviceInfo.MerchantId,
                HmacSecret = hmacSecret,
                EntityId = deviceInfo.EntityId
            };

            return apiKeySecret;
        }

        public async Task<DeviceProvisionedKey> ProvisionKey(Guid deviceId, CancellationToken ct = default)
        {
            await _unitOfWork.BeginTransactionAsync(ct);
            try
            {
                // tao apikey
                var apiKey = await _apiKeyService.CreateApiKeyAsync(prefix: "pos_sk", ownerType: OwnerType.POS_DEVICE, ownerId: deviceId, cancellationToken: ct);
                // tao hmac
                var hmacKey = await _encryptionKeyService.CreateHmacKeyAsync(identifier: apiKey.ApiKey!.Id.ToString(), keyCategory: KeyCategory.Signing, ownerId: deviceId, ownerType: OwnerType.POS_DEVICE, cancellationToken: ct);
                await _unitOfWork.CommitTransactionAsync(ct);
                return new DeviceProvisionedKey
                {
                    KeyId = apiKey.ApiKey.Id.ToString(),
                    ApiKey = apiKey.PlainTextKey,
                    HmacSecret = hmacKey.HmacSecret!,
                    ExpiresAt = apiKey.ApiKey.ExpiresAt

                };
            }
            catch (Exception ex)
            {

                await _unitOfWork.RollbackTransactionAsync(ct);
                _logger.LogError("ProvisionDeviceKey error: {0}", ex.Message);
                throw;
            }

        }

        public async Task<DeviceProvisionedKey> RotateKey(string keyIdentifier, CancellationToken ct = default)
        {
            await _unitOfWork.BeginTransactionAsync(ct);
            try
            {

                var (newApiKey, plainText) = await _apiKeyService.RotateKey(Guid.Parse(keyIdentifier), ct);
                // tao hmac moi tu identifier moi
                var newHmacKey = await _encryptionKeyService.RotateHmacKeyAsync(
                        oldIdentifier: keyIdentifier,
                        newIdentifier: newApiKey.Id.ToString(),
                        updatedBy: string.Empty,
                        cancellationToken: ct);

                await _unitOfWork.CommitTransactionAsync(ct);
                return new DeviceProvisionedKey
                {
                    KeyId = newApiKey.Id.ToString(),
                    ApiKey = plainText,
                    HmacSecret = newHmacKey.HmacSecret!,
                    ExpiresAt = newApiKey.ExpiresAt

                };
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackTransactionAsync(ct);
                _logger.LogError("ProvisionDeviceKey error: {0}", ex.Message);
                throw;
            }

        }

        public async Task UpdateLastUsedAsync(string apiKey)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(apiKey);

            try
            {
                //   await _apiKeyService.UpdateLastUsedAsync(apiKey);
                _logger.LogDebug("Updated last used timestamp for API key: {ApiKey}", apiKey);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating last used timestamp for API key: {ApiKey}", apiKey);
                // Don't throw - this is not critical for authentication
            }
        }
    }
}
