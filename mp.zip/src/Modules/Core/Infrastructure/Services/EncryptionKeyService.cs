﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Security;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
using SHT.MerchantPortal.Modules.Core.Application.Contract.Services;
using SHT.MerchantPortal.Modules.Core.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Enums;
using System.Security.Cryptography;

namespace SHT.MerchantPortal.Modules.Core.Infrastructure.Services;

public class EncryptionKeyService : IEncryptionKeyService
{
    private readonly IRepositoryBase<EncryptionKey> _repository;
    private readonly ILogger<EncryptionKeyService> _logger;
    private readonly IEncryptionService _encryptionService;

    public EncryptionKeyService(
        IRepositoryBase<EncryptionKey> repository,
        IEncryptionService encryptionService,
         ICoreUnitOfWork unitOfWork,
    ILogger<EncryptionKeyService> logger)
    {
        _repository = repository;
        _encryptionService = encryptionService;
        _logger = logger;
    }
    public Task ActivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<CreateKeyResult> CreateHmacKeyAsync(
        string? identifier,
        KeyCategory keyCategory,
        OwnerType ownerType,
        Guid ownerId,
        string? hmacKekAlias = null,
        string? createdBy = null,
        CancellationToken cancellationToken = default)
    {

        hmacKekAlias = string.IsNullOrEmpty(hmacKekAlias) ? "DEFAULT" : hmacKekAlias;
        var encryptedKeyMaterial = await _encryptionService.GetEncryptionKeyMaterialAsync(hmacKekAlias, cancellationToken);
        var hmacSecret = GenerateSecret("hs");
        Console.WriteLine($"[Debug] hmacSecret : {hmacSecret}");

        var hmacSecretEncrypted = await _encryptionService.EncryptAsync(hmacSecret, encryptedKeyMaterial, cancellationToken);
        byte[] encryptedBytes = Convert.FromBase64String(hmacSecretEncrypted);


        var encryptionKey = new EncryptionKey
        {
            KeyIdentifier = string.IsNullOrEmpty(identifier) ? Guid.NewGuid().ToString() : identifier,
            KeyVersion = "v" + DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmss"),
            KeyType = EncryptionType.HMAC,
            KeyCategory = keyCategory,
            OwnerType = ownerType,
            OwnerId = ownerId,
            EncryptedHmacSecretMaterial = encryptedBytes,
            Algorithm = "HMAC-SHA256",
            HmacKekAlias = hmacKekAlias,
            KeyStatus = KeyStatus.Active,
            CreatedBy = !string.IsNullOrEmpty(createdBy) ? Guid.Parse(createdBy) : Guid.Empty,
            CreatedAt = DateTime.UtcNow,

        };
        await _repository.AddAsync(encryptionKey, cancellationToken);

        return new CreateKeyResult
        {
            Id = encryptionKey.Id.ToString(),
            HmacSecret = hmacSecret,
            KeyIdentifier = encryptionKey.KeyIdentifier,
            KeyCategory = encryptionKey.KeyCategory,
            OwnerType = ownerType,
            OwnerId = ownerId,
            KeyType = encryptionKey.KeyType,
            ExpiresAt = encryptionKey.ExpiresAt,
            KeyVersion = encryptionKey.KeyVersion,
            Algorithm = encryptionKey.Algorithm,
        };
    }

    public async Task<CreateKeyResult> RotateHmacKeyAsync(string oldIdentifier, string newIdentifier, string updatedBy, CancellationToken cancellationToken = default)
    {
        var oldKey = await _repository.FindAsync(x => x.KeyIdentifier == oldIdentifier && x.KeyType == EncryptionType.HMAC && x.KeyStatus == KeyStatus.Active, cancellationToken);
        if (oldKey == null)
        {
            _logger.LogError("Old HMAC key with identifier {OldIdentifier} not found or not active", oldIdentifier);
            throw new NotFoundException("Old HMAC key not found");
        }
        var newKey = await CreateHmacKeyAsync(newIdentifier, oldKey.KeyCategory, oldKey.OwnerType, oldKey.OwnerId, oldKey.HmacKekAlias, updatedBy, cancellationToken);
        oldKey.KeyStatus = KeyStatus.Revoked;
        oldKey.UpdatedBy = !string.IsNullOrEmpty(updatedBy) ? Guid.Parse(updatedBy) : Guid.Empty;
        oldKey.UpdatedAt = DateTime.UtcNow;
        oldKey.RotatedToKeyId = Guid.Parse(newKey.Id);
        await _repository.UpdateAsync(oldKey, cancellationToken);
        _logger.LogInformation("Rotated HMAC key {OldIdentifier} to new key {NewIdentifier}", oldIdentifier, newIdentifier);
        return newKey;
    }


    public Task<EncryptionKey> CreateKeyAsync(string keyIdentifier, EncryptionType keyType, KeyCategory keyCategory, OwnerType ownerType, Guid? ownerId, string algorithm, string createdBy, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<CreateKeyResult> CreateRsaKeyAsync(
      KeyCategory keyCategory,
      OwnerType ownerType,
      Guid ownerId,
      string? privateKekAlias = null,
      string? createdBy = null,
      CancellationToken cancellationToken = default)
    {
        var exist = await _repository.ExistsAsync(
             x => x.OwnerId == ownerId &&
                  x.OwnerType == ownerType &&
                  x.KeyType == EncryptionType.RSA &&
                  x.KeyCategory == keyCategory &&
                  x.KeyStatus == KeyStatus.Active,
             cancellationToken);
        if (exist)
        {
            _logger.LogError("An active RSA key already exists for {OwnerType} {OwnerId} and category {KeyCategory}", ownerType, ownerId, keyCategory);
            throw new ConflictException("An active RSA key already exists");
        }

        privateKekAlias = string.IsNullOrEmpty(privateKekAlias) ? "DEFAULT" : privateKekAlias;

        // 1. Tạo cặp RSA key
        using var rsa = RSA.Create(2048);

        // Xuất public key PEM
        var publicKeyPem = ExportPublicKeyPem(rsa);

        // Xuất private key PEM (plaintext)
        var privateKeyPem = ExportPrivateKeyPem(rsa);

        // Xuất private key raw byte để lưu DB (PKCS8)
        var privateKeyBytes = rsa.ExportPkcs8PrivateKey();

        // 2. Lấy KEK từ service bảo vệ
        var encryptedKeyMaterial = await _encryptionService.GetEncryptionKeyMaterialAsync(privateKekAlias, cancellationToken);

        // 3. Mã hóa private key
        var encryptedPrivateKeyBytes = await _encryptionService.EncryptAsync(privateKeyBytes, encryptedKeyMaterial, cancellationToken);

        // 4. Tạo entity để lưu DB
        var encryptionKey = new EncryptionKey
        {
            KeyIdentifier = Guid.NewGuid().ToString(),
            KeyVersion = "v" + DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmss"),
            KeyType = EncryptionType.RSA,
            KeyCategory = keyCategory,
            OwnerType = ownerType,
            OwnerId = ownerId,
            PublicKeyPem = publicKeyPem,
            EncryptedPrivateKeyMaterial = encryptedPrivateKeyBytes,
            Algorithm = "RSA-PS256",
            PrivateKekAlias = privateKekAlias,
            KeyStatus = KeyStatus.Active,
            CreatedBy = !string.IsNullOrEmpty(createdBy) ? Guid.Parse(createdBy) : Guid.Empty,
            CreatedAt = DateTime.UtcNow,
        };

        await _repository.AddAsync(encryptionKey, cancellationToken);

        return new CreateKeyResult
        {
            Id = encryptionKey.Id.ToString(),
            KeyIdentifier = encryptionKey.KeyIdentifier,
            KeyCategory = encryptionKey.KeyCategory,
            OwnerType = ownerType,
            OwnerId = ownerId,
            KeyType = encryptionKey.KeyType,
            ExpiresAt = encryptionKey.ExpiresAt,
            KeyVersion = encryptionKey.KeyVersion,
            Algorithm = encryptionKey.Algorithm,
            PublicKeyPem = publicKeyPem,
            PrivateKeyPem = privateKeyPem
        };
    }


    public async Task<byte[]?> GetRSAPublicKeyAsync(
    KeyCategory keyCategory,
    Guid ownerId,
    OwnerType ownerType,
    CancellationToken cancellationToken = default)
    {
        // 1. Lấy key đang active
        var rsaKey = await _repository.FindAsync(
            x => x.OwnerId == ownerId
                 && x.OwnerType == ownerType
                 && x.KeyCategory == keyCategory
                 && x.KeyType == EncryptionType.RSA
                 && x.KeyStatus == KeyStatus.Active,
            cancellationToken);

        if (rsaKey == null || string.IsNullOrEmpty(rsaKey.PublicKeyPem))
        {
            _logger.LogWarning(
                "RSA public key not found for OwnerId={OwnerId}, OwnerType={OwnerType}, Category={Category}",
                ownerId, ownerType, keyCategory);
            return null;
        }

        try
        {
            // 2. Convert PEM -> RSAParameters -> byte[]
            using var rsa = RSA.Create();
            rsa.ImportFromPem(rsaKey.PublicKeyPem.AsSpan());
            return rsa.ExportSubjectPublicKeyInfo(); // chuẩn X.509 (SPKI)
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to parse RSA public key from PEM for key {KeyId}", rsaKey.Id);
            return null;
        }
    }


    public Task DeactivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<EncryptionKey?> GetActiveKeyAsync(string keyIdentifier, OwnerType ownerType, Guid? ownerId = null, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<byte[]?> GetHmacSecretByKeyIdentifierAsync(string identifier, CancellationToken cancellationToken = default)
    {
        // Tìm key HMAC đang active cho identifier
        var key = await _repository.FindAsync(
            x => x.KeyIdentifier == identifier &&
                 x.KeyType == EncryptionType.HMAC &&
                 x.KeyStatus == KeyStatus.Active,
            cancellationToken);

        if (key == null)
        {
            _logger.LogWarning("No active HMAC key found for {identifier}", identifier);
            return null;
        }

        if (key.EncryptedHmacSecretMaterial == null)
        {
            _logger.LogWarning("HMAC key {KeyId} has no material stored", key.Id);
            return null;
        }

        try
        {
            _logger.LogInformation("Retrieved HMAC secret for {identifier}", identifier);
            var secret = await _encryptionService.DecryptAsync(key.EncryptedHmacSecretMaterial, key.HmacKekAlias ?? "DEFAULT", cancellationToken);
            return secret;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to decrypt HMAC secret for {identifier}", identifier);
            return null;
        }
    }


    public Task<EncryptionKey?> GetKeyByIdAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<IReadOnlyList<EncryptionKey>> GetKeysByOwnerAsync(OwnerType ownerType, Guid? ownerId, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task RotateKeyAsync(Guid oldKeyId, string updatedBy, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    private string GenerateSecret(string prefix)
    {
        const int keyLength = 32;

        using var rng = RandomNumberGenerator.Create();
        var bytes = new byte[keyLength];
        rng.GetBytes(bytes);

        var key = Convert.ToBase64String(bytes)
            .Replace("+", "")
            .Replace("/", "")
            .Replace("=", "")
            .Substring(0, keyLength);

        return prefix + "-" + key;
    }

    /// <summary>
    /// Xuất public key PEM
    /// </summary>
    private string ExportPublicKeyPem(RSA rsa)
    {
        var publicKeyBytes = rsa.ExportSubjectPublicKeyInfo();
        var base64 = Convert.ToBase64String(publicKeyBytes, Base64FormattingOptions.InsertLineBreaks);
        return $"-----BEGIN PUBLIC KEY-----\n{base64}\n-----END PUBLIC KEY-----";
    }

    /// <summary>
    /// Xuất private key PEM (plaintext)
    /// </summary>
    private string ExportPrivateKeyPem(RSA rsa)
    {
        var privateKeyBytes = rsa.ExportPkcs8PrivateKey();
        var base64 = Convert.ToBase64String(privateKeyBytes, Base64FormattingOptions.InsertLineBreaks);
        return $"-----BEGIN PRIVATE KEY-----\n{base64}\n-----END PRIVATE KEY-----";
    }


}


