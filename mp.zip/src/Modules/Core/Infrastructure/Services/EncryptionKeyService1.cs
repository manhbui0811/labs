//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using SHT.MerchantPortal.Shared.Kernel.Enums;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

//public class EncryptionKeyService : IEncryptionKeyService
//{
//    private readonly IEncryptionKeyRepository _encryptionKeyRepository;
//    private readonly ILogger<EncryptionKeyService> _logger;

//    public EncryptionKeyService(
//        IEncryptionKeyRepository encryptionKeyRepository,
//        ILogger<EncryptionKeyService> logger)
//    {
//        _encryptionKeyRepository = encryptionKeyRepository;
//        _logger = logger;
//    }

//    public async Task<EncryptionKey> CreateKeyAsync(
//        string keyIdentifier,
//        EncryptionType keyType,
//        KeyCategory keyCategory,
//        OwnerType ownerType,
//        Guid? ownerId,
//        string algorithm,
//        string createdBy,
//        CancellationToken cancellationToken = default)
//    {
//        // Generate key version
//        var keyVersion = "v" + DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmss");

//        // For demonstration, we'll create empty key materials
//        // In real implementation, you'd generate actual cryptographic keys
//        string? publicKey = null;
//        byte[]? encryptedKeyMaterial = null;

//        if (keyType == EncryptionType.RSA)
//        {
//            publicKey = "dummy_public_key"; // Generate actual RSA public key
//        }
//        else
//        {
//            encryptedKeyMaterial = new byte[32]; // Generate actual encrypted key material
//        }

//        var encryptionKey = EncryptionKey.Create(
//            keyIdentifier,
//            keyVersion,
//            keyType,
//            keyCategory,
//            ownerType,
//            ownerId,
//            publicKey,
//            encryptedKeyMaterial,
//            algorithm,
//            createdBy);

//        await _encryptionKeyRepository.AddAsync(encryptionKey, cancellationToken);

//        _logger.LogInformation("Created encryption key {KeyId} with identifier {KeyIdentifier}", 
//            encryptionKey.Id, keyIdentifier);

//        return encryptionKey;
//    }

//    public async Task<EncryptionKey?> GetActiveKeyAsync(
//        string keyIdentifier,
//        OwnerType ownerType,
//        Guid? ownerId = null,
//        CancellationToken cancellationToken = default)
//    {
//        return await _encryptionKeyRepository.GetActiveKeyAsync(keyIdentifier, ownerType, ownerId, cancellationToken);
//    }

//    public async Task<EncryptionKey?> GetKeyByIdAsync(Guid keyId, CancellationToken cancellationToken = default)
//    {
//        return await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//    }

//    public async Task ActivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default)
//    {
//        var key = await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//        if (key != null)
//        {
//            key.Activate(updatedBy);
//            await _encryptionKeyRepository.UpdateAsync(key, cancellationToken);
            
//            _logger.LogInformation("Activated encryption key {KeyId}", keyId);
//        }
//    }

//    public async Task RotateKeyAsync(Guid oldKeyId, string updatedBy, CancellationToken cancellationToken = default)
//    {
//        var oldKey = await _encryptionKeyRepository.GetByIdAsync(oldKeyId, cancellationToken);
//        if (oldKey == null)
//        {
//            throw new InvalidOperationException($"Encryption key {oldKeyId} not found");
//        }

//        // Create new key with same parameters
//        var newKey = await CreateKeyAsync(
//            oldKey.KeyIdentifier,
//            oldKey.KeyType,
//            oldKey.KeyCategory,
//            oldKey.OwnerType,
//            oldKey.OwnerId,
//            oldKey.Algorithm,
//            updatedBy,
//            cancellationToken);

//        // Mark old key for rotation
//        oldKey.MarkForRotation(updatedBy);
//        await _encryptionKeyRepository.UpdateAsync(oldKey, cancellationToken);

//        // Activate new key
//        await ActivateKeyAsync(newKey.Id, updatedBy, cancellationToken);

//        // Complete rotation
//        oldKey.MarkAsRotated(newKey.Id, updatedBy);
//        await _encryptionKeyRepository.UpdateAsync(oldKey, cancellationToken);

//        _logger.LogInformation("Rotated encryption key {OldKeyId} to {NewKeyId}", oldKeyId, newKey.Id);
//    }

//    public async Task DeactivateKeyAsync(Guid keyId, string updatedBy, CancellationToken cancellationToken = default)
//    {
//        var key = await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//        if (key != null)
//        {
//            key.Deactivate(updatedBy);
//            await _encryptionKeyRepository.UpdateAsync(key, cancellationToken);
            
//            _logger.LogInformation("Deactivated encryption key {KeyId}", keyId);
//        }
//    }

//    public async Task<IReadOnlyList<EncryptionKey>> GetKeysByOwnerAsync(
//        OwnerType ownerType,
//        Guid? ownerId,
//        CancellationToken cancellationToken = default)
//    {
//        return await _encryptionKeyRepository.GetKeysByOwnerAsync(ownerType, ownerId, cancellationToken);
//    }
//}


