//using Microsoft.Extensions.Logging;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Services;
//using System.Text.Json;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

//public class FeatureFlagService : IFeatureFlagService
//{
//    private readonly IFeatureFlagRepository _featureFlagRepository;
//    private readonly ICacheService _cacheService;
//    private readonly ILogger<FeatureFlagService> _logger;

//    public FeatureFlagService(
//        IFeatureFlagRepository featureFlagRepository,
//        ICacheService cacheService,
//        ILogger<FeatureFlagService> logger)
//    {
//        _featureFlagRepository = featureFlagRepository;
//        _cacheService = cacheService;
//        _logger = logger;
//    }

//    public async Task<bool> IsEnabledAsync(
//        string featureName,
//        string? tenantId = null,
//        string? userId = null,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var cacheKey = $"feature_flag:{featureName}";
//            var featureFlag = await _cacheService.GetOrSetAsync(
//                cacheKey,
//                async ct => await _featureFlagRepository.GetByNameAsync(featureName, ct),
//                TimeSpan.FromMinutes(5),
//                cancellationToken);

//            if (featureFlag == null)
//            {
//                _logger.LogWarning("Feature flag {FeatureName} not found", featureName);
//                return false;
//            }

//            // Check tenant-specific enablement
//            if (!string.IsNullOrEmpty(tenantId))
//            {
//                return featureFlag.IsEnabledForTenant(tenantId);
//            }

//            // Check user-specific enablement
//            if (!string.IsNullOrEmpty(userId))
//            {
//                return featureFlag.IsEnabledForUser(userId);
//            }

//            // Check global enablement
//            return featureFlag.IsEnabled && 
//                   (!featureFlag.ExpiresAt.HasValue || featureFlag.ExpiresAt.Value > DateTimeOffset.UtcNow);
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error checking feature flag {FeatureName}", featureName);
//            return false;
//        }
//    }

//    public async Task<T?> GetSettingValueAsync<T>(
//        string featureName,
//        string settingKey,
//        T? defaultValue = default,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var cacheKey = $"feature_flag:{featureName}";
//            var featureFlag = await _cacheService.GetOrSetAsync(
//                cacheKey,
//                async ct => await _featureFlagRepository.GetByNameAsync(featureName, ct),
//                TimeSpan.FromMinutes(5),
//                cancellationToken);

//            if (featureFlag == null)
//            {
//                return defaultValue;
//            }

//            var stringValue = featureFlag.GetSettingValue(settingKey);
//            if (string.IsNullOrEmpty(stringValue))
//            {
//                return defaultValue;
//            }

//            // Try to convert to target type
//            if (typeof(T) == typeof(string))
//            {
//                return (T)(object)stringValue;
//            }

//            try
//            {
//                return JsonSerializer.Deserialize<T>(stringValue);
//            }
//            catch
//            {
//                // If JSON deserialization fails, try simple conversion
//                return (T)Convert.ChangeType(stringValue, typeof(T));
//            }
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error getting setting value for feature flag {FeatureName}, key {SettingKey}", 
//                featureName, settingKey);
//            return defaultValue;
//        }
//    }

//    public async Task EnableFeatureAsync(string featureName, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.Enable(updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    public async Task DisableFeatureAsync(string featureName, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.Disable(updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    public async Task EnableForTenantAsync(string featureName, string tenantId, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.EnableForTenant(tenantId, updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    public async Task DisableForTenantAsync(string featureName, string tenantId, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.DisableForTenant(tenantId, updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    public async Task EnableForUserAsync(string featureName, string userId, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.EnableForUser(userId, updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    public async Task DisableForUserAsync(string featureName, string userId, string? updatedBy = null, CancellationToken cancellationToken = default)
//    {
//        var featureFlag = await _featureFlagRepository.GetByNameAsync(featureName, cancellationToken);
//        if (featureFlag != null)
//        {
//            featureFlag.DisableForUser(userId, updatedBy);
//            await _featureFlagRepository.UpdateAsync(featureFlag, cancellationToken);
//            await InvalidateCacheAsync(featureName);
//        }
//    }

//    private async Task InvalidateCacheAsync(string featureName)
//    {
//        var cacheKey = $"feature_flag:{featureName}";
//        await _cacheService.RemoveAsync(cacheKey);
//    }
//}


