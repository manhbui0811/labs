//using System.Diagnostics;
//using System.Security.Cryptography;
//using System.Text;
//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Options;
//using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
//using SHT.MerchantPortal.Modules.Core.Application.Contract.Persistence;
//using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
//using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Configuration;
//using SHT.MerchantPortal.Shared.Kernel.Entities;
//using SHT.MerchantPortal.Shared.Kernel.Enums;

//namespace SHT.MerchantPortal.BuildingBlocks.Infrastructure.Services;

//public class FileBasedKeyManagementService : IKeyManagementService
//{
//    private readonly ILogger<FileBasedKeyManagementService> _logger;
//    private readonly string _masterKeyPath;
//    private readonly FileKmsOptions _options;
//    private readonly IUnitOfWork _unitOfWork;
//    private readonly IEncryptionKeyRepository _encryptionKeyRepository;


//    public FileBasedKeyManagementService(
//        IUnitOfWork unitOfWork,
//        IOptions<FileKmsOptions> options,
//        IEncryptionKeyRepository encryptionService,
//        ILogger<FileBasedKeyManagementService> logger)
//    {
//        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
//        _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
//        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
//        _masterKeyPath = _options.MasterKeyPath;
//        _encryptionKeyRepository = encryptionService ?? throw new ArgumentNullException(nameof(encryptionService));

//        // Ensure master key exists, or create it if it doesn't
//        EnsureMasterKeyExistsAsync().GetAwaiter().GetResult();
//    }

//    public async Task<EncryptionKey> CreateKeyAsync(
//        EncryptionType keyType,
//        KeyCategory keyCategory,
//        OwnerType ownerType,
//        Guid? ownerId,
//        string algorithm,
//        string createdBy,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            _logger.LogInformation("Creating new {KeyType} key for {OwnerType} {OwnerId}",
//                keyType, ownerType, ownerId);

//            // Generate appropriate key material based on key type
//            byte[] keyMaterial;
//            byte[] publicKeyMaterial = null;
//            string publicKeyPem = null;

//            switch (keyType)
//            {
//                case EncryptionType.AES:
//                    // Generate AES key
//                    keyMaterial = new byte[32]; // 256-bit AES key
//                    using (var rng = RandomNumberGenerator.Create())
//                    {
//                        rng.GetBytes(keyMaterial);
//                    }

//                    break;

//                case EncryptionType.RSA:
//                    // Generate RSA key pair
//                    using (var rsa = RSA.Create(2048))
//                    {
//                        keyMaterial = rsa.ExportPkcs8PrivateKey();
//                        publicKeyMaterial = rsa.ExportSubjectPublicKeyInfo();
//                        publicKeyPem = ExportPublicKeyToPem(rsa);
//                    }

//                    break;

//                case EncryptionType.EC:
//                    // Generate EC key pair
//                    using (var ec = ECDsa.Create(ECCurve.NamedCurves.nistP256))
//                    {
//                        keyMaterial = ec.ExportPkcs8PrivateKey();
//                        publicKeyMaterial = ec.ExportSubjectPublicKeyInfo();
//                        publicKeyPem = ExportPublicKeyToPem(ec);
//                    }

//                    break;

//                default:
//                    throw new ArgumentOutOfRangeException(nameof(keyType), $"Unsupported key type: {keyType}");
//            }

//            // Get master key for key encryption
//            var masterKey = await GetMasterKeyAsync();

//            // Encrypt key material with master key
//            byte[] encryptedKeyMaterial;
//            using (var aes = Aes.Create())
//            {
//                aes.Key = masterKey;
//                aes.GenerateIV();

//                using var encryptor = aes.CreateEncryptor();
//                var ciphertext = encryptor.TransformFinalBlock(keyMaterial, 0, keyMaterial.Length);

//                // Combine IV and ciphertext
//                encryptedKeyMaterial = new byte[aes.IV.Length + ciphertext.Length];
//                Buffer.BlockCopy(aes.IV, 0, encryptedKeyMaterial, 0, aes.IV.Length);
//                Buffer.BlockCopy(ciphertext, 0, encryptedKeyMaterial, aes.IV.Length, ciphertext.Length);
//            }

//            // Generate a unique identifier for the key
//            var keyIdentifier = $"{keyType}_{Guid.NewGuid().ToString("N")}";
//            var keyVersion = DateTimeOffset.Now.ToString("yyyyMMdd-HHmm");

//            // Create database record for key metadata
//            var encryptionKey = EncryptionKey.Create(
//                keyIdentifier,
//                keyVersion,
//                keyType,
//                keyCategory,
//                ownerType,
//                ownerId,
//                publicKeyPem,
//                encryptedKeyMaterial,
//                algorithm,
//                createdBy
//            );

//            // Save to database
//            await _encryptionKeyRepository.AddAsync(encryptionKey, cancellationToken);
//            await _unitOfWork.SaveChangesAsync(cancellationToken);

//            return encryptionKey;
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error creating encryption key");
//            throw;
//        }
//    }

//    public async Task<EncryptionKey> ActivateKeyAsync(Guid keyId, string updatedBy,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var key = await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//            if (key == null) throw new KeyNotFoundException($"Encryption key with ID {keyId} not found");

//            key.Activate(updatedBy);
//            await _encryptionKeyRepository.UpdateAsync(key, cancellationToken);
//            await _unitOfWork.SaveChangesAsync(cancellationToken);

//            return key;
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error activating encryption key {KeyId}", keyId);
//            throw;
//        }
//    }

//    public async Task<EncryptionKey> RotateKeyAsync(Guid keyId, string updatedBy,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var oldKey = await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//            if (oldKey == null) throw new KeyNotFoundException($"Encryption key with ID {keyId} not found");

//            // Create a new key with the same settings
//            var newKey = await CreateKeyAsync(
//                oldKey.KeyType,
//                oldKey.KeyCategory,
//                oldKey.OwnerType,
//                oldKey.OwnerId,
//                oldKey.Algorithm,
//                updatedBy,
//                cancellationToken);

//            // Mark old key as rotated and link to new key
//            oldKey.MarkAsRotated(newKey.Id, updatedBy);
//            await _encryptionKeyRepository.UpdateAsync(oldKey, cancellationToken);
//            await _unitOfWork.SaveChangesAsync(cancellationToken);

//            return newKey;
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error rotating encryption key {KeyId}", keyId);
//            throw;
//        }
//    }

//    public async Task<EncryptionKey> DeactivateKeyAsync(Guid keyId, string updatedBy,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var key = await _encryptionKeyRepository.GetByIdAsync(keyId, cancellationToken);
//            if (key == null) throw new KeyNotFoundException($"Encryption key with ID {keyId} not found");

//            key.Deactivate(updatedBy);
//            await _encryptionKeyRepository.UpdateAsync(key, cancellationToken);
//            await _unitOfWork.SaveChangesAsync(cancellationToken);

//            return key;
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error deactivating encryption key {KeyId}", keyId);
//            throw;
//        }
//    }

//    public async Task<byte[]> GetPublicKeyAsync(string keyIdentifier, CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var key = await _encryptionKeyRepository.GetByKeyIdentifierAsync(keyIdentifier, cancellationToken);
//            if (key == null)
//                throw new KeyNotFoundException($"Encryption key with identifier {keyIdentifier} not found");

//            if (string.IsNullOrEmpty(key.PublicKey))
//                throw new InvalidOperationException($"Key {keyIdentifier} does not have a public key");

//            // Convert PEM format to raw public key
//            var pem = key.PublicKey;

//            // Remove header, footer, and newlines
//            pem = pem.Replace("-----BEGIN PUBLIC KEY-----", "")
//                .Replace("-----END PUBLIC KEY-----", "")
//                .Replace("\n", "")
//                .Replace("\r", "");

//            // Decode from base64
//            return Convert.FromBase64String(pem);
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error getting public key for {KeyIdentifier}", keyIdentifier);
//            throw;
//        }
//    }

//    public async Task<byte[]?> GetKeyMaterialAsync(string keyIdentifier, CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            var key = await _encryptionKeyRepository.GetByKeyIdentifierAsync(keyIdentifier, cancellationToken);
//            if (key == null)
//            {
//                _logger.LogWarning("Key with identifier {KeyIdentifier} not found", keyIdentifier);
//                return null;
//            }

//            if (key.KeyStatus != EncryptionKeyStatus.Active)
//            {
//                _logger.LogWarning("Key {KeyIdentifier} is not active (status: {Status})", keyIdentifier,
//                    key.KeyStatus);

//                // If the key has been rotated, try to get the new key
//                if (key.KeyStatus == EncryptionKeyStatus.Rotated && key.RotatedToKeyId.HasValue)
//                {
//                    var newKey =
//                        await _encryptionKeyRepository.GetByIdAsync(key.RotatedToKeyId.Value, cancellationToken);
//                    if (newKey != null && newKey.KeyStatus == EncryptionKeyStatus.Active)
//                    {
//                        _logger.LogInformation("Using rotated key {NewKeyIdentifier} instead of {OldKeyIdentifier}",
//                            newKey.KeyIdentifier, keyIdentifier);
//                        return await GetKeyMaterialAsync(newKey.KeyIdentifier, cancellationToken);
//                    }
//                }

//                return null;
//            }

//            if (key.EncryptedKeyMaterial == null)
//            {
//                _logger.LogWarning("Key {KeyIdentifier} has no encrypted key material", keyIdentifier);
//                return null;
//            }

//            // Get master key
//            var masterKey = await GetMasterKeyAsync();

//            // Decrypt key material
//            var iv = new byte[16]; // AES block size
//            var encryptedKey = new byte[key.EncryptedKeyMaterial.Length - 16];

//            Buffer.BlockCopy(key.EncryptedKeyMaterial, 0, iv, 0, iv.Length);
//            Buffer.BlockCopy(key.EncryptedKeyMaterial, iv.Length, encryptedKey, 0, encryptedKey.Length);

//            using var aes = Aes.Create();
//            aes.Key = masterKey;
//            aes.IV = iv;

//            using var decryptor = aes.CreateDecryptor();
//            return decryptor.TransformFinalBlock(encryptedKey, 0, encryptedKey.Length);
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error getting key material for {KeyIdentifier}", keyIdentifier);
//            throw;
//        }
//    }

//    public async Task<byte[]?> GetPublicKeyMaterialAsync(string keyIdentifier,
//        CancellationToken cancellationToken = default)
//    {
//        try
//        {
//            return await GetPublicKeyAsync(keyIdentifier, cancellationToken);
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error getting public key material for {KeyIdentifier}", keyIdentifier);
//            throw;
//        }
//    }

//    private async Task EnsureMasterKeyExistsAsync()
//    {
//        try
//        {
//            // 1. Kiểm tra xem key đã được bảo vệ cục bộ chưa
//            bool keyExistsAndProtected = false;
//            if (OperatingSystem.IsWindows())
//            {
//                keyExistsAndProtected = File.Exists(_masterKeyPath);
//            }
//            else // Linux
//            {
//                // Ví dụ với Kernel Keyring:
//                // keyExistsAndProtected = await LinuxKeyring.KeyExistsAsync("myapp-master-key");
//                // Hoặc nếu dùng file + GPG/EnvVarKey:
//                keyExistsAndProtected = File.Exists(_masterKeyPath);
//            }

//            if (!keyExistsAndProtected)
//            {
//                _logger.LogWarning("Protected master key not found. Attempting to bootstrap/create.");

//                // 2. Lấy raw master key từ nguồn an toàn (ví dụ: config, env var)
//                // Đây là phần bạn cần thiết kế cẩn thận cho việc phân phối key
//                byte[] masterKeyMaterial;
//                string rawMasterKeyBase64 = _options.InitialMasterKeyBase64; // Lấy từ config

//                if (string.IsNullOrEmpty(rawMasterKeyBase64))
//                {
//                    // Nếu không có initial key, chỉ tạo mới cho môi trường dev đơn lẻ (không an toàn cho production đa instance)
//                    _logger.LogWarning("No initial master key provided. Generating a new one. " +
//                                       "THIS IS NOT SUITABLE FOR MULTI-INSTANCE PRODUCTION ENVIRONMENTS " +
//                                       "unless this instance is the designated key generator and the key is then distributed.");
//                    masterKeyMaterial = new byte[32];
//                    using (var rng = RandomNumberGenerator.Create())
//                    {
//                        rng.GetBytes(masterKeyMaterial);
//                    }
//                    _logger.LogInformation("MasterKey Created: {0}", Convert.ToBase64String(masterKeyMaterial));
//                    // GHI CHÚ QUAN TRỌNG: Nếu đây là instance đầu tiên tạo key, bạn cần có cách để
//                    // xuất raw key này (Convert.ToBase64String(masterKeyMaterial)) một cách an toàn
//                    // để phân phối cho các instance khác.
//                    // Với mục đích đồng bộ, lý tưởng nhất là rawMasterKeyBase64 PHẢI được cung cấp từ bên ngoài.
//                }
//                else
//                {
//                    masterKeyMaterial = Convert.FromBase64String(rawMasterKeyBase64);
//                }

//                var directory = Path.GetDirectoryName(_masterKeyPath);
//                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
//                    Directory.CreateDirectory(directory);

//                if (OperatingSystem.IsWindows())
//                {
//                    byte[] protectedKey = ProtectedData.Protect(masterKeyMaterial, null, DataProtectionScope.LocalMachine);
//                    await File.WriteAllBytesAsync(_masterKeyPath, protectedKey);
//                    _logger.LogInformation("Master key protected using DPAPI and saved to {MasterKeyPath}", _masterKeyPath);
//                }
//                else // Linux
//                {
//                    // Lựa chọn 1: Linux Kernel Keyring
//                    // await LinuxKeyring.AddKeyAsync("myapp-master-key", masterKeyMaterial);
//                    // _logger.LogInformation("Master key stored in Linux Kernel Keyring under 'myapp-master-key'.");
//                    // File.WriteAllText(_masterKeyPath, "keyring:myapp-master-key"); // Lưu con trỏ

//                    // Lựa chọn 2: Mã hóa bằng key từ Env Var (ví dụ)
//                    // string rekString = Environment.GetEnvironmentVariable("APP_MASTER_KEY_ENCRYPTION_KEY");
//                    // if (string.IsNullOrEmpty(rekString)) throw new InvalidOperationException("REK not found in env vars.");
//                    // byte[] rek = Convert.FromBase64String(rekString);
//                    // byte[] iv; // Tạo IV
//                    // byte[] encryptedMasterKey = EncryptWithRek(masterKeyMaterial, rek, out iv);
//                    // byte[] contentToWrite = iv.Concat(encryptedMasterKey).ToArray();
//                    // await File.WriteAllBytesAsync(_masterKeyPath, contentToWrite);
//                    // _logger.LogWarning("Master key encrypted with REK and saved to {MasterKeyPath}. Ensure file permissions are 600.", _masterKeyPath);
//                    // SetPermissions(_masterKeyPath, "600"); // Gọi hàm chmod

//                    // Tạm thời vẫn giữ cách cũ của bạn nhưng với masterKeyMaterial đã được cung cấp
//                    _logger.LogWarning("WARNING: Storing master key with basic Base64 encoding on non-Windows. THIS IS NOT SECURE FOR PRODUCTION if raw key wasn't protected by other means before this step.");
//                    byte[] protectedKey = Encoding.UTF8.GetBytes(Convert.ToBase64String(masterKeyMaterial));
//                    await File.WriteAllBytesAsync(_masterKeyPath, protectedKey);
//                    SetPermissions(_masterKeyPath, "600");
//                }
//            }
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error ensuring master key exists");
//            throw;
//        }
//    }

//    private async Task<byte[]> GetMasterKeyAsync()
//    {
//        try
//        {
//            byte[] masterKey;
//            if (OperatingSystem.IsWindows())
//            {
//                if (!File.Exists(_masterKeyPath))
//                    throw new FileNotFoundException("Master key file not found for DPAPI", _masterKeyPath);
//                var protectedKey = await File.ReadAllBytesAsync(_masterKeyPath);
//                masterKey = ProtectedData.Unprotect(protectedKey, null, DataProtectionScope.LocalMachine);
//                _logger.LogInformation("Base 64 masterkey={0}",Convert.ToBase64String(masterKey));
//            }
//            else // Linux
//            {
//                // Lựa chọn 1: Linux Kernel Keyring
//                // string keyPointer = await File.ReadAllTextAsync(_masterKeyPath); // Giả sử file lưu "keyring:myapp-master-key"
//                // if (!keyPointer.StartsWith("keyring:")) throw new InvalidOperationException("Invalid master key pointer.");
//                // string keyDescription = keyPointer.Substring("keyring:".Length);
//                // masterKey = await LinuxKeyring.RequestKeyAsync(keyDescription);
//                // if (masterKey == null) throw new KeyNotFoundException($"Master key '{keyDescription}' not found in Kernel Keyring.");

//                // Lựa chọn 2: Giải mã bằng key từ Env Var
//                // if (!File.Exists(_masterKeyPath))
//                //     throw new FileNotFoundException("Encrypted master key file not found", _masterKeyPath);
//                // byte[] contentFromFile = await File.ReadAllBytesAsync(_masterKeyPath);
//                // byte[] iv = contentFromFile.Take(16).ToArray(); // Giả sử IV 16 bytes
//                // byte[] encryptedMasterKey = contentFromFile.Skip(16).ToArray();
//                // string rekString = Environment.GetEnvironmentVariable("APP_MASTER_KEY_ENCRYPTION_KEY");
//                // if (string.IsNullOrEmpty(rekString)) throw new InvalidOperationException("REK not found in env vars.");
//                // byte[] rek = Convert.FromBase64String(rekString);
//                // masterKey = DecryptWithRek(encryptedMasterKey, rek, iv);

//                // Cách hiện tại (dùng Base64)
//                if (!File.Exists(_masterKeyPath))
//                    throw new FileNotFoundException("Master key file not found", _masterKeyPath);
//                var protectedKey = await File.ReadAllBytesAsync(_masterKeyPath);
//                masterKey = Convert.FromBase64String(Encoding.UTF8.GetString(protectedKey));
//            }
//            return masterKey;
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Error reading/decrypting master key");
//            throw;
//        }
//    }

//    private void SetPermissions(string filePath, string permissions) // Helper for chmod
//    {
//        try
//        {
//            var chmodProcess = new Process
//            {
//                StartInfo = new ProcessStartInfo
//                {
//                    FileName = "chmod",
//                    Arguments = $"{permissions} {filePath}",
//                    UseShellExecute = false,
//                    CreateNoWindow = true
//                }
//            };
//            chmodProcess.Start();
//            chmodProcess.WaitForExit();
//            if (chmodProcess.ExitCode != 0)
//            {
//                _logger.LogError($"chmod failed for {filePath} with exit code {chmodProcess.ExitCode}");
//            }
//        }
//        catch (Exception ex)
//        {
//            _logger.LogError(ex, "Failed to set permissions on master key file {FilePath}", filePath);
//        }
//    }

//    private string ExportPublicKeyToPem(RSA rsa)
//    {
//        var publicKey = rsa.ExportSubjectPublicKeyInfo();
//        var base64 = Convert.ToBase64String(publicKey);

//        // Format as PEM
//        var sb = new StringBuilder();
//        sb.AppendLine("-----BEGIN PUBLIC KEY-----");

//        // Split base64 into lines of 64 characters
//        for (var i = 0; i < base64.Length; i += 64) sb.AppendLine(base64.Substring(i, Math.Min(64, base64.Length - i)));

//        sb.AppendLine("-----END PUBLIC KEY-----");
//        return sb.ToString();
//    }

//    private string ExportPublicKeyToPem(ECDsa ecDsa)
//    {
//        var publicKey = ecDsa.ExportSubjectPublicKeyInfo();
//        var base64 = Convert.ToBase64String(publicKey);

//        // Format as PEM
//        var sb = new StringBuilder();
//        sb.AppendLine("-----BEGIN PUBLIC KEY-----");

//        // Split base64 into lines of 64 characters
//        for (var i = 0; i < base64.Length; i += 64) sb.AppendLine(base64.Substring(i, Math.Min(64, base64.Length - i)));

//        sb.AppendLine("-----END PUBLIC KEY-----");
//        return sb.ToString();
//    }
//}


