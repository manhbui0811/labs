using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Branch;

public class AddNewBranchRequest
{
    public Guid? ParentBranchId { get; set; }
    public string? BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public Guid EntityId { get; set; }
    public Guid CreatedBy { get; set; }
}

public class AddBranchEndpoint(IMediator mediator) : Endpoint<AddNewBranchRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Post("branches");
        Options(o => o.WithName("CreateBranch"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddNewBranchRequest req, CancellationToken ct)
    {
        var command = new AddBranchCommand{
            Name = req.Name,
            BranchCode = req.BranchCode,
            AddressLine1 = req.AddressLine1,
            AddressLine2 = req.AddressLine2,
            WardCode = req.WardCode,
            ProvinceCode = req.ProvinceCode,
            Phone = req.Phone,
            EntityId = req.EntityId,
            CreatedBy = req.CreatedBy,
            ParentBranchId = req.ParentBranchId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
