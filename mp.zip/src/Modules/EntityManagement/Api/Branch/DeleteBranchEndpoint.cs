using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Branch;

public class DeleteBranchRequest
{
    public Guid Id { get; set; }
}
[Tags("BranchManagement")]
public class DeleteBranchEndpoint(IMediator mediator) : Endpoint<DeleteBranchRequest, Result>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Post("branches/{id}/delete");
        Options(o => o.WithName("DeleteBranch"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(DeleteBranchRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
[Tags("BranchManagement")]
public class HardDeleteBranchEndpoint(IMediator mediator) : Endpoint<DeleteBranchRequest, Result>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Delete("branches/{id}");
        Options(o => o.WithName("DeleteBranchById"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(DeleteBranchRequest req, CancellationToken ct)
    {
        var command = new DeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}