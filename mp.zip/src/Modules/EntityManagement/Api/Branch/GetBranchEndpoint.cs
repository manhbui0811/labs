using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Branch;

public class GetBranchRequest
{
    public Guid Id { get; set; }
}

public class GetBranchesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetBranchesByEntityRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
}

public class GetBranchByTidMidRequest
{
    public string Tid { get; set; } = string.Empty;
    public string Mid { get; set; } = string.Empty;
}

public class GetBranchByTidMidEndpoint(IMediator mediator)
    : Endpoint<GetBranchByTidMidRequest, Result<BranchResponseDto>>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Get("branches/by-tid-mid");
        Options(o => o.WithName("GetBranchByTidMid"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetBranchByTidMidRequest req, CancellationToken ct)
    {
        var query = new GetBranchByTidMidQuery
        {
            Tid = req.Tid,
            Mid = req.Mid
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);

    }
}

[Tags("BranchManagement")]
public class GetBranchEndpoint(IMediator mediator) : Endpoint<GetBranchRequest, Result<BranchResponseDto>>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Get("branches/{id}");
        Options(o => o.WithName("GetBranchById"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetBranchRequest req, CancellationToken ct)
    {
        var query = new GetBranchQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}
[Tags("BranchManagement")]
public class GetBranchesEndpoint(IMediator mediator) : Endpoint<GetBranchesRequest, Result<PagedResult<BranchResponseDto>>>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Get("branches");
        Options(o => o.WithName("GetAllBranch"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetBranchesRequest req, CancellationToken ct)
    {
        var query = new GetBranchesQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}
[Tags("BranchManagement")]
public class GetBranchesByEntityEndpoint(IMediator mediator) : Endpoint<GetBranchesByEntityRequest, Result<PagedResult<BranchResponseDto>>>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Version(1);
        Get("branches/entity/{entityId}");
        Options(o => o.WithName("GetBranchByEntityId"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetBranchesByEntityRequest req, CancellationToken ct)
    {
        var query = new GetBranchesByEntityQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}