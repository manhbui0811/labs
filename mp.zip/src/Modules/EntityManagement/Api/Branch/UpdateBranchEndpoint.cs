using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Branch;

public class UpdateBranchRequest
{
    public Guid Id { get; set; }
    public Guid? ParentBranchId { get; set; }
    public string? BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public Guid? EntityId { get; set; }
    public Guid? CreatedBy { get; set; }
}
[Tags("BranchManagement")]
public class UpdateBranchEndpoint(IMediator mediator) : Endpoint<UpdateBranchRequest, Result>
{
    public override void Configure()
    {
        Tags("BranchManagement");
        Put("branches");
        Options(o => o.WithName("UpdateBranch"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(UpdateBranchRequest req, CancellationToken ct)
    {
        var command = new UpdateBranchCommand{
            Name = req.Name,
            BranchCode = req.BranchCode,
            AddressLine1 = req.AddressLine1,
            AddressLine2 = req.AddressLine2,
            WardCode = req.WardCode,
            ProvinceCode = req.ProvinceCode,
            Phone = req.Phone,
            EntityId = req.EntityId,
            CreatedBy = req.CreatedBy,
            ParentBranchId = req.ParentBranchId,
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}