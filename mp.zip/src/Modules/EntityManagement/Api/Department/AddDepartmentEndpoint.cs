using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Department;


public class AddDepartmentRequest
{
    public Guid EntityId { get; set; }
    public Guid? ParentDepartmentId { get; set; }
    public required string DepartmentCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
}

public class AddDepartmentEnpoint(IMediator mediator) : Endpoint<AddDepartmentRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("Department Management");
        Post("departments");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddDepartmentRequest req, CancellationToken ct)
    {
        var command = new AddDepartmentCommand{
            Name = req.Name,
            Description = req.Description,
            EntityId = req.EntityId,
            ParentDepartmentId = req.ParentDepartmentId,
            DepartmentCode = req.DepartmentCode
        };

        var result = await mediator.Send(command, ct);
    
        await Send.OkAsync(result, ct);
    }
}
