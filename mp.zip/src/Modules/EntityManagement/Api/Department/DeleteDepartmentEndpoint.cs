using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Department;

public class DeleteDepartmentRequest
{
    public Guid Id { get; set; }
}

public class DeleteDepartmentEndpoint(IMediator mediator) : Endpoint<DeleteDepartmentRequest, Result>
{
    public override void Configure()
    {
        Tags("Department Management");
        Post("departments/{id}/delete");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeleteDepartmentRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteDepartmentCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class HardDeleteDepartmentEndpoint(IMediator mediator) : Endpoint<DeleteDepartmentRequest, Result>
{
    public override void Configure()
    {
        Tags("Department Management");
        Delete("departments/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeleteDepartmentRequest req, CancellationToken ct)
    {
        var command = new DeleteDepartmentCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}