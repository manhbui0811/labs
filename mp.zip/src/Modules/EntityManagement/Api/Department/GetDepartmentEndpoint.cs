using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Department;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Department;

public class GetDepartmentRequest
{
    public Guid Id { get; set; }
}

public class GetDepartmentsRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetDepartmentsByEntityRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
}

public class GetDepartmentEndpoint(IMediator mediator) : Endpoint<GetDepartmentRequest, Result<DepartmentResponseDto>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("departments/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetDepartmentRequest req, CancellationToken ct)
    {
        var query = new GetDepartmentQuery
        {
            Id = req.Id
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class GetDepartmentsEndpoint(IMediator mediator) : Endpoint<GetDepartmentsRequest, Result<PagedResult<DepartmentResponseDto>>>
{
    public override void Configure()
    {
        Tags("Department Management");
        Get("departments");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetDepartmentsRequest req, CancellationToken ct)
    {
        var query = new GetDepartmentsQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class GetDepartmentsByEntityEndpoint(IMediator mediator) : Endpoint<GetDepartmentsByEntityRequest, Result<PagedResult<DepartmentResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("departments/entity/{entityId}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetDepartmentsByEntityRequest req, CancellationToken ct)
    {
        var query = new GetDepartmentsByEntityQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}