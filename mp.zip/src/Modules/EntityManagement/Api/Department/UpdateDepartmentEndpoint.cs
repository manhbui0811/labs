using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Department;

public class UpdateDepartmentRequest : AddDepartmentRequest
{
    public Guid Id { get; set; }
}
public class UpdateDepartmentEndpoint(IMediator mediator) : Endpoint<UpdateDepartmentRequest, Result>
{
    public override void Configure()
    {
        Tags("Department Management");
        Put("departments");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(UpdateDepartmentRequest req, CancellationToken ct)
    {
        var command = new UpdateDepartmentCommand{
            Id = req.Id,
            Name = req.Name,
            Description = req.Description,
            EntityId = req.EntityId,
            ParentDepartmentId = req.ParentDepartmentId,
            DepartmentCode = req.DepartmentCode
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}