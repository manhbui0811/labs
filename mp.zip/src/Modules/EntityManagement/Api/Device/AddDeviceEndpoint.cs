using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Device;

public class AddDeviceRequest
{
    public required string SerialNumber { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public required string DeviceType { get; set; }
    public string? FcmToken { get; set; }
    public PosStatus Status { get; set; }
    public int? BatteryLevel { get; set; }
    public string? AppVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTime? LastSeen { get; set; }
    public double? CurrentLatitude { get; set; }
    public double? CurrentLongitude { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }
    public string Provider { get; set; }
    public Guid EntityId { get; set; }
    public Guid PaymentChannelId { get; set; }
}

public class AddDeviceEnpoint(IMediator mediator) : Endpoint<AddDeviceRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("Device Management");
        Post("devices");
        Options(o => o.WithName("CreateDevice"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddDeviceRequest req, CancellationToken ct)
    {
        var command = new AddDeviceCommand
        {
            DeviceType = req.DeviceType,
            SerialNumber = req.SerialNumber,
            Status = req.Status,
            AppVersion = req.AppVersion,
            EntityId = req.EntityId,
            NetworkType = req.NetworkType,
            BatteryLevel = req.BatteryLevel,
            CurrentLatitude = req.CurrentLatitude,
            CurrentLongitude = req.CurrentLongitude,
            DeviceModel = req.DeviceModel,
            DeviceName = req.DeviceName,
            FcmToken = req.FcmToken,
            LastSeen = req.LastSeen,
            LocationUpdatedAt = req.LocationUpdatedAt,
            Provider = req.Provider,
            PaymentChannelId = req.PaymentChannelId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
