using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Device;

public class DeleteDeviceRequest
{
    public Guid Id { get; set; }
}

public class DeleteDeviceEndpoint(IMediator mediator) : Endpoint<DeleteDeviceRequest, Result>
{
    public override void Configure()
    {
        Tags("Device Management");
        Post("devices/{id}/delete");
        Options(o => o.WithName("DeleteDevice"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(DeleteDeviceRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteDeviceCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}

public class HardDeleteDeviceEndpoint(IMediator mediator) : Endpoint<DeleteDeviceRequest, Result>
{
    public override void Configure()
    {
        Tags("Device Management");
        Delete("devices/{id}");
        Options(o => o.WithName("DeleteDeviceHard"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(DeleteDeviceRequest req, CancellationToken ct)
    {
        var command = new DeleteDeviceCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}