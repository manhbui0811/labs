using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Device;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Device;

public class GetDeviceRequest
{
    public Guid Id { get; set; }
}

public class GetDevicesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetDevicesByEntityRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
}

public class GetDevicesInformationRequest
{
    public Guid? PosId { get; set; }
    public Guid? MerchantId { get; set; }
    public PosStatus? Status { get; set; } = null;
    public int? BatteryLevel { get; set; }
    public int? Latency { get; set; }
}

public class GetDeviceEndpoint(IMediator mediator) : Endpoint<GetDeviceRequest, Result<DeviceResponseDto>>
{
    public override void Configure()
    {
        Tags("Device Management");
        Get("devices/{id}");
        Options(o => o.WithName("GetDevice"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetDeviceRequest req, CancellationToken ct)
    {
        var query = new GetDeviceQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetBranchesEndpoint(IMediator mediator) : Endpoint<GetDevicesRequest, Result<PagedResult<DeviceResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("devices");
        Options(o => o.WithName("GetDevices"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetDevicesRequest req, CancellationToken ct)
    {
        var query = new GetDevicesQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetBranchesByEntityEndpoint(IMediator mediator) : Endpoint<GetDevicesByEntityRequest, Result<PagedResult<DeviceResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("devices/entity/{entityId}");
        Options(o => o.WithName("GetDevicesByEntity"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetDevicesByEntityRequest req, CancellationToken ct)
    {
        var query = new GetDevicesByEntityQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetDevicesInformationEndpoint(IMediator mediator) : Endpoint<GetDevicesInformationRequest, Result<DevicesInformationRespsonseDto>>
{
    public override void Configure()
    {
        Tags("Device Management");
        Get("/api/devices/information");
        Options(o => o.WithName("GetDevicesTracking"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetDevicesInformationRequest req, CancellationToken ct)
    {
        var query = new GetDevicesInformationQuery
        {
            BatteryLevel = req.BatteryLevel,
            Latency = req.Latency,
            Status = req.Status,
            MerchantId = req.MerchantId,
            PosId = req.PosId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}