using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Device;

public class UpdateDeviceRequest : AddDeviceRequest
{
    public Guid Id { get; set; }
}
public class UpdateDeviceEndpoint(IMediator mediator) : Endpoint<UpdateDeviceRequest, Result>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Put("devices");
        Options(o => o.WithName("UpdateDevice"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(UpdateDeviceRequest req, CancellationToken ct)
    {
        var command = new UpdateDeviceCommand{
            Id = req.Id,
            DeviceType = req.DeviceType,
            SerialNumber = req.SerialNumber,
            Status = req.Status,
            AppVersion = req.AppVersion,
            EntityId = req.EntityId,
            NetworkType = req.NetworkType,
            BatteryLevel = req.BatteryLevel,
            CurrentLatitude = req.CurrentLatitude,
            CurrentLongitude = req.CurrentLongitude,
            DeviceModel = req.DeviceModel,
            DeviceName = req.DeviceName,
            FcmToken = req.FcmToken,
            LastSeen = req.LastSeen,
            LocationUpdatedAt = req.LocationUpdatedAt,
            Provider = req.Provider,
            PaymentChannelId = req.PaymentChannelId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}