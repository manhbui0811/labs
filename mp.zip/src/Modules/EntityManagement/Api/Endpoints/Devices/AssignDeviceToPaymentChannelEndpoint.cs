using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices;

public class AssignDeviceToPaymentChannelRequest
{
    public Guid IotDeviceId { get; set; }
    public Guid PaymentChannelId { get; set; }
}

public class AssignDeviceToPaymentChannelEndpoint(IMediator mediator) : Endpoint<AssignDeviceToPaymentChannelRequest, Result>
{
    public override void Configure()
    {
        Tags("IotDevice Management");
        Post("iot-devices/assign");
        Options(o => o.WithName("AssignIotDevice"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AssignDeviceToPaymentChannelRequest req, CancellationToken ct)
    {
        var command = new AssignDeviceToPaymentChannelCommand
        {
            IotDeviceId = req.IotDeviceId,
            PaymentChannelId = req.PaymentChannelId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}