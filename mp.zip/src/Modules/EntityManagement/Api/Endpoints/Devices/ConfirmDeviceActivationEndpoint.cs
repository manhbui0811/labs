// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Api/Endpoints/Public/Activation/ConfirmDeviceActivationEndpoint.cs
using FastEndpoints;
using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Activation.Commands;
using System.ComponentModel.DataAnnotations;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Public.Activation;

public class ConfirmDeviceActivationEndpoint : Endpoint<ConfirmDeviceActivationRequest, ConfirmDeviceActivationResponse>
{
    private readonly IMediator _mediator;
    private readonly ILogger<ConfirmDeviceActivationEndpoint> _logger;

    public ConfirmDeviceActivationEndpoint(IMediator mediator, ILogger<ConfirmDeviceActivationEndpoint> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    public override void Configure()
    {
        Post("/em/iot/activation/confirm");
        AllowAnonymous(); // Public endpoint
        Summary(s =>
        {
            s.Summary = "Confirm Device Activation";
            s.Description = "Confirms and completes device activation session";
        });
    }

    public override async Task HandleAsync(ConfirmDeviceActivationRequest req, CancellationToken ct)
    {
        try
        {
            _logger.LogInformation("Confirming device activation for session {SessionId}", req.ActivationSessionId);

            var command = new ConfirmDeviceActivationCommand
            {
                ActivationSessionId = req.ActivationSessionId,
                RequestId = req.RequestId,
                CompletionNotes = req.CompletionNotes
            };

            var result = await _mediator.Send(command, ct);

            if (result.IsSuccess)
            {
                var response = new ConfirmDeviceActivationResponse
                {
                    Status = "SUCCESS",
                    Message = "Device activation confirmed successfully",
                    DeviceId = result.Payload!.DeviceId,
                    SessionId = result.Payload.SessionId,
                    SerialNumber = result.Payload.SerialNumber,
                    CompletedAt = result.Payload.CompletedAt,
                    RequestId = result.Payload.RequestId
                };

                await Send.OkAsync(response, ct);
            }
            else
            {
                foreach (var error in result.Errors)
                {
                    AddError(error.Message, error.Code);
                }
                ThrowIfAnyErrors();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in ConfirmDeviceActivationEndpoint for session {SessionId}", req.ActivationSessionId);
            await Send.ResponseAsync(new ConfirmDeviceActivationResponse
            {
                Status = "ERROR",
                Message = "Internal server error"
            }, 500, ct);
        }
    }
}

public class ConfirmDeviceActivationRequest
{
    [Required]
    public Guid ActivationSessionId { get; set; }
    
    public string? RequestId { get; set; }
    
    public string? CompletionNotes { get; set; }
}

public class ConfirmDeviceActivationResponse
{
    public string Status { get; set; } = default!;
    public string Message { get; set; } = default!;
    public Guid? DeviceId { get; set; }
    public Guid? SessionId { get; set; }
    public string? SerialNumber { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public string? RequestId { get; set; }
}