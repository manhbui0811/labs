﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices
{


    public class CreateDeviceRSAKeyEndpoint : Endpoint<CreateDeviceRSAKeyCommand, CreateDeviceRSAKeyDto>
    {
        private readonly ISender _sender;

        public CreateDeviceRSAKeyEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Devices");
            Post("/devices/{serialNumber}/rsa");
            Summary(s => s.Summary = "API Cấp phát khóa");
            AllowAnonymous();
            //AuthSchemes(PosAuthenticationDefaults.AuthenticationScheme);
            //Policies("PosDailyOperationsOnly");
        }

        public override async Task HandleAsync(CreateDeviceRSAKeyCommand req, CancellationToken ct)
        {
            var rs = await _sender.Send(req, ct);
            await Send.OkAsync(rs, ct);
        }
    }
}
