using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices;

public class CreateIotDeviceEndpoint : Endpoint<CreateIotDeviceRequest, IotDeviceDto>
{
    private readonly ISender _sender;

    public CreateIotDeviceEndpoint(ISender sender) => _sender = sender;

    public override void Configure()
    {
        Post("entity-management/iot");
        Tags("EntityManagement - Devices");
        Options(o => o.WithName("CreateIotDevice"));
        AllowAnonymous();
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
        Description(b => b
            .WithName("CreateIotDevice")
            .WithDisplayName("Create IoT Device")
            .WithDescription("Creates a new IoT device.")
            .Accepts<CreateIotDeviceRequest>("application/json")
            .Produces<IotDeviceDto>(201, "application/json")
            .ProducesProblemFE<ErrorResponse>(400)
            .ProducesProblemFE<ErrorResponse>(409)
            .ProducesProblemFE<ErrorResponse>(500));
    }

    public override async Task HandleAsync(CreateIotDeviceRequest req, CancellationToken ct)
    {
        var command = new CreateIotDeviceCommand
        {
            EntityId = req.EntityId,
            SerialNumber = req.SerialNumber,
            DeviceModel = req.DeviceModel,
            DeviceKind = req.DeviceKind,
            DeviceName = req.DeviceName,
            FirmwareVersion = req.FirmwareVersion,
            NetworkType = req.NetworkType
        };

        var result = await _sender.Send(command, ct);
        if (!result.IsSuccess)
        {
            foreach (var error in result.Errors)
            {
                AddError(error.Message, error.Code);
            }
            ThrowIfAnyErrors();
        }

        await Send.OkAsync(result.Payload!, ct);
    }
}

public class CreateIotDeviceRequest
{
    public Guid EntityId { get; set; }
    public string SerialNumber { get; set; } = string.Empty;
    public string DeviceModel { get; set; } = string.Empty;
    public string DeviceKind { get; set; } = string.Empty;
    public string? DeviceName { get; set; }
    public string? FirmwareVersion { get; set; }
    public string? NetworkType { get; set; }
}


