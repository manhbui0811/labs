﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.BuildingBlocks.Infrastructure.Authentication;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices
{


    public class DeviceProvisioningEndpoint : Endpoint<DeviceProvisioningCommand, DeviceProvisioningDto>
    {
        private readonly ISender _sender;

        public DeviceProvisioningEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Devices");
            Post("/devices/provisioning");
            Summary(s => s.Summary = "API Cấp phát khóa");
            //AllowAnonymous();
            AuthSchemes(PosAuthenticationDefaults.AuthenticationScheme);
            Policies("PosProvisioningOnly");
        }

        public override async Task HandleAsync(DeviceProvisioningCommand request, CancellationToken ct)
        {
            var rs = await _sender.Send(request, ct);
            await Send.OkAsync(rs, ct);
        }
    }
}
