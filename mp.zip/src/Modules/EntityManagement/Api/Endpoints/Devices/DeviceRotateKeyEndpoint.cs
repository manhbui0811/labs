﻿using FastEndpoints;
using MediatR;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices
{
    public class DeviceRotateKeyEndpoint : Endpoint<DeviceRotateKeyCommand, DeviceProvisioningDto>
    {
        private readonly ISender _sender;

        public DeviceRotateKeyEndpoint(ISender sender) => _sender = sender;

        public override void Configure()
        {
            Tags("Devices");
            Post("/devices/keys/{keyId}/rotate");
            Summary(s => s.Summary = "API Cấp phát khóa");
            AllowAnonymous();
            //AuthSchemes(PosAuthenticationDefaults.AuthenticationScheme);
            //Policies("PosProvisioningOnly");
        }

        public override async Task HandleAsync(DeviceRotateKeyCommand request, CancellationToken ct)
        {
            var rs = await _sender.Send(request, ct);
            await Send.OkAsync(rs, ct);
        }
    }
}
