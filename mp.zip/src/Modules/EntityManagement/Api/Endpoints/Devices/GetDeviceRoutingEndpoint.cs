// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Api/Endpoints/Internal/Devices/GetDeviceRoutingEndpoint.cs
using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Queries;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Internal.Devices;

[Authorize("InternalOnly")]
public class GetDeviceRoutingEndpoint : Endpoint<GetDeviceRoutingRequest, GetDeviceRoutingResponse>
{
    private readonly IMediator _mediator;
    private readonly ILogger<GetDeviceRoutingEndpoint> _logger;

    public GetDeviceRoutingEndpoint(IMediator mediator, ILogger<GetDeviceRoutingEndpoint> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    public override void Configure()
    {
        Get("/internal/em/iot/{deviceId}/routing");
        Policies("InternalOnly");
        Summary(s =>
        {
            s.Summary = "Get Device Routing Information";
            s.Description = "Internal endpoint to get device routing information including MID/TID";
        });
    }

    public override async Task HandleAsync(GetDeviceRoutingRequest req, CancellationToken ct)
    {
        try
        {
            _logger.LogDebug("Getting device routing for device {DeviceId}", req.DeviceId);

            var query = new GetDeviceRoutingQuery { DeviceId = req.DeviceId };
            var result = await _mediator.Send(query, ct);

            if (result.IsSuccess)
            {
                var response = new GetDeviceRoutingResponse
                {
                    DeviceId = result.Payload!.DeviceId,
                    SerialNumber = result.Payload.SerialNumber,
                    MerchantCode = result.Payload.MerchantCode,
                    TerminalCode = result.Payload.TerminalCode,
                    Topic = result.Payload.Topic
                };

                await Send.OkAsync(response, ct);
            }
            else
            {
                foreach (var error in result.Errors)
                {
                    AddError(error.Message, error.Code);
                }
                ThrowIfAnyErrors();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetDeviceRoutingEndpoint for device {DeviceId}", req.DeviceId);
            await Send.ErrorsAsync(500, ct);
        }
    }
}

public class GetDeviceRoutingRequest
{
    public Guid DeviceId { get; set; }
}

public class GetDeviceRoutingResponse
{
    public Guid DeviceId { get; set; }
    public string SerialNumber { get; set; } = default!;
    public string MerchantCode { get; set; } = default!;
    public string TerminalCode { get; set; } = default!;
    public string? Topic { get; set; }
}