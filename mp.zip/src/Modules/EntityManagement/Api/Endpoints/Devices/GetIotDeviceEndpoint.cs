using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices;

public class GetIotDeviceEndpoint : Endpoint<GetIotDeviceRequest, IotDeviceDto>
{
    private readonly ISender _sender;

    public GetIotDeviceEndpoint(ISender sender) => _sender = sender;

    public override void Configure()
    {
        Get("entity-management/iot/{deviceId}");
        Tags("EntityManagement - Devices");
        Options(o => o.WithName("GetIotDevice"));
        AllowAnonymous();
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
        Description(b => b
            .WithName("GetIotDevice")
            .WithDisplayName("Get IoT Device Information")
            .WithDescription("Retrieves information about a specific IoT device.")
            .Produces<IotDeviceDto>(200, "application/json")
            .ProducesProblemFE<ErrorResponse>(404)
            .ProducesProblemFE<ErrorResponse>(500));
    }

    public override async Task HandleAsync(GetIotDeviceRequest req, CancellationToken ct)
    {
        var query = new GetIotDeviceByIdQuery { DeviceId = req.DeviceId };
        var result = await _sender.Send(query, ct);

        if (result.IsFailure)
        {
            await Send.NotFoundAsync(ct);
            return;
        }

        if (result.Payload == null)
        {
            await Send.NotFoundAsync(ct);
            return;
        }

        await Send.OkAsync(result.Payload, ct);
    }
}

public class GetIotDeviceRequest
{
    public Guid DeviceId { get; set; }
}


