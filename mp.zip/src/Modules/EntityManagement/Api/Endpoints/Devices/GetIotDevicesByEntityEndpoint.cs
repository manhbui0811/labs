using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Devices;

public class GetIotDevicesByEntityEndpoint : Endpoint<GetIotDevicesByEntityRequest, GetIotDevicesByEntityResponse>
{
    private readonly ISender _sender;

    public GetIotDevicesByEntityEndpoint(ISender sender) => _sender = sender;

    public override void Configure()
    {
        Get("entity-management/entities/{entityId}/iot-devices");
        Tags("EntityManagement - Devices");
        Options(o => o.WithName("GetIotDevicesByEntity"));
        AllowAnonymous();
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
        Description(b => b
            .WithName("GetIotDevicesByEntity")
            .WithDisplayName("Get IoT Devices by Entity")
            .WithDescription("Retrieves all IoT devices for a specific entity.")
            .Produces<GetIotDevicesByEntityResponse>(200, "application/json")
            .ProducesProblemFE<ErrorResponse>(500));
    }

    public override async Task HandleAsync(GetIotDevicesByEntityRequest req, CancellationToken ct)
    {
        var query = new GetIotDevicesByEntityQuery
        {
            EntityId = req.EntityId,
            Status = req.Status,
            Skip = req.Skip,
            Take = req.Take
        };

        var result = await _sender.Send(query, ct);

        if (result.IsFailure)
        {
            foreach (var error in result.Errors)
            {
                AddError(error.Message, error.Code);
            }
            ThrowIfAnyErrors();
        }

        await Send.OkAsync(new GetIotDevicesByEntityResponse
        {
            Devices = result.Payload!.ToList(),
            Total = result.Payload!.Count
        }, ct);
    }
}

public class GetIotDevicesByEntityRequest
{
    public Guid EntityId { get; set; }
    public string? Status { get; set; }
    public int Skip { get; set; } = 0;
    public int Take { get; set; } = 50;
}

public class GetIotDevicesByEntityResponse
{
    public List<IotDeviceDto> Devices { get; set; } = new();
    public int Total { get; set; }
}


