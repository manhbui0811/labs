// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Api/Endpoints/Public/Activation/InitDeviceActivationEndpoint.cs
using FastEndpoints;
using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Activation.Commands;
using System.ComponentModel.DataAnnotations;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Endpoints.Public.Activation;

public class InitDeviceActivationEndpoint : Endpoint<InitDeviceActivationRequest, InitDeviceActivationResponse>
{
    private readonly IMediator _mediator;
    private readonly ILogger<InitDeviceActivationEndpoint> _logger;

    public InitDeviceActivationEndpoint(IMediator mediator, ILogger<InitDeviceActivationEndpoint> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    public override void Configure()
    {
        Post("/em/iot/activation/init");
        AllowAnonymous(); // Public endpoint
        Summary(s =>
        {
            s.Summary = "Initialize Device Activation";
            s.Description = "Initializes a new device activation session";
        });
    }

    public override async Task HandleAsync(InitDeviceActivationRequest req, CancellationToken ct)
    {
        try
        {
            _logger.LogInformation("Initializing device activation for device {DeviceId}", req.DeviceId);

            var command = new InitDeviceActivationCommand
            {
                DeviceId = req.DeviceId,
                ExpirationMinutes = req.ExpirationMinutes,
                RequestId = req.RequestId
            };

            var result = await _mediator.Send(command, ct);

            if (result.IsSuccess)
            {
                var response = new InitDeviceActivationResponse
                {
                    Status = "SUCCESS",
                    Message = "Device activation session initialized",
                    SessionId = result.Payload!.SessionId,
                    SessionCode = result.Payload.SessionCode,
                    ExpiresAt = result.Payload.ExpiresAt,
                    DeviceId = result.Payload.DeviceId,
                    RequestId = result.Payload.RequestId
                };

                await Send.OkAsync(response, ct);
            }
            else
            {
                foreach (var error in result.Errors)
                {
                    AddError(error.Message, error.Code);
                }
                ThrowIfAnyErrors();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in InitDeviceActivationEndpoint for device {DeviceId}", req.DeviceId);
            await Send.ResponseAsync(new InitDeviceActivationResponse
            {
                Status = "ERROR",
                Message = "Internal server error"
            }, 500, ct);
        }
    }
}

public class InitDeviceActivationRequest
{
    [Required]
    public Guid DeviceId { get; set; }
    
    public int ExpirationMinutes { get; set; } = 30;
    
    public string? RequestId { get; set; }
}

public class InitDeviceActivationResponse
{
    public string Status { get; set; } = default!;
    public string Message { get; set; } = default!;
    public Guid? SessionId { get; set; }
    public string? SessionCode { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public Guid? DeviceId { get; set; }
    public string? RequestId { get; set; }
}