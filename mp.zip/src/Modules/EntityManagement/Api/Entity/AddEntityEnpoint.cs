using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class AddNewEntityRequest
{
    public Guid? EntityStructureId { get; set; }
    public string? EntityCode { get; set; }
    public required string Name { get; set; }
    public string? ShortName { get; set; }
    public string? TaxCode { get; set; }
    public string? Website { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public Guid? BusinessCategoryId { get; set; }
    public Guid? CreatedBy { get; set; }
    public List<EntityRelationshipDto> ParentEntities { get; set; } = [];
    public List<EntityRelationshipDto> ChildEntities { get; set; } = [];
}

public class AddEntityEnpoint(IMediator mediator) : Endpoint<AddNewEntityRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Post("entities/onboard");
        Options(o => o.WithName("AddEntity"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddNewEntityRequest req, CancellationToken ct)
    {
        var command = new AddEntityCommand{
            Name = req.Name,
            ShortName = req.ShortName,
            TaxCode = req.TaxCode,
            Website = req.Website,
            Phone = req.Phone,
            Email = req.Email,
            AddressLine1 = req.AddressLine1,
            AddressLine2 = req.AddressLine2,
            EntityCode = req.EntityCode??CodeGenerator.GenerateRandomNumericCode(),
            ParentEntities = req.ParentEntities,
            ChildEntities = req.ChildEntities,
            BusinessCategoryId = req.BusinessCategoryId,
            CreatedBy = req.CreatedBy,
            ProvinceCode = req.ProvinceCode,
            WardCode = req.WardCode,
            EntityStructureId = req.EntityStructureId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}