using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class UserEntityMemberShipRolerequestDto
{
    public Guid RoleId { get; set; }
    public string RoleType { get; set;}
}

public class AddUserEntityRelationDto
{
    public string JobTitle { get; set; } = string.Empty;
    public Guid UserId { get; set; }
    public Guid EntityId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? CreatedBy { get; set; }
    public Guid? UpdatedBy { get; set; }
    public List<UserEntityMemberShipRolerequestDto> Roles { get; set; } = [];
}
public class AddUserEntityRequest
{
    public List<AddUserEntityRelationDto> Relations { get; set; } = [];
}

public class AddUserEntityEndpoint(IMediator mediator) : Endpoint<AddUserEntityRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Post("entities/add-user");
        Options(o => o.WithName("AddUserToEntity"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(AddUserEntityRequest req, CancellationToken ct)
    {
        var command = new AddUserEntityCommand{
            Relations = req.Relations.Select(r => new AddUserEntityDto
            {
                CreatedBy = r.CreatedBy,
                UpdatedBy = r.UpdatedBy,
                JobTitle = r.JobTitle,
                EntityId = r.EntityId,
                UserId = r.UserId,
                DepartmentId = r.DepartmentId,
                Roles = r.Roles.Select(role => new UserEntityMemberShipRoleDto
                {
                    RoleId = role.RoleId,
                    RoleType = role.RoleType
                }).ToList()
            }).ToList()
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }

}