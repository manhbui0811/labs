using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class DeleteEntityRequest
{
    public Guid Id { get; set; }
}

public class DeleteEntityEndpoint(IMediator mediator) : Endpoint<DeleteEntityRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Delete("entities/{id}");
        Options(o => o.WithName("DeleteEntity"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(DeleteEntityRequest req, CancellationToken ct)
    {
        var command = new DeleteEntityCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}

public class SoftDeleteEntityEndpoint(IMediator mediator) : Endpoint<DeleteEntityRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Post("entities/{id}/delete");
        Options(o => o.WithName("SoftDeleteEntity"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(DeleteEntityRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteEntityCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}