using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class GetEntitiesByUserRequest : GetEntitiesQuery
{
    public Guid UserId { get; set; }
}

public class GetEntitiesByUserEndpoint(IMediator mediator)
    : Endpoint<GetEntitiesByUserRequest, Result<PagedResult<EntityResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities/user/{userId}");
        Options(o => o.WithName("GetEntityByUserId"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetEntitiesByUserRequest req, CancellationToken ct)
    {
        var query = new GetEntitiesByUserQuery
        {
            SearchText = req.SearchText,
            PageSize = req.PageSize,
            PageNumber = req.PageNumber,
            UserId = req.UserId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);

    }
}