using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class GetEntitiesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    
    public bool NewView { get; set; } = false;
}

public class GetEntitiesByEntityStructureRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityStructureId { get; set; }
    
}

public class GetNoChildEntitiesRequest
{
    public Guid? UserId { get; set; } = null;
    public string? SearchText { get; set; }
}
public class GetEntitiesEndpoint(IMediator mediator)
    : Endpoint<GetEntitiesRequest, Result<PagedResult<EntityResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities");
        Options(o => o.WithName("GetEntities"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetEntitiesRequest req, CancellationToken ct)
    {
        var query = new GetEntitiesQuery
        {
            SearchText = req.SearchText,
            PageSize = req.PageSize,
            PageNumber = req.PageNumber,
            NewView = req.NewView
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);

    }
}

public class GetEntitiesByEntityStructureEndpoint(IMediator mediator)
    : Endpoint<GetEntitiesByEntityStructureRequest, Result<PagedResult<EntityResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities/get-by-structure/{EntityStructureId}/");
        Options(o => o.WithName("GetEntitiesByEntityStructure"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetEntitiesByEntityStructureRequest req, CancellationToken ct)
    {
        var query = new GetEntitiesByEntityStructureQuery
        {
            SearchText = req.SearchText,
            PageSize = req.PageSize,
            PageNumber = req.PageNumber,
            EntityStructureId = req.EntityStructureId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);

    }
}

public class GetNoChildEntitiesEndpoint(IMediator mediator)
    : Endpoint<GetNoChildEntitiesRequest, Result<List<EntityResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities/no-child/");
        Options(o => o.WithName("GetNoChildEntities"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetNoChildEntitiesRequest req, CancellationToken ct)
    {
        var query = new GetNoChildEntitiesQuery
        {
            SearchText = req.SearchText,
            UserId = req.UserId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);

    }
}