using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class GetEntityRequest
{
    public Guid Id { get; set; }
}

public class GetListChildEntitiesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;
    public Guid ParentId { get; set; }
    public string? SearchText { get; set; }
}

public class GetEntityEndpoint(IMediator mediator)
    : Endpoint<GetEntityRequest, Result<EntityResponseDto>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities/{id}");
        Options(o => o.WithName("GetEntityById"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetEntityRequest req, CancellationToken ct)
    {
        var query = new GetEntityQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetListChildEntitiesEndpoint(IMediator mediator)
    : Endpoint<GetListChildEntitiesRequest, Result<PagedResult<EntityResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Get("entities/{parentId}/list-childs");
        Options(o => o.WithName("GetListChildEntities"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetListChildEntitiesRequest req, CancellationToken ct)
    {
        var query = new GetListChildEntitiesQuery
        {
            ParentId = req.ParentId,
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SeachText = req.SearchText
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}