using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;

public class UpdateEntityRequest : AddNewEntityRequest
{
    public Guid Id { get; set; }
}

public class UpdateEntityEndpoint(IMediator mediator) : Endpoint<UpdateEntityRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityManagement");
        Put("entities");
        Options(o => o.WithName("UpdateEntity"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(UpdateEntityRequest req, CancellationToken ct)
    {
        var command = new UpdateEntityCommand{
            Id = req.Id,
            Name = req.Name,
            ShortName = req.ShortName,
            TaxCode = req.TaxCode,
            Website = req.Website,
            Phone = req.Phone,
            Email = req.Email,
            AddressLine1 = req.AddressLine1,
            AddressLine2 = req.AddressLine2,
            EntityCode = req.EntityCode,
            ParentEntities = req.ParentEntities,
            ChildEntities = req.ChildEntities,
            BusinessCategoryId = req.BusinessCategoryId,
            CreatedBy = req.CreatedBy,
            ProvinceCode = req.ProvinceCode,
            WardCode = req.WardCode,
            EntityStructureId = req.EntityStructureId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }

}