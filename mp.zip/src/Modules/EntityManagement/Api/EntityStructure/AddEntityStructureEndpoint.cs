using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.EntityStructure;

public class AddEntityStructureRequest
{
    public string Name { get; set; }
    public Guid? ParentId { get; set; }
}

public class AddEntityStructureEndpoint(IMediator mediator) : Endpoint<AddEntityStructureRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("EntityStructure");
        Post("entity-structures");
        Options(o => o.WithName("AddEntityStructure"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(AddEntityStructureRequest req, CancellationToken ct)
    {
        var command = new AddEntityStructureCommand{
            Name = req.Name,
            ParentId = req.ParentId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}