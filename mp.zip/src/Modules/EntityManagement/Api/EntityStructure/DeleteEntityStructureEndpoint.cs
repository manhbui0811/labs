using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Api.Entity;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.EntityStructure;

public class DeleteEntityStructureRequest
{
    public Guid Id { get; set; }
}

public class DeleteEntityStructureEndpoint(IMediator mediator) : Endpoint<DeleteEntityStructureRequest, Result>
{
        public override void Configure()
        {
            Tags("EntityStructure");
            Delete("entity-structures/{id}");
            Options(o => o.WithName("SoftDeleteEntityStructure"));
            AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
            Version(1);
        }
        public override async Task HandleAsync(DeleteEntityStructureRequest req, CancellationToken ct)
        {
            var command = new DeleteEntityStructureCommand{
                Id = req.Id
            };

            var result = await mediator.Send(command, ct);

            await Send.OkAsync(result, ct);
        }
}

public class SoftDeleteEntityEndpoint(IMediator mediator) : Endpoint<DeleteEntityStructureRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityStructure");
        Post("entity-structures/{id}/delete");
        Options(o => o.WithName("DeleteEntityStructure"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(DeleteEntityStructureRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteEntityStructureCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}