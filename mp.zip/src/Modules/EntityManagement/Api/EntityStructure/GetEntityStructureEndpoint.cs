using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.EntityStructure;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.EntityStructure;

public class GetEntityStructureRequest
{
    public Guid Id { get; set; }
}

public class GetEntityStructuresRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetEntityStructureEndpoint(IMediator mediator) : Endpoint<GetEntityStructureRequest, Result<EntityStructureResponseDto>>
{
    public override void Configure()
    {
        Tags("EntityStructure");
        Get("entity-structures/{id}");
        Options(o => o.WithName("GetEntityStructure"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(GetEntityStructureRequest req, CancellationToken ct)
    {
        var command = new GetEntityStructureQuery{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetEntityStructuresEndpoint(IMediator mediator) : Endpoint<GetEntityStructuresRequest, Result<PagedResult<EntityStructureResponseDto>>>
{
    public override void Configure()
    {
        Tags("EntityStructure");
        Get("entity-structures");
        Options(o => o.WithName("GetEntityStructures"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(GetEntityStructuresRequest req, CancellationToken ct)
    {
        var command = new GetEntityStructuresQuery{
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
