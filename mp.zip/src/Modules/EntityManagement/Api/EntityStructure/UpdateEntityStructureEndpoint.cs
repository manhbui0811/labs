using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.EntityStructure;

public class UpdateEntityStructureRequest
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public Guid? ParentId { get; set; }
}

public class UpdateEntityStructureEndpoint(IMediator mediator) : Endpoint<UpdateEntityStructureRequest, Result>
{
    public override void Configure()
    {
        Tags("EntityStructure");
        Put("entity-structures");
        Options(o => o.WithName("UpdateEntityStructure"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    public override async Task HandleAsync(UpdateEntityStructureRequest req, CancellationToken ct)
    {
        var command = new UpdateEntityStructureCommand{
            Id = req.Id,
            Name = req.Name,
            ParentId = req.ParentId
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}