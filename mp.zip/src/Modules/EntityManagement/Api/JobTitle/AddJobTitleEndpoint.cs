using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.JobTitle;

public class AddJobTitleRequest
{
    public Guid EntityId { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
}

public class AddJobTitleEnpoint(IMediator mediator) : Endpoint<AddJobTitleRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Post("jobtitles");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddJobTitleRequest req, CancellationToken ct)
    {
        var command = new AddJobTitleCommand{
            Title = req.Title,
            Description = req.Description,
            EntityId = req.EntityId
        };

        var result = await mediator.Send(command, ct);
    
        await Send.OkAsync(result, ct);
    }
}
