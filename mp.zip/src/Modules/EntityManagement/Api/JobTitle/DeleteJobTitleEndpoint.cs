using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.JobTitle;

public class DeleteJobTitleRequest
{
    public Guid Id { get; set; }
}

public class DeleteJobTitleEndpoint(IMediator mediator) : Endpoint<DeleteJobTitleRequest, Result>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Post("jobtitles/{id}/delete");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeleteJobTitleRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteJobTitleCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class HardDeleteJobTitleEndpoint(IMediator mediator) : Endpoint<DeleteJobTitleRequest, Result>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Delete("jobtitles/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeleteJobTitleRequest req, CancellationToken ct)
    {
        var command = new DeleteJobTitleCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}