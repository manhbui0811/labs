using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.JobTitle;

public class GetJobTitleRequest
{
    public Guid Id { get; set; }
}

public class GetJobTitlesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetJobTitlesByEntityRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
}

public class GetJobTitleEndpoint(IMediator mediator) : Endpoint<GetJobTitleRequest, Result<JobTitleResponseDto>>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Get("jobtitles/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetJobTitleRequest req, CancellationToken ct)
    {
        var query = new GetJobTitleQuery
        {
            Id = req.Id
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class GetJobTitlesEndpoint(IMediator mediator) : Endpoint<GetJobTitlesRequest, Result<PagedResult<JobTitleResponseDto>>>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Get("jobtitles");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetJobTitlesRequest req, CancellationToken ct)
    {
        var query = new GetJobTitlesQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class GetJobTitlesByEntityEndpoint(IMediator mediator) : Endpoint<GetJobTitlesByEntityRequest, Result<PagedResult<JobTitleResponseDto>>>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Get("jobtitles/entity/{entityId}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetJobTitlesByEntityRequest req, CancellationToken ct)
    {
        var query = new GetJobTitlesByEntityQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId
        };
        
        var result = await mediator.Send(query, ct);
        
        await Send.OkAsync(result, ct);
    }
}