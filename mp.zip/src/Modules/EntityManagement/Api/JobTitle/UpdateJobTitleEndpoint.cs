using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.JobTitle;

public class UpdateJobTitleRequest : AddJobTitleRequest
{
    public Guid Id { get; set; }
}
public class UpdateJobTitleEndpoint(IMediator mediator) : Endpoint<UpdateJobTitleRequest, Result>
{
    public override void Configure()
    {
        Tags("JobTitle Management");
        Put("jobtitles");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(UpdateJobTitleRequest req, CancellationToken ct)
    {
        var command = new UpdateJobTitleCommand{
            Title = req.Title,
            Description = req.Description,
            EntityId = req.EntityId,
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}