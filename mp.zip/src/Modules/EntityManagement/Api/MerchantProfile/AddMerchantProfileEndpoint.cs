using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.MerchantProfile;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.MerchantProfile;

public class AddMerchantProfileRequest
{
    public required string MerchantCode { get; set; }
    public required string MerchantName { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;
    public Guid EntityId { get; set; }
    public Guid AcquiringBankId { get; set; }

    public ICollection<AddSettlementAccountRequest>? SettlementAccounts { get; set; } = [];
}

public class AddSettlementAccountRequest
{
    public string AccountNumber { get; set; }
    public string AccountName { get; set; }
    
    public string BankName { get; set; }
    
    public string? BankCode { get; set; }
}

public class AddMerchantProfileEnpoint(IMediator mediator) : Endpoint<AddMerchantProfileRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Post("merchantprofiles");
        Options(o => o.WithName("CreateMerchant"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(AddMerchantProfileRequest req, CancellationToken ct)
    {
        var command = new AddMerchantProfileCommand{
            MerchantCode = req.MerchantCode,
            MerchantName = req.MerchantName,
            Status = req.Status,
            EntityId = req.EntityId,
            AcquiringBankId = req.AcquiringBankId,
            SettlementAccounts = req.SettlementAccounts.Select(s => new AddSettlementAccountCommand
            {
                AccountName = s.AccountName,
                AccountNumber = s.AccountNumber,
                BankCode = s.BankCode,
                BankName = s.BankName
            }).ToList()
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
