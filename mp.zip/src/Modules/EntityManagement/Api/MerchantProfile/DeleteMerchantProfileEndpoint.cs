using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.MerchantProfile;

public class DeleteBranchRequest
{
    public Guid Id { get; set; }
}

public class DeleteMerchantProfileEndpoint(IMediator mediator) : Endpoint<DeleteBranchRequest, Result>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Post("merchantprofiles/{id}/delete");
        Options(o => o.WithName("DeleteMerchant"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(DeleteBranchRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}

public class HardDeleteMerchantProfileEndpoint(IMediator mediator) : Endpoint<DeleteBranchRequest, Result>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Delete("merchantprofiles/{id}");
        Options(o => o.WithName("DeleteMerchantHard"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(DeleteBranchRequest req, CancellationToken ct)
    {
        var command = new DeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}