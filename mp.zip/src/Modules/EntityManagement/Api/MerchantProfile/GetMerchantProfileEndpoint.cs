using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.MerchantProfile;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.MerchantProfile;

public class GetMerchantProfileRequest
{
    public Guid Id { get; set; }
}

public class GetMerchantProfilesByUserRequest
{
    public string? SearchText { get; set; } = string.Empty;
}

public class GetMerchantProfilesRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    public Guid? AcquiringBankId { get; set; } = null;
    public EntityStatus? Status { get; set; } = null;
    public Guid? EntityId { get; set; } = null;
}

public class GetMerchantProfilesByEntityRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
}

public class GetMerchantProfileEndpoint(IMediator mediator) : Endpoint<GetMerchantProfileRequest, Result<MerchantProfileResponseDto>>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Get("merchantprofiles/{id}");
        Options(o => o.WithName("GetMerchant"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetMerchantProfileRequest req, CancellationToken ct)
    {
        var query = new GetMerchantProfileQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetMerchantProfilesByUserEndpoint(IMediator mediator) : Endpoint<GetMerchantProfilesByUserRequest, Result<List<MerchantProfileResponseDto>>>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Get("merchantprofiles/by-user");
        Options(o => o.WithName("GetMerchantsByUser"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetMerchantProfilesByUserRequest req, CancellationToken ct)
    {
        var query = new GetMerchantProfilesByUserQuery
        {
            SearchText = req.SearchText,
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}


public class GetMerchantProfilesEndpoint(IMediator mediator) : Endpoint<GetMerchantProfilesRequest, Result<PagedResult<MerchantProfileResponseDto>>>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Get("merchantprofiles");
        Options(o => o.WithName("GetMerchants"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetMerchantProfilesRequest req, CancellationToken ct)
    {
        var query = new GetMerchantProfilesQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId,
            AcquiringBankId = req.AcquiringBankId,
            Status = req.Status,
            FromDate = req.FromDate,
            ToDate = req.ToDate
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetMerchantProfilesByEntityEndpoint(IMediator mediator) : Endpoint<GetMerchantProfilesByEntityRequest, Result<PagedResult<MerchantProfileResponseDto>>>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Get("merchantprofiles/entity/{entityId}");
        Options(o => o.WithName("GetMerchantByEntityId"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetMerchantProfilesByEntityRequest req, CancellationToken ct)
    {
        var query = new GetMerchantProfilesByEntityQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            EntityId = req.EntityId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}