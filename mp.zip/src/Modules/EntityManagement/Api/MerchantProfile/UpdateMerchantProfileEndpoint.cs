using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.MerchantProfile;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.MerchantProfile;

public class UpdateMerchantProfileRequest : AddMerchantProfileRequest
{
    public Guid Id { get; set; }
}
public class UpdateMerchantProfileEndpoint(IMediator mediator) : Endpoint<UpdateMerchantProfileRequest, Result>
{
    public override void Configure()
    {
        Tags("MerchantProfile Management");
        Put("merchantprofiles");
        Options(o => o.WithName("UpdateMerchant"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(UpdateMerchantProfileRequest req, CancellationToken ct)
    {
        var command = new UpdateMerchantProfileCommand{
            MerchantCode = req.MerchantCode,
            MerchantName = req.MerchantName,
            Status = req.Status,
            EntityId = req.EntityId,
            AcquiringBankId = req.AcquiringBankId,
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}