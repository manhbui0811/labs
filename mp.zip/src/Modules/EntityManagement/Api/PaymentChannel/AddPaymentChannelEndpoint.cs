using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;

public class AddPaymentChannelRequest
{
    public required string ChannelType { get; set; }
    public required string TidCode { get; set; }
    public required string MidCode { get; set; }
    public string? ChannelName { get; set; }
    public Guid PosId { get; set; }
    public Guid MerchantProfileId { get; set; }
    public Guid PointOfSaleId { get; set; }
}

public class AddPaymentChannelEnpoint(IMediator mediator) : Endpoint<AddPaymentChannelRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("PaymentChannel Management");
        Post("paymentchannels");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddPaymentChannelRequest req, CancellationToken ct)
    {
        var command = new AddPaymentChannelCommand{
            ChannelType = req.ChannelType,
            TidCode = req.TidCode,
            MidCode = req.MidCode,
            ChannelName = req.ChannelName,
            PosId = req.PosId,
            MerchantProfileId = req.MerchantProfileId,
            PointOfSaleId = req.PointOfSaleId
        };

        var result = await mediator.Send(command, ct);
    
        await Send.OkAsync(result, ct);
    }
}
