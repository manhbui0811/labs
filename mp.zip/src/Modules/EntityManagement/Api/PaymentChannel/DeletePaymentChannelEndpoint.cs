using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;

public class DeletePaymentChannelRequest
{
    public Guid Id { get; set; }
}

public class DeletePaymentChannelEndpoint(IMediator mediator) : Endpoint<DeletePaymentChannelRequest, Result>
{
    public override void Configure()
    {
        Tags("PaymentChannel Management");
        Post("paymentchannels/{id}/delete");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeletePaymentChannelRequest req, CancellationToken ct)
    {
        var command = new SoftDeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}

public class HardDeletePaymentChannelEndpoint(IMediator mediator) : Endpoint<DeletePaymentChannelRequest, Result>
{
    public override void Configure()
    {
        Tags("PaymentChannel Management");
        Delete("paymentchannels/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(DeletePaymentChannelRequest req, CancellationToken ct)
    {
        var command = new DeleteBranchCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}