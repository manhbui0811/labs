using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PaymentChannel;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;

public class GetPaymentChannelRequest
{
    public Guid Id { get; set; }
}

public class GetPaymentChannelsRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetPaymentChannelsByPointOfSaleRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid PointOfSaleId { get; set; }
}

public class GetPaymentChannelsByMerchantProfileRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid MerchantProfileId { get; set; }
}

public class GetPaymentChannelEndpoint(IMediator mediator) : Endpoint<GetPaymentChannelRequest, Result<PaymentChannelResponseDto>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("paymentchannels/{id}");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPaymentChannelRequest req, CancellationToken ct)
    {
        var query = new GetPaymentChannelQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetBranchesEndpoint(IMediator mediator) : Endpoint<GetPaymentChannelsRequest, Result<PagedResult<PaymentChannelResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("paymentchannels");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPaymentChannelsRequest req, CancellationToken ct)
    {
        var query = new GetPaymentChannelsQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetPaymentChannelsByPointOfSaleEndpoint(IMediator mediator) : Endpoint<GetPaymentChannelsByPointOfSaleRequest, Result<PagedResult<PaymentChannelResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("paymentchannels/pointofsale/{pointOfSaleId}");
        Options(o => o.WithName("GetPaymentChannelsByPosId"));
        Version(1);
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
    }

    public override async Task HandleAsync(GetPaymentChannelsByPointOfSaleRequest req, CancellationToken ct)
    {
        var query = new GetPaymentChannelByPointOfSaleQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            PointOfSaleId = req.PointOfSaleId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetPaymentChannelsByMerchantProfileEndpoint(IMediator mediator) : Endpoint<GetPaymentChannelsByMerchantProfileRequest, Result<PagedResult<PaymentChannelResponseDto>>>
{
    public override void Configure()
    {
        Tags("Branch Management");
        Get("paymentchannels/merchantprofile/{merchantProfileId}");
        Options(o => o.WithName("GetPaymentChannelsByMerchantProfil"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPaymentChannelsByMerchantProfileRequest req, CancellationToken ct)
    {
        var query = new GetPaymentChannelByMerchantProfileQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            MerchantProfileId = req.MerchantProfileId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}