using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;

public class UpdatePaymentChannelRequest : AddPaymentChannelRequest
{
    public Guid Id { get; set; }
}
public class UpdatePaymentChannelEndpoint(IMediator mediator) : Endpoint<UpdatePaymentChannelRequest, Result>
{
    public override void Configure()
    {
        Tags("PaymentChannel Management");
        Put("paymentchannels");
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }
    
    public override async Task HandleAsync(UpdatePaymentChannelRequest req, CancellationToken ct)
    {
        var command = new UpdatePaymentChannelCommand{
            ChannelType = req.ChannelType,
            TidCode = req.TidCode,
            MidCode = req.MidCode,
            ChannelName = req.ChannelName,
            PosId = req.PosId,
            MerchantProfileId = req.MerchantProfileId,
            PointOfSaleId = req.PointOfSaleId,
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);
        
        await Send.OkAsync(result, ct);
    }
}