using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;
using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PointsOfSale;


public class AddNewPointOfSaleRequest
{
    public string? PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; }
    public Guid BranchId { get; set; }
    public ICollection<AddPaymentChannelRequest>? PaymentChannels { get; set; }
}

public class AddPointOfSaleEndpoint(IMediator mediator) : Endpoint<AddNewPointOfSaleRequest, Result<Guid>>
{
    public override void Configure()
    {
        Tags("PointsOfSaleManagement");
        Post("points-of-sale");
        Options(o => o.WithName("AddPointOfSale"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(AddNewPointOfSaleRequest req, CancellationToken ct)
    {
        var command = new AddPointOfSaleCommand{
            Name = req.Name,
            PosCode = req.PosCode??CodeGenerator.GenerateRandomNumericCode(),
            Description = req.Description,
            Status = req.Status,
            BranchId = req.BranchId,
            PaymentChannels = req.PaymentChannels != null ? 
                req.PaymentChannels.Select(p => new AddPaymentChannelCommand
                {
                    ChannelType = p.ChannelType,
                    ChannelName = p.ChannelName,
                    MidCode = p.MidCode,
                    TidCode = p.TidCode,
                    PosId = p.PosId
                }).ToList() : []
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}
