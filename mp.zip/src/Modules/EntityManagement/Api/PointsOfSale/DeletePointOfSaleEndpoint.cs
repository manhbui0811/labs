using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Api.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PointsOfSale;

public class DeletePointsOfSaleRequest
{
    public Guid Id { get; set; }
}

public class DeletePointOfSaleEndpoint(IMediator mediator) : Endpoint<DeletePointsOfSaleRequest, Result>
{
    public override void Configure()
    {
        Tags("PointsOfSaleManagement");
        Post("points-of-sale/{id}/delete");
        Options(o => o.WithName("DeletePOS"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(DeletePointsOfSaleRequest req, CancellationToken ct)
    {
        var command = new SoftDeletePointOfSaleCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}

public class HardDeletePointsOfSaleEndpoint(IMediator mediator) : Endpoint<DeletePointsOfSaleRequest, Result>
{
    public override void Configure()
    {
        Tags("PointsOfSaleManagement");
        Delete("points-of-sale/{id}");
        Options(o => o.WithName("DeletePOSById"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(DeletePointsOfSaleRequest req, CancellationToken ct)
    {
        var command = new DeletePointOfSaleCommand{
            Id = req.Id
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}