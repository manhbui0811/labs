using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PointsOfSale;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PointsOfSale;

public class GetPointOfSaleRequest
{
    public Guid Id { get; set; }
}

public class GetPointsOfSaleRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
}

public class GetPointsOfSaleByBranchRequest
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = 20;

    public string? SearchText { get; set; } = string.Empty;
    public Guid BranchId { get; set; }
}

public class GetPointOfSaleEndpoint(IMediator mediator) : Endpoint<GetPointOfSaleRequest, Result<PointsOfSaleRepsoneDto>>
{
    public override void Configure()
    {
        Tags("PointsOfSaleManagement");
        Get("points-of-sale/{id}");
        Options(o => o.WithName("GetPOSById"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPointOfSaleRequest req, CancellationToken ct)
    {
        var query = new GetPointOfSaleQuery
        {
            Id = req.Id
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetPointsOfSaleEndpoint(IMediator mediator) : Endpoint<GetPointsOfSaleRequest, Result<PagedResult<PointsOfSaleRepsoneDto>>>
{
    public override void Configure()
    {
        Tags("PointsOfSaleManagement");
        Get("points-of-sale");
        Options(o => o.WithName("GetPOS"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPointsOfSaleRequest req, CancellationToken ct)
    {
        var query = new GetPointsOfSaleQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}

public class GetPointsOfSaleByBranchEndpoint(IMediator mediator) : Endpoint<GetPointsOfSaleByBranchRequest, Result<PagedResult<PointsOfSaleRepsoneDto>>>
{
    public override void Configure()
    {
        Get("points-of-sale/branch/{branchId}");
        Tags("PointsOfSaleManagement");
        Options(o => o.WithName("GetPOSByBranchId"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(GetPointsOfSaleByBranchRequest req, CancellationToken ct)
    {
        var query = new GetPointsOfSaleByBranchQuery
        {
            PageNumber = req.PageNumber,
            PageSize = req.PageSize,
            SearchText = req.SearchText,
            BranchId = req.BranchId
        };

        var result = await mediator.Send(query, ct);

        await Send.OkAsync(result, ct);
    }
}