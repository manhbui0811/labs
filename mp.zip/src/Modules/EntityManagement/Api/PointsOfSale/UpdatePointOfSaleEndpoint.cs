using FastEndpoints;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Api.PaymentChannel;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Api.PointsOfSale;

public class UpdatePointOfSaleRequest
{
    public Guid Id { get; set; }
    public string? PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; }
    public Guid? BranchId { get; set; }
    public ICollection<UpdatePaymentChannelRequest> PaymentChannels { get; set; } = [];
}
public class UpdatePointOfSaleEndpoint(IMediator mediator) : Endpoint<UpdatePointOfSaleRequest, Result>
{
    public override void Configure()
    {
        Put("points-of-sale");
        Tags("PointsOfSaleManagement");
        Options(o => o.WithName("UpdatePOS"));
        AuthSchemes(JwtBearerDefaults.AuthenticationScheme);
        Version(1);
    }

    public override async Task HandleAsync(UpdatePointOfSaleRequest req, CancellationToken ct)
    {
        var command = new UpdatePointOfSaleCommand{
            Name = req.Name,
            PosCode = req.PosCode,
            Description = req.Description,
            Status = req.Status,
            BranchId = req.BranchId,
            Id = req.Id,
            PaymentChannels = req.PaymentChannels.Select(p => new UpdatePaymentChannelCommand
            {
                ChannelType = p.ChannelType,
                ChannelName = p.ChannelName,
                TidCode = p.TidCode,
                PosId = p.PosId,
                MidCode = p.MidCode,
                Id = p.Id,
                PointOfSaleId = p.PointOfSaleId,
                MerchantProfileId = p.MerchantProfileId
            }).ToList()
        };

        var result = await mediator.Send(command, ct);

        await Send.OkAsync(result, ct);
    }
}