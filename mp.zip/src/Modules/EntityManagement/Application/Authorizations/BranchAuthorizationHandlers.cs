using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetBranchAuthorizationHandler(IBranchRepository branchRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetBranchQuery>
{

    public async Task<bool> AuthorizeAsync(GetBranchQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Logic kiểm tra quyền được đặt ở đây
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null)
        {
            return false;
        }
        
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetBranchesAuthorizationHandler(IPermissionRepository permissionRepository, ICurrentUser currentUser)
    : IAuthorizationHandler<GetBranchesQuery>
{

    public async Task<bool> AuthorizeAsync(GetBranchesQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await Task.FromResult(true);
    }
}

public class GetBranchesByEntityAuthorizationHandler(IPermissionRepository permissionRepository, ICurrentUser currentUser)
    : IAuthorizationHandler<GetBranchesByEntityQuery>
{

    public async Task<bool> AuthorizeAsync(GetBranchesByEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class UpdateBranchAuthorizationHandler(IBranchRepository branchRepository,ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateBranchCommand>
{

    public async Task<bool> AuthorizeAsync(UpdateBranchCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Logic kiểm tra quyền được đặt ở đây
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null)
        {
            return false;
        }
        
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class AddBranchAuthorizationHandler(IPermissionRepository permissionRepository, ICurrentUser currentUser)
    : IAuthorizationHandler<AddBranchCommand>
{

    public async Task<bool> AuthorizeAsync(AddBranchCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class DeleteBranchAuthorizationHandler(IBranchRepository branchRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeleteBranchCommand>
{

    public async Task<bool> AuthorizeAsync(DeleteBranchCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Logic kiểm tra quyền được đặt ở đây
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null)
        {
            return false;
        }
        
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class SoftDeleteBranchAuthorizationHandler(IBranchRepository branchRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<SoftDeleteBranchCommand>
{

    public async Task<bool> AuthorizeAsync(SoftDeleteBranchCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Logic kiểm tra quyền được đặt ở đây
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null)
        {
            return false;
        }
        
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}