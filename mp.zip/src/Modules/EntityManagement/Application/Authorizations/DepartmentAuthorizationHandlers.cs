// FileName: DepartmentAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Department;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetDepartmentAuthorizationHandler(IDepartmentRepository departmentRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetDepartmentQuery>
{
    public async Task<bool> AuthorizeAsync(GetDepartmentQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await departmentRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetDepartmentsByEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetDepartmentsByEntityQuery>
{
    public async Task<bool> AuthorizeAsync(GetDepartmentsByEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class AddDepartmentAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddDepartmentCommand>
{
    public async Task<bool> AuthorizeAsync(AddDepartmentCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class UpdateDepartmentAuthorizationHandler(IDepartmentRepository departmentRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateDepartmentCommand>
{
    public async Task<bool> AuthorizeAsync(UpdateDepartmentCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await departmentRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeleteDepartmentAuthorizationHandler(IDepartmentRepository departmentRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeleteDepartmentCommand>
{
    public async Task<bool> AuthorizeAsync(DeleteDepartmentCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await departmentRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}