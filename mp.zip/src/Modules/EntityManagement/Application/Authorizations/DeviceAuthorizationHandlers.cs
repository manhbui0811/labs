// FileName: PosDeviceAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Device;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetDeviceAuthorizationHandler(IDeviceRepository deviceRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetDeviceQuery>
{
    public async Task<bool> AuthorizeAsync(GetDeviceQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await deviceRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetDevicesByEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetDevicesByEntityQuery>
{
    public async Task<bool> AuthorizeAsync(GetDevicesByEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class AddDeviceAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddDeviceCommand>
{
    public async Task<bool> AuthorizeAsync(AddDeviceCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class UpdateDeviceAuthorizationHandler(IDeviceRepository deviceRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateDeviceCommand>
{
    public async Task<bool> AuthorizeAsync(UpdateDeviceCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await deviceRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeleteDeviceAuthorizationHandler(IDeviceRepository deviceRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeleteDeviceCommand>
{
    public async Task<bool> AuthorizeAsync(DeleteDeviceCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await deviceRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}