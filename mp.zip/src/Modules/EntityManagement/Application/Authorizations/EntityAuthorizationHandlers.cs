// FileName: EntityAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetEntityQuery>
{
    public async Task<bool> AuthorizeAsync(GetEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.Id);
    }
}

public class GetEntitiesByUserAuthorizationHandler(ICurrentUser currentUser)
    : IAuthorizationHandler<GetEntitiesByUserQuery>
{
    public Task<bool> AuthorizeAsync(GetEntitiesByUserQuery request)
    {
        // User always has permission to see their own entities
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return Task.FromResult(true);
        return Task.FromResult(request.UserId == currentUser.UserId);
    }
}

public class UpdateEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateEntityCommand>
{
    public async Task<bool> AuthorizeAsync(UpdateEntityCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var hasAccessToEntity = await permissionRepository.HasAccessToEntityAsync(request.Id);
        if (!hasAccessToEntity) return false;

        var parentIds = request.ParentEntities.Select(p => p.EntityId).ToList();
        var childIds = request.ChildEntities.Select(c => c.EntityId).ToList();
        
        foreach (var id in parentIds.Concat(childIds))
        {
            if (!await permissionRepository.HasAccessToEntityAsync(id)) return false;
        }

        return true;
    }
}

public class AddEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddEntityCommand>
{
     public async Task<bool> AuthorizeAsync(AddEntityCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        
        var parentIds = request.ParentEntities.Select(p => p.EntityId).ToList();
        var childIds = request.ChildEntities.Select(c => c.EntityId).ToList();
        
        foreach (var id in parentIds.Concat(childIds))
        {
            if (!await permissionRepository.HasAccessToEntityAsync(id)) return false;
        }

        return true;
    }
}