using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.IotDevice;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

// public class GetIotDeviceAuthorizationHandler(IIotDeviceRepository iotDeviceRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
//     : IAuthorizationHandler<GetIotDeviceQuery>
// {
//
//     public async Task<bool> AuthorizeAsync(GetIotDeviceQuery request)
//     {
//         if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
//         return false;
//     }
// }