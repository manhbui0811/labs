// FileName: JobTitleAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetJobTitleAuthorizationHandler(IJobTitleRepository jobTitleRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetJobTitleQuery>
{
    public async Task<bool> AuthorizeAsync(GetJobTitleQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await jobTitleRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetJobTitlesByEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetJobTitlesByEntityQuery>
{
    public async Task<bool> AuthorizeAsync(GetJobTitlesByEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class AddJobTitleAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddJobTitleCommand>
{
    public async Task<bool> AuthorizeAsync(AddJobTitleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class UpdateJobTitleAuthorizationHandler(IJobTitleRepository jobTitleRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateJobTitleCommand>
{
    public async Task<bool> AuthorizeAsync(UpdateJobTitleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await jobTitleRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeleteJobTitleAuthorizationHandler(IJobTitleRepository jobTitleRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeleteJobTitleCommand>
{
    public async Task<bool> AuthorizeAsync(DeleteJobTitleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await jobTitleRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}