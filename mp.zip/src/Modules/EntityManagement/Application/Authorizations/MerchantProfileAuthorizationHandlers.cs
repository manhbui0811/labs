// FileName: MerchantProfileAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.MerchantProfile;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.MerchantProfile;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetMerchantProfileAuthorizationHandler(IMerchantProfileRepository profileRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetMerchantProfileQuery>
{
    public async Task<bool> AuthorizeAsync(GetMerchantProfileQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await profileRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetMerchantProfilesByUserAuthorizationHandler(ICurrentUser currentUser, IMerchantProfileRepository merchantProfileRepository, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetMerchantProfilesByUserQuery>
{
    public async Task<bool> AuthorizeAsync(GetMerchantProfilesByUserQuery request)
    {
        return true;
    }
}

public class GetMerchantProfilesByEntityAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetMerchantProfilesByEntityQuery>
{
    public async Task<bool> AuthorizeAsync(GetMerchantProfilesByEntityQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class AddMerchantProfileAuthorizationHandler(ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddMerchantProfileCommand>
{
    public async Task<bool> AuthorizeAsync(AddMerchantProfileCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        return await permissionRepository.HasAccessToEntityAsync(request.EntityId);
    }
}

public class UpdateMerchantProfileAuthorizationHandler(IMerchantProfileRepository profileRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdateMerchantProfileCommand>
{
    public async Task<bool> AuthorizeAsync(UpdateMerchantProfileCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await profileRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeleteMerchantProfileAuthorizationHandler(IMerchantProfileRepository profileRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeleteMerchantProfileCommand>
{
    public async Task<bool> AuthorizeAsync(DeleteMerchantProfileCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await profileRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}