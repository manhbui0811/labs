// FileName: PaymentChannelAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PaymentChannel;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetPaymentChannelAuthorizationHandler(IPaymentChannelRepository channelRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetPaymentChannelQuery>
{
    public async Task<bool> AuthorizeAsync(GetPaymentChannelQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await channelRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class AddPaymentChannelAuthorizationHandler(IPointOfSaleRepository posRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddPaymentChannelCommand>
{
    public async Task<bool> AuthorizeAsync(AddPaymentChannelCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Kiểm tra quyền trên PointOfSale cha
        var owningEntityId = await posRepository.GetOwningEntityIdAsync(request.PointOfSaleId);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class UpdatePaymentChannelAuthorizationHandler(IPaymentChannelRepository channelRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdatePaymentChannelCommand>
{
    public async Task<bool> AuthorizeAsync(UpdatePaymentChannelCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await channelRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeletePaymentChannelAuthorizationHandler(IPaymentChannelRepository channelRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeletePaymentChannelCommand>
{
    public async Task<bool> AuthorizeAsync(DeletePaymentChannelCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await channelRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}