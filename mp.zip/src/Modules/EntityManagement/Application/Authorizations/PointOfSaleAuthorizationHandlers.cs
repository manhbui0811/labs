// FileName: PointOfSaleAuthorizationHandlers.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PointsOfSale;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Authorizations;

public class GetPointOfSaleAuthorizationHandler(IPointOfSaleRepository posRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetPointOfSaleQuery>
{
    public async Task<bool> AuthorizeAsync(GetPointOfSaleQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await posRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class GetPointOfSalesByBranchAuthorizationHandler(IBranchRepository branchRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<GetPointsOfSaleByBranchQuery>
{
    public async Task<bool> AuthorizeAsync(GetPointsOfSaleByBranchQuery request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.BranchId);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class AddPointOfSaleAuthorizationHandler(IBranchRepository branchRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<AddPointOfSaleCommand>
{
    public async Task<bool> AuthorizeAsync(AddPointOfSaleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        // Kiểm tra quyền trên Branch cha
        var owningEntityId = await branchRepository.GetOwningEntityIdAsync(request.BranchId);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class UpdatePointOfSaleAuthorizationHandler(IPointOfSaleRepository posRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<UpdatePointOfSaleCommand>
{
    public async Task<bool> AuthorizeAsync(UpdatePointOfSaleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await posRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}

public class DeletePointOfSaleAuthorizationHandler(IPointOfSaleRepository posRepository, ICurrentUser currentUser, IPermissionRepository permissionRepository)
    : IAuthorizationHandler<DeletePointOfSaleCommand>
{
    public async Task<bool> AuthorizeAsync(DeletePointOfSaleCommand request)
    {
        if ((bool)currentUser.KeycloakSubject?.Equals("system_admin")) return true;
        var owningEntityId = await posRepository.GetOwningEntityIdAsync(request.Id);
        if (owningEntityId is null) return false;
        return await permissionRepository.HasAccessToEntityAsync(owningEntityId.Value);
    }
}