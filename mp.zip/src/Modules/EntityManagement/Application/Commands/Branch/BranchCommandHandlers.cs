using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

public class AddBranchCommandHandler(
    ILogger<CommandHandlerBase<AddBranchCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository,
    IBranchRepository branchRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<AddBranchCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddBranchCommand request, CancellationToken cancellationToken)
    {
        var getEntityResult  = await entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
        if (getEntityResult == null)
        {
            return Result.Failure<Guid>(new Error("404", "Entity not found"));
        }
        
        var newBranch = new Domain.Entities.Branch
        {
            Name = request.Name,
            BranchCode = string.IsNullOrEmpty(request.BranchCode)?CodeGenerator.GenerateRandomNumericCode(): request.BranchCode,
            CreatedBy = CurrentUser.UserId.ToString(),
            AddressLine1 = request.AddressLine1,
            AddressLine2 = request.AddressLine2,
            EntityId = request.EntityId,
            Phone = request.Phone,
            ProvinceCode = request.ProvinceCode,
            WardCode = request.WardCode,
            Entity = getEntityResult
        };

        if (request.ParentBranchId.HasValue)
        {
            var parentBranch= await branchRepository.GetByIdAsync(request.ParentBranchId.Value, cancellationToken);
            if (parentBranch== null)
            {
                return Result.Failure<Guid>(new Error("404", "Parent branch not found"));
            }

            newBranch.ParentBranch = parentBranch;
        }
        
        
        await branchRepository.AddAsync(newBranch, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newBranch.Id);
    }
}

public class UpdateBranchCommandHandler(
    ILogger<CommandHandlerBase<UpdateBranchCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository,
    IBranchRepository branchRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<UpdateBranchCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateBranchCommand request, CancellationToken cancellationToken)
    {
        
        var currentBranch = await branchRepository.GetByIdAsync(request.Id, cancellationToken);

        if (currentBranch == null)
        {
            return Result.Failure<Guid>(new Error("404", "Branch not found"));
        }

        if (request.EntityId.HasValue)
        {
            var getEntityResult  = await entityRepository.GetByIdAsync(request.EntityId.Value, cancellationToken);
            
            if (getEntityResult == null)
            {
                return Result.Failure<Guid>(new Error("404", "Entity not found"));
            }
            currentBranch.Entity = getEntityResult;
            currentBranch.EntityId = request.EntityId.Value;
        }
        
        currentBranch.Name = request.Name;
        currentBranch.BranchCode = string.IsNullOrEmpty(request.BranchCode)?currentBranch.BranchCode:request.BranchCode;
        currentBranch.CreatedBy = CurrentUser.UserId.ToString();
        currentBranch.AddressLine1 = request.AddressLine1;
        currentBranch.AddressLine2 = request.AddressLine2;
        currentBranch.Phone = request.Phone;
        currentBranch.ProvinceCode = request.ProvinceCode;
        currentBranch.WardCode = request.WardCode;

        await branchRepository.UpdateAsync(currentBranch, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteBranchCommandHandler(
    ILogger<CommandHandlerBase<DeleteBranchCommand, Result>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteBranchCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteBranchCommand request, CancellationToken cancellationToken)
    {
        var currentBranchResult  = await branchRepository.Get(request.Id, cancellationToken);
        if (currentBranchResult.IsFailure || currentBranchResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Branch not found"));
        }
        
        var currentBranch = currentBranchResult.Payload;

        if (currentBranch.ChildBranches.Count != 0)
        {
            return Result.Failure(new Error("400", "This branch cannot be deleted, it's containing many other branches!"));
        }
        
        var targetBranch = await branchRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await branchRepository.HardDeleteAsync(targetBranch, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteBranchCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteBranchCommand, Result>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteBranchCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteBranchCommand request, CancellationToken cancellationToken)
    {
        var currentBranchResult  = await branchRepository.Get(request.Id, cancellationToken);
        if (currentBranchResult.IsFailure || currentBranchResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Branch not found"));
        }
        
        var currentBranch = currentBranchResult.Payload;

        if (currentBranch.ChildBranches.Count != 0)
        {
            return Result.Failure(new Error("400", "This branch cannot be deleted, it's containing many other branches!"));
        }
        
        var targetBranch = await branchRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await branchRepository.DeleteAsync(targetBranch, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}