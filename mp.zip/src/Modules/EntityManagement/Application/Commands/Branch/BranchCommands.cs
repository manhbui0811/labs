using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Branch;

public class AddBranchCommand : ITransactionalCommand<Result<Guid>>, IAuthorizableRequest
{
    public Guid? ParentBranchId { get; set; }
    public string? BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public Guid EntityId { get; set; }
    public Guid? CreatedBy { get; set; }
}

public class UpdateBranchCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public Guid Id { get; set; }
    public Guid? EntityId { get; set; }
    public Guid? ParentBranchId { get; set; }
    public string? BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public Guid? CreatedBy { get; set; }
}

public class DeleteBranchCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class SoftDeleteBranchCommand : DeleteBranchCommand
{
    
}