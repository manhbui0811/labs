using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;

public class AddDepartmentCommandHandler(
    ILogger<CommandHandlerBase<AddDepartmentCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IDepartmentRepository departmentRepository,
    IEntityRepository entityRepository) : CommandHandlerBase<AddDepartmentCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddDepartmentCommand request, CancellationToken cancellationToken)
    {
        var targetEntity = await entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
        if (targetEntity == null)
        {
            return Result.Failure<Guid>(new  Error("404", "Entity not found"));
        }

        var newDepartment = new Domain.Entities.Department
        {
            Name = request.Name,
            Description = request.Description,
            CreatedBy = currentUser.UserId.ToString(),
            DepartmentCode = request.DepartmentCode,
            Entity = targetEntity,
            EntityId = targetEntity.Id,
            ParentDepartmentId = request.ParentDepartmentId
        };

        if (request.ParentDepartmentId.HasValue)
        {
            var parentDepartment = await departmentRepository.GetByIdAsync(request.ParentDepartmentId.Value, cancellationToken);
            if (parentDepartment == null)
            {
                return Result.Failure<Guid>(new Error("404", "Parent Department not found!"));
            }

            if (parentDepartment.EntityId == Guid.Empty || parentDepartment.EntityId != request.EntityId)
            {
                return Result.Failure<Guid>(new Error("404", "Parent Department is invalid!"));
            }

            newDepartment.ParentDepartment = parentDepartment;
        }
        
        await departmentRepository.AddAsync(newDepartment, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newDepartment.Id);
    }
}

public class UpdateDepartmentCommandHandler(
    ILogger<CommandHandlerBase<UpdateDepartmentCommand, Result>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<UpdateDepartmentCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateDepartmentCommand request, CancellationToken cancellationToken)
    {
        var currentDepartment = await departmentRepository.GetByIdAsync(request.Id, cancellationToken);

        if (currentDepartment == null)
        {
            return Result.Failure<Guid>(new Error("404", "Department not found"));
        }

        if (request.ParentDepartmentId.HasValue)
        {
            var parentDepartment = await departmentRepository.GetByIdAsync(request.ParentDepartmentId.Value, cancellationToken);
            if (parentDepartment == null)
            {
                return Result.Failure<Guid>(new Error("404", "Parent department not found!"));
            }

            if (parentDepartment.EntityId == Guid.Empty || parentDepartment.EntityId != request.EntityId)
            {
                return Result.Failure<Guid>(new Error("404", "Parent department is invalid!"));
            }

            currentDepartment.ParentDepartment = parentDepartment;
        }
        
        currentDepartment.Name = request.Name;
        currentDepartment.Description = request.Description;
        currentDepartment.UpdatedBy = CurrentUser.UserId.ToString();
        currentDepartment.DepartmentCode = request.DepartmentCode;

        await departmentRepository.UpdateAsync(currentDepartment, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteDepartmentCommandHandler(
    ILogger<CommandHandlerBase<DeleteDepartmentCommand, Result>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteDepartmentCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
    {
        var currentDepartmentResult  = await departmentRepository.Get(request.Id, cancellationToken);
        if (currentDepartmentResult.IsFailure || currentDepartmentResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Department not found"));
        }
        
        var currentDepartment = currentDepartmentResult.Payload;

        if (currentDepartment.ChildDepartments.Count != 0 )
        {
            return Result.Failure(new Error("400", "This department cannot be deleted!"));
        }
        
        var targetEntity = await departmentRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await departmentRepository.HardDeleteAsync(targetEntity, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteDepartmentCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteDepartmentCommand, Result>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteDepartmentCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteDepartmentCommand request, CancellationToken cancellationToken)
    {
        var currentDepartmentResult  = await departmentRepository.Get(request.Id, cancellationToken);
        if (currentDepartmentResult.IsFailure || currentDepartmentResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Department not found"));
        }
        
        var currentDepartment = currentDepartmentResult.Payload;

        if (currentDepartment.ChildDepartments.Count != 0 )
        {
            return Result.Failure(new Error("400", "This department cannot be deleted!"));
        }
        
        var targetEntity = await departmentRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await departmentRepository.DeleteAsync(targetEntity, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}