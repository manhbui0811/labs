using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Department;

public class AddDepartmentCommand : ITransactionalCommand<Result<Guid>>, IAuthorizableRequest
{
    public Guid EntityId { get; set; }
    public Guid? ParentDepartmentId { get; set; }
    public required string DepartmentCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
}

public class UpdateDepartmentCommand : AddDepartmentCommand, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class DeleteDepartmentCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class SoftDeleteDepartmentCommand : DeleteDepartmentCommand
{
    
}