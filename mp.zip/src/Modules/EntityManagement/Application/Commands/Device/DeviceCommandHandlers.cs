using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;

public class AddDeviceCommandHandler(
    ILogger<CommandHandlerBase<AddDeviceCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IDeviceRepository deviceRepository,
    IEntityRepository entityRepository,
    IPaymentChannelRepository paymentChannelRepository
    ) : CommandHandlerBase<AddDeviceCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddDeviceCommand request, CancellationToken cancellationToken)
    {
        var entity = await entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
        if (entity == null)
        {
            return Result.Failure<Guid>(new Error("404","Entity not found"));
        }
        
        var newDevice = new Domain.Entities.Device
        {
            DeviceType = request.DeviceType,
            SerialNumber = request.SerialNumber,
            Status = request.Status,
            Entity = entity,
            AppVersion = request.AppVersion,
            DeviceModel = request.DeviceModel,
            DeviceName = request.DeviceName,
            NetworkType = request.NetworkType,
            LocationUpdatedAt = request.LocationUpdatedAt,
            Provider = request.Provider,
            BatteryLevel = request.BatteryLevel,
            CurrentLatitude = request.CurrentLatitude,
            CurrentLongitude = request.CurrentLongitude,
            FcmToken = request.FcmToken,
            LastSeen = request.LastSeen
        };
        
        if (request.PaymentChannelId.HasValue && request.PaymentChannelId != Guid.Empty)
        {
            var channel = await paymentChannelRepository.GetByIdAsync(request.PaymentChannelId.Value, cancellationToken);
            if (channel == null)
            {
                return Result.Failure<Guid>(new Error("404","Payment channel not found"));
            }
            newDevice.PaymentChannel = channel;
        }
        
        await deviceRepository.AddAsync(newDevice, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newDevice.Id);
    }
}

public class UpdateDeviceCommandHandler(
    ILogger<CommandHandlerBase<UpdateDeviceCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IDeviceRepository deviceRepository,
    IEntityRepository entityRepository,
    IPaymentChannelRepository paymentChannelRepository
) : CommandHandlerBase<UpdateDeviceCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateDeviceCommand request, CancellationToken cancellationToken)
    {
        var currentDevice = await deviceRepository.GetByIdAsync(request.Id, cancellationToken);
        if (currentDevice == null)
        {
            return Result.Failure<Guid>(new Error("404","Device not found"));
        }

        currentDevice.DeviceType = request.DeviceType;
        currentDevice.SerialNumber = request.SerialNumber;
        currentDevice.Status = request.Status;
        currentDevice.AppVersion = request.AppVersion;
        currentDevice.DeviceModel = request.DeviceModel;
        currentDevice.DeviceName = request.DeviceName;
        currentDevice.NetworkType = request.NetworkType;
        currentDevice.LocationUpdatedAt = request.LocationUpdatedAt;
        currentDevice.Provider = request.Provider;
        currentDevice.BatteryLevel = request.BatteryLevel;
        currentDevice.CurrentLatitude = request.CurrentLatitude;
        currentDevice.CurrentLongitude = request.CurrentLongitude;
        currentDevice.FcmToken = request.FcmToken;
        currentDevice.LastSeen = request.LastSeen;
        
        if (request.EntityId.HasValue && request.EntityId != Guid.Empty)
        {
            var entity = await entityRepository.GetByIdAsync(request.EntityId.Value, cancellationToken);
            if (entity == null)
            {
                return Result.Failure<Guid>(new Error("404","Entity not found"));
            }

            currentDevice.Entity = entity;
        }

        if (request.PaymentChannelId.HasValue && request.PaymentChannelId != Guid.Empty)
        {
            var channel = await paymentChannelRepository.GetByIdAsync(request.PaymentChannelId.Value, cancellationToken);
            if (channel == null)
            {
                return Result.Failure<Guid>(new Error("404","Payment channel not found"));
            }
            currentDevice.PaymentChannel = channel;
        }
        
        await deviceRepository.UpdateAsync(currentDevice, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteDeviceCommandHandler(
    ILogger<CommandHandlerBase<DeleteDeviceCommand, Result>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteDeviceCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteDeviceCommand request, CancellationToken cancellationToken)
    {
        var targetDevice = await deviceRepository.GetByIdAsync(request.Id, cancellationToken);
        if (targetDevice == null)
        {
            return Result.Failure(new Error("404", "Device not found"));
        }
        await deviceRepository.HardDeleteAsync(targetDevice, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteDeviceCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteDeviceCommand, Result>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteDeviceCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteDeviceCommand request, CancellationToken cancellationToken)
    {
        var targetDevice = await deviceRepository.GetByIdAsync(request.Id, cancellationToken);
        if (targetDevice == null)
        {
            return Result.Failure(new Error("404", "Device not found"));
        }
        await deviceRepository.HardDeleteAsync(targetDevice, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}