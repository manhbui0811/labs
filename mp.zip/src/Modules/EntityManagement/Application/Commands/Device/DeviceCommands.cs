using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Device;

public class AddDeviceCommand : ITransactionalCommand<Result<Guid>>
{
    public required string SerialNumber { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public required string DeviceType { get; set; }
    public string? FcmToken { get; set; }
    public PosStatus Status { get; set; }
    public int? BatteryLevel { get; set; }
    public string? AppVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTime? LastSeen { get; set; }
    public double? CurrentLatitude { get; set; }
    public double? CurrentLongitude { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }
    public string Provider { get; set; }
    public Guid EntityId { get; set; }
    public Guid? PaymentChannelId { get; set; }
}

public class UpdateDeviceCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public Guid? EntityId { get; set; }
    public Guid? PaymentChannelId { get; set; }
    public required string SerialNumber { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public string DeviceType { get; set; }
    public string? FcmToken { get; set; }
    public PosStatus Status { get; set; }
    public int? BatteryLevel { get; set; }
    public string? AppVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTime? LastSeen { get; set; }
    public double? CurrentLatitude { get; set; }
    public double? CurrentLongitude { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }
    public string Provider { get; set; }
}

public class DeleteDeviceCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeleteDeviceCommand : DeleteDeviceCommand
{
    
}