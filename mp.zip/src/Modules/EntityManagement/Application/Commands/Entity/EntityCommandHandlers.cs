using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;

public class AddEntityCommandHandler(
    ILogger<CommandHandlerBase<AddEntityCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork, 
    IEntityRepository  entityRepository,
    IEntityStructureRepository entityStructureRepository,
    IEntityClosureRepository entityClosureRepository,
    IUserEntityMembershipRepository membershipRepository) : CommandHandlerBase<AddEntityCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddEntityCommand request, CancellationToken cancellationToken)
    {
        if (request.ParentEntities.Count > 0 && request.ChildEntities.Count > 0)
        {
            var areEntitiesInSameChainAsync = await AreEntitiesInSameChainAsync(
                request.ParentEntities.Select(p => p.EntityId).ToList(), 
                request.ChildEntities.Select(c => c.EntityId).ToList());
            if (!areEntitiesInSameChainAsync)
            {
                return Result.Failure<Guid>(new Error("01", "One of related agencies is invalid!"));
            }
        }
        
        var newEntity = new Domain.Entities.Entity(Guid.NewGuid())
        {
            Name = request.Name,
            EntityCode = string.IsNullOrEmpty(request.EntityCode)?CodeGenerator.GenerateRandomNumericCode():request.EntityCode,
            ShortName = request.ShortName,
            Email = request.Email,
            AddressLine1 = request.AddressLine1,
            AddressLine2 = request.AddressLine2,
            BusinessCategoryId = request.BusinessCategoryId,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.CreatedBy.ToString(),
            Phone = request.Phone,
            ProvinceCode = request.ProvinceCode,
            TaxCode = request.TaxCode,
            WardCode = request.WardCode,
            Website = request.Website,
            ParentRelationships = [],
            ChildRelationships = []
        };
        
        if (request.EntityStructureId.HasValue && request.EntityStructureId != Guid.Empty)
        {
            var entityStructure = await entityStructureRepository.GetByIdAsync(request.EntityStructureId.Value, cancellationToken);
            if (entityStructure == null)
            {
                return Result.Failure<Guid>(new Error("01", "EntityStructure not found!"));
            }
            newEntity.EntityStructure = entityStructure;
        }
        
        var newMembership = new UserEntityMembership
        {
            CreatedBy = currentUser.UserId.ToString(),
            EntityId = newEntity.Id,
            UserId = currentUser.UserId??Guid.Empty,
            Entity = newEntity
        };
 
        await membershipRepository.AddAsync(newMembership, cancellationToken);
        
        if (request.ParentEntities.Count != 0)
        {
            foreach(var parent in request.ParentEntities)
            {
                var currentParent = await entityRepository.GetByIdAsync(parent.EntityId, cancellationToken);
                if (currentParent == null) return Result.Failure<Guid>(new Error("01", "One of parent agency is invalid!"));
                var entityRelationship = new EntityRelationship()
                {
                    CreatedBy = request.CreatedBy.ToString(),
                    ChildEntity = newEntity,
                    ChildEntityId = newEntity.Id,
                    ParentEntity = currentParent,
                    ParentEntityId = currentParent.Id,
                    StartDate = DateTime.UtcNow,
                    RelationshipType = parent.RelationshipType,
                    RelationshipDetails = parent.RelationshipDetails,
                    Status = parent.Status
                };
                await entityRepository.AddRelationshipAsync(entityRelationship, cancellationToken);
            }
        }

        if (request.ChildEntities.Count != 0)
        {
            foreach(var child in request.ChildEntities)
            {
                var currentChild = await entityRepository.GetByIdAsync(child.EntityId, cancellationToken);
                if (currentChild == null) return Result.Failure<Guid>(new Error("01", "One of child agency is invalid!"));
                var entityRelationship = new EntityRelationship()
                {
                    CreatedBy = request.CreatedBy.ToString(),
                    ChildEntity = currentChild,
                    ChildEntityId = currentChild.Id,
                    ParentEntity = newEntity,
                    ParentEntityId = newEntity.Id,
                    StartDate = DateTime.UtcNow,
                    RelationshipType = child.RelationshipType,
                    RelationshipDetails = child.RelationshipDetails,
                    Status = child.Status
                };
                await entityRepository.AddRelationshipAsync(entityRelationship, cancellationToken);
            }
        }
        
        await entityRepository.AddAsync(newEntity, cancellationToken);
        await entityClosureRepository.CreateSelfReferenceAsync(newEntity.Id, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        
        foreach (var parent in request.ParentEntities)
        {
            // Lệnh này dùng Raw SQL nên sẽ được thực thi ngay
            await entityClosureRepository.LinkParentToChildAsync(parent.EntityId, newEntity.Id);
        }
        foreach (var child in request.ChildEntities)
        {
            // Lệnh này dùng Raw SQL nên sẽ được thực thi ngay
            await entityClosureRepository.LinkParentToChildAsync(newEntity.Id, child.EntityId);
        }
        
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newEntity.Id);
    }
    
    /// <summary>
    /// Hàm helper nội bộ để kiểm tra các entity có cùng thuộc một chuỗi hay không, đây là đoạn logic phức tạp, tránh sửa vì nếu logic check sai, có thể gây ra sai sót khi thêm các entity
    /// </summary>
    private async Task<bool> AreEntitiesInSameChainAsync(List<Guid> parentIds, List<Guid> childIds)
    {
        // đưa vào 1 list duy nhất
        var allEntityIds = parentIds.Concat(childIds).Distinct().ToList();

        if (allEntityIds.Count <= 1)
        {
            return true;
        }

        // tạo hashset để chứa Id của cụ tổ của các entity
        var rootIds = new HashSet<Guid>();

        foreach (var entityId in allEntityIds)
        {
            // lấy ra cụ tổ
            var root = await entityRepository.GetRootAncestorIdAsync(entityId);

            if (!root.IsSuccess || root.Payload == Guid.Empty) return false;
            
            rootIds.Add(root.Payload);
        }

        // nếu tất cả các entity trong danh sách cha con của entity thêm mới mà có cùng cụ tổ thì chứng tỏ chúng cùng 1 chuối
        return rootIds.Count == 1;
    }
}

public class AddUserEntityCommandHandler(
    ILogger<CommandHandlerBase<AddUserEntityCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork, 
    IEntityRepository  entityRepository,
    IUserEntityMembershipRepository membershipRepository) : CommandHandlerBase<AddUserEntityCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(AddUserEntityCommand request, CancellationToken cancellationToken)
    {
        // hàm này xử lý logic phức tạp, khi thêm 1 user vào 1 entity, sẽ cần kiểm tra cụ thể user đó đã thuộc entity nào chưa,
        // nếu đã thuộc entity khác chuỗi với entity mục tiêu thì sẽ không cho phép thêm
        foreach (var relation in request.Relations)
        {
            // xác định entity cụ tổ trong chuỗi của entity đích
            var targetChainRootIdResult = await entityRepository.GetRootAncestorIdAsync(relation.EntityId);
            if (!targetChainRootIdResult.IsSuccess)
            {
                return Result.Failure(new Error("400", $"An error occured when checking relationship."));
            }
            
            // lấy ra tất cả các entity mà user được gắn
            var existingMembershipsResult = await membershipRepository.GetByUserIdAsync(relation.UserId, cancellationToken);
            if (!existingMembershipsResult.IsSuccess)
            {
                return Result.Failure(new Error("400", $"An error occured when checking relationship."));
            }
            
            // nếu user này đã được gắn với các entity khác, thực hiện kiểm tra ADN
            if (existingMembershipsResult.Payload != null && existingMembershipsResult.Payload.Count != 0)
            {
                // Chỉ cần lấy chuỗi của membership đầu tiên, vì tất cả phải cùng một chuỗi
                var userCurrentEntityId = existingMembershipsResult.Payload.First().EntityId;
                
                // tìm ra cụ tổ của các entity àm user này đã được gắn
                var userCurrentChainRootIdResult = await entityRepository.GetRootAncestorIdAsync(userCurrentEntityId);

                // nếu không có cùng cụ tổ -> không hợp lệ
                if (targetChainRootIdResult.Payload != userCurrentChainRootIdResult.Payload)
                {
                    return Result.Failure(new Error("400", 
                        $"User {relation.UserId} cannot be added to Entity {relation.EntityId}, cause it belonged to another series."));
                }
            }
            
            // Kiểm tra xem user đã là thành viên của entity đích này chưa
            var isUserBelongToEntityResult =
                await membershipRepository.ExistsAsync(relation.UserId, relation.EntityId, cancellationToken);

            if (!isUserBelongToEntityResult.IsSuccess)
            {
                return Result.Failure(new Error("400", $"An error occured when checking relationship."));
            }
            
            // reject nếu user đã thuộc về entity này rồi
            if (isUserBelongToEntityResult.Payload)
            {
                return Result.Failure(new Error("400", 
                    $"User {relation.UserId} already be added to Entity {relation.EntityId}."));
            }

            var newMembership = new UserEntityMembership
            {
                CreatedBy = CurrentUser.UserId.ToString(),
                EntityId = relation.EntityId,
                UserId = relation.UserId,
                DepartmentId = relation.DepartmentId,
                JobTitle = relation.JobTitle,
            };
            
            // Thêm các vai trò
            newMembership.Roles = relation.Roles.Select(r => new UserEntityMembershipRole
            {
                RoleId = r.RoleId,
                RoleType = r.RoleType,
                GrantedBy = CurrentUser.UserId,
                MembershipId = newMembership.Id,
                Membership = newMembership
            }).ToList();
            
            await membershipRepository.AddAsync(newMembership, cancellationToken);
        }

        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        
        return Result.Success();
    }
}

public class UpdateEntityCommandHandler(
    ILogger<CommandHandlerBase<UpdateEntityCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityRepository entityRepository,
    IEntityStructureRepository entityStructureRepository,
    IEntityClosureRepository entityClosureRepository) : CommandHandlerBase<UpdateEntityCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateEntityCommand request, CancellationToken cancellationToken)
    {
        // 1. Lấy entity hiện tại từ DB, bao gồm cả các mối quan-hệ
        var currentEntity = await entityRepository.GetByIdAsync(request.Id, cancellationToken);
        if (currentEntity == null)
        {
            return Result.Failure(new Error("404", "Entity not existed."));
        }
        
        if (request.EntityStructureId.HasValue && request.EntityStructureId != Guid.Empty)
        {
            var entityStructure = await entityStructureRepository.GetByIdAsync(request.EntityStructureId.Value, cancellationToken);
            if (entityStructure == null)
            {
                return Result.Failure<Guid>(new Error("01", "EntityStructure not found!"));
            }
            currentEntity.EntityStructure = entityStructure;
        }
        
        currentEntity.Name = request.Name;
        currentEntity.EntityCode = string.IsNullOrEmpty(request.EntityCode)?currentEntity.EntityCode : request.EntityCode;
        currentEntity.ShortName = request.ShortName;
        currentEntity.Email = request.Email;
        currentEntity.AddressLine1 = request.AddressLine1;
        currentEntity.AddressLine2 = request.AddressLine2;
        currentEntity.BusinessCategoryId = request.BusinessCategoryId;
        currentEntity.UpdatedAt = DateTime.UtcNow;
        currentEntity.UpdatedBy = CurrentUser.UserId.ToString();
        currentEntity.Phone = request.Phone;
        currentEntity.ProvinceCode = request.ProvinceCode;
        currentEntity.TaxCode = request.TaxCode;
        currentEntity.WardCode = request.WardCode;
        currentEntity.Website = request.Website;
        
        // Kiểm tra logic "cùng dòng dõi" cho các mối quan-hệ MỚI
        var newParentIds = request.ParentEntities.Select(p => p.EntityId).ToList();
        var newChildIds = request.ChildEntities.Select(c => c.EntityId).ToList();
        if (newParentIds.Count != 0 && newChildIds.Count != 0 && !await AreEntitiesInSameChainAsync(newParentIds, newChildIds))
        {
            return Result.Failure(new Error("400", "Không thể cập nhật quan hệ với các đại lý khác chuỗi."));
        }
        
        // --- Xử lý quan hệ Cha ---
        var currentParentIds = currentEntity.ParentRelationships.Select(r => r.ParentEntityId).ToList();
        var newParentIdsFromRequest = request.ParentEntities.Select(p => p.EntityId).ToList();
        
        var parentsToAdd = newParentIdsFromRequest.Except(currentParentIds).ToList();
        var parentsToRemove = currentParentIds.Except(newParentIdsFromRequest).ToList();

        foreach (var parentId in parentsToRemove)
        {
            await entityClosureRepository.UnlinkParentFromChildAsync(parentId, currentEntity.Id, cancellationToken);
        }
        foreach (var parentDto in request.ParentEntities.Where(p => parentsToAdd.Contains(p.EntityId)))
        {
            var getParentResult = await entityRepository.GetByIdAsync(parentDto.EntityId, cancellationToken);
            if (getParentResult == null)
            {
                return  Result.Failure(new Error("404", "Entity not existed."));
            }
            var entityRelationship = new EntityRelationship()
            {
                CreatedBy = CurrentUser.UserId.ToString(),
                ChildEntity = currentEntity,
                ChildEntityId = currentEntity.Id,
                ParentEntity = getParentResult,
                ParentEntityId = parentDto.EntityId,
                StartDate = DateTime.UtcNow,
                RelationshipType = parentDto.RelationshipType,
                RelationshipDetails = parentDto.RelationshipDetails,
                Status = parentDto.Status
            };
            await entityRepository.AddRelationshipAsync(entityRelationship, cancellationToken);
            await entityClosureRepository.LinkParentToChildAsync(parentDto.EntityId, currentEntity.Id);
        }

        // --- Xử lý quan hệ Con ---
        var currentChildIds = currentEntity.ChildRelationships.Select(r => r.ChildEntityId).ToList();
        var newChildIdsFromRequest = request.ChildEntities.Select(c => c.EntityId).ToList();

        var childrenToAdd = newChildIdsFromRequest.Except(currentChildIds).ToList();
        var childrenToRemove = currentChildIds.Except(newChildIdsFromRequest).ToList();
        
        foreach (var childId in childrenToRemove)
        {
            await entityClosureRepository.UnlinkParentFromChildAsync(currentEntity.Id, childId, cancellationToken);
        }
        foreach (var childDto in request.ChildEntities.Where(c => childrenToAdd.Contains(c.EntityId)))
        {
            var getChildResult = await entityRepository.GetByIdAsync(childDto.EntityId, cancellationToken);
            if (getChildResult == null)
            {
                return  Result.Failure(new Error("404", "Entity not existed."));
            }
            var entityRelationship = new EntityRelationship()
            {
                CreatedBy = CurrentUser.UserId.ToString(),
                ChildEntity = getChildResult,
                ChildEntityId = getChildResult.Id,
                ParentEntity = currentEntity,
                ParentEntityId = currentEntity.Id,
                StartDate = DateTime.UtcNow,
                RelationshipType = childDto.RelationshipType,
                RelationshipDetails = childDto.RelationshipDetails,
                Status = childDto.Status
            };
            await entityRepository.AddRelationshipAsync(entityRelationship, cancellationToken);
            await entityClosureRepository.LinkParentToChildAsync(currentEntity.Id, childDto.EntityId);
        }
        
        await entityRepository.UpdateAsync(currentEntity, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
    
    /// <summary>
    /// Hàm helper nội bộ để kiểm tra các entity có cùng thuộc một chuỗi hay không, đây là đoạn logic phức tạp,
    /// tránh sửa vì nếu logic check sai, có thể gây ra sai sót khi thêm các entity
    /// </summary>
    private async Task<bool> AreEntitiesInSameChainAsync(List<Guid> parentIds, List<Guid> childIds)
    {
        // đưa vào 1 list duy nhất
        var allEntityIds = parentIds.Concat(childIds).Distinct().ToList();

        if (allEntityIds.Count <= 1)
        {
            return true;
        }

        // tạo hashset để chứa Id của cụ tổ của các entity
        var rootIds = new HashSet<Guid>();

        foreach (var entityId in allEntityIds)
        {
            // lấy ra cụ tổ
            var root = await entityRepository.GetRootAncestorIdAsync(entityId);

            if (!root.IsSuccess || root.Payload == Guid.Empty) return false;
            
            rootIds.Add(root.Payload);
        }

        // nếu tất cả các entity trong danh sách cha con của entity thêm mới mà có cùng cụ tổ thì chứng tỏ chúng cùng 1 chuối
        return rootIds.Count == 1;
    }
}

public class DeleteEntityCommandHandler(
    ILogger<CommandHandlerBase<DeleteEntityCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteEntityCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteEntityCommand request, CancellationToken cancellationToken)
    {
        var currentEntityResult  = await entityRepository.Get(request.Id, cancellationToken);
        if (currentEntityResult.IsFailure || currentEntityResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Entity not found"));
        }
        
        var currentEntity = currentEntityResult.Payload;

        if (currentEntity.ChildEntities.Count != 0
            || currentEntity.MerchantProfiles.Count != 0
            || currentEntity.Branches.Count != 0
            || currentEntity.JobTitles.Count != 0
            || currentEntity.JobTitles.Count != 0
            || currentEntity.Devices.Count != 0
            || currentEntity.Departments.Count != 0)
        {
            return Result.Failure(new Error("400", "This entity cannot be deleted!"));
        }
        
        var targetEntity = await entityRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await entityRepository.HardDeleteAsync(targetEntity, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteEntityCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteEntityCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteEntityCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteEntityCommand request, CancellationToken cancellationToken)
    {
        var currentEntityResult  = await entityRepository.Get(request.Id, cancellationToken);
        if (currentEntityResult.IsFailure || currentEntityResult.Payload == null)
        {
            return Result.Failure(new Error("404", "Entity not found"));
        }
        
        var currentEntity = currentEntityResult.Payload;

        if (currentEntity.ChildEntities.Count != 0
            || currentEntity.MerchantProfiles.Count != 0
            || currentEntity.Branches.Count != 0
            || currentEntity.JobTitles.Count != 0
            || currentEntity.JobTitles.Count != 0
            || currentEntity.Devices.Count != 0
            || currentEntity.Departments.Count != 0)
        {
            return Result.Failure(new Error("400", "This entity cannot be deleted!"));
        }
        
        var targetEntity = await entityRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await entityRepository.DeleteAsync(targetEntity, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}