using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.Entity;

public class AddEntityCommand : ITransactionalCommand<Result<Guid>>, IAuthorizableRequest
{
    public Guid? EntityStructureId { get; set; }
    public string? EntityCode { get; set; }
    public required string Name { get; set; }
    public string? ShortName { get; set; }
    public string? TaxCode { get; set; }
    public string? Website { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public Guid? BusinessCategoryId { get; set; }
    public Guid? CreatedBy { get; set; }
    public List<EntityRelationshipDto> ParentEntities { get; set; } = [];
    public List<EntityRelationshipDto> ChildEntities { get; set; } = [];
}

public class EntityRelationshipDto
{
    public Guid EntityId { get; set; }
    public RelationshipType RelationshipType { get; set; }
    public RequestStatus Status { get; set; } = RequestStatus.Pending;
    public string? RelationshipDetails { get; set; } // JSONB
}

public class AddUserEntityCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public List<AddUserEntityDto> Relations { get; set; } = [];
}

public class UpdateEntityCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public Guid? EntityStructureId { get; set; }
    public string? EntityCode { get; set; }
    public string Name { get; set; }
    public string? ShortName { get; set; }
    public string? TaxCode { get; set; }
    public string? Website { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public Guid? BusinessCategoryId { get; set; }
    public Guid? CreatedBy { get; set; }
    public List<EntityRelationshipDto> ParentEntities { get; set; } = [];
    public List<EntityRelationshipDto> ChildEntities { get; set; } = [];
}

public class DeleteEntityCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeleteEntityCommand : DeleteEntityCommand
{
    
}