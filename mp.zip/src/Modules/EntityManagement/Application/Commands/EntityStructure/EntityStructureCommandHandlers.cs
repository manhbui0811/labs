using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;

public class AddEntityStructureCommandHandler(
    ILogger<CommandHandlerBase<AddEntityStructureCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityStructureRepository entityStructureRepository
) : CommandHandlerBase<AddEntityStructureCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddEntityStructureCommand request, CancellationToken cancellationToken)
    {
        var entityStructure = new Domain.Entities.EntityStructure
        {
            Name = request.Name
        };
        
        if (request.ParentId.HasValue && request.ParentId != Guid.Empty)
        {
            var parent = await entityStructureRepository.GetByIdAsync(request.ParentId.Value, cancellationToken);
            if (parent == null)
            {
                return Result.Failure<Guid>(new Error("404","Parent EntityStructure not found"));
            }

            entityStructure.Parent = parent;
        }
        
        await entityStructureRepository.AddAsync(entityStructure, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(entityStructure.Id);
    }
}

public class UpdateEntityStructureCommandHandler(
    ILogger<CommandHandlerBase<UpdateEntityStructureCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityStructureRepository entityStructureRepository
) : CommandHandlerBase<UpdateEntityStructureCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateEntityStructureCommand request, CancellationToken cancellationToken)
    {
        var entityStructure = await entityStructureRepository.GetByIdAsync(request.Id, cancellationToken);
        if (entityStructure == null)
        {
            return Result.Failure(new Error("404","EntityStructure not found"));
        }

        if (entityStructure.IsDeleted)
        {
            return Result.Failure(new Error("400","You cannot perform this action!"));
        }

        if (request.ParentId.HasValue && request.ParentId != Guid.Empty)
        {
            var parent = await entityStructureRepository.GetByIdAsync(request.ParentId.Value, cancellationToken);
            if (parent == null)
            {
                return Result.Failure(new Error("404","Parent EntityStructure not found"));
            }

            entityStructure.Parent = parent;
        }
        
        entityStructure.Name = request.Name;

        await entityStructureRepository.UpdateAsync(entityStructure, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteEntityStructureCommandHandler(
    ILogger<CommandHandlerBase<DeleteEntityStructureCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityStructureRepository entityStructureRepository
) : CommandHandlerBase<DeleteEntityStructureCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteEntityStructureCommand request, CancellationToken cancellationToken)
    {
        var entityStructure = await entityStructureRepository.GetByIdAsync(request.Id, cancellationToken);
        if (entityStructure == null)
        {
            return Result.Failure(new Error("404","EntityStructure not found"));
        }

        if (entityStructure.IsDeleted)
        {
            return Result.Failure(new Error("400","You cannot perform this action!"));
        }

        await entityStructureRepository.HardDeleteAsync(entityStructure, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class HardDeleteEntityStructureCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteEntityStructureCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityStructureRepository entityStructureRepository
) : CommandHandlerBase<SoftDeleteEntityStructureCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteEntityStructureCommand request, CancellationToken cancellationToken)
    {
        var entityStructure = await entityStructureRepository.GetByIdAsync(request.Id, cancellationToken);
        if (entityStructure == null)
        {
            return Result.Failure(new Error("404","EntityStructure not found"));
        }

        if (entityStructure.IsDeleted)
        {
            return Result.Failure(new Error("400","You cannot perform this action!"));
        }

        await entityStructureRepository.DeleteAsync(entityStructure, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}