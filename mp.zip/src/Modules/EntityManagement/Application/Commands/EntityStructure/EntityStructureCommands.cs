using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.EntityStructure;

public class AddEntityStructureCommand : ITransactionalCommand<Result<Guid>>
{
    public string Name { get; set; }
    public Guid? ParentId { get; set; }
}

public class UpdateEntityStructureCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public Guid? ParentId { get; set; }
}

public class DeleteEntityStructureCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeleteEntityStructureCommand : DeleteEntityStructureCommand
{
    
}