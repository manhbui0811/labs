namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.IotDevice;

public class IotDeviceCommandHandlers
{
    
}