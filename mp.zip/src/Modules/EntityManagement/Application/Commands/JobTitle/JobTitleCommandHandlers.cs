using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;

public class AddJobTitleCommandHandler(
    ILogger<CommandHandlerBase<AddJobTitleCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityRepository entityRepository,
    IJobTitleRepository jobTitleRepository
) : CommandHandlerBase<AddJobTitleCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddJobTitleCommand request, CancellationToken cancellationToken)
    {
        var entity = await entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
        if (entity == null)
        {
            return Result.Failure<Guid>(new Error("404","Entity not found"));
        }

        var newJobtitle = new Domain.Entities.JobTitle
        {
            Title = request.Title,
            Description = request.Description,
            Entity = entity
        };
        
        await jobTitleRepository.AddAsync(newJobtitle, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newJobtitle.Id);
    }
}

public class UpdateJobTitleCommandHandler(
    ILogger<CommandHandlerBase<UpdateJobTitleCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityRepository entityRepository,
    IJobTitleRepository jobTitleRepository
) : CommandHandlerBase<UpdateJobTitleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateJobTitleCommand request, CancellationToken cancellationToken)
    {
        var currentJobtitle = await jobTitleRepository.GetByIdAsync(request.Id, cancellationToken);
        if (currentJobtitle == null)
        {
            return Result.Failure(new Error("404","JobTitle not found"));
        }
        
        currentJobtitle.Title = request.Title;
        currentJobtitle.Description = request.Description;
        
        if (request.EntityId.HasValue)
        {
            var entity = await entityRepository.GetByIdAsync(request.EntityId.Value, cancellationToken);
            if (entity == null)
            {
                return Result.Failure(new Error("404","Entity not found"));
            }

            currentJobtitle.Entity = entity;
        }
        
        await jobTitleRepository.UpdateAsync(currentJobtitle, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteJobTitleCommandHandler(
    ILogger<CommandHandlerBase<DeleteJobTitleCommand, Result>> logger,
    ICurrentUser currentUser,
    IJobTitleRepository jobTitleRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteJobTitleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteJobTitleCommand request, CancellationToken cancellationToken)
    {
        var currentJobTitle = await jobTitleRepository.GetByIdAsync(request.Id, cancellationToken);
        
        if (currentJobTitle == null)
        {
            return Result.Failure(new Error("404", "JobTitle not found"));
        }
        
        await jobTitleRepository.DeleteAsync(currentJobTitle, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteJobTitleCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteJobTitleCommand, Result>> logger,
    ICurrentUser currentUser,
    IJobTitleRepository jobTitleRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteJobTitleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteJobTitleCommand request, CancellationToken cancellationToken)
    {
        var currentJobTitle = await jobTitleRepository.GetByIdAsync(request.Id, cancellationToken);
        
        if (currentJobTitle == null)
        {
            return Result.Failure(new Error("404", "JobTitle not found"));
        }
        
        await jobTitleRepository.DeleteAsync(currentJobTitle, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}