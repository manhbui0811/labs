using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.JobTitle;

public class AddJobTitleCommand : ITransactionalCommand<Result<Guid>>, IAuthorizableRequest
{
    public Guid EntityId { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
}

public class UpdateJobTitleCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public Guid Id { get; set; }
    public Guid? EntityId { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
}

public class DeleteJobTitleCommand : ITransactionalCommand<Result>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class SoftDeleteJobTitleCommand : DeleteJobTitleCommand
{
    
}