using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.MerchantProfile;

public class AddMerchantProfileCommandHandler(
    ILogger<CommandHandlerBase<AddMerchantProfileCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityRepository entityRepository,
    IMerchantProfileRepository merchantProfileRepository
) : CommandHandlerBase<AddMerchantProfileCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddMerchantProfileCommand request, CancellationToken cancellationToken)
    {
        var entity = await entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
        if (entity == null)
        {
            return Result.Failure<Guid>(new Error("404","Entity not found"));
        }

        var newMerchantProfile = new Domain.Entities.MerchantProfile
        {
            MerchantCode = request.MerchantCode,
            MerchantName = request.MerchantName,
            Status = request.Status,
            AcquiringBankId = request.AcquiringBankId,
            Entity = entity
        };

        if (request.SettlementAccounts != null && request.SettlementAccounts.Count != 0)
        {
            foreach (var settlementAccount in request.SettlementAccounts)
            {
                var newSettlementAccount = new SettlementAccount
                {
                    AccountName = settlementAccount.AccountName,
                    AccountNumber = settlementAccount.AccountNumber,
                    BankCode = settlementAccount.BankCode,
                    BankName = settlementAccount.BankName,
                    CreatedBy = currentUser.UserId.ToString()
                };
                newMerchantProfile.SettlementAccounts.Add(newSettlementAccount);
            }
        }
        
        await merchantProfileRepository.AddAsync(newMerchantProfile, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newMerchantProfile.Id);
    }
}

public class UpdateMerchantProfileCommandHandler(
    ILogger<CommandHandlerBase<UpdateMerchantProfileCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IEntityRepository entityRepository,
    IMerchantProfileRepository merchantProfileRepository
) : CommandHandlerBase<UpdateMerchantProfileCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdateMerchantProfileCommand request, CancellationToken cancellationToken)
    {
        var currentMerchantProfile = await merchantProfileRepository.GetByIdAsync(request.Id, cancellationToken);
        if (currentMerchantProfile == null)
        {
            return Result.Failure(new Error("404","MerchantProfile not found"));
        }
        
        if(request.AcquiringBankId.HasValue) currentMerchantProfile.AcquiringBankId = request.AcquiringBankId.Value;
        
        currentMerchantProfile.MerchantCode = request.MerchantCode;
        currentMerchantProfile.MerchantName = request.MerchantName;
        currentMerchantProfile.Status = request.Status;
        
        if (request.EntityId.HasValue)
        {
            var entity = await entityRepository.GetByIdAsync(request.EntityId.Value, cancellationToken);
            if (entity == null)
            {
                return Result.Failure(new Error("404","Entity not found"));
            }

            currentMerchantProfile.Entity = entity;
        }
        
        await merchantProfileRepository.UpdateAsync(currentMerchantProfile, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeleteDepartmentCommandHandler(
    ILogger<CommandHandlerBase<DeleteMerchantProfileCommand, Result>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeleteMerchantProfileCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeleteMerchantProfileCommand request, CancellationToken cancellationToken)
    {
        var currentMerchantProfileResult  = await merchantProfileRepository.Get(request.Id, cancellationToken);
        if (currentMerchantProfileResult.IsFailure || currentMerchantProfileResult.Payload == null)
        {
            return Result.Failure(new Error("404", "MerchantProfile not found"));
        }
        
        var currentMerchantProfile = currentMerchantProfileResult.Payload;

        if (currentMerchantProfile.PaymentChannels.Count != 0 
            || currentMerchantProfile.SettlementAccounts.Count != 0
            || currentMerchantProfile.Devices.Count != 0)
        {
            return Result.Failure(new Error("400", "This merchantProfile cannot be deleted!"));
        }
        
        var targetMerchantProfile = await merchantProfileRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await merchantProfileRepository.HardDeleteAsync(targetMerchantProfile, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeleteMerchantProfileCommandHandler(
    ILogger<CommandHandlerBase<SoftDeleteMerchantProfileCommand, Result>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeleteMerchantProfileCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeleteMerchantProfileCommand request, CancellationToken cancellationToken)
    {
        var currentMerchantProfileResult  = await merchantProfileRepository.Get(request.Id, cancellationToken);
        if (currentMerchantProfileResult.IsFailure || currentMerchantProfileResult.Payload == null)
        {
            return Result.Failure(new Error("404", "MerchantProfile not found"));
        }
        
        var currentMerchantProfile = currentMerchantProfileResult.Payload;

        if (currentMerchantProfile.PaymentChannels.Count != 0 
            || currentMerchantProfile.SettlementAccounts.Count != 0
            || currentMerchantProfile.Devices.Count != 0)
        {
            return Result.Failure(new Error("400", "This merchantProfile cannot be deleted!"));
        }
        
        var targetMerchantProfile = await merchantProfileRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await merchantProfileRepository.DeleteAsync(targetMerchantProfile, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}