using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.MerchantProfile;

public class AddMerchantProfileCommand : ITransactionalCommand<Result<Guid>>
{
    public required string MerchantCode { get; set; }
    public required string MerchantName { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;
    public Guid EntityId { get; set; }
    public Guid AcquiringBankId { get; set; }

    public ICollection<AddSettlementAccountCommand>? SettlementAccounts { get; set; } = [];
}

public class AddSettlementAccountCommand
{
    public string AccountNumber { get; set; }
    public string AccountName { get; set; }
    
    public string BankName { get; set; }
    
    public string? BankCode { get; set; }
}

public class UpdateMerchantProfileCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public Guid? EntityId { get; set; }
    public Guid? AcquiringBankId { get; set; }
    public string MerchantCode { get; set; }
    public string MerchantName { get; set; }
    public EntityStatus Status { get; set; }
    
    public AddSettlementAccountCommand? SettlementAccount { get; set; }
}

public class DeleteMerchantProfileCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeleteMerchantProfileCommand : DeleteMerchantProfileCommand
{
    
}