using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;

public class AddPaymentChannelCommand : ITransactionalCommand<Result<Guid>>
{
    public required string ChannelType { get; set; }
    public required string TidCode { get; set; }
    public required string MidCode { get; set; }
    public string? ChannelName { get; set; }
    public Guid? PosId { get; set; }
    public Guid? MerchantProfileId { get; set; }
    public Guid PointOfSaleId { get; set; }
}

public class UpdatePaymentChannelCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public Guid? PointOfSaleId { get; set; }
    public Guid? MerchantProfileId { get; set; }
    public required string ChannelType { get; set; }
    public required string TidCode { get; set; }
    public required string MidCode { get; set; }
    public string? ChannelName { get; set; }
    public Guid? PosId { get; set; }

}

public class DeletePaymentChannelCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeletePaymentChannelCommand : DeletePaymentChannelCommand
{
    
}