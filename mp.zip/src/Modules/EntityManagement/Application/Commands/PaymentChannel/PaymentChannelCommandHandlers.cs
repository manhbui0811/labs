using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;

public class AddPaymentChannelCommandHandler(
    ILogger<CommandHandlerBase<AddPaymentChannelCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IPointOfSaleRepository pointOfSaleRepository,
    IMerchantProfileRepository merchantProfileRepository,
    IPaymentChannelRepository paymentChannelRepository
) : CommandHandlerBase<AddPaymentChannelCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddPaymentChannelCommand request, CancellationToken cancellationToken)
    {
        var pointOfSale = await pointOfSaleRepository.GetByIdAsync(request.PointOfSaleId,  cancellationToken);
        if (pointOfSale == null)
        {
            return Result.Failure<Guid>(new Error("404","PointOfSale not found"));
        }

        var newPaymentChannel = new Domain.Entities.PaymentChannel
        {
            MidCode = request.MidCode,
            ChannelType = request.ChannelType,
            ChannelName = request.ChannelName,
            TidCode = request.TidCode,
            PosId = request.PosId??Guid.Empty,
            PointOfSale = pointOfSale
        };

        if (request.MerchantProfileId.HasValue)
        {
            var merchantProfile = await merchantProfileRepository.GetByIdAsync(request.MerchantProfileId.Value, cancellationToken);
            if (merchantProfile == null)
            {
                return Result.Failure<Guid>(new Error("404","MerchantProfile not found"));
            }
            newPaymentChannel.MerchantProfile = merchantProfile;
        }
        
        await paymentChannelRepository.AddAsync(newPaymentChannel, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newPaymentChannel.Id);
    }
}

public class UpdatePaymentChannelCommandHandler(
    ILogger<CommandHandlerBase<UpdatePaymentChannelCommand, Result>> logger,
    ICurrentUser currentUser,
    IEntityManagementUnitOfWork entityManagementUnitOfWork,
    IPointOfSaleRepository pointOfSaleRepository,
    IMerchantProfileRepository merchantProfileRepository,
    IPaymentChannelRepository paymentChannelRepository
) : CommandHandlerBase<UpdatePaymentChannelCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdatePaymentChannelCommand request, CancellationToken cancellationToken)
    {
        var currentPaymentChannel = await paymentChannelRepository.GetByIdAsync(request.Id, cancellationToken);
        if (currentPaymentChannel == null)
        {
            return Result.Failure(new Error("404","PaymentChannel not found"));
        }

        currentPaymentChannel.MidCode = request.MidCode;
        currentPaymentChannel.ChannelType = request.ChannelType;
        currentPaymentChannel.ChannelName = request.ChannelName;
        currentPaymentChannel.TidCode = request.TidCode;
        currentPaymentChannel.PosId = request.PosId ?? Guid.Empty;

        if (request.PointOfSaleId.HasValue)
        {
            var pointOfSale = await pointOfSaleRepository.GetByIdAsync(request.PointOfSaleId.Value,  cancellationToken);
            if (pointOfSale == null)
            {
                return Result.Failure<Guid>(new Error("404","PointOfSale not found"));
            }

            currentPaymentChannel.PointOfSale = pointOfSale;
        }
        

        if (request.MerchantProfileId.HasValue)
        {
            var merchantProfile = await merchantProfileRepository.GetByIdAsync(request.MerchantProfileId.Value, cancellationToken);
            if (merchantProfile == null)
            {
                return Result.Failure<Guid>(new Error("404","MerchantProfile not found"));
            }
            currentPaymentChannel.MerchantProfile = merchantProfile;
        }

        await paymentChannelRepository.UpdateAsync(currentPaymentChannel, cancellationToken);
        await entityManagementUnitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeletePaymentChannelCommandHandler(
    ILogger<CommandHandlerBase<DeletePaymentChannelCommand, Result>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeletePaymentChannelCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeletePaymentChannelCommand request, CancellationToken cancellationToken)
    {
        var targetPaymentChannel = await paymentChannelRepository.GetByIdAsync(request.Id, cancellationToken);
        if (targetPaymentChannel == null)
        {
            return Result.Failure(new Error("404", "PaymentChannel not found"));
        }
        await paymentChannelRepository.HardDeleteAsync(targetPaymentChannel, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeletePaymentChannelCommandHandler(
    ILogger<CommandHandlerBase<SoftDeletePaymentChannelCommand, Result>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeletePaymentChannelCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeletePaymentChannelCommand request, CancellationToken cancellationToken)
    {
        var targetPaymentChannel = await paymentChannelRepository.GetByIdAsync(request.Id, cancellationToken);
        if (targetPaymentChannel == null)
        {
            return Result.Failure(new Error("404", "PaymentChannel not found"));
        }
        await paymentChannelRepository.DeleteAsync(targetPaymentChannel, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}