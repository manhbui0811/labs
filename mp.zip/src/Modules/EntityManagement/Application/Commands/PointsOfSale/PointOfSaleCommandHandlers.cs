using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;

public class AddPointOfSaleCommandHandler(
    ILogger<CommandHandlerBase<AddPointOfSaleCommand, Result<Guid>>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository,
    IBranchRepository branchRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<AddPointOfSaleCommand, Result<Guid>>(logger, currentUser)
{
    public override async Task<Result<Guid>> Handle(AddPointOfSaleCommand request, CancellationToken cancellationToken)
    {
        var parentBranch  = await branchRepository.GetByIdAsync(request.BranchId, cancellationToken);
        if (parentBranch == null)
        {
            return Result.Failure<Guid>(new Error("404", "Entity not found"));
        }
        
        var newPointOfSale = new Domain.Entities.PointOfSale
        {
            Name = request.Name,
            Branch = parentBranch,
            CreatedBy = CurrentUser.UserId.ToString(),
            PosCode = string.IsNullOrEmpty(request.PosCode)?CodeGenerator.GenerateRandomNumericCode(): request.PosCode,
            Description = request.Description,
            Status = request.Status
        };

        if (request.PaymentChannels.Any())
        {
            foreach (var paymentChannel in request.PaymentChannels)
            {
                var newPaymentChannel = new Domain.Entities.PaymentChannel
                {
                    ChannelType = paymentChannel.ChannelType,
                    ChannelName = paymentChannel.ChannelName,
                    CreatedBy = CurrentUser.UserId.ToString(),
                    MidCode = paymentChannel.MidCode,
                    TidCode = paymentChannel.TidCode,
                    PosId = paymentChannel.PosId??Guid.Empty
                };
                
                newPointOfSale.PaymentChannels.Add(newPaymentChannel);
            }
            
        }
        
        await pointOfSaleRepository.AddAsync(newPointOfSale, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success(newPointOfSale.Id);
    }
}

public class UpdatePointOfSaleCommandHandler(
    ILogger<CommandHandlerBase<UpdatePointOfSaleCommand, Result>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository,
    IBranchRepository branchRepository,
    IPaymentChannelRepository paymentChannelRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<UpdatePointOfSaleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(UpdatePointOfSaleCommand request, CancellationToken cancellationToken)
    {
        
        var currentPointOfSale = await pointOfSaleRepository.GetByIdAsync(request.Id, cancellationToken);

        if (currentPointOfSale == null)
        {
            return Result.Failure<Guid>(new Error("404", "PointOfSale not found"));
        }

        if (request.BranchId.HasValue)
        {
            var newParentBranch  = await branchRepository.GetByIdAsync(request.BranchId.Value, cancellationToken);
            
            if (newParentBranch == null)
            {
                return Result.Failure<Guid>(new Error("404", "Branch not found"));
            }
            currentPointOfSale.BranchId = newParentBranch.Id;
            currentPointOfSale.Branch = newParentBranch;
        }
        
        currentPointOfSale.Name = request.Name;
        currentPointOfSale.Description = request.Description;
        currentPointOfSale.CreatedBy = CurrentUser.UserId.ToString();
        currentPointOfSale.Status = request.Status;
        currentPointOfSale.PosCode = string.IsNullOrEmpty(request.PosCode)?currentPointOfSale.PosCode : request.PosCode;

        foreach (var paymentChannel in request.PaymentChannels)
        {
            var currentPaymentChannel = await paymentChannelRepository.GetByIdAsync(paymentChannel.Id, cancellationToken);
            if (currentPaymentChannel == null || currentPaymentChannel.PointOfSaleId != currentPointOfSale.Id)
            {
                return Result.Failure(new Error("404","PaymentChannel not found or invalid"));
            }

            currentPaymentChannel.MidCode = paymentChannel.MidCode;
            currentPaymentChannel.ChannelType = paymentChannel.ChannelType;
            currentPaymentChannel.ChannelName = paymentChannel.ChannelName;
            currentPaymentChannel.TidCode = paymentChannel.TidCode;
            await paymentChannelRepository.UpdateAsync(currentPaymentChannel,  cancellationToken);
        }
        
        await pointOfSaleRepository.UpdateAsync(currentPointOfSale, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class DeletePointOfSaleCommandHandler(
    ILogger<CommandHandlerBase<DeletePointOfSaleCommand, Result>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<DeletePointOfSaleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(DeletePointOfSaleCommand request, CancellationToken cancellationToken)
    {
        var currentPointOfSaleResult  = await pointOfSaleRepository.Get(request.Id, cancellationToken);
        if (currentPointOfSaleResult.IsFailure || currentPointOfSaleResult.Payload == null)
        {
            return Result.Failure(new Error("404", "MerchantProfile not found"));
        }
        
        var currentPointsOfSale = currentPointOfSaleResult.Payload;

        if (currentPointsOfSale.PaymentChannels.Count != 0)
        {
            return Result.Failure(new Error("400", "This merchantProfile cannot be deleted!"));
        }
        
        var targetPointsOfSale = await pointOfSaleRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await pointOfSaleRepository.HardDeleteAsync(targetPointsOfSale, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}

public class SoftDeletePointOfSaleCommandHandler(
    ILogger<CommandHandlerBase<SoftDeletePointOfSaleCommand, Result>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<SoftDeletePointOfSaleCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(SoftDeletePointOfSaleCommand request, CancellationToken cancellationToken)
    {
        var currentPointOfSaleResult  = await pointOfSaleRepository.Get(request.Id, cancellationToken);
        if (currentPointOfSaleResult.IsFailure || currentPointOfSaleResult.Payload == null)
        {
            return Result.Failure(new Error("404", "MerchantProfile not found"));
        }
        
        var currentPointsOfSale = currentPointOfSaleResult.Payload;

        if (currentPointsOfSale.PaymentChannels.Count != 0)
        {
            return Result.Failure(new Error("400", "This merchantProfile cannot be deleted!"));
        }
        
        var targetPointsOfSale = await pointOfSaleRepository.GetByIdAsync(request.Id, cancellationToken);
        
        await pointOfSaleRepository.DeleteAsync(targetPointsOfSale, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }
}