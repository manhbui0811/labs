using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PaymentChannel;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Commands.PointsOfSale;

public class AddPointOfSaleCommand : ITransactionalCommand<Result<Guid>>
{
    public string? PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; }
    public Guid BranchId { get; set; }
    public ICollection<AddPaymentChannelCommand> PaymentChannels { get; set; } = [];
}

public class UpdatePointOfSaleCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
    public Guid? BranchId { get; set; }
    public string? PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; }
    public ICollection<UpdatePaymentChannelCommand> PaymentChannels { get; set; } = [];
}

public class DeletePointOfSaleCommand : ITransactionalCommand<Result>
{
    public Guid Id { get; set; }
}

public class SoftDeletePointOfSaleCommand : DeletePointOfSaleCommand
{
    
}