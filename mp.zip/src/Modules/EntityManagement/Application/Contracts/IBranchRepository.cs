using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IBranchRepository : IRepositoryBase<Branch, Guid>, IOwnershipRepository
{
    public Task<Result<BranchResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<BranchResponseDto>> GetByTidMid(string tid, string mid, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<BranchResponseDto>>> GetAll(PagingRequest request, Guid? userId = null, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<BranchResponseDto>>> GetByEntity(Guid entityId, PagingRequest request, string searchText = "", CancellationToken cancellationToken = default);
}