using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IDepartmentRepository : IRepositoryBase<Department, Guid>, IOwnershipRepository
{
    public Task<Result<DepartmentResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<DepartmentResponseDto>>> GetAll(PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<DepartmentResponseDto>>> GetByEntity(Guid entityId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
}