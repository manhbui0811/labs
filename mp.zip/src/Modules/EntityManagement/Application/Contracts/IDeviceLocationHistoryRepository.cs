using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IDeviceLocationHistoryRepository : IRepositoryBase<DeviceLocationHistory, Guid>, IOwnershipRepository
{
    public Task<Result<DeviceLocationHistory>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<DeviceLocationHistory>>> GetAll(PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<DeviceLocationHistory>>> GetByPosDevice(Guid posDeviceId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
}