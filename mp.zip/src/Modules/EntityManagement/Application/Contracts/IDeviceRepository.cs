using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IDeviceRepository : IRepositoryBase<Device, Guid>, IOwnershipRepository
{
    public Task<Result<DeviceResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<DeviceResponseDto>>> GetAll(PagingRequest request, Guid? userId = null, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<DevicesInformationRespsonseDto>> GetDevicesInformation(
        Guid? userId,
        Guid? merchantId, 
        Guid? posId,
        PosStatus? status,
        int? batteryLevel,
        int? latency,
        CancellationToken cancellationToken = default
        );
    
    public Task<Result<PagedResult<DeviceResponseDto>>> GetByEntity(Guid entityId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
}