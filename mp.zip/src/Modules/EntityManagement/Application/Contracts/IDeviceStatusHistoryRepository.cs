using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IDeviceStatusHistoryRepository : IRepositoryBase<DeviceStatusHistory, Guid>, IOwnershipRepository
{
    public Task<Result<DeviceStatusHistory>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<DeviceStatusHistory>>> GetAll(PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<DeviceStatusHistory>>> GetByPosDevice(Guid posDeviceId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
}