using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IEntityClosureRepository : IRepositoryBase<EntityClosure, Guid>
{
    public Task<Result> CreateSelfReferenceAsync(Guid newEntityId, CancellationToken cancellationToken = default);
    public Task<Result> LinkParentToChildAsync(Guid parentId, Guid childId);
    
    public Task<Result> UnlinkParentFromChildAsync(Guid parentId, Guid childId, CancellationToken cancellationToken = default);
}