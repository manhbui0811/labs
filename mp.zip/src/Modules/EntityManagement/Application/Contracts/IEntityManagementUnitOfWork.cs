using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IEntityManagementUnitOfWork : IUnitOfWork
{
}