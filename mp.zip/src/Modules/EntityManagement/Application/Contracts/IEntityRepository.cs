using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IEntityRepository : IRepositoryBase<Entity, Guid>
{
    public Task<Result<PagedResult<EntityResponseDto>>>  GetAll(PagingRequest request, bool newView = false, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<EntityResponseDto>>> GetListChilds(PagingRequest request, Guid parentId, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<EntityResponseDto>>> GetNoParentEntities(PagingRequest request, Guid userId, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<EntityResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<EntityResponseDto>>>  GetByUser(Guid userId, PagingRequest request, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<List<EntityResponseDto>>>  GetNoChildEntities(Guid? userId, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<EntityResponseDto>>>  GetByEntityStructure(Guid entityStructureId, PagingRequest request, Guid? userId, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<Guid>> GetRootAncestorIdAsync(Guid entityId);
    public Task<Result> AddRelationshipAsync(EntityRelationship entityRelationship, CancellationToken cancellationToken = default);
    Task<Result<PagedResult<EntityResponseDto>>> GetAccessibleEntitiesInChainForUserAsync(
        Guid userId, 
        PagingRequest request, 
        Guid? entityStructureId, 
        string searchText = "", 
        CancellationToken cancellationToken = default);
    
    Task<Result<List<Guid>>> GetAccessibleEntityIdsInChainForUserAsync(Guid userId, CancellationToken cancellationToken = default);
}