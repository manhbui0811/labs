using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IEntityStructureRepository : IRepositoryBase<EntityStructure, Guid>
{
    public Task<Result<PagedResult<EntityStructureResponseDto>>> GetAll(PagingRequest request, string searchText = "", CancellationToken cancellationToken = default);
    public Task<Result<EntityStructureResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
}