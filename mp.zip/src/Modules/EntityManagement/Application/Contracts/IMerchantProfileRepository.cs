using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IMerchantProfileRepository : IRepositoryBase<MerchantProfile, Guid>, IOwnershipRepository
{
    public Task<Result<MerchantProfileResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<MerchantProfileResponseDto>>> GetAll(
        PagingRequest request, 
        Guid? userId = null,
        Guid? acquiringBankId = null,
        EntityStatus? status = null,
        Guid? entityId = null,
        string searchText = "",
        DateTime? fromDate = null,
        DateTime? toDate = null,
        CancellationToken cancellationToken = default
        );
    
    public Task<Result<List<MerchantProfileResponseDto>>> GetByUser(Guid? userId = null, string searchText = "", CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<MerchantProfileResponseDto>>> GetByEntity(Guid entityId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    Task<MerchantProfile?> GetByMerchantCodeAsync(string merchantCode, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<MerchantProfile>> GetByEntityIdAsync(Guid entityId, CancellationToken cancellationToken = default);



}