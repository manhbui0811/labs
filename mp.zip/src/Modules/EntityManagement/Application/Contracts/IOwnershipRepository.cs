namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IOwnershipRepository
{
    /// <summary>
    /// Từ ID của một đối tượng, tìm ra ID của Entity sở hữu nó.
    /// </summary>
    /// <param name="objectId">ID của đối tượng cần kiểm tra (ví dụ: branchId, paymentChannelId...).</param>
    /// <returns>ID của Entity chủ quản, hoặc null nếu không tìm thấy.</returns>
    Task<Guid?> GetOwningEntityIdAsync(Guid objectId, CancellationToken cancellationToken = default);
}