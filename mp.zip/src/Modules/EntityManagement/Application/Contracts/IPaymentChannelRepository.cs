using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IPaymentChannelRepository : IRepositoryBase<PaymentChannel, Guid>, IOwnershipRepository
{
    public Task<Result<PaymentChannelResponseDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<PaymentChannelResponseDto>>> GetAll(PagingRequest request, Guid? userId = null, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<PaymentChannelResponseDto>>> GetByPointOfSale(Guid pointOfSaleId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<PaymentChannelResponseDto>>> GetByMerchantProfile(Guid merchantProfileId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    Task<PaymentChannel?> GetByIdWithMerchantProfileAsync(Guid paymentChannelId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<PaymentChannel>> GetByMerchantProfileIdAsync(Guid merchantProfileId, CancellationToken cancellationToken = default);
    Task<PaymentChannel?> GetByMidAndTidAsync(string midCode, string tidCode, CancellationToken cancellationToken = default);
}