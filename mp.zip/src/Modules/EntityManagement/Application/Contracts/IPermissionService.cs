namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IPermissionRepository
{
    /// <summary>
    /// Kiểm tra xem người dùng hiện tại có quyền truy cập vào một entity mục tiêu hay không.
    /// Quyền truy cập được xác định nếu người dùng là thành viên của chính entity đó,
    /// hoặc là thành viên của một entity cha bất kỳ trong cây phân cấp.
    /// </summary>
    /// <param name="targetEntityId">ID của entity cần kiểm tra quyền (ví dụ: entity sở hữu thiết bị, chi nhánh...).</param>
    /// <returns>True nếu có quyền, False nếu không.</returns>
    public Task<bool> HasAccessToEntityAsync(Guid targetEntityId);

    /// <summary>
    /// Kiểm tra xem người dùng hiện tại có quyền truy cập vào một entity mục tiêu hay không.
    /// Quyền truy cập được xác định nếu người dùng là thành viên của chính entity đó,
    /// hoặc là thành viên của một entity cha bất kỳ trong cây phân cấp.
    /// </summary>
    /// <param name="objectId">ID của entity cần kiểm tra quyền (ví dụ: entity sở hữu thiết bị, chi nhánh...).</param>
    /// <returns>True nếu có quyền, False nếu không.</returns>
    public Task<bool> HasAccessAsync<TRepository>(Guid objectId, CancellationToken cancellationToken = default) where  TRepository : IOwnershipRepository;
}