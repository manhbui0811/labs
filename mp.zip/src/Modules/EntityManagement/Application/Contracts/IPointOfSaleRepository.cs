using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IPointOfSaleRepository : IRepositoryBase<PointOfSale, Guid>, IOwnershipRepository
{
    public Task<Result<PointsOfSaleRepsoneDto>> Get(Guid id, CancellationToken cancellationToken = default);
    public Task<Result<PagedResult<PointsOfSaleRepsoneDto>>> GetAll(PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
    
    public Task<Result<PagedResult<PointsOfSaleRepsoneDto>>> GetByBranch(Guid branchId, PagingRequest request, string searchText = "",
        CancellationToken cancellationToken = default);
}