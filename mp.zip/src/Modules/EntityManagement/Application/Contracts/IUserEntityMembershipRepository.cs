using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;

public interface IUserEntityMembershipRepository : IRepositoryBase<UserEntityMembership, Guid>
{
    public Task<Result<List<UserEntityMembership>>> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken = default);
    public Task<Result<bool>> ExistsAsync(Guid userId, Guid entityId, CancellationToken cancellationToken = default);
}