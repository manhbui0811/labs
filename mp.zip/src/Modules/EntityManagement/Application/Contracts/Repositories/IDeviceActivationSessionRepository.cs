using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;

public interface IDeviceActivationSessionRepository : IRepositoryBase<DeviceActivationSession>
{
    Task<DeviceActivationSession?> GetBySessionCodeAsync(string sessionCode, CancellationToken cancellationToken = default);
    Task<DeviceActivationSession?> GetByIdWithDeviceAsync(Guid sessionId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<DeviceActivationSession>> GetActiveByDeviceIdAsync(Guid deviceId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<DeviceActivationSession>> GetExpiredSessionsAsync(CancellationToken cancellationToken = default);
}