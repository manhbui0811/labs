// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Contracts/Repositories/IIotDeviceRepository.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;

public interface IIotDeviceRepository : IRepositoryBase<IotDevice>
{
    Task<IotDevice?> GetBySerialNumberAsync(string serialNumber, CancellationToken cancellationToken = default);
    Task<IotDevice?> GetByIdWithPaymentChannelAsync(Guid deviceId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<IotDevice>> GetByEntityIdAsync(Guid entityId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<IotDevice>> GetByPaymentChannelIdAsync(Guid paymentChannelId, CancellationToken cancellationToken = default);
}