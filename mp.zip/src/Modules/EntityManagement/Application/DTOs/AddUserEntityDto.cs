using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class AddUserEntityDto
{
    public string JobTitle { get; set; } = string.Empty;
    public Guid UserId { get; set; }
    public Guid EntityId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? CreatedBy { get; set; }
    public Guid? UpdatedBy { get; set; }
    public List<UserEntityMemberShipRoleDto> Roles { get; set; } = [];
}