using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class BranchResponseDto : FullAuditedAggregateRoot
{
    public required string BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public long? NumberOfPointsOfSale { get; set; }
    public long? NumberOfChildBranches { get; set; }
    public EntityStatus Status { get; set; }
    public EntityResponseDto Entity { get; set; }
    public ICollection<PointsOfSaleRepsoneDto> PointsOfSale { get; set; } = [];
    public ICollection<BranchResponseDto> ChildBranches  { get; set; } = [];
    public BranchResponseDto ParentBranch  { get; set; }
}