using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class DepartmentResponseDto : FullAuditedAggregateRoot
{
    public required string DepartmentCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public EntityResponseDto Entity { get; set; }
    public DepartmentResponseDto? ParentDepartment { get; set; }
    public ICollection<DepartmentResponseDto> ChildDepartments { get; set; } = [];
    public long? NumberOfChildDepartments { get; set; }
}