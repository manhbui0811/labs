using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class DeviceLocationHistoryResponseDto  : FullAuditedAggregateRoot
{
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public double? AccuracyMeters { get; set; }
    public string? LocationSource { get; set; }
    public DateTime RecordedAt { get; set; }
    public DeviceResponseDto Device { get; set; }
}