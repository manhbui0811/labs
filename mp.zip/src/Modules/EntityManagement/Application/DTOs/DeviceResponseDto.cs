using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class DeviceResponseDto  : FullAuditedAggregateRoot
{
    public required string SerialNumber { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public string Provider { get; set; }
    public required string DeviceType { get; set; }
    public string? FcmToken { get; set; }
    public PosStatus Status { get; set; }
    public int? BatteryLevel { get; set; }
    public string? AppVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTime? LastSeen { get; set; }
    public double? CurrentLatitude { get; set; }
    public double? CurrentLongitude { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }
    public int? Latency { get; set; }
    public EntityResponseDto Entity { get; set; } = null!;
    public PaymentChannelResponseDto PaymentChannel { get; set; } = null!;
    public ICollection<DeviceLocationHistoryResponseDto> LocationHistories { get; set; } = [];
    public ICollection<DeviceStatusHistoryResponseDto> StatusHistories { get; set; } = [];
    public ICollection<MerchantProfileResponseDto> MerchantProfiles { get; set; } = [];
}