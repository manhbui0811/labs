using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class DeviceStatusHistoryResponseDto : FullAuditedAggregateRoot
{
    public PosStatus? OldStatus { get; set; }
    public PosStatus NewStatus { get; set; }
    public int? BatteryLevel { get; set; }
    public string? NetworkType { get; set; }
    public string? AppVersion { get; set; }
    public string? StatusReason { get; set; }
    public DateTime RecordedAt { get; set; }
    public DeviceResponseDto Device { get; set; }
}