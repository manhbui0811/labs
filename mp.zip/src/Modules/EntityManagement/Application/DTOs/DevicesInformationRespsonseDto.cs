namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class DevicesInformationRespsonseDto
{
    public long Total { get; set; }
    public List<DeviceResponseDto> Devices { get; set; } = [];
    public long Online { get; set; }
    public long Offline { get; set; }
    public long Unknown { get; set; }
    public long BatteryLow { get; set; }
}