using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class EntityResponseDto : FullAuditedAggregateRoot
{
    public required string EntityCode { get; set; }
    public required string Name { get; set; }
    public string? ShortName { get; set; }
    public string? TaxCode { get; set; }
    public string? Website { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public EntityStructureResponseDto? EntityStructure { get; set; }
    public EntityStatus Status { get; set; }
    public ICollection<EntityResponseDto> ParentEntities { get; set; } = [];
    public ICollection<EntityResponseDto> ChildEntities { get; set; } = [];
    public ICollection<BranchResponseDto> Branches { get; set; } = [];
    public ICollection<DepartmentResponseDto> Departments { get; set; } = [];
    public ICollection<DeviceResponseDto> Devices { get; set; } = [];
    public ICollection<MerchantProfileResponseDto> MerchantProfiles { get; set; } = [];
    public ICollection<JobTitleResponseDto> JobTitles { get; set; } = [];
    public long? NumberOfBranches { get; set; }
    public long? NumberOfDepartments { get; set; }
    public long? NumberOfDirectUsers { get; set; }
    public long? NumberOfDevices { get; set; }
    public long? NumberOfMerchantProfiles { get; set; }
    public long? NumberOfJobTitles { get; set; }
    public long? NumberOfChilds { get; set; }
}