namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class EntityStructureResponseDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public EntityStructureResponseDto? Parent { get; set; }
    
    public EntityStructureResponseDto? Child { get; set; }
    
    public ICollection<EntityResponseDto> Entities { get; set; } = [];
}