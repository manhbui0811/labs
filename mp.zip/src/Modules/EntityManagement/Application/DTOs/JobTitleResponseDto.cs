using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class JobTitleResponseDto : FullAuditedAggregateRoot
{
    public required string Title { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual EntityResponseDto Entity { get; set; } = null!;
}