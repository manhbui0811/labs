using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class MerchantProfileResponseDto : FullAuditedAggregateRoot
{
    public required string MerchantCode { get; set; }
    public required string MerchantName { get; set; }
    public EntityStatus Status { get; set; }
    public Guid AcquiringBankId { get; set; }

    public EntityResponseDto Entity { get; set; }
    public ICollection<SettlementAccountResponseDto> SettlementAccounts { get; set; } = [];
    public ICollection<PaymentChannelResponseDto> PaymentChannels { get; set; } = [];
    public ICollection<DeviceResponseDto> Devices { get; set; } = [];
}