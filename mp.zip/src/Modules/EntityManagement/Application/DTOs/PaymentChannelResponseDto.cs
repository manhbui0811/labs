using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class PaymentChannelResponseDto : FullAuditedAggregateRoot
{
    //public new Guid Id { get; set; }
    public required string ChannelType { get; set; }
    public required string TidCode { get; set; }
    public required string MidCode { get; set; }
    public string? ChannelName { get; set; }
    public EntityStatus Status { get; set; }
    public Guid PosId { get; set; }
    public PointsOfSaleRepsoneDto PointOfSale { get; set; } = null!;
    public MerchantProfileResponseDto? MerchantProfile { get; set; } = null!;
}