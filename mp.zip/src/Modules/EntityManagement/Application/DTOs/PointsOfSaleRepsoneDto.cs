using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class PointsOfSaleRepsoneDto : FullAuditedAggregateRoot
{
    public required string PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; }
    public BranchResponseDto Branch { get; set; }
    public ICollection<PaymentChannelResponseDto> PaymentChannels { get; set; } = [];
}