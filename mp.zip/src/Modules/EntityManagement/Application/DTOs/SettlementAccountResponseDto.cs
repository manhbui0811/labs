using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class SettlementAccountResponseDto : FullAuditedAggregateRoot
{
    public required string AccountNumber { get; set; }
    public required string AccountName { get; set; }
    public required string BankName { get; set; }
    public string? BankCode { get; set; }
    public bool IsDefault { get; set; }
    public MerchantProfileResponseDto MerchantProfile { get; set; }
}