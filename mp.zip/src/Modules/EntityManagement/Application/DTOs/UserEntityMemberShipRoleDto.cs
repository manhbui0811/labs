namespace SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

public class UserEntityMemberShipRoleDto
{
    public Guid RoleId { get; set; }
    public string RoleType { get; set;}
}