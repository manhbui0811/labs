using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public record AssignDeviceToPaymentChannelCommand : ITransactionalCommand<Result>
{
    public Guid IotDeviceId { get; set; }
    public Guid PaymentChannelId { get; set; }
}


