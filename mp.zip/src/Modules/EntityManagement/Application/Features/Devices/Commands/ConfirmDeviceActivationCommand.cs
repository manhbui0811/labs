// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Activation/Commands/ConfirmDeviceActivationCommand.cs

using System.ComponentModel.DataAnnotations;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public sealed record ConfirmDeviceActivationCommand : ITransactionalCommand<Result<ConfirmDeviceActivationResult>>
{
    [Required]
    public Guid ActivationSessionId { get; init; }

    public string? RequestId { get; init; }

    public string? CompletionNotes { get; init; }
}

public sealed record ConfirmDeviceActivationResult
{
    public Guid DeviceId { get; init; }
    public Guid SessionId { get; init; }
    public string SerialNumber { get; init; } = default!;
    public bool IsCompleted { get; init; }
    public DateTimeOffset CompletedAt { get; init; }
    public string RequestId { get; init; } = default!;
}