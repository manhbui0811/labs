﻿using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands
{
    public class CreateDeviceRSAKeyCommand : ICommand<CreateDeviceRSAKeyDto>
    {
        public string? SerialNumber { get; set; }
    }

    public class CreateDeviceRSAKeyCommandValidator : AbstractValidatorBase<CreateDeviceRSAKeyCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.SerialNumber).NotEmpty().WithMessage("SerialNumber cannot be empty.");
        }
    }

    public class CreateDeviceRSAKeyCommandHandler
       : CommandHandlerBase<CreateDeviceRSAKeyCommand, CreateDeviceRSAKeyDto>
    {
        private readonly IRepositoryBase<Device> _deviceRepository;
        private readonly IDeviceKeyProvider _deviceKeyProvider;
        public CreateDeviceRSAKeyCommandHandler(
            IDeviceKeyProvider deviceKeyProvider,
            IRepositoryBase<Device> deviceRepository,
            ILogger<CreateDeviceRSAKeyCommandHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _deviceRepository = deviceRepository;
            _deviceKeyProvider = deviceKeyProvider;
        }

        public override async Task<CreateDeviceRSAKeyDto> Handle(CreateDeviceRSAKeyCommand request, CancellationToken ct)
        {
            var device = await _deviceRepository.GetQueryable().Where(d => d.SerialNumber == request.SerialNumber)
                 .Include(d => d.PaymentChannel)
                 .FirstOrDefaultAsync(ct);
            if (device == null) throw new NotFoundException("Device not found");

            var key = await _deviceKeyProvider.CreateRSAKey(device.Id, ct);
            
            return new CreateDeviceRSAKeyDto
            {
                Id = key.Id ,
                KeyIdentifier = key.KeyIdentifier,
                KeyVersion = key.KeyVersion,
                Algorithm = key.Algorithm,
                KeyType = key.KeyType,
                KeyCategory = key.KeyCategory,
                OwnerType = key.OwnerType,
                OwnerId = key.OwnerId,
                ExpiresAt = key.ExpiresAt,
                PublicKey = key.PublicKeyPem,
                PrivateKey = key.PrivateKeyPem
            };
        }
    }
}
