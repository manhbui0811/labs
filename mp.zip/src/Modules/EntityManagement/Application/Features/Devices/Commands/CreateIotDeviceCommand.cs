using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public record CreateIotDeviceCommand : ITransactionalCommand<Result<IotDeviceDto>>
{
    public Guid EntityId { get; init; }
    public string DeviceCode { get; init; } = string.Empty;
    public string SerialNumber { get; init; } = string.Empty;
    public string DeviceModel { get; init; } = string.Empty;
    public string DeviceKind { get; init; } = string.Empty;
    public string? DeviceName { get; init; }
    public string? FirmwareVersion { get; init; }
    public string? NetworkType { get; init; }
}


