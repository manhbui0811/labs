﻿using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Exceptions;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Validation;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands
{
    public class DeviceProvisioningCommand : ICommand<DeviceProvisioningDto>
    {
        public string TerminalId { get; set; } = default!;
        public string SerialNumber { get; set; } = default!;
        public string? DeviceId { get; set; }
    }

    public class DeviceProvisioningCommandValidator : AbstractValidatorBase<DeviceProvisioningCommand>
    {
        protected override void ConfigureRules()
        {
            RuleFor(x => x.TerminalId).NotEmpty().WithMessage("TerminalId cannot be empty.");
            RuleFor(x => x.SerialNumber).NotEmpty().WithMessage("SerialNumber cannot be empty.");
        }
    }

    public class DeviceProvisioningCommandHandler
       : CommandHandlerBase<DeviceProvisioningCommand, DeviceProvisioningDto>
    {
        private readonly IRepositoryBase<Device> _deviceRepository;
        private readonly IDeviceKeyProvider _deviceKeyProvider;
        public DeviceProvisioningCommandHandler(
             IDeviceKeyProvider deviceKeyProvider,
            IRepositoryBase<Device> deviceRepository,
            ILogger<DeviceProvisioningCommandHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _deviceRepository = deviceRepository;
            _deviceKeyProvider = deviceKeyProvider;
        }

        public override async Task<DeviceProvisioningDto> Handle(DeviceProvisioningCommand request, CancellationToken ct)
        {

            var device = await _deviceRepository.GetQueryable().Where(d => d.SerialNumber == request.SerialNumber)
                .Include(d => d.PaymentChannel)
                .FirstOrDefaultAsync(ct);
            if (device == null) throw new NotFoundException("Device not found");

            var key = await _deviceKeyProvider.ProvisionKey(device.Id, ct);
            return new DeviceProvisioningDto
            {
                KeyId = key.KeyId,
                ApiKey = key.ApiKey,
                HmacSecret = key.HmacSecret,
                NtfyToken = "",
                ExpiresAt = key.ExpiresAt
            };
        }
    }

}
