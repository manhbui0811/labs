﻿using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands
{
    public class DeviceRotateKeyCommand : ICommand<DeviceProvisioningDto>
    {
        public string KeyId { get; set; } = default!;
    }


    public class DeviceRotateKeyCommandHandler
       : CommandHandlerBase<DeviceRotateKeyCommand, DeviceProvisioningDto>
    {
        private readonly IRepositoryBase<Device> _deviceRepository;
        private readonly IDeviceKeyProvider _deviceKeyProvider;
        public DeviceRotateKeyCommandHandler(
             IDeviceKeyProvider deviceKeyProvider,
            IRepositoryBase<Device> deviceRepository,
            ILogger<DeviceRotateKeyCommandHandler> logger,
            ICurrentUser currentUser) : base(logger, currentUser)
        {
            _deviceRepository = deviceRepository;
            _deviceKeyProvider = deviceKeyProvider;
        }

        public override async Task<DeviceProvisioningDto> Handle(DeviceRotateKeyCommand request, CancellationToken ct)
        {
       
            var key = await _deviceKeyProvider.RotateKey(request.KeyId, ct);
            return new DeviceProvisioningDto
            {
                KeyId = key.KeyId,
                ApiKey = key.ApiKey,
                HmacSecret = key.HmacSecret,
                NtfyToken = "",
                ExpiresAt = key.ExpiresAt
            };
        }
    }

}
