using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Enums;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands.Handlers;

public class AssignDeviceToPaymentChannelCommandHandler(
    ILogger<CommandHandlerBase<AssignDeviceToPaymentChannelCommand, Result>> logger,
    ICurrentUser currentUser,
    IIotDeviceRepository iotDeviceRepository,
    IPaymentChannelRepository paymentChannelRepository,
    IEntityManagementUnitOfWork unitOfWork)
    : CommandHandlerBase<AssignDeviceToPaymentChannelCommand, Result>(logger, currentUser)
{
    public override async Task<Result> Handle(AssignDeviceToPaymentChannelCommand request, CancellationToken cancellationToken)
    {
        var currentIotDevice = await iotDeviceRepository.GetByIdAsync(request.IotDeviceId, cancellationToken);
        if (currentIotDevice == null)
        {
            return Result.Failure(new Error("404", "Device not found."));
        }

        if (currentIotDevice.Status != DeviceStatus.Inactive)
        {
            return Result.Failure(new Error("404", "Device is invalid."));
        }
        return Result.Success();
    }
}