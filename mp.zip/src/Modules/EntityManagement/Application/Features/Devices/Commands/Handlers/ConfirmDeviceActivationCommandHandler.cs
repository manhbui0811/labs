// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Activation/Commands/ConfirmDeviceActivationCommandHandler.cs
using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Domain.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Activation.Commands;

public sealed class ConfirmDeviceActivationCommandHandler : IRequestHandler<ConfirmDeviceActivationCommand, Result<ConfirmDeviceActivationResult>>
{
    private readonly IDeviceActivationSessionRepository _sessionRepository;
    private readonly IEventSnapshotService _eventSnapshotService;
    private readonly IIntegrationOutboxService _integrationOutboxService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<ConfirmDeviceActivationCommandHandler> _logger;

    public ConfirmDeviceActivationCommandHandler(
        IDeviceActivationSessionRepository sessionRepository,
        IEventSnapshotService eventSnapshotService,
        IIntegrationOutboxService integrationOutboxService,
        IUnitOfWork unitOfWork,
        ILogger<ConfirmDeviceActivationCommandHandler> logger)
    {
        _sessionRepository = sessionRepository;
        _eventSnapshotService = eventSnapshotService;
        _integrationOutboxService = integrationOutboxService;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<Result<ConfirmDeviceActivationResult>> Handle(
        ConfirmDeviceActivationCommand request,
        CancellationToken cancellationToken)
    {
        try
        {
            var requestId = request.RequestId ?? Guid.NewGuid().ToString();

            _logger.LogInformation("Confirming device activation for session {SessionId}, RequestId: {RequestId}",
                request.ActivationSessionId, requestId);

            // 1. Load activation session with device and payment channel
            var session = await _sessionRepository.GetByIdWithDeviceAsync(request.ActivationSessionId, cancellationToken);
            if (session == null)
            {
                return Result.Failure<ConfirmDeviceActivationResult>(Error.Create(
                    "ActivationSession.NotFound",
                    "Activation session not found"));
            }

            // 2. Validate session is authorized
            if (!session.IsAuthorized)
            {
                _logger.LogWarning("Attempted to complete unauthorized session {SessionId}", request.ActivationSessionId);
                return Result.Failure<ConfirmDeviceActivationResult>(Error.Create(
                    "ActivationSession.NotAuthorized",
                    "Cannot complete session that is not authorized"));
            }

            // 3. Complete the session (domain rule validation inside)
            session.Complete(request.CompletionNotes);

            // 4. Validate device has payment channel
            var device = session.Device;
            var paymentChannel = device.PaymentChannel;

            if (paymentChannel == null)
            {
                return Result.Failure<ConfirmDeviceActivationResult>(Error.Create(
                    "Device.NoPaymentChannel",
                    "Device must be assigned to a payment channel before activation"));
            }

            // 5. Activate device
            device.Activate();

            // 6. Save snapshot
            var snapshot = new
            {
                SerialNumber = device.SerialNumber,
                PaymentChannelId = device.PaymentChannelId,
                MerchantCode = paymentChannel.MidCode,
                TerminalCode = paymentChannel.TidCode,
                MerchantProfileId = paymentChannel.MerchantProfileId,
                DeviceId = device.Id,
                Version = device.Version
            };

            var snapshotResult = await _eventSnapshotService.SaveSnapshotAsync(
                "IotDevice",
                device.Id,
                snapshot,
                device.Version,
                cancellationToken);

            if (!snapshotResult.IsSuccess)
            {
                _logger.LogError("Failed to save device snapshot: {Error}", snapshotResult.Error.Message);
                return Result.Failure<ConfirmDeviceActivationResult>(snapshotResult.Error);
            }

            // 7. Create and enqueue rich integration event
            var integrationEvent = new DeviceActivatedIntegrationEvent(
                device.Id,
                device.SerialNumber,
                paymentChannel.Id,
                paymentChannel.MidCode,
                paymentChannel.TidCode,
                paymentChannel.MerchantProfileId,
                correlationId: null,
                requestId: requestId);

            var enqueueResult = await _integrationOutboxService.EnqueueRichEventAsync(
                integrationEvent,
                cancellationToken);

            if (!enqueueResult.IsSuccess)
            {
                _logger.LogError("Failed to enqueue integration event: {Error}", enqueueResult.Error.Message);
                return Result.Failure<ConfirmDeviceActivationResult>(enqueueResult.Error);
            }

            // 8. Save changes in one transaction
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("Successfully confirmed device activation for device {DeviceId}, session {SessionId}",
                device.Id, session.Id);

            return Result.Success(new ConfirmDeviceActivationResult
            {
                DeviceId = device.Id,
                SessionId = session.Id,
                SerialNumber = device.SerialNumber,
                IsCompleted = session.IsCompleted,
                CompletedAt = session.CompletedAt!.Value,
                RequestId = requestId
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Domain rule violation in device activation confirmation");
            return Result.Failure<ConfirmDeviceActivationResult>(Error.Create(
                "ActivationSession.DomainViolation",
                ex.Message));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error confirming device activation for session {SessionId}",
                request.ActivationSessionId);
            return Result.Failure<ConfirmDeviceActivationResult>(Error.Create(
                "ActivationSession.ConfirmationFailed",
                "Failed to confirm device activation"));
        }
    }
}