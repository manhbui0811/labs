using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands.Handlers;

public class CreateIotDeviceCommandHandler : CommandHandlerBase<CreateIotDeviceCommand, Result<IotDeviceDto>>
{
    private readonly IIotDeviceRepository _deviceRepository;
    private readonly IEntityRepository _entityRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateIotDeviceCommandHandler(
        ILogger<CreateIotDeviceCommandHandler> logger,
        ICurrentUser currentUser,
        IIotDeviceRepository deviceRepository,
        IEntityRepository entityRepository,
        IUnitOfWork unitOfWork) : base(logger, currentUser)
    {
        _deviceRepository = deviceRepository;
        _entityRepository = entityRepository;
        _unitOfWork = unitOfWork;
    }

    public override async Task<Result<IotDeviceDto>> Handle(CreateIotDeviceCommand request, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Creating IoT device with serial: {SerialNumber}", request.SerialNumber);

        try
        {
            // Verify entity exists
            var entity = await _entityRepository.GetByIdAsync(request.EntityId, cancellationToken);
            if (entity == null)
            {
                return Result.Failure<IotDeviceDto>(new Error("ENTITY_NOT_FOUND", "Entity not found"));
            }

            // Check if device with same serial already exists
            var existingDevice = await _deviceRepository.GetBySerialNumberAsync(request.SerialNumber, cancellationToken);
            if (existingDevice != null)
            {
                return Result.Failure<IotDeviceDto>(new Error("DEVICE_ALREADY_EXISTS", 
                    "Device with this serial number already exists"));
            }

            // Create device
            var device = IotDevice.Create(request.EntityId,request.DeviceCode, request.SerialNumber, request.DeviceKind);
            
            device.UpdateInfo(request.DeviceName, request.DeviceModel, request.FirmwareVersion, request.NetworkType);

            await _deviceRepository.AddAsync(device, cancellationToken);
            
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            Logger.LogInformation("IoT device created successfully: {DeviceId}", device.Id);

            var dto = new IotDeviceDto
            {
                Id = device.Id,
                EntityId = device.EntityId,
                DeviceCode = device.DeviceCode,
                SerialNumber = device.SerialNumber,
                DeviceName = device.DeviceName,
                DeviceModel = device.DeviceModel,
                DeviceKind = device.DeviceKind,
                Status = device.Status.ToString(),
                FirmwareVersion = device.FirmwareVersion,
                NetworkType = device.NetworkType,
                CreatedAt = device.CreatedAt
            };

            return Result<IotDeviceDto>.Success(dto);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error creating IoT device with serial: {SerialNumber}", request.SerialNumber);
            return Result.Failure<IotDeviceDto>(new Error("DEVICE_CREATION_FAILED", 
                "Failed to create IoT device"));
        }
    }
}


