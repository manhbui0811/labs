﻿// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Activation/Commands/InitDeviceActivationCommandHandler.cs
using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Contracts.Persistence;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Activation.Commands;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands.Handlers;

public sealed class InitDeviceActivationCommandHandler : IRequestHandler<InitDeviceActivationCommand, Result<InitDeviceActivationResult>>
{
    private readonly IIotDeviceRepository _deviceRepository;
    private readonly IDeviceActivationSessionRepository _sessionRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<InitDeviceActivationCommandHandler> _logger;

    public InitDeviceActivationCommandHandler(
        IIotDeviceRepository deviceRepository,
        IDeviceActivationSessionRepository sessionRepository,
        IUnitOfWork unitOfWork,
        ILogger<InitDeviceActivationCommandHandler> logger)
    {
        _deviceRepository = deviceRepository;
        _sessionRepository = sessionRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<Result<InitDeviceActivationResult>> Handle(
        InitDeviceActivationCommand request,
        CancellationToken cancellationToken)
    {
        try
        {
            var requestId = request.RequestId ?? Guid.NewGuid().ToString();

            _logger.LogInformation("Initializing device activation for device {DeviceId}, RequestId: {RequestId}",
                request.DeviceId, requestId);

            // 1. Check if device exists
            var device = await _deviceRepository.GetByIdAsync(request.DeviceId, cancellationToken);
            if (device == null)
            {
                return Result.Failure<InitDeviceActivationResult>(Error.Create(
                    "Device.NotFound",
                    "Device not found"));
            }

            // 2. Check for existing active sessions
            var activeSessions = await _sessionRepository.GetActiveByDeviceIdAsync(request.DeviceId, cancellationToken);
            if (activeSessions.Any())
            {
                return Result.Failure<InitDeviceActivationResult>(Error.Create(
                    "ActivationSession.AlreadyActive",
                    "Device already has an active activation session"));
            }

            // 3. Generate session code
            var sessionCode = GenerateSessionCode();

            // 4. Create new activation session
            var expirationDuration = TimeSpan.FromMinutes(request.ExpirationMinutes);
            var session = DeviceActivationSession.Create(
                request.DeviceId,
                sessionCode,
                expirationDuration);

            await _sessionRepository.AddAsync(session, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("Successfully initialized activation session {SessionId} for device {DeviceId}",
                session.Id, request.DeviceId);

            return Result.Success(new InitDeviceActivationResult
            {
                SessionId = session.Id,
                SessionCode = session.SessionCode,
                ExpiresAt = session.ExpiresAt,
                DeviceId = device.Id,
                RequestId = requestId
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error initializing device activation for device {DeviceId}", request.DeviceId);
            return Result.Failure<InitDeviceActivationResult>(Error.Create(
                "ActivationSession.InitializationFailed",
                "Failed to initialize device activation"));
        }
    }

    private static string GenerateSessionCode()
    {
        return Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
    }
}