// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Activation/Commands/InitDeviceActivationCommand.cs

using System.ComponentModel.DataAnnotations;
using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public sealed record InitDeviceActivationCommand : ITransactionalCommand<Result<InitDeviceActivationResult>>
{
    [Required]
    public Guid DeviceId { get; init; }
    
    public int ExpirationMinutes { get; init; } = 30;
    
    public string? RequestId { get; init; }
}

public sealed record InitDeviceActivationResult
{
    public Guid SessionId { get; init; }
    public string SessionCode { get; init; } = default!;
    public DateTimeOffset ExpiresAt { get; init; }
    public Guid DeviceId { get; init; }
    public string RequestId { get; init; } = default!;
}