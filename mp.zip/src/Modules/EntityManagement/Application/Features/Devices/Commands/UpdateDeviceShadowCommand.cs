using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public record UpdateDeviceShadowCommand : ITransactionalCommand<Result>
{
    public Guid IotDeviceId { get; init; }
    public string PayloadJson { get; init; } = string.Empty;
    public string? RequestId { get; init; }
}


