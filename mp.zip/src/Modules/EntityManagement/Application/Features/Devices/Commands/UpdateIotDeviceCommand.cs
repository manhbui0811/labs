using SHT.MerchantPortal.BuildingBlocks.Application.Commands;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Commands;

public record UpdateIotDeviceCommand : ITransactionalCommand<Result>
{
    public Guid DeviceId { get; init; }
    public string? DeviceName { get; init; }
    public string? DeviceModel { get; init; }
    public string? FirmwareVersion { get; init; }
    public string? NetworkType { get; init; }
}


