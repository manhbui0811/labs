﻿using SHT.MerchantPortal.Shared.Kernel.Enums;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs
{
    public class CreateDeviceRSAKeyDto
    {
        public string Id { get; set; } = null!;
        public string KeyIdentifier { get; set; } = null!;
        public string KeyVersion { get; set; } = null!;
        public string Algorithm { get; set; } = string.Empty;
        public EncryptionType KeyType { get; set; }
        public KeyCategory KeyCategory { get; set; }
        public OwnerType OwnerType { get; set; }
        public Guid OwnerId { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public string? PublicKey { get; set; }
        public string? PrivateKey { get; set; }
    }
}
