namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

public class DeviceActivationSessionDto
{
    public Guid Id { get; set; }
    public string StateToken { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string? DeviceModel { get; set; }
    public Guid? EntityId { get; set; }
    public Guid? InitiatorUserId { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? AuthCode { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}


