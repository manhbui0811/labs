﻿namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs
{
    public class DeviceProvisioningDto
    {
        public string KeyId { get; set; } = default!;
        public string ApiKey { get; set; } = default!;
        public string HmacSecret { get; set; } = default!;
        public string? NtfyToken { get; set; } = default!;
        public DateTime? ExpiresAt { get; set; }
    }
}
