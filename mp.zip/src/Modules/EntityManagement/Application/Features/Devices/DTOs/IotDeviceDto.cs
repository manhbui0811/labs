using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

public class IotDeviceDto
{
    public Guid Id { get; set; }
    public Guid EntityId { get; set; }
    public string DeviceCode { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public string DeviceKind { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public Guid? FixedPosId { get; set; }
    public Guid? PaymentChannelId { get; set; }
    public DateTimeOffset? LastSeen { get; set; }
    public string? FirmwareVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    
    // Navigation properties
    public EntityResponseDto? Entity { get; set; }
    public MerchantProfileResponseDto? MerchantProfile { get; set; }
    public IotDeviceShadowDto? DeviceShadow { get; set; }
}


