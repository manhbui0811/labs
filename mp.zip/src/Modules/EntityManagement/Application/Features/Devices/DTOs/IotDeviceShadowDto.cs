namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

public class IotDeviceShadowDto
{
    public Guid Id { get; set; }
    public Guid IotDeviceId { get; set; }
    public string? DesiredRetainedPayload { get; set; }
    public long DesiredVersion { get; set; }
    public string? ReportedState { get; set; }
    public long ReportedVersion { get; set; }
    public DateTimeOffset? LastReportedAt { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
}


