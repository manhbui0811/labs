// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Queries/GetDeviceRoutingQuery.cs
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Queries;

public sealed record GetDeviceRoutingQuery : IQuery<Result<GetDeviceRoutingResult>>
{
    public Guid DeviceId { get; init; }
}

public sealed record GetDeviceRoutingResult
{
    public Guid DeviceId { get; init; }
    public string SerialNumber { get; init; } = default!;
    public string MerchantCode { get; init; } = default!;
    public string TerminalCode { get; init; } = default!;
    public string? Topic { get; init; }
}