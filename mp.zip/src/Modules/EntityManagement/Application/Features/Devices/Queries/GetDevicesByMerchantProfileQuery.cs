using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries;

public record GetDevicesByMerchantProfileQuery : IQuery<Result<IReadOnlyList<IotDeviceDto>>>
{
    public Guid MerchantProfileId { get; init; }
    public string? Status { get; init; }
}


