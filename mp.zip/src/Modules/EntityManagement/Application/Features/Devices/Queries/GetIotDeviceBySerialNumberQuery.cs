using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries;

public record GetIotDeviceBySerialNumberQuery : IQuery<Result<IotDeviceDto?>>
{
    public string SerialNumber { get; init; } = string.Empty;
}


