using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries;

public record GetIotDevicesByEntityQuery : IQuery<Result<IReadOnlyList<IotDeviceDto>>>
{
    public Guid EntityId { get; init; }
    public string? Status { get; init; }
    public int Skip { get; init; } = 0;
    public int Take { get; init; } = 50;
}


