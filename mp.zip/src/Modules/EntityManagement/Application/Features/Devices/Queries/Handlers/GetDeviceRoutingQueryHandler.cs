// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Application/Features/Iot/Queries/GetDeviceRoutingQueryHandler.cs
using MediatR;
using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Iot.Queries;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries.Handlers;

public sealed class GetDeviceRoutingQueryHandler : IRequestHandler<GetDeviceRoutingQuery, Result<GetDeviceRoutingResult>>
{
    private readonly IIotDeviceRepository _deviceRepository;
    private readonly ILogger<GetDeviceRoutingQueryHandler> _logger;

    public GetDeviceRoutingQueryHandler(
        IIotDeviceRepository deviceRepository,
        ILogger<GetDeviceRoutingQueryHandler> logger)
    {
        _deviceRepository = deviceRepository;
        _logger = logger;
    }

    public async Task<Result<GetDeviceRoutingResult>> Handle(
        GetDeviceRoutingQuery request,
        CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogDebug("Getting device routing for device {DeviceId}", request.DeviceId);

            var device = await _deviceRepository.GetByIdWithPaymentChannelAsync(request.DeviceId, cancellationToken);
            if (device == null)
            {
                return Result.Failure<GetDeviceRoutingResult>(Error.Create(
                    "Device.NotFound",
                    $"Device {request.DeviceId} not found"));
            }

            if (device.PaymentChannel == null)
            {
                return Result.Failure<GetDeviceRoutingResult>(Error.Create(
                    "Device.NoPaymentChannel",
                    "Device is not assigned to a payment channel"));
            }

            var topic = $"{device.SerialNumber}/data"; // Default topic format

            var result = new GetDeviceRoutingResult
            {
                DeviceId = device.Id,
                SerialNumber = device.SerialNumber,
                MerchantCode = device.PaymentChannel.MidCode,
                TerminalCode = device.PaymentChannel.TidCode,
                Topic = topic
            };

            _logger.LogDebug("Successfully retrieved device routing for device {DeviceId}", request.DeviceId);
            return Result.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting device routing for device {DeviceId}", request.DeviceId);
            return Result.Failure<GetDeviceRoutingResult>(Error.Create(
                "Device.RoutingFailed",
                "Failed to get device routing information"));
        }
    }
}