using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries.Handlers;

public class GetIotDeviceByIdQueryHandler : QueryHandlerBase<GetIotDeviceByIdQuery, Result<IotDeviceDto?>>
{
    private readonly IIotDeviceRepository _deviceRepository;

    public GetIotDeviceByIdQueryHandler(
        ILogger<GetIotDeviceByIdQueryHandler> logger,
        ICurrentUser currentUser,
        IIotDeviceRepository deviceRepository) : base(logger, currentUser)
    {
        _deviceRepository = deviceRepository;
    }

    public override async Task<Result<IotDeviceDto?>> Handle(GetIotDeviceByIdQuery request, CancellationToken cancellationToken)
    {
        Logger.LogDebug("Getting IoT device by ID: {DeviceId}", request.DeviceId);

        try
        {
            var device = await _deviceRepository.GetByIdAsync(request.DeviceId, cancellationToken);
            if (device == null)
            {
                Logger.LogWarning("IoT device not found: {DeviceId}", request.DeviceId);
                return Result.Success<IotDeviceDto?>(null);
            }

            var dto = new IotDeviceDto
            {
                Id = device.Id,
                EntityId = device.EntityId,
                DeviceCode = device.DeviceCode,
                SerialNumber = device.SerialNumber,
                DeviceName = device.DeviceName,
                DeviceModel = device.DeviceModel,
                DeviceKind = device.DeviceKind,
                Status = device.Status.ToString(),
                FixedPosId = device.FixedPosId,
                PaymentChannelId = device.PaymentChannelId,
                LastSeen = device.LastSeen,
                FirmwareVersion = device.FirmwareVersion,
                NetworkType = device.NetworkType,
                CreatedAt = device.CreatedAt,
                UpdatedAt = device.UpdatedAt
            };

            return Result<IotDeviceDto?>.Success(dto);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error getting IoT device by ID: {DeviceId}", request.DeviceId);
            return Result.Failure<IotDeviceDto?>(new Error("DEVICE_QUERY_FAILED", "Failed to get device"));
        }
    }
}


