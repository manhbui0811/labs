using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.Queries.Handlers;

public class GetIotDeviceBySerialNumberQueryHandler : QueryHandlerBase<GetIotDeviceBySerialNumberQuery, Result<IotDeviceDto?>>
{
    private readonly IIotDeviceRepository _deviceRepository;
    private readonly ICurrentUser _currentUser;

    public GetIotDeviceBySerialNumberQueryHandler(
        ILogger<GetIotDeviceBySerialNumberQueryHandler> logger,
        ICurrentUser currentUser,
        IIotDeviceRepository deviceRepository) : base(logger, currentUser)
    {
        _deviceRepository = deviceRepository;
        _currentUser = currentUser;
    }

    public override async Task<Result<IotDeviceDto?>> Handle(GetIotDeviceBySerialNumberQuery request, CancellationToken cancellationToken)
    {
        Logger.LogDebug("Getting IoT device by serial number: {SerialNumber}", request.SerialNumber);

        try
        {
            var device = await _deviceRepository.GetBySerialNumberAsync(request.SerialNumber, cancellationToken);
            if (device == null)
            {
                Logger.LogWarning("IoT device not found with serial: {SerialNumber}", request.SerialNumber);
                return Result.Success<IotDeviceDto?>(null);
            }

            var dto = new IotDeviceDto
            {
                Id = device.Id,
                EntityId = device.EntityId,
                DeviceCode = device.DeviceCode,
                SerialNumber = device.SerialNumber,
                DeviceName = device.DeviceName,
                DeviceModel = device.DeviceModel,
                DeviceKind = device.DeviceKind,
                Status = device.Status.ToString(),
                FixedPosId = device.FixedPosId,
                PaymentChannelId = device.PaymentChannelId,
                LastSeen = device.LastSeen,
                FirmwareVersion = device.FirmwareVersion,
                NetworkType = device.NetworkType,
                CreatedAt = device.CreatedAt,
                UpdatedAt = device.UpdatedAt
            };

            return Result<IotDeviceDto?>.Success(dto);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error getting IoT device by serial: {SerialNumber}", request.SerialNumber);
            return Result.Failure<IotDeviceDto?>(new Error("DEVICE_QUERY_FAILED", "Failed to get device"));
        }
    }
}


