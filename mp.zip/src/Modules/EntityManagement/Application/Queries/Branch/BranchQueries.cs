using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;

public class GetBranchByTidMidQuery : IQuery<Result<BranchResponseDto>>, IAuthorizableRequest
{
    public string? SearchText { get; set; } = string.Empty;
    public string Tid { get; set; } = string.Empty;
    public string Mid { get; set; } = string.Empty;
}
public class GetBranchQuery : IQuery<Result<BranchResponseDto>>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}
public class GetBranchesQuery : PagingRequest, IQuery<Result<PagedResult<BranchResponseDto>>>, IAuthorizableRequest
{
    public string? SearchText { get; set; }
}
public class GetBranchesByEntityQuery : GetBranchesQuery
{
    public Guid EntityId { get; set; }
}

