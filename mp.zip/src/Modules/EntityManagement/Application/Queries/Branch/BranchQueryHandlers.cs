using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Branch;


public class GetBranchByTidMidQueryHandler(
    ILogger<QueryHandlerBase<GetBranchByTidMidQuery, Result<BranchResponseDto>>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository)
    : QueryHandlerBase<GetBranchByTidMidQuery, Result<BranchResponseDto>>(logger, currentUser)
{
    public override async Task<Result<BranchResponseDto>> Handle(GetBranchByTidMidQuery request, CancellationToken cancellationToken)
    {
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<BranchResponseDto>(new Error("403",
                "You cannot perform this action."));
        }
        
        var result = await branchRepository.GetByTidMid(request.Tid, request.Mid, cancellationToken);
        return !result.IsSuccess ? Result.Failure<BranchResponseDto>(result.Error) : result;
    }
}
public class GetBranchQueryHandler(
    ILogger<QueryHandlerBase<GetBranchQuery, Result<BranchResponseDto>>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository) : QueryHandlerBase<GetBranchQuery, Result<BranchResponseDto>>(logger, currentUser)
{
    public override async Task<Result<BranchResponseDto>> Handle(GetBranchQuery request, CancellationToken cancellationToken)
    {
        var branchResponse = await branchRepository.Get(request.Id, cancellationToken);
        return Result.Success(branchResponse.Payload);
    }
}

public class GetBranchesQueryHandler(
    ILogger<QueryHandlerBase<GetBranchesQuery, Result<PagedResult<BranchResponseDto>>>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository) : QueryHandlerBase<GetBranchesQuery, Result<PagedResult<BranchResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<BranchResponseDto>>> Handle(GetBranchesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<BranchResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var branchResponse = await branchRepository.GetAll(pagingRequest, null,  request.SearchText, cancellationToken);
            return Result.Success(branchResponse.Payload);
        }
        else
        {
            var branchResponse = await branchRepository.GetAll(pagingRequest, currentUser.UserId,  request.SearchText, cancellationToken);
            return Result.Success(branchResponse.Payload);
        }
    }
}

public class GetBranchesByEntityQueryHandler(
    ILogger<QueryHandlerBase<GetBranchesByEntityQuery, Result<PagedResult<BranchResponseDto>>>> logger,
    ICurrentUser currentUser,
    IBranchRepository branchRepository) : QueryHandlerBase<GetBranchesByEntityQuery, Result<PagedResult<BranchResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<BranchResponseDto>>> Handle(GetBranchesByEntityQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var branchResponse = await branchRepository.GetByEntity(request.EntityId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(branchResponse.Payload);
    }
}