using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Department;

public class GetDepartmentQuery : IQuery<Result<DepartmentResponseDto>>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class GetDepartmentsQuery : PagingRequest, IQuery<Result<PagedResult<DepartmentResponseDto>>>
{
    public string? SearchText { get; set; }
}

public class GetDepartmentsByEntityQuery : PagingRequest, IQuery<Result<PagedResult<DepartmentResponseDto>>>, IAuthorizableRequest
{
    public Guid EntityId { get; set; }
    public string? SearchText { get; set; }
}