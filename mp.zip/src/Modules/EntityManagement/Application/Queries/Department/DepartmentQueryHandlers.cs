using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Department;

public class GetDepartmentQueryHandler(
    ILogger<QueryHandlerBase<GetDepartmentQuery, Result<DepartmentResponseDto>>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository) : QueryHandlerBase<GetDepartmentQuery, Result<DepartmentResponseDto>>(logger, currentUser)
{
    public override async Task<Result<DepartmentResponseDto>> Handle(GetDepartmentQuery request, CancellationToken cancellationToken)
    {
        var getDepartmentResult = await departmentRepository.Get(request.Id, cancellationToken);
        
        return  Result.Success(getDepartmentResult.Payload);
    }
}

public class GetDepartmentsQueryHandler(
    ILogger<QueryHandlerBase<GetDepartmentsQuery, Result<PagedResult<DepartmentResponseDto>>>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository) : QueryHandlerBase<GetDepartmentsQuery, Result<PagedResult<DepartmentResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<DepartmentResponseDto>>> Handle(GetDepartmentsQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var getDepartmentsResult = await departmentRepository.GetAll(pagingRequest, request.SearchText, cancellationToken);

        return  Result.Success(getDepartmentsResult.Payload);
    }
}

public class GetDepartmentsByEntityQueryHandler(
    ILogger<QueryHandlerBase<GetDepartmentsByEntityQuery, Result<PagedResult<DepartmentResponseDto>>>> logger,
    ICurrentUser currentUser,
    IDepartmentRepository departmentRepository) : QueryHandlerBase<GetDepartmentsByEntityQuery, Result<PagedResult<DepartmentResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<DepartmentResponseDto>>> Handle(GetDepartmentsByEntityQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var getDepartmentsResult = await departmentRepository.GetByEntity(request.EntityId, pagingRequest, request.SearchText, cancellationToken);
        return  Result.Success(getDepartmentsResult.Payload);
    }
}