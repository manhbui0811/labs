using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Device;

public class GetDeviceQuery : IQuery<Result<DeviceResponseDto>>
{
    public Guid Id { get; set; }
}

public class GetDevicesQuery : PagingRequest, IQuery<Result<PagedResult<DeviceResponseDto>>>
{
    public string? SearchText { get; set; }
}

public class GetDevicesByEntityQuery : PagingRequest, IQuery<Result<PagedResult<DeviceResponseDto>>>
{
    public string? SearchText { get; set; }
    public Guid EntityId { get; set; }
}

public class GetDevicesInformationQuery : IQuery<Result<DevicesInformationRespsonseDto>>
{
    public Guid? PosId { get; set; }
    public Guid? MerchantId { get; set; }
    public PosStatus? Status { get; set; } = null;
    public int? BatteryLevel { get; set; }
    public int? Latency { get; set; }
}