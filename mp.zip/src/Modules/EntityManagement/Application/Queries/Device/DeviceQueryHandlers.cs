using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Device;

public class GetDeviceQueryHandler(
    ILogger<QueryHandlerBase<GetDeviceQuery, Result<DeviceResponseDto>>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository) : QueryHandlerBase<GetDeviceQuery, Result<DeviceResponseDto>>(logger, currentUser)
{
    public override async Task<Result<DeviceResponseDto>> Handle(GetDeviceQuery request, CancellationToken cancellationToken)
    {
        var deviceResponse = await deviceRepository.Get(request.Id, cancellationToken);
        return Result.Success(deviceResponse.Payload);
    }
}

public class GetDevicesByEntityQueryHandler(
    ILogger<QueryHandlerBase<GetDevicesByEntityQuery, Result<PagedResult<DeviceResponseDto>>>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository) : QueryHandlerBase<GetDevicesByEntityQuery, Result<PagedResult<DeviceResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<DeviceResponseDto>>> Handle(GetDevicesByEntityQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var deviceResponse = await deviceRepository.GetByEntity(request.EntityId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(deviceResponse.Payload);
    }
}

public class GetDevicesQueryHandler(
    ILogger<QueryHandlerBase<GetDevicesQuery, Result<PagedResult<DeviceResponseDto>>>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository) : QueryHandlerBase<GetDevicesQuery, Result<PagedResult<DeviceResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<DeviceResponseDto>>> Handle(GetDevicesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<DeviceResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var deviceResponse = await deviceRepository.GetAll(pagingRequest, null,  request.SearchText, cancellationToken);
            return Result.Success(deviceResponse.Payload);
        }
        else
        {
            var deviceResponse = await deviceRepository.GetAll(pagingRequest, currentUser.UserId,  request.SearchText, cancellationToken);
            return Result.Success(deviceResponse.Payload);
        }
    }
}

public class GetDevicesInformationQueryHandler(
    ILogger<QueryHandlerBase<GetDevicesInformationQuery, Result<DevicesInformationRespsonseDto>>> logger,
    ICurrentUser currentUser,
    IDeviceRepository deviceRepository) : QueryHandlerBase<GetDevicesInformationQuery, Result<DevicesInformationRespsonseDto>>(logger, currentUser)
{
    public override async Task<Result<DevicesInformationRespsonseDto>> Handle(GetDevicesInformationQuery request, CancellationToken cancellationToken)
    {
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<DevicesInformationRespsonseDto>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var result = await deviceRepository.GetDevicesInformation(
                null,
                request.MerchantId, 
                request.PosId, 
                request.Status, 
                request.BatteryLevel, 
                request.Latency, 
                cancellationToken);
            return result;
        }
        else
        {
            var result = await deviceRepository.GetDevicesInformation(
                currentUser.UserId,
                request.MerchantId, 
                request.PosId, 
                request.Status, 
                request.BatteryLevel, 
                request.Latency, 
                cancellationToken);
            return result;
        }
    }
}