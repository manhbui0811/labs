using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

public class GetEntityQuery : IQuery<Result<EntityResponseDto>>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class GetEntitiesQuery : PagingRequest, IQuery<Result<PagedResult<EntityResponseDto>>>, IAuthorizableRequest
{
    public string? SearchText { get; set; }
    public bool NewView { get; set; } = false;
}

public class GetEntitiesByUserQuery : GetEntitiesQuery
{
    public Guid UserId { get; set; }
}

public class GetEntitiesByEntityStructureQuery : GetEntitiesQuery
{
    public Guid EntityStructureId { get; set; }
}

public class GetListChildEntitiesQuery : PagingRequest, IQuery<Result<PagedResult<EntityResponseDto>>>, IAuthorizableRequest
{
    public Guid ParentId { get; set; }
    public string? SeachText { get; set; }
}

public class GetNoChildEntitiesQuery : IQuery<Result<List<EntityResponseDto>>>, IAuthorizableRequest
{
    public Guid? UserId { get; set; } = null;
    public string? SearchText { get; set; }
}