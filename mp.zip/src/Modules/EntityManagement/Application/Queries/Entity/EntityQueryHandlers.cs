using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.Entity;

public class GetEntityQueryHandler(
    ILogger<QueryHandlerBase<GetEntityQuery, Result<EntityResponseDto>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository)
    : QueryHandlerBase<GetEntityQuery, Result<EntityResponseDto>>(logger, currentUser)
{
    public override async Task<Result<EntityResponseDto>> Handle(GetEntityQuery request, CancellationToken cancellationToken)
    {
        var getEntityResult = await entityRepository.Get(request.Id);
        if (!getEntityResult.IsSuccess)
        {
            return Result.Failure<EntityResponseDto>(getEntityResult.Errors);
        }
        
        return Result.Success(getEntityResult.Payload);
    }
}

public class GetEntitiesQueryHandler(
    ILogger<QueryHandlerBase<GetEntitiesQuery, Result<PagedResult<EntityResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository) : QueryHandlerBase<GetEntitiesQuery, Result<PagedResult<EntityResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<EntityResponseDto>>> Handle(GetEntitiesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<EntityResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var getEntitiesResults = await entityRepository.GetAll(pagingRequest, request.NewView, request.SearchText, cancellationToken);
            return  Result.Success(getEntitiesResults.Payload);
        }

        if (request.NewView)
        {
            var getEntitiesResults = await entityRepository.GetNoParentEntities(pagingRequest, currentUser.UserId??Guid.Empty, request.SearchText, cancellationToken);
            return  Result.Success(getEntitiesResults.Payload);
            
        }
        else
        {
            var getEntitiesResults = await entityRepository.GetByUser(currentUser.UserId??Guid.Empty, pagingRequest, request.SearchText, cancellationToken);
            return  Result.Success(getEntitiesResults.Payload);
        }
    }
}

public class GetEntitiesByUserQueryHandler(
    ILogger<QueryHandlerBase<GetEntitiesByUserQuery, Result<PagedResult<EntityResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository) : QueryHandlerBase<GetEntitiesByUserQuery, Result<PagedResult<EntityResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<EntityResponseDto>>> Handle(GetEntitiesByUserQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var getEntitiesResult = await entityRepository.GetByUser(request.UserId, pagingRequest, request.SearchText, cancellationToken);
        return getEntitiesResult;
    }
}

public class GetEntitiesByEntityStructureQueryHandler(
    ILogger<QueryHandlerBase<GetEntitiesByEntityStructureQuery, Result<PagedResult<EntityResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository) : QueryHandlerBase<GetEntitiesByEntityStructureQuery, Result<PagedResult<EntityResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<EntityResponseDto>>> Handle(GetEntitiesByEntityStructureQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<EntityResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var getEntitiesResult = await entityRepository.GetByEntityStructure(request.EntityStructureId, pagingRequest, null, request.SearchText, cancellationToken);
            return getEntitiesResult;
        }
        else
        {
            var getEntitiesResult = await entityRepository.GetByEntityStructure(request.EntityStructureId, pagingRequest, currentUser.UserId, request.SearchText, cancellationToken);
            return getEntitiesResult;
        }
        
    }
}

public class GetListChildEntitiesQueryHandler(
    ILogger<QueryHandlerBase<GetListChildEntitiesQuery, Result<PagedResult<EntityResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository) : QueryHandlerBase<GetListChildEntitiesQuery, Result<PagedResult<EntityResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<EntityResponseDto>>> Handle(GetListChildEntitiesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageSize = request.PageSize,
            PageNumber = request.PageNumber,
        };
        var results = await entityRepository.GetListChilds(pagingRequest, request.ParentId, request.SeachText, cancellationToken);
        
        return  Result.Success(results.Payload);
    }
}

public class GetNoChildEntitiesQueryHandler(
    ILogger<QueryHandlerBase<GetNoChildEntitiesQuery, Result<List<EntityResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityRepository entityRepository) : QueryHandlerBase<GetNoChildEntitiesQuery, Result<List<EntityResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<List<EntityResponseDto>>> Handle(GetNoChildEntitiesQuery request, CancellationToken cancellationToken)
    {
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<List<EntityResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var results = await entityRepository.GetNoChildEntities(request.UserId, request.SearchText, cancellationToken);
            return results;
        }
        else
        {
            var results = await entityRepository.GetNoChildEntities(currentUser.UserId, request.SearchText, cancellationToken);
            return results;
        }
        
    }
}