using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.EntityStructure;

public class GetEntityStructureQuery : IQuery<Result<EntityStructureResponseDto>>
{
    public Guid Id { get; set; }
}

public class GetEntityStructuresQuery : PagingRequest, IQuery<Result<PagedResult<EntityStructureResponseDto>>>
{
    public string? SearchText { get; set; }
}