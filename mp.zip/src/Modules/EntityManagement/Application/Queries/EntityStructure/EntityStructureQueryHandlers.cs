using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.EntityStructure;

public class GetEntityStructureQueryHandler(
    ILogger<QueryHandlerBase<GetEntityStructureQuery, Result<EntityStructureResponseDto>>> logger,
    ICurrentUser currentUser,
    IEntityStructureRepository entityStructureRepository) : QueryHandlerBase<GetEntityStructureQuery, Result<EntityStructureResponseDto>>(logger, currentUser)
{
    public override async Task<Result<EntityStructureResponseDto>> Handle(GetEntityStructureQuery request, CancellationToken cancellationToken)
    {
        var entityStructureResult = await entityStructureRepository.Get(request.Id, cancellationToken);
        if (entityStructureResult.IsFailure)
        {
            return Result.Failure<EntityStructureResponseDto>(entityStructureResult.Errors);
        }
        
        return entityStructureResult.Payload == null ? Result.Failure<EntityStructureResponseDto>(new Error("404","EntityStructure not found")) : entityStructureResult;
    }
}

public class GetEntityStructuresQueryHandler(
    ILogger<QueryHandlerBase<GetEntityStructuresQuery, Result<PagedResult<EntityStructureResponseDto>>>> logger,
    ICurrentUser currentUser,
    IEntityStructureRepository entityStructureRepository) : QueryHandlerBase<GetEntityStructuresQuery, Result<PagedResult<EntityStructureResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<EntityStructureResponseDto>>> Handle(GetEntityStructuresQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        var entityStructureResult = await entityStructureRepository.GetAll(pagingRequest, request.SearchText, cancellationToken);
        
        return entityStructureResult;
    }
}