using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.IotDevice;

