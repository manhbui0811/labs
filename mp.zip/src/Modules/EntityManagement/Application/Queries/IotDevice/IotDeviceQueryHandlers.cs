using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts.Repositories;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.JobTitle;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.IotDevice;

// public class IotDeviceQueryHandler(
//     ILogger<QueryHandlerBase<GetIotDeviceQuery, Result<IotDeviceResponseDto>>> logger,
//     ICurrentUser currentUser,
//     IIotDeviceRepository iotDeviceRepository) : QueryHandlerBase<GetIotDeviceQuery, Result<IotDeviceResponseDto>>(logger, currentUser)
// {
//     public override async Task<Result<IotDeviceResponseDto>> Handle(GetIotDeviceQuery request, CancellationToken cancellationToken)
//     {
//         throw new NotImplementedException();
//     }
// }