using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.JobTitle;

public class GetJobTitleQuery : IQuery<Result<JobTitleResponseDto>>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class GetJobTitlesQuery : PagingRequest, IQuery<Result<PagedResult<JobTitleResponseDto>>>
{
    public string? SearchText { get; set; }
}

public class GetJobTitlesByEntityQuery : PagingRequest, IQuery<Result<PagedResult<JobTitleResponseDto>>>, IAuthorizableRequest
{
    public string? SearchText { get; set; }
    public Guid EntityId { get; set; }
}