using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.JobTitle;

public class GetJobTitleQueryHandler(
    ILogger<QueryHandlerBase<GetJobTitleQuery, Result<JobTitleResponseDto>>> logger,
    ICurrentUser currentUser,
    IJobTitleRepository jobTitleRepository) : QueryHandlerBase<GetJobTitleQuery, Result<JobTitleResponseDto>>(logger, currentUser)
{
    public override async Task<Result<JobTitleResponseDto>> Handle(GetJobTitleQuery request, CancellationToken cancellationToken)
    {
        var jobTitleResponse = await jobTitleRepository.Get(request.Id, cancellationToken);
        return Result.Success(jobTitleResponse.Payload);
    }
}

public class GetJobTitlesQueryHandler(
    ILogger<QueryHandlerBase<GetJobTitlesQuery, Result<PagedResult<JobTitleResponseDto>>>> logger,
    ICurrentUser currentUser,
    IJobTitleRepository jobTitleRepository) : QueryHandlerBase<GetJobTitlesQuery, Result<PagedResult<JobTitleResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<JobTitleResponseDto>>> Handle(GetJobTitlesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var jobTitleResponse = await jobTitleRepository.GetAll(pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(jobTitleResponse.Payload);
    }
}

public class GetJobTitlesByEntityQueryHandler(
    ILogger<QueryHandlerBase<GetJobTitlesByEntityQuery, Result<PagedResult<JobTitleResponseDto>>>> logger,
    ICurrentUser currentUser,
    IJobTitleRepository jobTitleRepository) : QueryHandlerBase<GetJobTitlesByEntityQuery, Result<PagedResult<JobTitleResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<JobTitleResponseDto>>> Handle(GetJobTitlesByEntityQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var jobTitleResponse = await jobTitleRepository.GetByEntity(request.EntityId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(jobTitleResponse.Payload);
    }
}