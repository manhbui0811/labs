using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.MerchantProfile;

public class GetMerchantProfileQuery : IQuery<Result<MerchantProfileResponseDto>>
{
    public Guid Id { get; set; }
}

public class GetMerchantProfilesByUserQuery : IQuery<Result<List<MerchantProfileResponseDto>>>
{
    public string? SearchText { get; set; }
}

public class GetMerchantProfilesQuery : PagingRequest, IQuery<Result<PagedResult<MerchantProfileResponseDto>>>
{
    public string? SearchText { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    public Guid? AcquiringBankId { get; set; } = null;
    public EntityStatus? Status { get; set; } = null;
    public Guid? EntityId { get; set; } = null;
}

public class GetMerchantProfilesByEntityQuery : PagingRequest, IQuery<Result<PagedResult<MerchantProfileResponseDto>>>
{
    public string? SearchText { get; set; }
    public Guid EntityId { get; set; }
}