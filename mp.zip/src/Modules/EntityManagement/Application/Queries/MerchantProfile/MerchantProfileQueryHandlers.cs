using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.MerchantProfile;

public class GetMerchantProfileQueryHandler(
    ILogger<QueryHandlerBase<GetMerchantProfileQuery, Result<MerchantProfileResponseDto>>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository) : QueryHandlerBase<GetMerchantProfileQuery, Result<MerchantProfileResponseDto>>(logger, currentUser)
{
    public override async Task<Result<MerchantProfileResponseDto>> Handle(GetMerchantProfileQuery request, CancellationToken cancellationToken)
    {
        var merchantProfileResponse = await merchantProfileRepository.Get(request.Id, cancellationToken);
        return Result.Success(merchantProfileResponse.Payload);
    }
}

public class GetMerchantProfilesByUserQueryHandler(
    ILogger<QueryHandlerBase<GetMerchantProfilesByUserQuery, Result<List<MerchantProfileResponseDto>>>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository) : QueryHandlerBase<GetMerchantProfilesByUserQuery, Result<List<MerchantProfileResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<List<MerchantProfileResponseDto>>> Handle(GetMerchantProfilesByUserQuery request, CancellationToken cancellationToken)
    {
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<List<MerchantProfileResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        var merchantProfileResponse = await merchantProfileRepository.GetByUser(
            userName.Equals("system_admin") ? null : currentUser.UserId,
            request.SearchText,
            cancellationToken);
        return Result.Success(merchantProfileResponse.Payload);
    }
}

public class GetMerchantProfilesQueryHandler(
    ILogger<QueryHandlerBase<GetMerchantProfilesQuery, Result<PagedResult<MerchantProfileResponseDto>>>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository) : QueryHandlerBase<GetMerchantProfilesQuery, Result<PagedResult<MerchantProfileResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<MerchantProfileResponseDto>>> Handle(GetMerchantProfilesQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<MerchantProfileResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        var merchantProfileResponse = await merchantProfileRepository.GetAll(
            pagingRequest,
            userName.Equals("system_admin") ? null : currentUser.UserId,
            request.AcquiringBankId,
            request.Status,
            request.EntityId,
            request.SearchText,
            request.FromDate,
            request.ToDate,
            cancellationToken);
        return Result.Success(merchantProfileResponse.Payload);
    }
}

public class GetMerchantProfilesByEntityQueryHandler(
    ILogger<QueryHandlerBase<GetMerchantProfilesByEntityQuery, Result<PagedResult<MerchantProfileResponseDto>>>> logger,
    ICurrentUser currentUser,
    IMerchantProfileRepository merchantProfileRepository) : QueryHandlerBase<GetMerchantProfilesByEntityQuery, Result<PagedResult<MerchantProfileResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<MerchantProfileResponseDto>>> Handle(GetMerchantProfilesByEntityQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var merchantProfileResponse = await merchantProfileRepository.GetByEntity(request.EntityId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(merchantProfileResponse.Payload);
    }
}