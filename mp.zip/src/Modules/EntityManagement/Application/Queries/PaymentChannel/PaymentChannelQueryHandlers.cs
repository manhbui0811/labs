using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PaymentChannel;

public class GetPaymentChannelQueryHandler(
    ILogger<QueryHandlerBase<GetPaymentChannelQuery, Result<PaymentChannelResponseDto>>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository) : QueryHandlerBase<GetPaymentChannelQuery, Result<PaymentChannelResponseDto>>(logger, currentUser)
{
    public override async Task<Result<PaymentChannelResponseDto>> Handle(GetPaymentChannelQuery request, CancellationToken cancellationToken)
    {
        var paymentChannelResponse = await paymentChannelRepository.Get(request.Id, cancellationToken);
        return Result.Success(paymentChannelResponse.Payload);
    }
}

public class GetPaymentChannelsQueryHandler(
    ILogger<QueryHandlerBase<GetPaymentChannelsQuery, Result<PagedResult<PaymentChannelResponseDto>>>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository) : QueryHandlerBase<GetPaymentChannelsQuery, Result<PagedResult<PaymentChannelResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<PaymentChannelResponseDto>>> Handle(GetPaymentChannelsQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var userName = currentUser.KeycloakSubject;
        if (string.IsNullOrEmpty(userName))
        {
            return Result.Failure<PagedResult<PaymentChannelResponseDto>>(new Error("401",
                "You cannot perform this action."));
        }
        
        if (userName.Equals("system_admin"))
        {
            var getEntitiesResults = await paymentChannelRepository.GetAll(pagingRequest, null, request.SearchText, cancellationToken);
            return  Result.Success(getEntitiesResults.Payload);
        }
        else
        {
            var getEntitiesResults = await paymentChannelRepository.GetAll(pagingRequest, currentUser.UserId, request.SearchText, cancellationToken);
            return  Result.Success(getEntitiesResults.Payload);
        }
        
    }
}

public class GetPaymentChannelByPointOfSaleQueryHandler(
    ILogger<QueryHandlerBase<GetPaymentChannelByPointOfSaleQuery, Result<PagedResult<PaymentChannelResponseDto>>>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository) : QueryHandlerBase<GetPaymentChannelByPointOfSaleQuery, Result<PagedResult<PaymentChannelResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<PaymentChannelResponseDto>>> Handle(GetPaymentChannelByPointOfSaleQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var paymentChannelResponse = await paymentChannelRepository.GetByPointOfSale(request.PointOfSaleId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(paymentChannelResponse.Payload);
    }
}

public class GetPaymentChannelByMerchantProfileQueryHandler(
    ILogger<QueryHandlerBase<GetPaymentChannelByMerchantProfileQuery, Result<PagedResult<PaymentChannelResponseDto>>>> logger,
    ICurrentUser currentUser,
    IPaymentChannelRepository paymentChannelRepository) : QueryHandlerBase<GetPaymentChannelByMerchantProfileQuery, Result<PagedResult<PaymentChannelResponseDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<PaymentChannelResponseDto>>> Handle(GetPaymentChannelByMerchantProfileQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var paymentChannelResponse = await paymentChannelRepository.GetByMerchantProfile(request.MerchantProfileId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(paymentChannelResponse.Payload);
    }
}