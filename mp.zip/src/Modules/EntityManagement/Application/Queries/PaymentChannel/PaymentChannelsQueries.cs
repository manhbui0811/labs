using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PaymentChannel;

public class GetPaymentChannelQuery : IQuery<Result<PaymentChannelResponseDto>>
{
    public Guid Id { get; set; }
}

public class GetPaymentChannelsQuery : PagingRequest, IQuery<Result<PagedResult<PaymentChannelResponseDto>>>
{
    public string? SearchText { get; set; }
}

public class GetPaymentChannelByPointOfSaleQuery : PagingRequest, IQuery<Result<PagedResult<PaymentChannelResponseDto>>>
{
    public string? SearchText { get; set; }
    public Guid PointOfSaleId { get; set; }
}

public class GetPaymentChannelByMerchantProfileQuery : PagingRequest, IQuery<Result<PagedResult<PaymentChannelResponseDto>>>
{
    public string? SearchText { get; set; }
    public Guid MerchantProfileId { get; set; }
}