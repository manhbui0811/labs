using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PointsOfSale;

public class GetPointOfSaleQuery : IQuery<Result<PointsOfSaleRepsoneDto>>, IAuthorizableRequest
{
    public Guid Id { get; set; }
}

public class GetPointsOfSaleQuery : PagingRequest, IQuery<Result<PagedResult<PointsOfSaleRepsoneDto>>>
{
    public string? SearchText { get; set; }
}

public class GetPointsOfSaleByBranchQuery : PagingRequest, IQuery<Result<PagedResult<PointsOfSaleRepsoneDto>>>
{
    public string? SearchText { get; set; }
    public Guid BranchId { get; set; }
}