using Microsoft.Extensions.Logging;
using SHT.MerchantPortal.BuildingBlocks.Application.Interfaces;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.BuildingBlocks.Application.Queries;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Contracts;
using SHT.MerchantPortal.Modules.EntityManagement.Application.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Queries.PointsOfSale;

public class GetPointOfSaleQueryHandler(
    ILogger<QueryHandlerBase<GetPointOfSaleQuery, Result<PointsOfSaleRepsoneDto>>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository) : QueryHandlerBase<GetPointOfSaleQuery, Result<PointsOfSaleRepsoneDto>>(logger, currentUser)
{
    public override async Task<Result<PointsOfSaleRepsoneDto>> Handle(GetPointOfSaleQuery request, CancellationToken cancellationToken)
    {
        var PointsOfSaleResponse = await pointOfSaleRepository.Get(request.Id, cancellationToken);
        return Result.Success(PointsOfSaleResponse.Payload);
    }
}

public class GetPointsOfSaleQueryHandler(
    ILogger<QueryHandlerBase<GetPointsOfSaleQuery, Result<PagedResult<PointsOfSaleRepsoneDto>>>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository) : QueryHandlerBase<GetPointsOfSaleQuery, Result<PagedResult<PointsOfSaleRepsoneDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<PointsOfSaleRepsoneDto>>> Handle(GetPointsOfSaleQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var PointsOfSaleResponse = await pointOfSaleRepository.GetAll(pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(PointsOfSaleResponse.Payload);
    }
}

public class GetPointsOfSaleByBranchQueryHandler(
    ILogger<QueryHandlerBase<GetPointsOfSaleByBranchQuery, Result<PagedResult<PointsOfSaleRepsoneDto>>>> logger,
    ICurrentUser currentUser,
    IPointOfSaleRepository pointOfSaleRepository) : QueryHandlerBase<GetPointsOfSaleByBranchQuery, Result<PagedResult<PointsOfSaleRepsoneDto>>>(logger, currentUser)
{
    public override async Task<Result<PagedResult<PointsOfSaleRepsoneDto>>> Handle(GetPointsOfSaleByBranchQuery request, CancellationToken cancellationToken)
    {
        var pagingRequest = new PagingRequest
        {
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        };
        
        var PointsOfSaleResponse = await pointOfSaleRepository.GetByBranch(request.BranchId, pagingRequest, request.SearchText, cancellationToken);
        return Result.Success(PointsOfSaleResponse.Payload);
    }
}