using SHT.MerchantPortal.BuildingBlocks.Application.Models;
using SHT.MerchantPortal.Modules.EntityManagement.Application.Features.Devices.DTOs;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Services;

public interface IDeviceActivationService
{
    Task<Result<DeviceActivationSessionDto>> InitiateActivationAsync(string serialNumber, string? deviceModel = null, Guid? initiatorUserId = null, CancellationToken cancellationToken = default);
    Task<Result> ConfirmActivationAsync(string stateToken, Guid merchantProfileId, Guid? posId = null, string? requestId = null, CancellationToken cancellationToken = default);
    Task<Result<DeviceActivationSessionDto?>> GetActivationSessionAsync(string stateToken, CancellationToken cancellationToken = default);
    Task<Result> ExpireOldSessionsAsync(CancellationToken cancellationToken = default);
}


