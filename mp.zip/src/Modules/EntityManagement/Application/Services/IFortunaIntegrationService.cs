﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SHT.MerchantPortal.BuildingBlocks.Application.Models;

namespace SHT.MerchantPortal.Modules.EntityManagement.Application.Services
{
    public interface IFortunaIntegrationService
    {
        Task<Result> SendDeviceConfigurationAsync(Guid deviceId, object payload, string? requestId = null,
            CancellationToken cancellationToken = default);
        Task<Result> SendQrConfigurationAsync(Guid deviceId, string qrPayload, string? requestId = null, CancellationToken cancellationToken = default);
        Task<Result> NotifyDeviceActivatedAsync(Guid deviceId, Guid merchantProfileId, string? requestId = null, CancellationToken cancellationToken = default);
    }
}
