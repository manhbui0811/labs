namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Common;

public class GenericResponse
{
    public GenericResponse(bool isSuccess, string code, string message, string description)
    {
        IsSuccess = isSuccess;
        Code = code;
        Message = message;
        Description = description;
    }
    public bool IsSuccess { get; set; }
    public string Code { get; set; }
    public string? Message { get; set; }
    public string? Description { get; set; }

    public static GenericResponse SuccessResponse(string message = "", string description = "")
    {
        return new GenericResponse(true, "00", message, description);
    }
    
    public static GenericResponse FailureResponse(string code = "01", string message = "", string description = "")
    {
        return new GenericResponse(false, code, message, description);
    }
}

public class GenericResponse<T>(T result, bool isSuccess, string code, string message, string description) 
    : GenericResponse(isSuccess, code, message, description)
{
    public T Result { get; set; }
    public static GenericResponse<T> SuccessResponse(T result, string message = "", string description = "")
    {
        return new GenericResponse<T>(result, true, "00", message, description);
    }
    
    public new static GenericResponse<T> FailureResponse(string code = "01", string message = "", string description = "")
    {
        return new GenericResponse<T>(default, false, code, message, description);
    }
}