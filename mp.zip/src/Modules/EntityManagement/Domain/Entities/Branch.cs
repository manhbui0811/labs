using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Một chi nhánh vật lý thuộc một Entity
/// </summary>
public class Branch : FullAuditedAggregateRoot
{
    public Branch? ParentBranch { get; set; }
    public Guid? ParentBranchId { get; set; }
    public required string BranchCode { get; set; }
    public required string Name { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public string? Phone { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;

    // Khóa ngoại
    public Guid EntityId { get; set; }

    // Navigation properties
    public ICollection<Branch> ChildBranches { get; set; } = new List<Branch>();
    public virtual Entity Entity { get; set; } = null!;
    public virtual ICollection<PointOfSale> PointsOfSale { get; set; } = new List<PointOfSale>();
    
}