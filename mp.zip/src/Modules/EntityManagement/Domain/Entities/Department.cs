using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;


/// <summary>
/// Quản lý các phòng ban trong một entity.
/// </summary>
public class Department : FullAuditedAggregateRoot
{
    public Guid EntityId { get; set; }
    public Guid? ParentDepartmentId { get; set; }
    public required string DepartmentCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public virtual Entity Entity { get; set; } = null!;
    
    // Thuộc tính tham chiếu đến Department cha (có thể null nếu nó là gốc)
    public virtual Department? ParentDepartment { get; set; }

    // Thuộc tính collection chứa danh sách các Department con trực tiếp
    public virtual ICollection<Department> ChildDepartments { get; set; } = new List<Department>();
}