using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Các thiết bị POS vật lý
/// </summary>
public class Device : FullAuditedAggregateRoot
{
    public required string SerialNumber { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceModel { get; set; }
    public required string DeviceType { get; set; }
    public string? FcmToken { get; set; }
    public PosStatus Status { get; set; } = PosStatus.Unknown;
    public int? BatteryLevel { get; set; }
    public string? AppVersion { get; set; }
    public string? NetworkType { get; set; }
    public DateTime? LastSeen { get; set; }
    public double? CurrentLatitude { get; set; }
    public double? CurrentLongitude { get; set; }
    public DateTime? LocationUpdatedAt { get; set; }
    public string Provider { get; set; }
    public int? Latency { get; set; }
    
    // Khóa ngoại
    public Guid? PaymentChannelId { get; set; }
    public Guid EntityId { get; set; }
    
    // Navigation properties
    public virtual PaymentChannel? PaymentChannel { get; set; } = null!;
    public virtual Entity Entity { get; set; } = null!;
    public virtual ICollection<DeviceLocationHistory> DeviceLocationHistories { get; set; } = new List<DeviceLocationHistory>();
    public virtual ICollection<DeviceStatusHistory> DeviceStatusHistories { get; set; } = new List<DeviceStatusHistory>();
    public virtual ICollection<DeviceMerchantProfile> DeviceMerchantProfiles { get; set; } = new List<DeviceMerchantProfile>();
}