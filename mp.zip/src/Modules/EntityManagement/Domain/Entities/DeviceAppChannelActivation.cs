using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;


/// <summary>
/// Kích hoạt một kênh thanh toán cụ thể trên một cấu hình device-merchant.
/// </summary>
public class DeviceAppChannelActivation : FullAuditedAggregateRoot
{
    public Guid DeviceMerchantProfileId { get; set; }
    public Guid PaymentChannelId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime ActivationDate { get; set; } = DateTime.UtcNow;
    public DateTime? DeactivationDate { get; set; }
    public string? DeviceConfiguration { get; set; } // JSONB
    public DateTime? LastTransactionAt { get; set; }
    public int? TransactionCount { get; set; }
    public DateTime? LastHeartbeatAt { get; set; }
    public string? ActivatedBy { get; set; }
    
    // Navigation properties
    public virtual DeviceMerchantProfile DeviceMerchantProfile { get; set; } = null!;
    public virtual PaymentChannel PaymentChannel { get; set; } = null!;
}