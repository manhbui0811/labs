using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Lịch sử vị trí của thiết bị POS
/// </summary>
public class DeviceLocationHistory : FullAuditedAggregateRoot
{
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public double? AccuracyMeters { get; set; }
    public string? LocationSource { get; set; }
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
    
    // Khóa ngoại
    public Guid DeviceId { get; set; }

    // Navigation properties
    public virtual Device Device { get; set; } = null!;
}