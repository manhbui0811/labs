using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Mối quan hệ giữa một thiết bị POS và một Merchant Profile.
/// </summary>
public class DeviceMerchantProfile : FullAuditedAggregateRoot
{
    public Guid DeviceId { get; set; }
    public Guid MerchantProfileId { get; set; }
    public string? AppPackageName { get; set; }
    public string? AppVersion { get; set; }
    public string? AppStatus { get; set; }
    public string? Configuration { get; set; } // JSONB
    public DateTime? ActivatedAt { get; set; }
    public Guid? ActivatedBy { get; set; }
    public bool IsActive { get; set; } = true;
    
    // Navigation properties
    public virtual Device Device { get; set; } = null!;
    public virtual MerchantProfile MerchantProfile { get; set; } = null!;

}