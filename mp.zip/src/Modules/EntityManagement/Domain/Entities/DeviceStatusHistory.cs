using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Lịch sử thay đổi trạng thái của thiết bị POS
/// </summary>
public class DeviceStatusHistory : FullAuditedAggregateRoot
{
    public PosStatus? OldStatus { get; set; }
    public PosStatus NewStatus { get; set; }
    public int? BatteryLevel { get; set; }
    public string? NetworkType { get; set; }
    public string? AppVersion { get; set; }
    public string? StatusReason { get; set; }
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
    
    // Khóa ngoại
    public Guid DeviceId { get; set; }
    
    // Navigation properties
    public virtual Device Device { get; set; } = null!;
}