using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;
using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

public class Entity(Guid id) : FullAuditedAggregateRoot(id, null)
{
    public required string EntityCode { get; set; }
    public required string Name { get; set; }
    public string? ShortName { get; set; }
    public string? TaxCode { get; set; }
    public string? Website { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? WardCode { get; set; }
    public string? ProvinceCode { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;

    // Khóa ngoại
    public Guid? EntityStructureId { get; set; }
    public virtual EntityStructure? EntityStructure { get; set; }
    public Guid? BusinessCategoryId { get; set; }

    // Navigation properties
    
    public virtual ICollection<EntityRelationship> ParentRelationships { get; set; } = new List<EntityRelationship>();
    public virtual ICollection<EntityRelationship> ChildRelationships { get; set; } = new List<EntityRelationship>();
    public virtual ICollection<UserEntityMembership> Memberships { get; set; } = new List<UserEntityMembership>();
    public virtual ICollection<Branch> Branches { get; set; } = new List<Branch>();
    public virtual ICollection<MerchantProfile> MerchantProfiles { get; set; } = new List<MerchantProfile>();
    public virtual ICollection<Device> Devices { get; set; } = new List<Device>();
    public virtual ICollection<IotDevice> IotDevices { get; set; } = new List<IotDevice>();
    public virtual ICollection<Department> Departments { get; set; } = new List<Department>();
    public virtual ICollection<JobTitle> JobTitles { get; set; } = new List<JobTitle>();
}