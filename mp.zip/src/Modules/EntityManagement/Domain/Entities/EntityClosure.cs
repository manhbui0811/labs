using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;


/// <summary>
/// Lưu trữ cấu trúc phân cấp entity để truy vấn nhanh hơn.
/// </summary>
public class EntityClosure : FullAuditedAggregateRoot
{
    public Guid AncestorId { get; set; }
    public Guid DescendantId { get; set; }
    public int Depth { get; set; }
}