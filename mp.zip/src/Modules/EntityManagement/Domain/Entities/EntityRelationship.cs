using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Định nghĩa sự liên kết nghiệp vụ giữa hai Thực thể.
/// </summary>
public class EntityRelationship : FullAuditedAggregateRoot
{
    public Guid ParentEntityId { get; set; }
    public virtual Entity ParentEntity { get; set; } = null!;
    public Guid ChildEntityId { get; set; }
    public virtual Entity ChildEntity { get; set; } = null!;
    public RelationshipType RelationshipType { get; set; }
    public RequestStatus Status { get; set; } = RequestStatus.Approved;
    public string? RelationshipDetails { get; set; } // JSONB
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
}