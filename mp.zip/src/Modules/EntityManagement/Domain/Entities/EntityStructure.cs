using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

public class EntityStructure : FullAuditedAggregateRoot
{
    public string Name { get; set; }
    public Guid? ParentId { get; set; }
    public virtual EntityStructure? Parent { get; set; }
    
    public virtual EntityStructure? Child { get; set; }
    
    public virtual ICollection<Entity> Entities { get; set; } = new List<Entity>();
}