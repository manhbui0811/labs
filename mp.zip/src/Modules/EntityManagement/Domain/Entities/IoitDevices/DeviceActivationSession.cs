﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SHT.MerchantPortal.Modules.EntityManagement.Domain.Enums;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices
{
    public class DeviceActivationSession : FullAuditedAggregateRoot<Guid>
    {
        public Guid DeviceId { get; private set; }
        public string SessionCode { get; private set; } = default!;
        public ActivationStatus Status { get; private set; }
        public bool IsAuthorized { get; private set; }
        public bool IsCompleted { get; private set; }
        public DateTimeOffset ExpiresAt { get; private set; }
        public string? AuthorizationCode { get; private set; }
        public DateTimeOffset? AuthorizedAt { get; private set; }
        public DateTimeOffset? CompletedAt { get; private set; }
        public string? CompletionNotes { get; private set; }

        // Navigation properties
        public virtual IotDevice Device { get; set; } = default!;

        private DeviceActivationSession() { } // EF Core

        public static DeviceActivationSession Create(
            Guid deviceId,
            string sessionCode,
            TimeSpan expirationDuration)
        {
            return new DeviceActivationSession
            {
                Id = Guid.NewGuid(),
                DeviceId = deviceId,
                SessionCode = sessionCode,
                Status = ActivationStatus.Pending,
                IsAuthorized = false,
                IsCompleted = false,
                ExpiresAt = DateTimeOffset.UtcNow.Add(expirationDuration),
                CreatedAt = DateTimeOffset.UtcNow
            };
        }

        public void Authorize(string authorizationCode)
        {
            if (IsExpired())
                throw new InvalidOperationException("Cannot authorize expired session");

            if (IsCompleted)
                throw new InvalidOperationException("Cannot authorize completed session");

            IsAuthorized = true;
            AuthorizationCode = authorizationCode;
            AuthorizedAt = DateTimeOffset.UtcNow;
            Status = ActivationStatus.Authorized;
            UpdatedAt = DateTimeOffset.UtcNow;
        }

        public void Complete(string? notes = null)
        {
            if (!IsAuthorized)
                throw new InvalidOperationException("Cannot complete session that is not authorized");

            if (IsCompleted)
                throw new InvalidOperationException("Session is already completed");

            if (IsExpired())
                throw new InvalidOperationException("Cannot complete expired session");

            IsCompleted = true;
            CompletedAt = DateTimeOffset.UtcNow;
            CompletionNotes = notes;
            Status = ActivationStatus.Completed;
            UpdatedAt = DateTimeOffset.UtcNow;
        }

        public bool IsExpired()
        {
            return DateTimeOffset.UtcNow > ExpiresAt;
        }

        public bool CanBeCompleted()
        {
            return IsAuthorized && !IsCompleted && !IsExpired();
        }
    }
}
