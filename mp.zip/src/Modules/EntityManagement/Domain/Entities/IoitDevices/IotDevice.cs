// File: src/Modules/EntityManagement/SHT.MerchantPortal.Modules.EntityManagement.Domain/Entities/IotDevice.cs

using SHT.MerchantPortal.Modules.EntityManagement.Domain.Enums;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;

public class IotDevice : FullAuditedAggregateRoot<Guid>
{
    public Guid EntityId { get; private set; }
    public string SerialNumber { get; private set; } = default!;
    public string DeviceCode { get; private set; } = default!;
    public string? DeviceName { get; private set; }
    public string? DeviceModel { get; private set; }
    public string DeviceKind { get; private set; } = default!;
    public DeviceStatus Status { get; private set; }
    public Guid? FixedPosId { get; private set; }
    public Guid? PaymentChannelId { get; private set; } // Changed from MerchantProfileId
    public DateTimeOffset? LastSeen { get; private set; }
    public string? FirmwareVersion { get; private set; }
    public string? NetworkType { get; private set; }
    public Guid? ProviderId { get; private set; }
    public long Version { get; private set; }

    // Navigation properties
    public virtual PaymentChannel? PaymentChannel { get; set; }

    private IotDevice() { } // EF Core

    public static IotDevice Create(
        Guid entityId,
        string deviceCode,
        string serialNumber,
        string deviceKind,
        Guid? paymentChannelId = null)
    {
        return new IotDevice
        {
            Id = Guid.CreateVersion7(),
            DeviceCode = deviceCode,
            EntityId = entityId,
            SerialNumber = serialNumber,
            DeviceKind = deviceKind,
            PaymentChannelId = paymentChannelId,
            Status = DeviceStatus.Inactive,
            Version = 1,
            CreatedAt = DateTimeOffset.UtcNow
        };
    }

    public void UpdateInfo(
        string  deviceName,
        string deviceModel,
        string firmwareVersion,
        string networkType)
    {

        DeviceName = deviceName;
        DeviceModel = deviceModel;
        FirmwareVersion = firmwareVersion;
        NetworkType = networkType;
        Status = DeviceStatus.Inactive;
        Version = 1;
        CreatedAt = DateTimeOffset.UtcNow;

    }

    public void AssignToPaymentChannel(Guid paymentChannelId)
    {
        PaymentChannelId = paymentChannelId;
        UpdateVersion();
    }

    public void Activate()
    {
        Status = DeviceStatus.Active;
        LastSeen = DateTimeOffset.UtcNow;
        UpdateVersion();
    }

    public void UpdateFirmware(string firmwareVersion)
    {
        FirmwareVersion = firmwareVersion;
        UpdateVersion();
    }

    private void UpdateVersion()
    {
        Version++;
        UpdatedAt = DateTimeOffset.UtcNow;
    }
}


