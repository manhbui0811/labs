using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Quản lý các chức danh trong một entity.
/// </summary>

public class JobTitle : FullAuditedAggregateRoot
{
    public Guid EntityId { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public virtual Entity Entity { get; set; } = null!;
}