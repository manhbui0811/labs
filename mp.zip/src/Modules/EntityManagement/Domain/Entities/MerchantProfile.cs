using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

public class MerchantProfile : FullAuditedAggregateRoot
{
    /// <summary>
    /// Mã merchant từ ngân hàng
    /// </summary>
    public required string MerchantCode { get; set; }
    public required string MerchantName { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;

    // Khóa ngoại
    public Guid EntityId { get; set; }
    public Guid AcquiringBankId { get; set; }

    // Navigation properties
    public virtual Entity Entity { get; set; } = null!;
    public virtual ICollection<SettlementAccount> SettlementAccounts { get; set; } = new List<SettlementAccount>();
    public virtual ICollection<PaymentChannel> PaymentChannels { get; set; } = new List<PaymentChannel>();
    public virtual ICollection<DeviceMerchantProfile> DeviceMerchantProfiles { get; set; } = new List<DeviceMerchantProfile>();
    public virtual ICollection<IotDevice> IotDevices { get; set; } = new List<IotDevice>();
    public MerchantProfile() { } // EF Core

    public static MerchantProfile Create(
        string merchantCode,
        string merchantName,
        Guid entityId,
        Guid acquiringBankId)
    {
        return new MerchantProfile
        {
            Id = Guid.NewGuid(),
            MerchantCode = merchantCode,
            MerchantName = merchantName,
            EntityId = entityId,
            AcquiringBankId = acquiringBankId,
            Status = EntityStatus.Active,
            CreatedAt = DateTimeOffset.UtcNow
        };
    }
}