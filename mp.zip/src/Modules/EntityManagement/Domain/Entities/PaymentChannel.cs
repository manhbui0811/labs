using SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities.IoitDevices;
using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;


/// <summary>
/// Là một luồng có thể nhận thanh toán (máy POS, mã QR tĩnh...)
/// tại một Điểm bán
/// </summary>
public class PaymentChannel : FullAuditedAggregateRoot
{
    
    public required string ChannelType { get; set; }
    public required string TidCode { get; set; }
    public required string MidCode { get; set; }
    public string? ChannelName { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;

    // Khóa ngoại
    public Guid PosId { get; set; }
    public Guid? MerchantProfileId { get; set; }
    public Guid PointOfSaleId { get; set; }

    // Navigation properties
    public virtual PointOfSale PointOfSale { get; set; } = null!;
    public virtual MerchantProfile? MerchantProfile { get; set; } = null!;
    
    public virtual ICollection<Device> Devices { get; set; } = new List<Device>();
    public virtual ICollection<IotDevice> IotDevices { get; set; } = new List<IotDevice>();

    public PaymentChannel() { } // EF Core

    public static PaymentChannel Create(
        string channelType,
        string tidCode,
        string midCode,
        Guid posId,
        Guid pointOfSaleId,
        Guid? merchantProfileId = null,
        string? channelName = null)
    {
        return new PaymentChannel
        {
            Id = Guid.NewGuid(),
            ChannelType = channelType,
            TidCode = tidCode,
            MidCode = midCode,
            PosId = posId,
            PointOfSaleId = pointOfSaleId,
            MerchantProfileId = merchantProfileId,
            ChannelName = channelName,
            Status = EntityStatus.Active,
            CreatedAt = DateTimeOffset.UtcNow
        };
    }
}