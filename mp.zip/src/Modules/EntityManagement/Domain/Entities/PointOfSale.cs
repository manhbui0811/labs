using SHT.MerchantPortal.Shared.Kernel.Common;
using SHT.MerchantPortal.Shared.Kernel.Utils;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

/// <summary>
/// Một điểm bán hàng (Point of Sale) tại một chi nhánh
/// </summary>
public class PointOfSale : FullAuditedAggregateRoot
{
    public required string PosCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;

    // Khóa ngoại
    public Guid BranchId { get; set; }

    // Navigation properties
    public virtual Branch Branch { get; set; } = null!;
    public virtual ICollection<PaymentChannel> PaymentChannels { get; set; } = new List<PaymentChannel>();
}