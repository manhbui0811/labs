using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;


/// <summary>
/// Lưu thông tin tài khoản ngân hàng thực tế mà tiền sẽ được chuyển về,
/// liên kết với một Hồ sơ Merchant cụ thể
/// </summary>
public class SettlementAccount : FullAuditedAggregateRoot
{
    
    public required string AccountNumber { get; set; }
    public required string AccountName { get; set; }
    
    public required string BankName { get; set; }
    
    public string? BankCode { get; set; }
    
    public bool IsDefault { get; set; } = false;

    // Khóa ngoại
    public Guid MerchantProfileId { get; set; }

    // Navigation property
    public virtual MerchantProfile MerchantProfile { get; set; } = null!;
}