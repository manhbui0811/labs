using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

public class UserEntityMembership : FullAuditedAggregateRoot
{
    public string? JobTitle { get; set; }
    public UserStatus Status { get; set; } = UserStatus.Active;

    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;

    // Khóa ngoại
    public Guid UserId { get; set; }
    public Guid EntityId { get; set; }
    public Guid? DepartmentId { get; set; }

    // Navigation properties
    public virtual Entity Entity { get; set; } = null!;
    public virtual ICollection<UserEntityMembershipRole> Roles { get; set; } = new List<UserEntityMembershipRole>();
}