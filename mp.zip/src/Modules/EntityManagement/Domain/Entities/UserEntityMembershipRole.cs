using SHT.MerchantPortal.Shared.Kernel.Common;

namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Entities;

public class UserEntityMembershipRole : FullAuditedAggregateRoot
{
    // Khóa ngoại & Khóa chính phức hợp
    public Guid MembershipId { get; set; }
    public Guid RoleId { get; set; }
    public required string RoleType { get; set;}

    public Guid? GrantedBy { get; set; }
    public DateTime GrantedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public virtual UserEntityMembership Membership { get; set; } = null!;
}