namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Enums;

public enum ActivationStatus
{
    Pending = 0,
    Authorized = 1,
    Completed = 2,
    Expired = 3,
    Cancelled = 4
}