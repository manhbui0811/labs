namespace SHT.MerchantPortal.Modules.EntityManagement.Domain.Enums;

public enum DeviceStatus
{
    Inactive,
    Active,
    Online,
    Offline,
    Error,
    Maintenance,
    Retired
}